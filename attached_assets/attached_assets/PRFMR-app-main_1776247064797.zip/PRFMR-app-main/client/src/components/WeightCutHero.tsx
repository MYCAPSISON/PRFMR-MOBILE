import { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import { Target, CalendarDays, TrendingDown, TrendingUp, Pencil, Trash2, CheckCircle2, Flame, Scale, ChevronRight } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWeightsRange } from "@/hooks/use-logs";
import { fireCelebration } from "@/lib/celebration";

type WeighInTiming = "same_day" | "day_before";

interface WeightCutData {
  planId: number;
  currentWeight: number;
  targetWeight: number;
  fightDate: string;
  daysUntil: number;
  weeksUntil: number;
  totalToLose: number;
  fatLossRequired: number;
  tempCut: number;
  tempCutDisplayed: number;
  weeklyRate: number;
  weeklyRatePct: number;
  dayMinus4Target: number | null;
  status: string;
  statusLabel: string;
  weeklyTargets: Array<{ week: number; targetWeight: number }>;
  suggestedDeficitKcal: number;
  bodyweightSource?: string;
  weighInTiming?: WeighInTiming;
  manualTempReductionKg?: number | null;
}

const statusColors: Record<string, string> = {
  on_track: "text-green-400 border-green-400/30 bg-green-400/10",
  aggressive: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  very_aggressive: "text-orange-400 border-orange-400/30 bg-orange-400/10",
  unrealistic: "text-red-400 border-red-400/30 bg-red-400/10",
  complete: "text-green-400 border-green-400/30 bg-green-400/10",
  past_date: "text-muted-foreground border-border bg-secondary/20",
};

function getPaceInfo(weeklyRatePct: number): {
  label: string;
  color: string;
  note: string | null;
} {
  if (weeklyRatePct < 0.5) {
    return { label: "Easy pace", color: "text-muted-foreground border-border/40 bg-secondary/20", note: null };
  }
  if (weeklyRatePct <= 0.75) {
    return { label: "Moderate pace", color: "text-primary border-primary/30 bg-primary/10", note: null };
  }
  return {
    label: "Aggressive pace",
    color: "text-orange-400 border-orange-400/30 bg-orange-400/10",
    note: "Quite fast — consider extending timeline",
  };
}

function getTrendMessage(
  weights: { date: string; weight: number }[],
  status: string
): { message: string; isUp: boolean } {
  if (weights.length < 2) return { message: "Trend forming — keep logging daily", isUp: false };

  const sorted = [...weights].sort((a, b) => a.date.localeCompare(b.date));
  const first = sorted[0].weight;
  const last = sorted[sorted.length - 1].weight;
  const change = last - first;

  if (status === "complete") return { message: "At fight weight — well done", isUp: false };
  if (status === "past_date") return { message: "Fight date passed", isUp: false };

  if (change < -0.2) return { message: "On trend — moving in the right direction", isUp: false };
  if (change >= -0.2 && change <= 0.3) return { message: "Fluctuations are normal — trends take time", isUp: false };
  return { message: "Weight naturally fluctuates — stay consistent", isUp: true };
}

function getConsistencyLabel(count: number): { label: string; color: string } | null {
  if (count >= 6) return { label: "Great momentum", color: "text-green-400 border-green-400/30 bg-green-400/10" };
  if (count >= 4) return { label: "Building rhythm", color: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10" };
  if (count >= 2) return { label: "Getting started", color: "text-muted-foreground border-border/40 bg-secondary/20" };
  return null;
}

const TIMING_OPTIONS: { value: WeighInTiming; label: string; sub: string }[] = [
  { value: "same_day", label: "Same day", sub: "Weigh in on fight day" },
  { value: "day_before", label: "Day before", sub: "Weigh in the evening prior" },
];

export function WeightCutHero() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<"create" | "edit">("create");
  const [formData, setFormData] = useState({
    currentWeight: "",
    targetWeight: "",
    fightDate: "",
    weighInTiming: "same_day" as WeighInTiming,
    manualTempReductionKg: "",
  });
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [weightInput, setWeightInput] = useState("");
  const [showWeightInput, setShowWeightInput] = useState(false);
  const [justLogged, setJustLogged] = useState(false);
  const submittedWeightRef = useRef<number | null>(null);
  const weightWentUpRef = useRef(false);
  const [fcModal, setFcModal] = useState<{ title: string; body?: string; isUp?: boolean } | null>(null);
  const [fcModalQueue, setFcModalQueue] = useState<Array<{ title: string; body?: string; isUp?: boolean }>>([]);
  const fcModalRef = useRef<{ title: string; body?: string; isUp?: boolean } | null>(null);
  const [breakdownDialogOpen, setBreakdownDialogOpen] = useState(false);

  // Keep ref in sync so showFcModal can check without stale closure issues
  useEffect(() => { fcModalRef.current = fcModal; }, [fcModal]);

  const dismissFcModal = () => setFcModal(null);

  // When a modal closes, advance the queue after the exit animation settles
  useEffect(() => {
    if (fcModal !== null) return;
    const t = setTimeout(() => {
      setFcModalQueue(q => {
        if (q.length === 0) return q;
        const [next, ...rest] = q;
        setFcModal(next);
        return rest;
      });
    }, 350);
    return () => clearTimeout(t);
  }, [fcModal]);

  // If a modal is already showing, queue the new one; otherwise show immediately
  const showFcModal = (title: string, body?: string, isUp?: boolean) => {
    if (fcModalRef.current === null) {
      setFcModal({ title, body, isUp });
    } else {
      setFcModalQueue(q => [...q, { title, body, isUp }]);
    }
  };

  // Auto-dismiss after 4500ms
  useEffect(() => {
    if (!fcModal) return;
    const t = setTimeout(() => dismissFcModal(), 4500);
    return () => clearTimeout(t);
  }, [fcModal]);

  const today = format(new Date(), "yyyy-MM-dd");
  const sevenDayStart = format(subDays(new Date(), 6), "yyyy-MM-dd");

  const { data: plan, isLoading } = useQuery<WeightCutData | null>({
    queryKey: ["/api/me/weight-cut"],
  });

  const { data: recentWeights = [] } = useWeightsRange(sevenDayStart, today);

  const daysWithWeight = new Set((recentWeights as { date: string; weight: number }[]).map((w) => w.date));
  const consistencyCount = daysWithWeight.size;
  const weightLoggedToday = daysWithWeight.has(today);

  const prevCountRef = useRef<number | null>(null);
  useEffect(() => {
    if (prevCountRef.current === null) {
      prevCountRef.current = consistencyCount;
      return;
    }
    const prev = prevCountRef.current;
    prevCountRef.current = consistencyCount;

    if (!weightWentUpRef.current) {
      if (prev < 3 && consistencyCount >= 3) {
        showFcModal("Building rhythm 🔥", "3 weigh-ins this week — consistency is how the trend forms.");
        fireCelebration("🔥");
      } else if (prev < 5 && consistencyCount >= 5) {
        showFcModal("Great momentum 🥊", "5 of the last 7 days logged — you're building a real picture.");
        fireCelebration("🥊");
      } else if (prev < 6 && consistencyCount >= 6) {
        showFcModal("Excellent 💪", "6 of 7 days logged this week — elite level consistency.");
        fireCelebration("💪");
      }
    }
  }, [consistencyCount]);

  const weightMutation = useMutation({
    mutationFn: async (data: { date: string; weight: number }) =>
      apiRequest("POST", "/api/weights", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      setShowWeightInput(false);
      setWeightInput("");
      setJustLogged(true);
      setTimeout(() => setJustLogged(false), 2500);

      // Check if the new weight is higher than the most recent prior reading
      const newWeight = submittedWeightRef.current;
      const priorWeights = (recentWeights as { date: string; weight: number }[])
        .filter(w => w.date < today)
        .sort((a, b) => b.date.localeCompare(a.date));
      const mostRecent = priorWeights[0];

      if (newWeight !== null && mostRecent && newWeight > mostRecent.weight) {
        weightWentUpRef.current = true;
        showFcModal(
          "Weight naturally fluctuates",
          "Day-to-day shifts are normal. Focus on the weekly trend.",
          true
        );
      } else {
        weightWentUpRef.current = false;
        showFcModal("On trend ↓", "Moving in the right direction.");
      }

      submittedWeightRef.current = null;
    },
  });

  const handleWeightSubmit = () => {
    const w = parseFloat(weightInput);
    if (isNaN(w) || w <= 0) return;
    submittedWeightRef.current = w;
    weightMutation.mutate({ date: today, weight: w });
  };

  const createMutation = useMutation({
    mutationFn: async (data: {
      currentWeight: number;
      targetWeight: number;
      fightDate: string;
      weighInTiming: WeighInTiming;
      manualTempReductionKg?: number | null;
    }) => apiRequest("POST", "/api/me/weight-cut", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      setDialogOpen(false);
      if (dialogMode === "edit") {
        toast({ title: "Fight camp plan updated 🎯" });
      } else {
        toast({ title: "Fight camp plan created 🎯" });
        fireCelebration("🎯");
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => apiRequest("DELETE", "/api/me/weight-cut"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      toast({ title: "Weight cut plan removed" });
    },
  });

  const handleSubmit = () => {
    const cw = parseFloat(formData.currentWeight);
    const tw = parseFloat(formData.targetWeight);
    if (isNaN(cw) || isNaN(tw) || !formData.fightDate) return;
    const manualKg = formData.manualTempReductionKg ? parseFloat(formData.manualTempReductionKg) : null;
    createMutation.mutate({
      currentWeight: cw,
      targetWeight: tw,
      fightDate: formData.fightDate,
      weighInTiming: formData.weighInTiming,
      manualTempReductionKg: (!manualKg || isNaN(manualKg)) ? null : manualKg,
    });
  };

  const openCreate = () => {
    setDialogMode("create");
    setShowAdvanced(false);
    setFormData({ currentWeight: "", targetWeight: "", fightDate: "", weighInTiming: "same_day", manualTempReductionKg: "" });
    setDialogOpen(true);
  };

  const openEdit = () => {
    if (!plan) return;
    setDialogMode("edit");
    const hasManual = typeof plan.manualTempReductionKg === "number" && plan.manualTempReductionKg > 0;
    setShowAdvanced(hasManual);
    setFormData({
      currentWeight: plan.currentWeight.toString(),
      targetWeight: plan.targetWeight.toString(),
      fightDate: plan.fightDate,
      weighInTiming: plan.weighInTiming || "same_day",
      manualTempReductionKg: hasManual ? (plan.manualTempReductionKg ?? "").toString() : "",
    });
    setDialogOpen(true);
  };

  const formDialog = (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">{dialogMode === "edit" ? "Edit Fight Camp Plan" : "Set Up Fight Camp Plan"}</DialogTitle>
          <DialogDescription>
            {dialogMode === "edit"
              ? "Update your target or timeline — the plan recalculates automatically."
              : "Plan a gradual weight cut targeting 0.5–1.0% bodyweight per week."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Current Weight (kg)</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.currentWeight}
              onChange={(e) => setFormData({ ...formData, currentWeight: e.target.value })}
              data-testid="input-cut-current-weight"
            />
          </div>
          <div>
            <Label>Fight Weight (kg)</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.targetWeight}
              onChange={(e) => setFormData({ ...formData, targetWeight: e.target.value })}
              data-testid="input-cut-target-weight"
            />
          </div>
          <div>
            <Label>Fight Date</Label>
            <Input
              type="date"
              value={formData.fightDate}
              onChange={(e) => setFormData({ ...formData, fightDate: e.target.value })}
              data-testid="input-cut-fight-date"
            />
          </div>

          <div>
            <Label className="mb-2 block">Weigh-In Timing</Label>
            <div className="grid grid-cols-2 gap-2" data-testid="group-weigh-in-timing">
              {TIMING_OPTIONS.map((opt) => {
                const active = formData.weighInTiming === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, weighInTiming: opt.value })}
                    data-testid={`button-timing-${opt.value}`}
                    className={`rounded-lg border p-3 text-left transition-colors ${
                      active
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border/40 hover:bg-secondary/30 text-muted-foreground"
                    }`}
                  >
                    <p className={`text-sm font-medium ${active ? "text-foreground" : ""}`}>{opt.label}</p>
                    <p className="text-[11px] text-muted-foreground">{opt.sub}</p>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-muted-foreground mt-2">
              {formData.weighInTiming === "day_before"
                ? "Day-before timing: a small additional buffer is factored in."
                : "Same-day: plan targets fight weight by fight week."}
            </p>
          </div>

          <div className="border-t border-border/30 pt-3">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              data-testid="button-toggle-advanced-cut"
              className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
            >
              <span>{showAdvanced ? "▲" : "▼"}</span>
              <span>Advanced options</span>
            </button>
            {showAdvanced && (
              <div className="mt-3 space-y-1.5">
                <Label className="text-xs">Manual temp. reduction override (kg)</Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  max="10"
                  placeholder="Leave blank to use automatic estimate"
                  value={formData.manualTempReductionKg}
                  onChange={(e) => setFormData({ ...formData, manualTempReductionKg: e.target.value })}
                  data-testid="input-manual-temp-reduction"
                />
                <p className="text-[10px] text-muted-foreground">
                  Overrides the automatic water-weight estimate (2–6% BW) with your own value. Leave blank to keep automatic calculation. This app does not provide acute weight-cut guidance.
                </p>
              </div>
            )}
          </div>

          <Button
            onClick={handleSubmit}
            disabled={createMutation.isPending || !formData.currentWeight || !formData.targetWeight || !formData.fightDate}
            className="w-full"
            data-testid="button-submit-cut-plan"
          >
            {dialogMode === "edit" ? "Update Plan" : "Start Camp Plan"}
          </Button>
          <p className="text-[10px] text-muted-foreground text-center">
            Educational tool only — not medical or nutritional advice.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );

  if (isLoading) {
    return (
      <Card data-testid="card-weight-cut-hero">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-secondary rounded w-1/3" />
            <div className="h-8 bg-secondary rounded w-1/2" />
            <div className="h-4 bg-secondary rounded w-3/4" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!plan) {
    return (
      <>
        <Card data-testid="card-weight-cut-hero-empty">
          <CardContent className="p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                <h3 className="text-sm font-display font-semibold">Fight Camp</h3>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Set a fight date to start your camp plan — track your cut and stay on pace.
            </p>
            <Button size="sm" onClick={openCreate} data-testid="button-create-cut-plan">
              Set a fight date
            </Button>
          </CardContent>
        </Card>
        {formDialog}
      </>
    );
  }

  const statusColor = statusColors[plan.status] || statusColors.on_track;
  const trend = getTrendMessage(recentWeights as { date: string; weight: number }[], plan.status);
  const consistencyBadge = getConsistencyLabel(consistencyCount);
  const pace = getPaceInfo(plan.weeklyRatePct);

  const daysText = plan.daysUntil === 1 ? "1 day" : `${plan.daysUntil} days`;

  return (
    <>
      <Card data-testid="card-weight-cut-hero" className="border-border/50">
        <CardContent className="p-5 space-y-4">

          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-display font-semibold">Fight Camp</h3>
            </div>
            <div className="flex items-center gap-1.5">
              <Badge className={`text-xs font-semibold ${statusColor}`} data-testid="badge-cut-status">
                {plan.statusLabel}
              </Badge>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={openEdit} data-testid="button-edit-cut-plan">
                <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
                data-testid="button-delete-cut-plan"
              >
                <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
            </div>
          </div>

          {/* Fight countdown — hero element */}
          <div className="flex items-center gap-2 py-1" data-testid="text-fight-countdown">
            <CalendarDays className="h-5 w-5 text-primary shrink-0" />
            <span className="text-3xl font-extrabold tracking-tight">{daysText}</span>
            <span className="text-sm font-medium text-muted-foreground">to fight night</span>
          </div>

          {/* Weight log CTA — first tappable action */}
          {!weightLoggedToday && !showWeightInput && (
            <button
              onClick={() => setShowWeightInput(true)}
              className="flex items-center gap-3 w-full p-3 rounded-lg border border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors text-left"
              data-testid="button-prompt-weight-hero"
            >
              <Scale className="h-4 w-4 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">Log today's weight</p>
                <p className="text-xs text-muted-foreground">Updates your cut trend</p>
              </div>
              <span className="text-xs text-primary font-medium">Tap →</span>
            </button>
          )}

          {!weightLoggedToday && showWeightInput && (
            <div className="space-y-2 p-3 rounded-lg border border-primary/30 bg-primary/5" data-testid="hero-weight-input-form">
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-primary" />
                <Label className="text-sm font-medium">Morning weight (kg)</Label>
              </div>
              <Input
                type="number"
                step="0.1"
                min="20"
                max="300"
                placeholder="e.g., 72.4"
                value={weightInput}
                onChange={(e) => setWeightInput(e.target.value)}
                autoFocus
                data-testid="input-hero-weight"
                onKeyDown={(e) => e.key === "Enter" && handleWeightSubmit()}
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={handleWeightSubmit}
                  disabled={weightMutation.isPending || !weightInput}
                  data-testid="button-submit-hero-weight"
                >
                  {weightMutation.isPending ? "Saving…" : "Save"}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setShowWeightInput(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Progress */}
          <div className="grid grid-cols-3 gap-3 text-center" data-testid="section-cut-progress">
            <div>
              <p
                className={`text-2xl font-extrabold font-mono tracking-tight transition-all duration-300 ${justLogged ? "text-green-400 scale-105" : ""}`}
                data-testid="text-cut-current"
              >
                {plan.currentWeight}
              </p>
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Current kg</p>
            </div>
            <div className="flex flex-col items-center justify-center">
              <TrendingDown className="h-4 w-4 text-primary mb-1" />
              <p className="text-sm font-bold" data-testid="text-cut-remaining">{plan.totalToLose} kg to go</p>
              <p className="text-[10px] text-muted-foreground">{plan.weeklyRate} kg/wk fat loss</p>
            </div>
            <div>
              <p className="text-2xl font-extrabold font-mono tracking-tight" data-testid="text-cut-target">{plan.targetWeight}</p>
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Fight weight</p>
            </div>
          </div>

          {/* Fat loss breakdown — tap to open */}
          <button
            onClick={() => setBreakdownDialogOpen(true)}
            className="w-full border-t border-border/30 pt-3 flex items-center justify-between group"
            data-testid="button-open-breakdown"
          >
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={`text-[10px] font-semibold ${pace.color}`} data-testid="badge-pace">
                {pace.label}
              </Badge>
              {pace.note && (
                <span className="text-[10px] text-orange-400/70">{pace.note}</span>
              )}
            </div>
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50 group-hover:text-muted-foreground transition-colors" />
          </button>

          {/* Week target */}
          {plan.weeklyTargets.length > 0 && (
            <div className="border-t border-border/30 pt-3">
              <p className="text-xs text-muted-foreground">
                <span className="font-semibold text-foreground/80 uppercase tracking-wide text-[10px]">This week's target</span>
                <span
                  className={`ml-2 text-sm font-bold transition-colors duration-300 ${justLogged ? "text-green-400" : "text-foreground"}`}
                  data-testid="text-week-target"
                >
                  {plan.weeklyTargets[0].targetWeight} kg
                </span>
                {plan.suggestedDeficitKcal > 0 && (
                  <span className="text-muted-foreground"> · ~{plan.suggestedDeficitKcal} kcal deficit/day</span>
                )}
              </p>
            </div>
          )}

          {/* Trend + consistency */}
          <div className="space-y-2 border-t border-border/30 pt-3">
            <div
              className={`flex items-center gap-2 font-semibold transition-colors duration-300 ${
                justLogged
                  ? "text-green-400 text-sm"
                  : trend.isUp
                  ? "text-amber-400 text-base"
                  : "text-foreground/70 text-xs"
              }`}
              data-testid="text-trend-message"
            >
              {trend.isUp
                ? <TrendingUp className="h-5 w-5 shrink-0 text-amber-400" />
                : <Flame className="h-3.5 w-3.5 shrink-0 text-primary/60" />
              }
              <span>{trend.message}</span>
            </div>

            <div className="flex items-center justify-between">
              <p
                className={`text-xs transition-colors duration-300 ${justLogged ? "text-green-400/80 font-semibold" : "text-muted-foreground"}`}
                data-testid="text-consistency"
              >
                Weight logged: <span className={`font-semibold ${justLogged ? "text-green-400" : "text-foreground"}`}>{consistencyCount} of last 7 days</span>
              </p>
              {consistencyBadge && (
                <Badge variant="outline" className={`text-[10px] font-semibold ${consistencyBadge.color}`} data-testid="badge-consistency">
                  {consistencyBadge.label}
                </Badge>
              )}
            </div>

          </div>

          <p className="text-[10px] text-muted-foreground/50 italic leading-relaxed">
            This planner focuses on gradual fat loss. Some athletes temporarily reduce body weight before weigh-ins. Weight naturally fluctuates day to day — focus on trends.
          </p>
        </CardContent>
      </Card>
      {formDialog}

      {/* Fat loss breakdown dialog */}
      {plan && (
        <Dialog open={breakdownDialogOpen} onOpenChange={setBreakdownDialogOpen}>
          <DialogContent className="max-w-sm mx-4">
            <DialogHeader>
              <DialogTitle className="font-display">Plan breakdown</DialogTitle>
              <DialogDescription>
                How your weight cut is structured.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 pt-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Fat loss target</span>
                <span className="font-semibold text-foreground" data-testid="text-fat-loss-required">{plan.fatLossRequired} kg</span>
              </div>
              {plan.tempCutDisplayed > 0 ? (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Temporary reduction assumed</span>
                  <span className="font-semibold text-muted-foreground" data-testid="text-temp-cut">~{plan.tempCutDisplayed} kg</span>
                </div>
              ) : plan.tempCut > 0 ? (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Estimated temp. reduction (fight week)</span>
                  <span className="font-semibold text-muted-foreground" data-testid="text-temp-cut">~{plan.tempCut} kg</span>
                </div>
              ) : null}
              {plan.dayMinus4Target && plan.daysUntil <= 10 && (
                <div className="flex items-center justify-between text-sm text-yellow-400/80">
                  <span>Target by D−4</span>
                  <span className="font-semibold" data-testid="text-day-minus4-target">≤ {plan.dayMinus4Target} kg</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm pt-1 border-t border-border/30">
                <span className="text-muted-foreground">Fat-loss pace</span>
                <div className="flex flex-col items-end gap-0.5">
                  <Badge variant="outline" className={`text-[10px] font-semibold ${pace.color}`}>
                    {pace.label}
                  </Badge>
                  {pace.note && (
                    <span className="text-[10px] text-orange-400/80 text-right" data-testid="text-pace-note">{pace.note}</span>
                  )}
                </div>
              </div>
              {plan.suggestedDeficitKcal > 0 && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Daily deficit target</span>
                  <span className="font-semibold text-foreground">~{plan.suggestedDeficitKcal} kcal</span>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {createPortal(
        <AnimatePresence>
          {fcModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/65"
              onClick={() => dismissFcModal()}
              data-testid="fight-camp-notice-overlay"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 8 }}
                transition={{ duration: 0.26, delay: 0.06 }}
                className={`mx-6 max-w-sm w-full bg-card rounded-2xl p-7 shadow-2xl border ${fcModal.isUp ? "border-amber-400/25" : "border-primary/20"}`}
                onClick={(e) => e.stopPropagation()}
                data-testid="fight-camp-notice-card"
              >
                <div className="flex items-start gap-3">
                  {fcModal.isUp
                    ? <TrendingUp className="h-6 w-6 text-amber-400 shrink-0 mt-0.5" />
                    : <Flame className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  }
                  <div>
                    <p className={`text-lg font-bold ${fcModal.isUp ? "text-amber-400" : "text-foreground"}`}>
                      {fcModal.title}
                    </p>
                    {fcModal.body && (
                      <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{fcModal.body}</p>
                    )}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground/40 mt-6 text-center">Tap anywhere to dismiss</p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </>
  );
}
