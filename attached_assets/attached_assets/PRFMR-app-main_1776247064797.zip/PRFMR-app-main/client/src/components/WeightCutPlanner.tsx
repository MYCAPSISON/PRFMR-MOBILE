import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Target, ChevronDown, Trash2, Pencil, CalendarDays, TrendingDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WeightCutData {
  planId: number;
  currentWeight: number;
  targetWeight: number;
  fightDate: string;
  daysUntil: number;
  weeksUntil: number;
  totalToLose: number;
  weeklyRate: number;
  weeklyRatePct: number;
  status: string;
  statusLabel: string;
  weeklyTargets: Array<{ week: number; targetWeight: number }>;
  suggestedDeficitKcal: number;
  bodyweightSource?: string;
}

const statusColors: Record<string, string> = {
  on_track: "text-green-400 border-green-400/30 bg-green-400/10",
  aggressive: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  very_aggressive: "text-orange-400 border-orange-400/30 bg-orange-400/10",
  unrealistic: "text-red-400 border-red-400/30 bg-red-400/10",
  complete: "text-green-400 border-green-400/30 bg-green-400/10",
  past_date: "text-muted-foreground border-border bg-secondary/20",
};

export function WeightCutPlanner({ userWeight }: { userWeight?: number }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<"create" | "edit">("create");
  const [trendsOpen, setTrendsOpen] = useState(false);
  const [formData, setFormData] = useState({
    currentWeight: "",
    targetWeight: "",
    fightDate: "",
  });

  const { data: plan, isLoading } = useQuery<WeightCutData | null>({
    queryKey: ["/api/me/weight-cut"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { currentWeight: number; targetWeight: number; fightDate: string }) => {
      return apiRequest("POST", "/api/me/weight-cut", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      setDialogOpen(false);
      toast({ title: dialogMode === "edit" ? "Plan updated" : "Weight cut plan created" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", "/api/me/weight-cut");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      toast({ title: "Weight cut plan removed" });
    },
  });

  const handleSubmit = () => {
    const cw = parseFloat(formData.currentWeight);
    const tw = parseFloat(formData.targetWeight);
    if (isNaN(cw) || isNaN(tw) || !formData.fightDate) return;
    createMutation.mutate({ currentWeight: cw, targetWeight: tw, fightDate: formData.fightDate });
  };

  const openCreateDialog = () => {
    setDialogMode("create");
    setFormData({
      currentWeight: userWeight?.toString() || "",
      targetWeight: "",
      fightDate: "",
    });
    setDialogOpen(true);
  };

  const openEditDialog = () => {
    if (!plan) return;
    setDialogMode("edit");
    setFormData({
      currentWeight: plan.currentWeight.toString(),
      targetWeight: plan.targetWeight.toString(),
      fightDate: plan.fightDate,
    });
    setDialogOpen(true);
  };

  if (isLoading) return null;

  const dialogTitle = dialogMode === "edit" ? "Edit Weight Cut Plan" : "Weight Cut Planner";
  const dialogDesc = dialogMode === "edit"
    ? "Update your target or timeline. The plan recalculates automatically."
    : "Set up a gradual fat-loss plan. This targets 0.5–1.0% bodyweight per week.";

  const formDialog = (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">{dialogTitle}</DialogTitle>
          <DialogDescription>{dialogDesc}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Current Weight (kg)</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.currentWeight}
              onChange={(e) => setFormData({ ...formData, currentWeight: e.target.value })}
              data-testid="input-cut-current-weight"
            />
          </div>
          <div>
            <Label>Target Weight (kg)</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.targetWeight}
              onChange={(e) => setFormData({ ...formData, targetWeight: e.target.value })}
              data-testid="input-cut-target-weight"
            />
          </div>
          <div>
            <Label>Fight Date</Label>
            <Input
              type="date"
              value={formData.fightDate}
              onChange={(e) => setFormData({ ...formData, fightDate: e.target.value })}
              data-testid="input-cut-fight-date"
            />
          </div>
          <Button
            onClick={handleSubmit}
            disabled={createMutation.isPending || !formData.currentWeight || !formData.targetWeight || !formData.fightDate}
            className="w-full"
            data-testid="button-submit-cut-plan"
          >
            {dialogMode === "edit" ? "Update Plan" : "Create Plan"}
          </Button>
          <p className="text-[10px] text-muted-foreground text-center">
            Educational tool only — not medical or nutritional advice.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );

  if (!plan) {
    return (
      <>
        <Card data-testid="card-weight-cut-empty">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                <h3 className="text-sm font-semibold">Weight Cut Planner</h3>
              </div>
              <Button size="sm" variant="outline" onClick={openCreateDialog} data-testid="button-create-cut-plan">
                Set Up
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Plan a gradual, safe weight cut for your next fight.
            </p>
          </CardContent>
        </Card>
        {formDialog}
      </>
    );
  }

  const statusColor = statusColors[plan.status] || statusColors.on_track;

  return (
    <>
      <Card data-testid="card-weight-cut">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold">Weight Cut</h3>
            </div>
            <div className="flex items-center gap-1">
              <Badge className={`text-xs ${statusColor}`} data-testid="badge-cut-status">
                {plan.statusLabel}
              </Badge>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={openEditDialog}
                data-testid="button-edit-cut-plan"
              >
                <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => deleteMutation.mutate()}
                data-testid="button-delete-cut-plan"
              >
                <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-lg font-bold" data-testid="text-cut-current">{plan.currentWeight}</p>
              <p className="text-[10px] text-muted-foreground">Current kg</p>
            </div>
            <div>
              <TrendingDown className="h-4 w-4 mx-auto text-muted-foreground" />
              <p className="text-[10px] text-muted-foreground mt-1">{plan.totalToLose} kg to lose</p>
            </div>
            <div>
              <p className="text-lg font-bold" data-testid="text-cut-target">{plan.targetWeight}</p>
              <p className="text-[10px] text-muted-foreground">Target kg</p>
            </div>
          </div>

          <div className="flex justify-between text-xs text-muted-foreground border-t border-border/30 pt-2">
            <div className="flex items-center gap-1">
              <CalendarDays className="h-3 w-3" />
              <span>{plan.weeksUntil} weeks ({plan.daysUntil} days)</span>
            </div>
            <span>{plan.weeklyRate} kg/wk ({plan.weeklyRatePct}%)</span>
          </div>

          {plan.suggestedDeficitKcal > 0 && (
            <p className="text-xs text-muted-foreground">
              Suggested daily deficit: ~{plan.suggestedDeficitKcal} kcal
            </p>
          )}

          {plan.weeklyTargets.length > 0 && (
            <Collapsible open={trendsOpen} onOpenChange={setTrendsOpen}>
              <CollapsibleTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors" data-testid="button-cut-weekly-trend">
                <ChevronDown className={`h-3.5 w-3.5 transition-transform ${trendsOpen ? "rotate-180" : ""}`} />
                Weekly targets
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-2">
                <div className="space-y-1">
                  {plan.weeklyTargets.map((t) => (
                    <div key={t.week} className="flex justify-between text-xs text-muted-foreground">
                      <span>Week {t.week}</span>
                      <span className="font-mono">{t.targetWeight} kg</span>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-2 italic">
                  Gradual fat-loss targets only — not medical advice.
                </p>
              </CollapsibleContent>
            </Collapsible>
          )}
        </CardContent>
      </Card>
      {formDialog}
    </>
  );
}

export function WeightCutSummaryCard({ userWeight }: { userWeight?: number }) {
  const { data: plan } = useQuery<WeightCutData | null>({
    queryKey: ["/api/me/weight-cut"],
  });

  if (!plan) return null;

  const statusColor = statusColors[plan.status] || statusColors.on_track;

  return (
    <Card className="border-border/30" data-testid="card-weight-cut-summary">
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Target className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs font-medium">Weight Cut</span>
          </div>
          <Badge className={`text-[10px] ${statusColor}`}>
            {plan.weeksUntil}w — {plan.weeklyRate} kg/wk
          </Badge>
        </div>
        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>{plan.currentWeight} → {plan.targetWeight} kg</span>
          <span>{plan.daysUntil} days left</span>
        </div>
      </CardContent>
    </Card>
  );
}
