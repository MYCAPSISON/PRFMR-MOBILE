import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useUser } from "@/hooks/use-user";
import { useEffect } from "react";

function isOnboardingComplete(profile: any): boolean {
  if (!profile) return false;
  return (
    profile.targetCalories != null &&
    profile.age != null &&
    profile.gender != null &&
    profile.height != null &&
    profile.currentWeight != null &&
    profile.activityLevel != null
  );
}

const DEV = import.meta.env.DEV;
function routeLog(guard: string, msg: string) {
  if (DEV) console.log(`[route][${guard}] ${msg}`);
}

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="animate-pulse text-muted-foreground">Loading...</div>
    </div>
  );
}

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireOnboarding?: boolean;
}

export function ProtectedRoute({ children, requireOnboarding = true }: ProtectedRouteProps) {
  const { data: authUser, isLoading: authLoading } = useAuth();
  const { data: profileUser, isLoading: profileLoading } = useUser();
  const [location, setLocation] = useLocation();

  const isOnboarded = isOnboardingComplete(profileUser);
  const isWaiting = authLoading || profileLoading;

  useEffect(() => {
    if (isWaiting) return;

    if (!authUser) {
      routeLog("ProtectedRoute", "no auth -> /login");
      setLocation("/");
      return;
    }

    if (requireOnboarding && !isOnboarded && location !== "/onboarding") {
      routeLog("ProtectedRoute", "not onboarded -> /onboarding");
      setLocation("/onboarding");
    }
  }, [authUser, isWaiting, isOnboarded, requireOnboarding, location, setLocation]);

  if (isWaiting) return <LoadingScreen />;

  if (!authUser) {
    routeLog("ProtectedRoute", "render: redirecting to login");
    return <LoadingScreen />;
  }

  if (requireOnboarding && !isOnboarded && location !== "/onboarding") {
    routeLog("ProtectedRoute", "render: redirecting to onboarding");
    return <LoadingScreen />;
  }

  return <>{children}</>;
}

export function PublicOnlyRoute({ children }: { children: React.ReactNode }) {
  const { data: authUser, isLoading } = useAuth();
  const { data: profileUser, isLoading: profileLoading, isFetching: profileFetching } = useUser();
  const [, setLocation] = useLocation();

  const isOnboarded = isOnboardingComplete(profileUser);
  const isWaiting = isLoading || profileLoading || profileFetching;

  useEffect(() => {
    if (isWaiting) return;

    if (authUser) {
      if (isOnboarded) {
        routeLog("PublicOnlyRoute", "onboarded -> /dashboard");
        setLocation("/dashboard");
      } else {
        routeLog("PublicOnlyRoute", "not onboarded -> /onboarding");
        setLocation("/onboarding");
      }
    }
  }, [authUser, isWaiting, isOnboarded, setLocation]);

  if (isWaiting) return <LoadingScreen />;

  if (authUser) {
    routeLog("PublicOnlyRoute", "render: redirecting");
    return <LoadingScreen />;
  }

  return <>{children}</>;
}

export function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const { data: authUser, isLoading: authLoading } = useAuth();
  const { data: profileUser, isLoading: profileLoading } = useUser();
  const [, setLocation] = useLocation();

  const isOnboarded = isOnboardingComplete(profileUser);
  const isRecalculate = typeof window !== "undefined" && new URLSearchParams(window.location.search).has("recalculate");
  const isWaiting = authLoading || profileLoading;

  useEffect(() => {
    if (isWaiting) return;

    if (!authUser) {
      routeLog("OnboardingGuard", "no auth -> /login");
      setLocation("/");
      return;
    }

    if (isOnboarded && !isRecalculate) {
      routeLog("OnboardingGuard", `already onboarded, no recalculate flag -> /dashboard`);
      setLocation("/dashboard", { replace: true });
    }
  }, [authUser, isWaiting, isOnboarded, isRecalculate, setLocation]);

  if (isWaiting) return <LoadingScreen />;
  if (!authUser) return <LoadingScreen />;
  if (isOnboarded && !isRecalculate) {
    routeLog("OnboardingGuard", "render: redirecting to dashboard");
    return <LoadingScreen />;
  }

  return <>{children}</>;
}
