import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Zap, Fuel } from "lucide-react";
import { Link } from "wouter";

interface ReadinessSummary {
  total: number;
  label: string;
  provisional: boolean;
}

interface FuelSummary {
  fuelStatus: string;
  glycogenRisk: string;
  provisional: boolean;
}

const readinessColor: Record<string, string> = {
  High: "text-green-400 border-green-400/30 bg-green-400/10",
  Moderate: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  Low: "text-orange-400 border-orange-400/30 bg-orange-400/10",
  Poor: "text-red-400 border-red-400/30 bg-red-400/10",
  Provisional: "text-blue-300 border-blue-300/30 bg-blue-300/10",
};

const fuelColor: Record<string, string> = {
  High: "text-green-400 border-green-400/30 bg-green-400/10",
  Adequate: "text-green-400 border-green-400/30 bg-green-400/10",
  Low: "text-red-400 border-red-400/30 bg-red-400/10",
};

export function ReadinessSummaryCard({ date }: { date: string }) {
  const { data: readiness } = useQuery<ReadinessSummary>({
    queryKey: ["/api/me/readiness", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/readiness/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const { data: fuel } = useQuery<FuelSummary>({
    queryKey: ["/api/me/fuel", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/fuel/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const readinessLabel = readiness?.provisional ? "Estimated" : (readiness?.label ?? "—");
  const fuelLabel = fuel?.fuelStatus ?? "—";

  return (
    <Link href="/readiness">
      <Card
        className="cursor-pointer hover:bg-secondary/10 transition-colors"
        data-testid="card-readiness-summary"
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-muted-foreground/50" />
                <div>
                  <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Readiness</p>
                  <Badge
                    variant="outline"
                    className={`text-[11px] mt-0.5 ${readiness ? (readiness.provisional ? readinessColor.Provisional : readinessColor[readiness.label] ?? "") : ""}`}
                    data-testid="badge-readiness-summary"
                  >
                    {readinessLabel}
                  </Badge>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Fuel className="h-4 w-4 text-muted-foreground/50" />
                <div>
                  <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Fuel</p>
                  <Badge
                    variant="outline"
                    className={`text-[11px] mt-0.5 ${fuel ? (fuelColor[fuel.fuelStatus] ?? "") : ""}`}
                    data-testid="badge-fuel-summary"
                  >
                    {fuelLabel}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground/50">
              <span>Details</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
