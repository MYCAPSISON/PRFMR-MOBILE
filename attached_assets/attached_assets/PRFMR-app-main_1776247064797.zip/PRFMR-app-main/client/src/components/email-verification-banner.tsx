import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { AlertTriangle, Mail, RefreshCw, Edit3, X } from "lucide-react";
import { useResendVerification, useChangeEmail, useAuth } from "@/hooks/use-auth";

export function EmailVerificationBanner() {
  const { data: user } = useAuth();
  const resendMutation = useResendVerification();
  const changeEmailMutation = useChangeEmail();
  const [showChangeEmail, setShowChangeEmail] = useState(false);
  const [newEmail, setNewEmail] = useState("");

  if (!user || user.emailVerified) {
    return null;
  }

  const handleResend = () => {
    resendMutation.mutate();
  };

  const handleChangeEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (newEmail.trim()) {
      changeEmailMutation.mutate(newEmail.trim(), {
        onSuccess: () => {
          setShowChangeEmail(false);
          setNewEmail("");
        },
      });
    }
  };

  return (
    <Card className="border-amber-500/50 bg-amber-500/5">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-full bg-amber-500/10 shrink-0">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-sm">Verify your email</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Please verify your email address ({user.email}) to access all features.
            </p>
            
            {showChangeEmail ? (
              <form onSubmit={handleChangeEmail} className="mt-3 flex gap-2">
                <Input
                  type="email"
                  placeholder="New email address"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="flex-1"
                  data-testid="input-new-email"
                />
                <Button 
                  type="submit" 
                  size="sm"
                  disabled={changeEmailMutation.isPending || !newEmail.trim()}
                  data-testid="button-save-email"
                >
                  {changeEmailMutation.isPending ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    "Save"
                  )}
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowChangeEmail(false);
                    setNewEmail("");
                  }}
                  data-testid="button-cancel-change-email"
                >
                  <X className="h-4 w-4" />
                </Button>
              </form>
            ) : (
              <div className="flex flex-wrap gap-2 mt-3">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleResend}
                  disabled={resendMutation.isPending}
                  data-testid="button-resend-verification"
                >
                  {resendMutation.isPending ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Mail className="h-4 w-4 mr-2" />
                  )}
                  Resend verification email
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowChangeEmail(true)}
                  data-testid="button-change-email"
                >
                  <Edit3 className="h-4 w-4 mr-2" />
                  Change email
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
