import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Moon, Scale, Dumbbell, Check, Star, BedDouble } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MorningStatus {
  hasSleep: boolean;
  hasWeight: boolean;
  hasPlannedTraining: boolean;
  isRestDay: boolean;
  sleepLog: { hoursSlept: number; sleepQuality: number | null } | null;
  weightLog: { weight: number } | null;
}

export function MorningCheckIn({ date }: { date: string }) {
  const { toast } = useToast();
  const [sleepHours, setSleepHours] = useState("");
  const [sleepQuality, setSleepQuality] = useState<number | null>(null);
  const [showSleepInput, setShowSleepInput] = useState(false);

  const [weightInput, setWeightInput] = useState("");
  const [showWeightInput, setShowWeightInput] = useState(false);

  const { data: status, isLoading } = useQuery<MorningStatus>({
    queryKey: ["/api/me/morning-status", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/morning-status/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const sleepMutation = useMutation({
    mutationFn: async (data: { hoursSlept: number; sleepQuality: number | null }) => {
      return apiRequest("PUT", `/api/me/sleep/${date}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", date] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/sleep"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      setShowSleepInput(false);
      setSleepHours("");
      setSleepQuality(null);
      toast({ title: "Sleep logged" });
    },
  });

  const weightMutation = useMutation({
    mutationFn: async (data: { date: string; weight: number }) => {
      return apiRequest("POST", "/api/weights", data);
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", date] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      setShowWeightInput(false);
      setWeightInput("");
      toast({ title: "Weight logged — trend updated ✅" });
    },
  });

  const restDayMutation = useMutation({
    mutationFn: async (markRest: boolean) => {
      if (markRest) {
        return apiRequest("POST", `/api/me/rest-day/${date}`, {});
      } else {
        return apiRequest("DELETE", `/api/me/rest-day/${date}`);
      }
    },
    onSuccess: (_, markRest) => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", date] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training/summary", date], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      toast({ title: markRest ? "Rest day marked" : "Rest day removed" });
    },
  });

  if (isLoading || !status) return null;

  const trainingDone = status.hasPlannedTraining || status.isRestDay;
  const allDone = status.hasSleep && status.hasWeight && trainingDone;
  if (allDone) return null;

  const handleSleepSubmit = () => {
    const hours = parseFloat(sleepHours);
    if (isNaN(hours) || hours < 0 || hours > 24) return;
    sleepMutation.mutate({ hoursSlept: hours, sleepQuality });
  };

  const handleWeightSubmit = () => {
    const w = parseFloat(weightInput);
    if (isNaN(w) || w <= 0) return;
    weightMutation.mutate({ date, weight: w });
  };

  return (
    <Card className="border-primary/20 bg-primary/5" data-testid="card-morning-checkin">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-display font-semibold">Morning Check-In</h3>
          <Badge variant="outline" className="text-xs">
            {[status.hasSleep, status.hasWeight, trainingDone].filter(Boolean).length}/3
          </Badge>
        </div>

        {/* Sleep section */}
        {!status.hasSleep && !showSleepInput && (
          <button
            onClick={() => setShowSleepInput(true)}
            className="flex items-center gap-3 w-full p-3 rounded-lg border border-border/50 hover:bg-secondary/30 transition-colors text-left"
            data-testid="button-prompt-sleep"
          >
            <Moon className="h-4 w-4 text-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">How did you sleep?</p>
              <p className="text-xs text-muted-foreground">Log last night's sleep</p>
            </div>
          </button>
        )}

        {showSleepInput && (
          <div className="space-y-3 p-3 rounded-lg border border-border/50 bg-secondary/20" data-testid="sleep-input-form">
            <div className="flex items-center gap-2">
              <Moon className="h-4 w-4 text-primary" />
              <Label className="text-sm font-medium">Hours slept</Label>
            </div>
            <Input
              type="number"
              step="0.5"
              min="0"
              max="24"
              placeholder="e.g., 7.5"
              value={sleepHours}
              onChange={(e) => setSleepHours(e.target.value)}
              data-testid="input-sleep-hours"
            />
            <div>
              <Label className="text-xs text-muted-foreground">Quality (optional)</Label>
              <div className="flex gap-1 mt-1">
                {[1, 2, 3, 4, 5].map((q) => (
                  <button
                    key={q}
                    onClick={() => setSleepQuality(sleepQuality === q ? null : q)}
                    className="p-1"
                    data-testid={`button-sleep-quality-${q}`}
                  >
                    <Star
                      className={`h-5 w-5 ${
                        sleepQuality && q <= sleepQuality
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-muted-foreground/30"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleSleepSubmit}
                disabled={sleepMutation.isPending || !sleepHours}
                data-testid="button-submit-sleep"
              >
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowSleepInput(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        {status.hasSleep && !showSleepInput && (
          <button
            onClick={() => {
              setSleepHours(status.sleepLog?.hoursSlept?.toString() || "");
              setSleepQuality(status.sleepLog?.sleepQuality ?? null);
              setShowSleepInput(true);
            }}
            className="flex items-center gap-2 p-2 rounded-lg bg-secondary/20 w-full text-left hover:bg-secondary/30 transition-colors"
            data-testid="button-edit-sleep"
          >
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm text-muted-foreground flex-1">
              Sleep logged: {status.sleepLog?.hoursSlept}h
              {status.sleepLog?.sleepQuality ? ` (quality ${status.sleepLog.sleepQuality}/5)` : ""}
            </span>
            <span className="text-[10px] text-muted-foreground/60">tap to edit</span>
          </button>
        )}

        {/* Weight section */}
        {!status.hasWeight && !showWeightInput && (
          <button
            onClick={() => setShowWeightInput(true)}
            className="flex items-center gap-3 w-full p-3 rounded-lg border border-border/50 hover:bg-secondary/30 transition-colors text-left"
            data-testid="button-prompt-weight"
          >
            <Scale className="h-4 w-4 text-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">Morning weight?</p>
              <p className="text-xs text-muted-foreground">Log today's weigh-in</p>
            </div>
          </button>
        )}

        {showWeightInput && (
          <div className="space-y-3 p-3 rounded-lg border border-border/50 bg-secondary/20" data-testid="weight-input-form">
            <div className="flex items-center gap-2">
              <Scale className="h-4 w-4 text-primary" />
              <Label className="text-sm font-medium">Morning weight (kg)</Label>
            </div>
            <Input
              type="number"
              step="0.1"
              min="20"
              max="300"
              placeholder="e.g., 72.4"
              value={weightInput}
              onChange={(e) => setWeightInput(e.target.value)}
              autoFocus
              data-testid="input-morning-weight"
            />
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleWeightSubmit}
                disabled={weightMutation.isPending || !weightInput}
                data-testid="button-submit-morning-weight"
              >
                {weightMutation.isPending ? "Saving…" : "Save"}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowWeightInput(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        {status.hasWeight && !showWeightInput && (
          <button
            onClick={() => {
              setWeightInput(status.weightLog?.weight?.toString() || "");
              setShowWeightInput(true);
            }}
            className="flex items-center gap-2 p-2 rounded-lg bg-secondary/20 w-full text-left hover:bg-secondary/30 transition-colors"
            data-testid="button-weight-logged"
          >
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm text-muted-foreground flex-1">
              Weight logged: {status.weightLog?.weight} kg
            </span>
            <span className="text-[10px] text-muted-foreground/60">tap to edit</span>
          </button>
        )}

        {/* Training section */}
        {!trainingDone && (
          <div className="p-3 rounded-lg border border-border/50 space-y-2">
            <div className="flex items-center gap-3">
              <Dumbbell className="h-4 w-4 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">Training today?</p>
                <p className="text-xs text-muted-foreground">Log a session or mark as rest</p>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="w-full text-xs gap-2"
              onClick={() => restDayMutation.mutate(true)}
              disabled={restDayMutation.isPending}
              data-testid="button-mark-rest-day"
            >
              <BedDouble className="h-3.5 w-3.5" />
              Mark as rest day
            </Button>
          </div>
        )}
        {status.isRestDay && (
          <button
            onClick={() => restDayMutation.mutate(false)}
            disabled={restDayMutation.isPending}
            className="flex items-center gap-2 p-2 rounded-lg bg-secondary/20 w-full text-left hover:bg-secondary/30 transition-colors"
            data-testid="button-unmark-rest-day"
          >
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm text-muted-foreground flex-1">Rest day</span>
            <span className="text-[10px] text-muted-foreground/60">tap to undo</span>
          </button>
        )}
        {status.hasPlannedTraining && !status.isRestDay && (
          <div className="flex items-center gap-2 p-2 rounded-lg bg-secondary/20">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm text-muted-foreground">Training session created</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
