import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, subDays, parseISO } from "date-fns";
import { AnimatePresence, motion } from "framer-motion";
import { ShieldCheck, Info, ChevronRight, BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { useToast } from "@/hooks/use-toast";

interface AMQSScoreResult {
  date: string;
  score: number;
  tier: string;
  confidence: "Low" | "Medium" | "High";
  totals: Record<string, number>;
  targets: Record<string, number>;
  coverage: Record<string, { pctOfTarget: number; status: string }>;
  topGaps: { microKey: string; label: string; pctOfTarget: number; suggestion?: string }[];
  allMet: boolean;
  breakdown: { food: Record<string, number>; supplements: Record<string, number> };
  coverageStats?: { totalTakenSupplements?: number };
  layer2Score?: number;
  layer2Tier?: string;
  layer2Targets?: Record<string, number>;
  layer2Coverage?: Record<string, { pctOfTarget: number; status: string }>;
  layer2TopGaps?: { microKey: string; label: string; pctOfTarget: number; suggestion?: string }[];
}

interface WeeklyAMQSResult {
  startDate: string;
  endDate: string;
  averageScore: number;
  tier: string;
  dailyScores: { date: string; score: number; tier: string }[];
}

interface AMQSTrendResult {
  layer1: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
  layer2: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
}

const formatPct = (pct: number) => (pct >= 100 ? "Target met" : `${pct}%`);

function formatTrendLine(layer: AMQSTrendResult["layer1"] | undefined): string {
  if (!layer) return "";
  const { delta, trend, prevWeekAvg } = layer;
  if (prevWeekAvg === 0) return "still building";
  if (trend === "improving") return `↑ +${delta} vs last week`;
  if (trend === "slightly_down") return `↓ ${delta} vs last week`;
  return "→ steady vs last week";
}

function trendLineColor(layer: AMQSTrendResult["layer1"] | undefined): string {
  if (!layer || layer.prevWeekAvg === 0) return "text-muted-foreground/40";
  if (layer.trend === "improving") return "text-emerald-500/70";
  if (layer.trend === "slightly_down") return "text-amber-400/70";
  return "text-muted-foreground/40";
}

const getTierColor = (tier: string) => {
  switch (tier) {
    case "Elite": return "bg-emerald-500 text-white";
    case "Optimal": return "bg-blue-500 text-white";
    case "Good": return "bg-amber-500 text-white";
    default: return "bg-slate-500 text-white";
  }
};

const getConfidenceValue = (conf: string) => {
  switch (conf) {
    case "High": return 100;
    case "Medium": return 60;
    case "Low": return 30;
    default: return 0;
  }
};

interface Props {
  date: string;
  onLogFirstMeal?: () => void;
}

export function AMQSCard({ date, onLogFirstMeal }: Props) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [goalsExpanded, setGoalsExpanded] = useState(false);
  const [referenceOpen, setReferenceOpen] = useState(false);
  const { toast } = useToast();

  const weekStart = format(subDays(parseISO(date), 6), "yyyy-MM-dd");

  const { data: daily } = useQuery<AMQSScoreResult | null>({
    queryKey: ["/api/me/amqs/score", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/amqs/score/${date}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return null;
      return res.json();
    },
  });

  const { data: weekly } = useQuery<WeeklyAMQSResult | null>({
    queryKey: ["/api/me/amqs/score-range", weekStart, date],
    queryFn: async () => {
      const res = await fetch(`/api/me/amqs/score-range/${weekStart}/${date}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return null;
      return res.json();
    },
  });

  const { data: trend } = useQuery<AMQSTrendResult | null>({
    queryKey: ["/api/me/amqs/trend", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/amqs/trend/${date}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!daily,
  });

  // Layer 1 completion toast — fires once per day when baseline is fully covered.
  // Keyed by date in localStorage so it doesn't repeat on the same day.
  useEffect(() => {
    if (!daily || !daily.allMet) return;
    const key = `amqs-l1-complete-${date}`;
    if (localStorage.getItem(key)) return;
    localStorage.setItem(key, "1");
    toast({
      title: "Baseline adequacy covered",
      description: "All key micronutrient targets met today. Now optimise for athlete targets.",
      duration: 5000,
    });
  }, [daily?.allMet, date]);

  const hasWeeklyData = weekly && typeof weekly.averageScore === "number";
  const hasSupplementsToday = !!(daily?.coverageStats?.totalTakenSupplements && daily.coverageStats.totalTakenSupplements > 0);
  const hasFoodToday = !!(daily && daily.score > 0 && daily.confidence !== "Low");

  const getTopContributor = () => {
    if (!daily?.breakdown) return null;
    const combined: Record<string, number> = {};
    const food = (daily.breakdown.food || {}) as Record<string, number>;
    const supps = (daily.breakdown.supplements || {}) as Record<string, number>;
    for (const [k, v] of Object.entries(food)) { if (v > 0) combined[k] = (combined[k] || 0) + v; }
    for (const [k, v] of Object.entries(supps)) { if (v > 0) combined[k] = (combined[k] || 0) + v; }
    const entries = Object.entries(combined).filter(([, v]) => v > 0);
    if (entries.length === 0) return null;
    entries.sort((a, b) => b[1] - a[1]);
    const topKey = entries[0][0];
    const topVal = entries[0][1];
    const label = topKey.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    return { key: topKey, label, value: topVal };
  };

  const hasDataToday = hasFoodToday || !!hasSupplementsToday;

  const getWhatMovedIt = () => {
    if (!daily || !hasDataToday) return "Log a meal or supplement to see drivers";
    const contributor = getTopContributor();
    const topGap = daily.topGaps?.[0];
    const parts: string[] = [];
    if (contributor) parts.push(`+${Math.round(contributor.value)}% ${contributor.label}`);
    if (topGap) parts.push(`${topGap.label} at ${formatPct(topGap.pctOfTarget)}`);
    return parts.length > 0 ? parts.join(" · ") : "Log one more meal to improve insight quality";
  };

  const isEmptyState = !daily || !hasDataToday;

  const exampleGaps = [
    { label: "Vitamin D", pctOfTarget: 15 },
    { label: "Magnesium", pctOfTarget: 32 },
    { label: "Omega-3", pctOfTarget: 8 },
  ];

  const microGoals = !isEmptyState && daily?.topGaps
    ? daily.topGaps.slice(0, 3).filter((g) => g.suggestion).map((gap) => ({
        ...gap,
        pointEst: Math.max(2, Math.min(8, Math.round(((100 - gap.pctOfTarget) / 100) * 7))),
      }))
    : [];

  const hasLayer2 = !isEmptyState && daily?.layer2Score !== undefined;

  return (
    <>
      <div
        className={`bg-card rounded-xl p-6 amqs-card-glow space-y-6 ${!isEmptyState ? "cursor-pointer amqs-card-interactive" : ""}`}
        data-testid="card-amqs"
        role={!isEmptyState ? "button" : undefined}
        tabIndex={!isEmptyState ? 0 : undefined}
        onClick={() => !isEmptyState && setDetailsOpen(true)}
        onKeyDown={(e) => { if (!isEmptyState && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); setDetailsOpen(true); } }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Micronutrient Quality</h3>
            <p className="text-[10px] text-muted-foreground/60 uppercase tracking-wider mt-0.5">Athlete Score (AMQS)</p>
          </div>
          {!isEmptyState ? (
            <ChevronRight className="h-4 w-4 text-muted-foreground/40" />
          ) : (
            <ShieldCheck className="h-5 w-5 text-muted-foreground/30" />
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground/70">General Score</p>
            <div className="flex items-baseline gap-2">
              <div className="relative inline-block">
                <span className="text-4xl font-extrabold font-mono amqs-glow" data-testid="text-amqs-daily-score">
                  {isEmptyState ? "—" : daily!.score}
                </span>
                <div className="absolute bottom-0 left-0 right-0 h-[2px] rounded-full bg-primary/30" />
              </div>
              <Badge className={isEmptyState ? "bg-slate-600 text-slate-300" : getTierColor(daily!.tier)} data-testid="badge-amqs-daily-tier">
                {isEmptyState ? "Provisional" : daily!.tier}
              </Badge>
            </div>
            <p className="text-[10px] text-muted-foreground/70 mt-2 leading-tight truncate" data-testid="text-what-moved-it">
              {getWhatMovedIt()}
            </p>
            {trend && (
              <p className={`text-[10px] mt-0.5 font-medium ${trendLineColor(trend.layer1)}`} data-testid="text-amqs-l1-trend">
                {formatTrendLine(trend.layer1)}
              </p>
            )}
          </div>
          <div className="space-y-1">
            {hasLayer2 ? (
              <>
                <p className="text-xs text-muted-foreground/50">Performance Score</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-semibold text-muted-foreground/60 font-mono" data-testid="text-amqs-layer2-score">
                    {daily!.layer2Score}
                  </span>
                  <Badge variant="outline" className="text-[10px] border-border/30 text-muted-foreground/60" data-testid="badge-amqs-layer2-tier">
                    {daily!.layer2Tier}
                  </Badge>
                </div>
                <p className="text-[10px] text-muted-foreground/40 mt-1">Optimisation targets</p>
                {trend && (
                  <p className={`text-[10px] mt-0.5 font-medium ${trendLineColor(trend.layer2)}`} data-testid="text-amqs-l2-trend">
                    {formatTrendLine(trend.layer2)}
                  </p>
                )}
              </>
            ) : (
              <>
                <p className="text-xs text-muted-foreground/50">Weekly Avg</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-semibold text-muted-foreground/60 font-mono" data-testid="text-amqs-weekly-score">
                    {hasWeeklyData ? weekly!.averageScore : "—"}
                  </span>
                  <Badge variant="outline" className="text-[10px] border-border/30 text-muted-foreground/60" data-testid="badge-amqs-weekly-tier">
                    {hasWeeklyData ? weekly!.tier : "—"}
                  </Badge>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <p className="text-[10px] text-muted-foreground/50 font-medium">Data Confidence</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-2.5 w-2.5 text-muted-foreground/30" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-[240px] text-[11px]">
                    Measures how much of your logged data has micronutrient info. High = 75%+ coverage, Medium = 40–74%, Low = under 40% or no data.
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Badge variant="secondary" className="text-[10px] px-1.5 bg-secondary/50" data-testid="badge-amqs-confidence">
              {isEmptyState ? "Low" : daily!.confidence}
            </Badge>
          </div>
          {isEmptyState ? (
            <div className="space-y-1">
              <Progress value={0} className="h-1" />
              <p className="text-[10px] text-muted-foreground/50">Building baseline — log your first meal</p>
            </div>
          ) : (
            <Progress value={getConfidenceValue(daily!.confidence)} className="h-1" />
          )}
        </div>

        {hasWeeklyData && weekly!.dailyScores && weekly!.dailyScores.length > 1 && (
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground/50 font-medium" data-testid="text-7day-trend-label">7-day trend</p>
            <div className="h-12">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weekly!.dailyScores.map((d) => ({ date: d.date.slice(5), score: d.score }))}>
                  <defs>
                    <linearGradient id="amqsTrendFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.1} />
                      <stop offset="100%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="score" stroke="hsl(var(--muted-foreground))" fill="url(#amqsTrendFill)" strokeWidth={1} dot={false} strokeOpacity={0.4} />
                  <XAxis dataKey="date" tick={{ fontSize: 8, fill: "hsl(var(--muted-foreground))", opacity: 0.4 }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} hide />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {isEmptyState ? (
          <div className="space-y-3 pt-3">
            <p className="text-[11px] font-semibold text-muted-foreground/50">Top gaps</p>
            <div className="space-y-2 opacity-30" aria-hidden="true">
              {exampleGaps.map((gap) => (
                <div key={gap.label} className="text-xs flex flex-col gap-1 p-2 rounded bg-secondary/15">
                  <div className="flex justify-between">
                    <span className="font-medium">{gap.label}</span>
                    <span className="text-muted-foreground">{formatPct(gap.pctOfTarget)}</span>
                  </div>
                  <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-muted-foreground/30" style={{ width: `${gap.pctOfTarget}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground/40 italic">Example — updates after your first log</p>
            {onLogFirstMeal && (
              <Button variant="default" size="sm" onClick={onLogFirstMeal} data-testid="button-log-first-meal">
                Log first meal
              </Button>
            )}
          </div>
        ) : daily!.allMet ? (
          <div className="pt-3" data-testid="amqs-all-met">
            <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0" />
              <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium leading-tight">
                Baseline adequacy covered. Tap to see athlete optimisation targets.
              </p>
            </div>
          </div>
        ) : daily!.topGaps && daily!.topGaps.length > 0 ? (
          <div className="space-y-2.5 pt-3">
            <p className="text-[11px] font-semibold text-muted-foreground/50">Top gaps</p>
            <div className="space-y-2">
              {daily!.topGaps.map((gap, idx) => (
                <div key={gap.microKey} className="text-xs flex flex-col gap-1 p-2 rounded bg-secondary/15" data-testid={`gap-${gap.microKey}`}>
                  <div className="flex justify-between">
                    <span className="font-medium">{gap.label}</span>
                    <span className="text-muted-foreground/70">{formatPct(gap.pctOfTarget)}</span>
                  </div>
                  <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${idx === 0 ? "bg-primary/70" : "bg-muted-foreground/30"}`}
                      style={{ width: `${Math.min(gap.pctOfTarget, 100)}%` }}
                    />
                  </div>
                  {gap.suggestion && (
                    <p className="text-[10px] text-muted-foreground/60">
                      Try: <span className="text-foreground/80 font-medium">{gap.suggestion}</span>
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {microGoals.length > 0 && (
          <div className="space-y-2 pt-3 border-t border-border/15">
            <p className="text-[11px] font-semibold text-muted-foreground/50">Micro-goals</p>
            <div className="space-y-1">
              <div className="text-xs flex items-center gap-2 py-0.5" data-testid={`micro-goal-${microGoals[0].microKey}`}>
                <span className="text-primary/80 font-bold whitespace-nowrap">+{microGoals[0].pointEst}</span>
                <span className="text-muted-foreground/70">if you add <span className="text-foreground/80 font-medium">{microGoals[0].suggestion}</span> ({microGoals[0].label})</span>
              </div>
              {microGoals.length > 1 && !goalsExpanded && (
                <button
                  className="text-[10px] text-muted-foreground/50 hover:text-muted-foreground transition-colors"
                  onClick={(e) => { e.stopPropagation(); setGoalsExpanded(true); }}
                  data-testid="button-see-micro-goals"
                >
                  See {microGoals.length} micro-goals →
                </button>
              )}
              <AnimatePresence>
                {goalsExpanded && microGoals.slice(1).map((goal, i) => (
                  <motion.div
                    key={goal.microKey}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2, delay: i * 0.05 }}
                    className="overflow-hidden"
                  >
                    <div className="text-xs flex items-center gap-2 py-0.5" data-testid={`micro-goal-${goal.microKey}`}>
                      <span className="text-primary/80 font-bold whitespace-nowrap">+{goal.pointEst}</span>
                      <span className="text-muted-foreground/70">if you add <span className="text-foreground/80 font-medium">{goal.suggestion}</span> ({goal.label})</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        <div className="pt-2 border-t border-border/15 flex items-center justify-between">
          <p className="text-[10px] text-muted-foreground/40 italic leading-tight">
            Includes logged foods + supplements. Estimates only; not medical advice.
          </p>
          <button
            className="flex items-center gap-1 text-[10px] text-muted-foreground/40 hover:text-muted-foreground/70 transition-colors shrink-0 ml-2"
            onClick={(e) => { e.stopPropagation(); setReferenceOpen(true); }}
            data-testid="button-amqs-how-scored"
          >
            <BookOpen className="h-3 w-3" />
            How scored
          </button>
        </div>
      </div>

      {/* Detail dialog */}
      {!isEmptyState && (
        <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
          <DialogContent className="sm:max-w-[400px] max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-display">AMQS Details</DialogTitle>
              <DialogDescription className="sr-only">Detailed breakdown of your Athlete Micronutrient Quality Score</DialogDescription>
            </DialogHeader>
            <div className="space-y-5 py-2">

              {/* Layer scores side by side */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-secondary/20 space-y-1">
                  <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">General Score</p>
                  <p className="text-[10px] text-muted-foreground/50">Baseline Adequacy</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold font-mono" data-testid="text-modal-layer1-score">{daily!.score}</span>
                    <Badge className={`text-[10px] ${getTierColor(daily!.tier)}`}>{daily!.tier}</Badge>
                  </div>
                </div>
                {hasLayer2 && (
                  <div className="p-3 rounded-lg bg-secondary/10 space-y-1">
                    <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Performance Score</p>
                    <p className="text-[10px] text-muted-foreground/50">Athlete Optimisation</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold font-mono text-muted-foreground/70" data-testid="text-modal-layer2-score">{daily!.layer2Score}</span>
                      <Badge variant="outline" className={`text-[10px] ${daily!.layer2Tier ? getTierColor(daily!.layer2Tier) : ""}`}>{daily!.layer2Tier}</Badge>
                    </div>
                  </div>
                )}
              </div>

              {/* 7-day trend sparklines */}
              {trend && (
                <div className="space-y-2" data-testid="section-amqs-trend">
                  <p className="text-[11px] font-semibold text-muted-foreground/60">7-day trend</p>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-secondary/15 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-muted-foreground/60">Basic</span>
                        <span className={`text-[10px] font-medium ${trendLineColor(trend.layer1)}`} data-testid="text-modal-l1-trend">{formatTrendLine(trend.layer1)}</span>
                      </div>
                      <div className="h-10">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={trend.layer1.dailyScores.map((d) => ({ date: d.date.slice(5), score: d.score }))}>
                            <defs>
                              <linearGradient id="l1TrendFill" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.15} />
                                <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="score" stroke="hsl(var(--primary))" fill="url(#l1TrendFill)" strokeWidth={1.5} dot={false} strokeOpacity={0.5} />
                            <XAxis dataKey="date" tick={{ fontSize: 7, fill: "hsl(var(--muted-foreground))", opacity: 0.4 }} axisLine={false} tickLine={false} />
                            <YAxis domain={[0, 100]} hide />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    <div className="p-2 rounded-lg bg-blue-500/5 border border-blue-500/10 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-muted-foreground/60">Performance</span>
                        <span className={`text-[10px] font-medium ${trendLineColor(trend.layer2)}`} data-testid="text-modal-l2-trend">{formatTrendLine(trend.layer2)}</span>
                      </div>
                      <div className="h-10">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={trend.layer2.dailyScores.map((d) => ({ date: d.date.slice(5), score: d.score }))}>
                            <defs>
                              <linearGradient id="l2TrendFill" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.12} />
                                <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="score" stroke="#3b82f6" fill="url(#l2TrendFill)" strokeWidth={1.5} dot={false} strokeOpacity={0.4} />
                            <XAxis dataKey="date" tick={{ fontSize: 7, fill: "hsl(var(--muted-foreground))", opacity: 0.4 }} axisLine={false} tickLine={false} />
                            <YAxis domain={[0, 100]} hide />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {daily!.score >= 85 && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20" data-testid="callout-layer1-strong">
                  <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 leading-relaxed">
                    Baseline micronutrient needs covered. If you're training hard, consider optimising toward athlete targets.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-[11px] font-semibold text-muted-foreground/60">What moved it today</p>
                <p className="text-sm text-foreground" data-testid="text-modal-what-moved">{getWhatMovedIt()}</p>
              </div>

              {/* Layer 1 gaps */}
              {daily!.topGaps && daily!.topGaps.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[11px] font-semibold text-muted-foreground/60">Layer 1 gaps (baseline)</p>
                  <div className="space-y-2">
                    {daily!.topGaps.map((gap, idx) => (
                      <div key={gap.microKey} className="text-xs flex flex-col gap-1.5 p-2 rounded bg-secondary/15">
                        <div className="flex justify-between">
                          <span className="font-medium">{gap.label}</span>
                          <span className="text-muted-foreground/60">{gap.pctOfTarget >= 100 ? "Target met" : `${gap.pctOfTarget}% of target`}</span>
                        </div>
                        <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${idx === 0 ? "bg-primary/70" : "bg-muted-foreground/30"}`} style={{ width: `${Math.min(gap.pctOfTarget, 100)}%` }} />
                        </div>
                        {gap.suggestion && (
                          <p className="text-[10px] text-muted-foreground/60">
                            Try: <span className="text-foreground/80 font-medium">{gap.suggestion}</span>
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Layer 2 gaps — athlete optimisation */}
              {hasLayer2 && daily!.layer2TopGaps && daily!.layer2TopGaps.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[11px] font-semibold text-muted-foreground/60">Layer 2 gaps (athlete optimisation)</p>
                  <div className="space-y-2">
                    {daily!.layer2TopGaps.map((gap, idx) => (
                      <div key={gap.microKey} className="text-xs flex flex-col gap-1.5 p-2 rounded bg-blue-500/5 border border-blue-500/10">
                        <div className="flex justify-between">
                          <span className="font-medium">{gap.label}</span>
                          <span className="text-muted-foreground/60">{gap.pctOfTarget >= 100 ? "Target met" : `${gap.pctOfTarget}% of athlete target`}</span>
                        </div>
                        <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${idx === 0 ? "bg-blue-500/60" : "bg-muted-foreground/20"}`} style={{ width: `${Math.min(gap.pctOfTarget, 100)}%` }} />
                        </div>
                        {gap.suggestion && (
                          <p className="text-[10px] text-muted-foreground/60">
                            Try: <span className="text-foreground/80 font-medium">{gap.suggestion}</span>
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground/60">Quick wins</p>
                <div className="space-y-2">
                  {daily!.topGaps && daily!.topGaps.length > 0 ? (
                    daily!.topGaps.slice(0, 2).map((gap) => gap.suggestion && (
                      <div key={gap.microKey} className="text-xs p-2 rounded bg-primary/5 border border-primary/10">
                        <span className="font-medium text-primary/80">Close {gap.label} gap</span>
                        <span className="text-muted-foreground/70"> — add {gap.suggestion}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground">All baseline targets covered. Focus on athlete optimisation above.</p>
                  )}
                </div>
              </div>

              <div className="pt-2 border-t border-border/20 space-y-2">
                <p className="text-[10px] text-muted-foreground/40 italic leading-tight">
                  Based on logged foods and supplements. Estimates only; not medical advice.
                </p>
                <button
                  className="flex items-center gap-1 text-[10px] text-muted-foreground/50 hover:text-muted-foreground transition-colors"
                  onClick={() => { setDetailsOpen(false); setTimeout(() => setReferenceOpen(true), 150); }}
                  data-testid="button-modal-how-scored"
                >
                  <BookOpen className="h-3 w-3" />
                  How this is scored — references and methodology
                </button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* "How this is scored" reference dialog */}
      <Dialog open={referenceOpen} onOpenChange={setReferenceOpen}>
        <DialogContent className="sm:max-w-[420px] max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">How AMQS is scored</DialogTitle>
            <DialogDescription className="sr-only">Scoring methodology and references for the Athlete Micronutrient Quality Score</DialogDescription>
          </DialogHeader>
          <div className="space-y-5 py-2 text-sm" data-testid="dialog-how-scored">

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Two-layer model</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                AMQS uses a two-layer approach to micronutrient scoring. <strong>Layer 1 (Adequacy)</strong> reflects whether your intake meets baseline reference nutrient intakes — similar to population-level RNIs. <strong>Layer 2 (Athlete Optimisation)</strong> uses stricter targets informed by sports nutrition research to reflect the higher demands of regular training.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">How the score is calculated</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                For each tracked nutrient, your intake is compared against the target. The adequacy ratio (intake ÷ target) is capped at 1.0 — exceeding one nutrient doesn't compensate for a gap in another. The final score is a weighted average of all adequacy ratios × 100. Athlete-critical nutrients (Iron, Calcium, Vitamin D, Magnesium, Zinc) carry higher weights.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Tier thresholds</h4>
              <div className="space-y-1">
                {[
                  { tier: "Elite", range: "95–100", note: "Requires critical nutrients ≥70% of target" },
                  { tier: "Optimal", range: "85–94", color: "text-blue-500" },
                  { tier: "Good", range: "70–84", color: "text-amber-500" },
                  { tier: "Fair", range: "50–69" },
                  { tier: "Basic", range: "< 50" },
                ].map(({ tier, range, note }) => (
                  <div key={tier} className="flex items-start gap-2 text-xs">
                    <Badge className={`text-[10px] shrink-0 ${getTierColor(tier)}`}>{tier}</Badge>
                    <span className="text-muted-foreground">{range}{note ? ` — ${note}` : ""}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Tracked nutrients</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Layer 1: Iron, Calcium, Vitamin D, Magnesium, Zinc, Iodine, Selenium, Folate, Vitamin B12, Vitamin C, Vitamin A, Potassium, B1, B2, B3, B6, Omega-3 (17 nutrients).
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Layer 2 uses the same nutrients with stricter athlete optimisation targets where supported by evidence.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Key references</h4>
              <ul className="text-xs text-muted-foreground space-y-1 list-disc pl-4 leading-relaxed">
                <li>Thomas DT, Erdman KA, Burke LM. <em>Nutrition and Athletic Performance.</em> J Acad Nutr Diet, 2016.</li>
                <li>Maughan RJ et al. <em>IOC Consensus Statement: Dietary Supplements and the High-Performance Athlete.</em> Br J Sports Med, 2018.</li>
                <li>Institute of Medicine. <em>Dietary Reference Intakes.</em> National Academies Press.</li>
                <li>Burke LM & Deakin V. <em>Clinical Sports Nutrition.</em> 5th ed.</li>
                <li>Holick MF et al. <em>Vitamin D Deficiency.</em> JCEM, 2011.</li>
                <li>Volpe SL. <em>Magnesium and the Athlete.</em> Curr Sports Med Rep, 2015.</li>
              </ul>
            </div>

            <div className="pt-2 border-t border-border/20">
              <p className="text-[10px] text-muted-foreground/50 italic leading-tight">
                Targets are athlete optimisation targets informed by sports nutrition literature and dietary reference intakes — not clinical RDAs. This is not medical advice.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
