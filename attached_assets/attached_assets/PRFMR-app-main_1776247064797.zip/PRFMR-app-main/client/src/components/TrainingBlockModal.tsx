import { useState, useCallback, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { format, nextMonday } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  Cell,
} from "recharts";
import {
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Flame,
  X,
  ShieldAlert,
  Plus,
  Dumbbell,
  Swords,
  Search,
  Moon,
  Info,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { BlockActivityTemplate } from "@shared/schema";

// ─── Types ───────────────────────────────────────────────────────────────────

type ActivityForm = {
  activityType: "cardio" | "lifting";
  name: string;
  durationMinutes: number;
  rpe: number;
  metValue?: number;
  bodyRegion?: string;
  activityCatalogId?: number;
  intensity?: string;
};

interface CatalogActivity {
  id: number;
  name: string;
  intensity: string;
  metValue: number | null;
}

interface WeekPreview {
  weekNum: number;
  startDate: string;
  endDate: string;
  days: { date: string; dow: number; plannedLoad: string; load: number }[];
  peakAcwr: number | null;
  avgLoad: number;
  hasSpike: boolean;
  hasCluster: boolean;
  warningReasons: string[];
}

interface PreviewResult {
  weeks: WeekPreview[];
  hasAnyOvertraining: boolean;
}

interface InitialBlock {
  name: string;
  startDate: string;
  weekCount: number;
  days: { dayOfWeek: number; activities?: BlockActivityTemplate[] }[];
}

interface Props {
  open: boolean;
  onClose: () => void;
  initialBlock?: InitialBlock | null;
}

// ─── Constants ───────────────────────────────────────────────────────────────

const DAYS_OF_WEEK = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const BODY_REGIONS = [
  { value: "upper", label: "Upper Body" },
  { value: "lower", label: "Lower Body" },
  { value: "full",  label: "Full Body" },
];

function getNextMonday(): string {
  return format(nextMonday(new Date()), "yyyy-MM-dd");
}

function computeDayAU(activities: BlockActivityTemplate[]): number {
  return activities.reduce((sum, a) => {
    if (a.rpe) return sum + a.rpe * a.durationMinutes;
    if (a.metValue) return sum + a.metValue * a.durationMinutes;
    return sum + a.durationMinutes * 3;
  }, 0);
}

// Thresholds match server/lib/training-load.ts classifyDayLoad: <300 light, <600 moderate, <900 hard, ≥900 very_hard
function auToLoadLabel(au: number): { label: string; color: string; bg: string; border: string } {
  if (au === 0)    return { label: "Rest",      color: "text-muted-foreground",  bg: "bg-muted/30",      border: "border-border/40"     };
  if (au < 300)    return { label: "Light",     color: "text-green-400",         bg: "bg-green-500/15",  border: "border-green-500/30"  };
  if (au < 600)    return { label: "Moderate",  color: "text-yellow-400",        bg: "bg-yellow-500/15", border: "border-yellow-500/30" };
  if (au < 900)    return { label: "Hard",      color: "text-orange-400",        bg: "bg-orange-500/15", border: "border-orange-500/30" };
  return             { label: "Very Hard",  color: "text-red-400",           bg: "bg-red-500/15",    border: "border-red-500/30"    };
}

function acwrBarColor(acwr: number | null) {
  if (acwr === null) return "#6b7280";
  if (acwr > 1.5) return "#ef4444";
  if (acwr > 1.3) return "#f97316";
  if (acwr > 0.8) return "#22c55e";
  return "#6b7280";
}

// ─── Inline Activity Add Form ─────────────────────────────────────────────────

function ActivityAddForm({
  type,
  onAdd,
  onCancel,
}: {
  type: "cardio" | "lifting";
  onAdd: (act: BlockActivityTemplate) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [duration, setDuration] = useState(45);
  const [rpe, setRpe] = useState(7);
  const [slot, setSlot] = useState<"morning" | "afternoon" | "evening" | "night">("morning");
  const [bodyRegion, setBodyRegion] = useState("full");
  const [search, setSearch] = useState("");
  const [selectedCatalog, setSelectedCatalog] = useState<CatalogActivity | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  const { data: catalogResults = [] } = useQuery<CatalogActivity[]>({
    queryKey: ["/api/activities", search],
    queryFn: async () => {
      if (search.length < 2) return [];
      const res = await fetch(`/api/activities?query=${encodeURIComponent(search)}`);
      if (!res.ok) return [];
      const all: CatalogActivity[] = await res.json();
      return all.slice(0, 8);
    },
    enabled: type === "cardio" && search.length >= 2,
  });

  const handleSelect = (cat: CatalogActivity) => {
    setSelectedCatalog(cat);
    setName(cat.name);
    setSearch(cat.name);
    setShowDropdown(false);
  };

  const handleAdd = () => {
    const finalName = type === "lifting"
      ? (name.trim() || `${bodyRegion === "upper" ? "Upper" : bodyRegion === "lower" ? "Lower" : "Full"} Body Lifting`)
      : (name.trim() || "Cardio");

    const act: BlockActivityTemplate = {
      activityType: type,
      name: finalName,
      durationMinutes: duration,
      rpe,
      slot,
      intensity: rpe <= 4 ? "light" : rpe <= 7 ? "moderate" : "vigorous",
      ...(type === "cardio" && selectedCatalog ? {
        metValue: selectedCatalog.metValue ?? 6,
        activityCatalogId: selectedCatalog.id,
      } : {}),
      ...(type === "lifting" ? { bodyRegion, metValue: 4.0 } : {}),
    };
    onAdd(act);
  };

  return (
    <div className="rounded-xl border border-border/40 bg-muted/20 p-3 space-y-3">
      <div className="flex items-center gap-2">
        {type === "cardio"
          ? <Swords className="h-3.5 w-3.5 text-blue-400" />
          : <Dumbbell className="h-3.5 w-3.5 text-purple-400" />}
        <span className="text-xs font-semibold text-foreground/80">
          {type === "cardio" ? "Add Session" : "Add Strength"}
        </span>
      </div>

      {type === "cardio" ? (
        <div className="relative">
          <Label className="text-[10px] text-muted-foreground mb-1 block">Activity</Label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground/50" />
            <Input
              ref={searchRef}
              data-testid="input-activity-search"
              placeholder="Search session type (e.g. wrestling, running…)"
              value={search}
              onChange={e => { setSearch(e.target.value); setSelectedCatalog(null); setName(e.target.value); setShowDropdown(true); }}
              onFocus={() => setShowDropdown(true)}
              className="h-8 text-xs pl-8"
            />
          </div>
          {showDropdown && catalogResults.length > 0 && (
            <div className="absolute z-50 w-full mt-1 bg-background border border-border/40 rounded-lg shadow-lg overflow-hidden">
              {catalogResults.map(c => (
                <button
                  key={c.id}
                  data-testid={`option-activity-${c.id}`}
                  className="w-full px-3 py-2 text-left text-xs hover:bg-muted/40 flex items-center justify-between"
                  onMouseDown={() => handleSelect(c)}
                >
                  <span>{c.name}</span>
                  {c.metValue && <span className="text-muted-foreground text-[10px]">MET {c.metValue}</span>}
                </button>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div>
          <Label className="text-[10px] text-muted-foreground mb-1 block">Body Region</Label>
          <div className="flex gap-1.5">
            {BODY_REGIONS.map(br => (
              <button
                key={br.value}
                data-testid={`button-region-${br.value}`}
                onClick={() => setBodyRegion(br.value)}
                className={`flex-1 py-1.5 rounded-lg border text-[10px] font-medium transition-colors ${
                  bodyRegion === br.value
                    ? "bg-purple-500/20 border-purple-500/40 text-purple-300"
                    : "border-border/30 text-muted-foreground hover:border-border/60"
                }`}
              >
                {br.label}
              </button>
            ))}
          </div>
          <div className="mt-2">
            <Label className="text-[10px] text-muted-foreground mb-1 block">Label (optional)</Label>
            <Input
              data-testid="input-lifting-name"
              placeholder="e.g. Bench Press, Squats…"
              value={name}
              onChange={e => setName(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        </div>
      )}

      {/* Slot selector */}
      <div>
        <Label className="text-[10px] text-muted-foreground mb-1 block">Time of Day</Label>
        <div className="grid grid-cols-4 gap-1">
          {(["morning", "afternoon", "evening", "night"] as const).map(s => {
            const labels: Record<string, string> = { morning: "AM", afternoon: "PM", evening: "Eve", night: "Night" };
            const active = slot === s;
            return (
              <button
                key={s}
                data-testid={`button-slot-${s}`}
                onClick={() => setSlot(s)}
                className={`py-1 rounded-lg border text-[10px] font-medium transition-colors ${
                  active
                    ? "bg-primary/20 border-primary/50 text-primary"
                    : "border-border/30 text-muted-foreground hover:border-border/60"
                }`}
              >
                {labels[s]}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-[10px] text-muted-foreground mb-1 block">Duration (min)</Label>
          <Input
            data-testid="input-activity-duration"
            type="number" min={5} max={300} step={5}
            value={duration}
            onChange={e => setDuration(Number(e.target.value))}
            className="h-8 text-xs"
          />
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground mb-1 block">Effort (RPE 1–10)</Label>
          <Input
            data-testid="input-activity-rpe"
            type="number" min={1} max={10}
            value={rpe}
            onChange={e => setRpe(Math.max(1, Math.min(10, Number(e.target.value))))}
            className="h-8 text-xs"
          />
        </div>
      </div>

      <div className="flex gap-2 justify-end">
        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={onCancel}>Cancel</Button>
        <Button
          data-testid="button-add-activity"
          size="sm"
          className="h-7 text-xs"
          onClick={handleAdd}
          disabled={type === "cardio" && !name.trim()}
        >
          Add
        </Button>
      </div>
    </div>
  );
}

// ─── Day Activity Editor ──────────────────────────────────────────────────────

const SLOT_LABELS: Record<string, string> = { morning: "AM", afternoon: "PM", evening: "Eve", night: "Night" };

function DayEditor({
  dow,
  dayName,
  activities,
  onChange,
}: {
  dow: number;
  dayName: string;
  activities: BlockActivityTemplate[];
  onChange: (activities: BlockActivityTemplate[]) => void;
}) {
  const [addType, setAddType] = useState<"cardio" | "lifting" | null>(null);
  const [isRestDay, setIsRestDay] = useState(false);
  const au = computeDayAU(activities);
  const loadInfo = auToLoadLabel(au);

  const handleAdd = (act: BlockActivityTemplate) => {
    onChange([...activities, act]);
    setAddType(null);
  };

  const handleRemove = (idx: number) => {
    onChange(activities.filter((_, i) => i !== idx));
  };

  const handleRestToggle = () => {
    if (!isRestDay) {
      onChange([]);
      setAddType(null);
    }
    setIsRestDay(r => !r);
  };

  return (
    <div className={`rounded-xl border overflow-hidden transition-colors ${
      isRestDay ? "border-border/15 bg-muted/10" : "border-border/25 bg-card/40"
    }`}>
      {/* Day header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-border/20">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-semibold w-6 ${isRestDay ? "text-muted-foreground/50" : "text-foreground/80"}`}>
            {dayName}
          </span>
          {isRestDay ? (
            <span className="flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded-full border font-semibold bg-muted/30 border-border/30 text-muted-foreground/50">
              <Moon className="h-2.5 w-2.5" /> Rest Day
            </span>
          ) : (
            <>
              {activities.length > 0 && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full border font-semibold ${loadInfo.bg} ${loadInfo.border} ${loadInfo.color}`}>
                  {loadInfo.label}
                </span>
              )}
              {activities.length === 0 && (
                <span className="text-[10px] text-muted-foreground/40">Rest</span>
              )}
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          {/* Rest day toggle */}
          <button
            data-testid={`button-rest-toggle-${dow}`}
            onClick={handleRestToggle}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md border text-[10px] font-medium transition-colors ${
              isRestDay
                ? "border-primary/40 text-primary bg-primary/10"
                : "border-border/25 text-muted-foreground/50 hover:border-border/60 hover:text-muted-foreground"
            }`}
          >
            <Moon className="h-2.5 w-2.5" />
            Rest
          </button>
          {!addType && !isRestDay && (
            <>
              <button
                data-testid={`button-add-cardio-${dow}`}
                onClick={() => setAddType("cardio")}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md border border-border/30 text-[10px] text-muted-foreground hover:border-blue-500/40 hover:text-blue-400 transition-colors"
              >
                <Plus className="h-2.5 w-2.5" /> Session
              </button>
              <button
                data-testid={`button-add-lifting-${dow}`}
                onClick={() => setAddType("lifting")}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md border border-border/30 text-[10px] text-muted-foreground hover:border-purple-500/40 hover:text-purple-400 transition-colors"
              >
                <Plus className="h-2.5 w-2.5" /> Lift
              </button>
            </>
          )}
        </div>
      </div>

      {/* Activity chips */}
      {!isRestDay && activities.length > 0 && (
        <div className="px-3 py-2 flex flex-wrap gap-1.5">
          {activities.map((act, i) => (
            <div
              key={i}
              data-testid={`chip-activity-${dow}-${i}`}
              className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-medium ${
                act.activityType === "cardio"
                  ? "bg-blue-500/10 border-blue-500/25 text-blue-300"
                  : "bg-purple-500/10 border-purple-500/25 text-purple-300"
              }`}
            >
              {act.activityType === "cardio"
                ? <Swords className="h-3 w-3 shrink-0" />
                : <Dumbbell className="h-3 w-3 shrink-0" />}
              <span>{act.name}</span>
              <span className="text-[9px] opacity-70">{act.durationMinutes}m · R{act.rpe}</span>
              {act.slot && (
                <span className="text-[8px] opacity-50 border border-current/30 rounded px-0.5">
                  {SLOT_LABELS[act.slot] ?? act.slot}
                </span>
              )}
              <button
                data-testid={`button-remove-activity-${dow}-${i}`}
                onClick={() => handleRemove(i)}
                className="ml-0.5 opacity-60 hover:opacity-100 transition-opacity"
              >
                <X className="h-2.5 w-2.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add form */}
      {!isRestDay && addType && (
        <div className="px-3 pb-3 pt-1">
          <ActivityAddForm
            type={addType}
            onAdd={handleAdd}
            onCancel={() => setAddType(null)}
          />
        </div>
      )}
    </div>
  );
}

// ─── Main Modal ───────────────────────────────────────────────────────────────

export function TrainingBlockModal({ open, onClose, initialBlock }: Props) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  type DayActivities = Record<number, BlockActivityTemplate[]>;

  const [step, setStep] = useState(1);
  const [blockName, setBlockName] = useState("");
  const [startDate, setStartDate] = useState(getNextMonday);
  const [weekCount, setWeekCount] = useState(4);
  const [dayActivities, setDayActivities] = useState<DayActivities>({
    0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [],
  });
  const [preview, setPreview] = useState<PreviewResult | null>(null);
  const [overtrained, setOvertrained] = useState(false);
  const [acknowledged, setAcknowledged] = useState(false);
  const [ambersAcknowledged, setAmbersAcknowledged] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);

  const resetModal = useCallback(() => {
    setStep(1);
    setBlockName("");
    setStartDate(getNextMonday());
    setWeekCount(4);
    setDayActivities({ 0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] });
    setPreview(null);
    setOvertrained(false);
    setAcknowledged(false);
    setAmbersAcknowledged(false);
  }, []);

  // Pre-fill form from existing block when opening in edit mode
  useEffect(() => {
    if (open && initialBlock) {
      setBlockName(initialBlock.name);
      setStartDate(initialBlock.startDate);
      setWeekCount(initialBlock.weekCount);
      const prefilled: DayActivities = { 0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] };
      for (const day of initialBlock.days) {
        prefilled[day.dayOfWeek] = (day.activities ?? []) as BlockActivityTemplate[];
      }
      setDayActivities(prefilled);
      setStep(1);
      setPreview(null);
      setOvertrained(false);
      setAcknowledged(false);
    } else if (open && !initialBlock) {
      resetModal();
    }
  }, [open, initialBlock]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleClose = () => {
    resetModal();
    onClose();
  };

  const createMutation = useMutation({
    mutationFn: (data: { name: string; startDate: string; weekCount: number; days: any[] }) =>
      apiRequest("POST", "/api/training-blocks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-blocks/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"] });
      toast({ title: "Training block saved", description: `${blockName} is active — sessions created for each week.` });
      handleClose();
    },
    onError: () => toast({ title: "Failed to save block", variant: "destructive" }),
  });

  const buildDays = () =>
    Object.entries(dayActivities).map(([dow, acts]) => ({
      dayOfWeek: Number(dow),
      plannedLoad: "rest",
      activities: acts,
    }));

  const fetchPreview = async () => {
    setPreviewLoading(true);
    try {
      const res = await apiRequest("POST", "/api/training-blocks/preview", {
        startDate,
        weekCount,
        days: buildDays(),
      });
      const data: PreviewResult = await res.json();
      setPreview(data);
      setOvertrained(data.hasAnyOvertraining);
      setAcknowledged(false);
      setAmbersAcknowledged(false);
      setStep(3);
    } catch {
      toast({ title: "Could not load preview", variant: "destructive" });
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleSubmit = () => {
    if (!blockName.trim()) return;
    createMutation.mutate({ name: blockName.trim(), startDate, weekCount, days: buildDays() });
  };

  const chartData = preview?.weeks.map(w => ({
    name: `W${w.weekNum}`,
    avgLoad: w.avgLoad,
    acwr: w.peakAcwr,
    spike: w.hasSpike,
  })) ?? [];

  const totalActiveDays = Object.values(dayActivities).filter(a => a.length > 0).length;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleClose(); }}>
      <DialogContent className="max-w-lg w-full max-h-[90vh] overflow-y-auto p-0">
        {/* Header */}
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-border/30">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="font-display text-base font-semibold flex items-center gap-2">
                <Calendar className="h-4 w-4 text-primary" />
                Plan Training Block
              </DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground/60 mt-0.5">
                Define your weekly activities — sessions are created for each week automatically.
              </DialogDescription>
            </div>
            <button onClick={handleClose} className="text-muted-foreground hover:text-foreground transition-colors">
              <X className="h-4 w-4" />
            </button>
          </div>
          {/* Step indicators */}
          <div className="flex items-center gap-1.5 mt-3">
            {["Setup", "Activities", "Preview"].map((label, i) => {
              const s = i + 1;
              const active = step === s;
              const done = step > s;
              return (
                <div key={s} className="flex items-center gap-1.5">
                  <div className={`flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold ${
                    active ? "bg-primary text-primary-foreground" :
                    done   ? "bg-green-500/20 text-green-400 border border-green-500/30" :
                             "bg-muted text-muted-foreground"
                  }`}>
                    {done ? "✓" : s}
                  </div>
                  <span className={`text-[11px] ${active ? "text-foreground font-medium" : "text-muted-foreground"}`}>{label}</span>
                  {i < 2 && <ChevronRight className="h-3 w-3 text-muted-foreground/40" />}
                </div>
              );
            })}
          </div>
        </DialogHeader>

        {/* ── Step 1: Setup ──────────────────────────────────────── */}
        {step === 1 && (
          <div className="px-5 py-4 space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Block Name</Label>
              <Input
                data-testid="input-block-name"
                placeholder="e.g. Pre-camp Strength Block"
                value={blockName}
                onChange={e => setBlockName(e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Start Date</Label>
              <Input
                data-testid="input-block-start-date"
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="h-9 text-sm"
              />
              <p className="text-[11px] text-muted-foreground/50">Defaults to next Monday.</p>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-medium">Duration</Label>
              <div className="grid grid-cols-5 gap-2">
                {[2, 3, 4, 6, 8].map(w => (
                  <button
                    key={w}
                    data-testid={`button-week-${w}`}
                    onClick={() => setWeekCount(w)}
                    className={`h-9 rounded-lg border text-sm font-medium transition-colors ${
                      weekCount === w
                        ? "bg-primary text-primary-foreground border-primary"
                        : "border-border/40 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                    }`}
                  >
                    {w}w
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-end pt-1">
              <Button
                data-testid="button-next-schedule"
                size="sm"
                disabled={!blockName.trim() || !startDate}
                onClick={() => setStep(2)}
              >
                Next: Activities <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {/* ── Step 2: Activity Editor ────────────────────────────── */}
        {step === 2 && (
          <div className="px-4 py-4 space-y-2.5">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-muted-foreground leading-relaxed">
                Add sessions or strength work per day. This repeats for all {weekCount} weeks.
              </p>
            </div>

            {DAYS_OF_WEEK.map((dayName, dow) => (
              <DayEditor
                key={dow}
                dow={dow}
                dayName={dayName}
                activities={dayActivities[dow] ?? []}
                onChange={acts => setDayActivities(prev => ({ ...prev, [dow]: acts }))}
              />
            ))}

            {totalActiveDays === 0 && (
              <p className="text-[11px] text-muted-foreground/50 text-center py-1">
                Add at least one activity to any day to build a block.
              </p>
            )}

            <div className="flex justify-between pt-2">
              <Button variant="ghost" size="sm" onClick={() => setStep(1)}>
                <ChevronLeft className="h-3.5 w-3.5 mr-1" /> Back
              </Button>
              <Button
                data-testid="button-preview-load"
                size="sm"
                onClick={fetchPreview}
                disabled={previewLoading || totalActiveDays === 0}
              >
                {previewLoading ? "Analysing…" : <><Flame className="h-3.5 w-3.5 mr-1" /> Preview Load</>}
              </Button>
            </div>
          </div>
        )}

        {/* ── Step 3: Load Preview ──────────────────────────────── */}
        {step === 3 && preview && (
          <div className="px-5 py-4 space-y-4">
            {/* Chart */}
            <div>
              <p className="text-xs font-medium mb-2">Projected Peak ACWR by Week</p>
              <div className="h-36">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#9ca3af" }} />
                    <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} domain={[0, "auto"]} />
                    <Tooltip
                      contentStyle={{ background: "#1a1a2e", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 6, fontSize: 11, color: "#e5e7eb" }}
                      labelStyle={{ color: "#e5e7eb", fontWeight: 600, marginBottom: 2 }}
                      itemStyle={{ color: "#d1d5db" }}
                      formatter={(v: number, name: string) =>
                        name === "acwr" ? [`${v} ACWR`, "Peak ACWR"] : [`${v} AU`, "Avg Load"]
                      }
                    />
                    <ReferenceLine y={1.5} stroke="#ef4444" strokeDasharray="4 2" label={{ value: "Spike", fill: "#ef4444", fontSize: 9, position: "right" }} />
                    <ReferenceLine y={1.3} stroke="#f97316" strokeDasharray="4 2" label={{ value: "Elevated", fill: "#f97316", fontSize: 9, position: "right" }} />
                    <Bar dataKey="acwr" radius={[3, 3, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={index} fill={acwrBarColor(entry.acwr)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[10px] text-muted-foreground/50 text-center mt-1">
                Green ≤ 1.3 · Orange 1.3–1.5 · Red {">"} 1.5 (overtraining risk)
              </p>
            </div>

            {/* Week breakdown */}
            <div className="space-y-1.5">
              {preview.weeks.map(w => (
                <div
                  key={w.weekNum}
                  className={`flex items-center justify-between p-2.5 rounded-lg border ${
                    w.hasSpike
                      ? "bg-red-500/8 border-red-500/25"
                      : w.hasCluster
                      ? "bg-orange-500/8 border-orange-500/20"
                      : "bg-muted/20 border-border/30"
                  }`}
                >
                  <div>
                    <p className="text-xs font-medium">
                      Week {w.weekNum}
                      <span className="text-muted-foreground font-normal ml-1.5 text-[11px]">
                        {format(new Date(w.startDate), "d MMM")} – {format(new Date(w.endDate), "d MMM")}
                      </span>
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {w.days.filter(d => d.load > 0).map((d, i) => {
                        const cfg = auToLoadLabel(d.load);
                        return (
                          <span
                            key={i}
                            className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold ${cfg.bg} ${cfg.border} ${cfg.color}`}
                          >
                            {DAYS_OF_WEEK[d.dow]}
                          </span>
                        );
                      })}
                    </div>
                    {w.warningReasons && w.warningReasons.length > 0 && (
                      <div className="flex flex-col gap-0.5 mt-1.5">
                        {w.warningReasons.map((reason, ri) => (
                          <div key={ri} className="flex items-center gap-1">
                            <Info className={`h-2.5 w-2.5 shrink-0 ${w.hasSpike ? "text-red-400" : "text-orange-400"}`} />
                            <span className={`text-[9px] ${w.hasSpike ? "text-red-400/80" : "text-orange-400/80"}`}>
                              {reason}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <div className={`text-sm font-bold ${
                      (w.peakAcwr ?? 0) > 1.5 ? "text-red-400" :
                      (w.peakAcwr ?? 0) > 1.3 ? "text-orange-400" : "text-green-400"
                    }`}>
                      {w.peakAcwr !== null ? w.peakAcwr.toFixed(2) : "—"}
                    </div>
                    <div className="text-[10px] text-muted-foreground/60">ACWR</div>
                    {w.hasSpike && (
                      <Badge variant="outline" className="text-[9px] px-1 py-0 mt-0.5 border-red-500/40 text-red-400">⚠ Spike</Badge>
                    )}
                    {!w.hasSpike && w.hasCluster && (
                      <Badge variant="outline" className="text-[9px] px-1 py-0 mt-0.5 border-orange-500/40 text-orange-400">Cluster</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Derive warning state */}
            {(() => {
              const hasAnyWarnings = preview.weeks.some(w => (w.warningReasons ?? []).length > 0);
              const allReasons = Array.from(new Set(
                preview.weeks.flatMap(w => w.warningReasons ?? [])
              ));
              const blockCommit = (overtrained && !acknowledged) ||
                (!overtrained && hasAnyWarnings && !ambersAcknowledged);

              return (
                <>
                  {/* Red — overtraining spike */}
                  {overtrained && !acknowledged && (
                    <div className="rounded-xl border border-red-500/40 bg-red-500/8 p-4 space-y-3">
                      <div className="flex items-start gap-2">
                        <ShieldAlert className="h-4 w-4 text-red-400 mt-0.5 shrink-0" />
                        <div>
                          <p className="text-sm font-semibold text-red-400">Overtraining Risk Detected</p>
                          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                            One or more weeks project a training spike (ACWR {">"} 1.5) relative to your baseline.
                            Consider adding rest days or reducing session intensity before committing.
                          </p>
                        </div>
                      </div>
                      <Button
                        data-testid="button-acknowledge-overtraining"
                        variant="outline"
                        size="sm"
                        className="w-full border-red-500/40 text-red-400 hover:bg-red-500/15"
                        onClick={() => setAcknowledged(true)}
                      >
                        I understand the risk — proceed anyway
                      </Button>
                    </div>
                  )}

                  {overtrained && acknowledged && (
                    <div className="flex items-center gap-2 text-xs text-orange-400/80 bg-orange-500/8 border border-orange-500/20 rounded-lg px-3 py-2">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      Overtraining risk acknowledged. Monitor your recovery closely.
                    </div>
                  )}

                  {/* Amber — cluster / elevated warnings (no full spike) */}
                  {!overtrained && hasAnyWarnings && !ambersAcknowledged && (
                    <div className="rounded-xl border border-amber-500/40 bg-amber-500/8 p-4 space-y-3">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-amber-400">Load Warnings Detected</p>
                          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                            Your plan has elevated load patterns. This can increase fatigue and reduce recovery if sustained.
                          </p>
                          <ul className="mt-2 space-y-0.5">
                            {allReasons.map((r, i) => (
                              <li key={i} className="flex items-center gap-1.5 text-[11px] text-amber-400/80">
                                <span className="w-1 h-1 rounded-full bg-amber-400/60 shrink-0" />
                                {r}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      <Button
                        data-testid="button-acknowledge-warnings"
                        variant="outline"
                        size="sm"
                        className="w-full border-amber-500/40 text-amber-400 hover:bg-amber-500/15"
                        onClick={() => setAmbersAcknowledged(true)}
                      >
                        I've reviewed the warnings — proceed
                      </Button>
                    </div>
                  )}

                  {!overtrained && hasAnyWarnings && ambersAcknowledged && (
                    <div className="flex items-center gap-2 text-xs text-amber-400/80 bg-amber-500/8 border border-amber-500/20 rounded-lg px-3 py-2">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      Load warnings noted. Monitor fatigue and recovery during this block.
                    </div>
                  )}

                  {/* Green — only when no warnings at all */}
                  {!overtrained && !hasAnyWarnings && (
                    <div className="flex items-center gap-2 text-xs text-green-400/80 bg-green-500/8 border border-green-500/20 rounded-lg px-3 py-2">
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                      Load looks sustainable — no projected spikes above 1.5.
                    </div>
                  )}

                  <div className="flex justify-between pt-1">
                    <Button variant="ghost" size="sm" onClick={() => setStep(2)}>
                      <ChevronLeft className="h-3.5 w-3.5 mr-1" /> Edit Activities
                    </Button>
                    <Button
                      data-testid="button-commit-block"
                      size="sm"
                      disabled={blockCommit || createMutation.isPending}
                      onClick={handleSubmit}
                    >
                      {createMutation.isPending ? "Saving…" : "Commit Block"}
                    </Button>
                  </div>
                </>
              );
            })()}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
