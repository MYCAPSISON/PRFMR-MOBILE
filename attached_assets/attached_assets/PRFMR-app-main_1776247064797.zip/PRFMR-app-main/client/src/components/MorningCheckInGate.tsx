import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { Moon, Scale, Dumbbell, Check, Star } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useMorningCheckInGate } from "@/hooks/useMorningCheckInGate";

export function MorningCheckInGate() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const { shouldShow, status, today, markSeen, allDone } = useMorningCheckInGate();

  const [showSleepForm, setShowSleepForm] = useState(false);
  const [sleepHours, setSleepHours] = useState("");
  const [sleepQuality, setSleepQuality] = useState<number | null>(null);

  const [showWeightForm, setShowWeightForm] = useState(false);
  const [weightInput, setWeightInput] = useState("");

  const gateWasOpen = useRef(false);
  const prevAllDone = useRef(false);

  useEffect(() => {
    if (shouldShow) gateWasOpen.current = true;
  }, [shouldShow]);

  useEffect(() => {
    if (gateWasOpen.current && allDone && !prevAllDone.current) {
      markSeen();
      toast({ title: "Check-in complete — your targets are up to date" });
    }
    prevAllDone.current = allDone;
  }, [allDone]);

  const sleepMutation = useMutation({
    mutationFn: (data: { hoursSlept: number; sleepQuality: number | null }) =>
      apiRequest("PUT", `/api/me/sleep/${today}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", today] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      setShowSleepForm(false);
      setSleepHours("");
      setSleepQuality(null);
      toast({ title: "Sleep logged" });
    },
  });

  const weightMutation = useMutation({
    mutationFn: (data: { date: string; weight: number }) =>
      apiRequest("POST", "/api/weights", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", today] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/weights/range"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      setShowWeightForm(false);
      setWeightInput("");
      toast({ title: "Weight logged" });
    },
  });

  function handleSleepSubmit() {
    const hours = parseFloat(sleepHours);
    if (isNaN(hours) || hours < 0 || hours > 24) return;
    sleepMutation.mutate({ hoursSlept: hours, sleepQuality });
  }

  function handleWeightSubmit() {
    const w = parseFloat(weightInput);
    if (isNaN(w) || w <= 0) return;
    weightMutation.mutate({ date: today, weight: w });
  }

  function handleContinue() {
    markSeen();
    if (!allDone) {
      toast({ title: "You can complete your check-in anytime from the dashboard" });
    }
  }

  function navigateToTraining() {
    markSeen();
    navigate("/training");
  }

  if (!status) return null;

  return (
    <Dialog open={shouldShow} onOpenChange={(open) => { if (!open) handleContinue(); }}>
      <DialogContent
        className="max-w-sm w-[calc(100%-2rem)] rounded-xl p-0 gap-0 overflow-hidden"
        data-testid="modal-morning-checkin-gate"
      >
        <div className="p-5 space-y-4">
          <DialogHeader className="space-y-1">
            <DialogTitle className="font-display text-base font-semibold">
              Start your day
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Complete your check-in to get accurate readiness and fuel targets
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            {/* Sleep row */}
            {!status.hasSleep && !showSleepForm && (
              <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-secondary/10">
                <Moon className="h-4 w-4 text-primary shrink-0" />
                <p className="text-sm font-medium flex-1 min-w-0">Log last night's sleep</p>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs h-7 px-3 shrink-0 border-primary text-primary"
                  onClick={() => setShowSleepForm(true)}
                  data-testid="gate-cta-sleep"
                >
                  Log
                </Button>
              </div>
            )}

            {!status.hasSleep && showSleepForm && (
              <div className="p-3 rounded-lg border border-primary/30 bg-secondary/10 space-y-3">
                <div className="flex items-center gap-2">
                  <Moon className="h-4 w-4 text-primary" />
                  <Label className="text-sm font-medium">Hours slept</Label>
                </div>
                <Input
                  type="number"
                  step="0.5"
                  min="0"
                  max="24"
                  placeholder="e.g., 7.5"
                  value={sleepHours}
                  onChange={(e) => setSleepHours(e.target.value)}
                  autoFocus
                  data-testid="gate-input-sleep-hours"
                />
                <div>
                  <Label className="text-xs text-muted-foreground">Quality (optional)</Label>
                  <div className="flex gap-1 mt-1">
                    {[1, 2, 3, 4, 5].map((q) => (
                      <button
                        key={q}
                        onClick={() => setSleepQuality(sleepQuality === q ? null : q)}
                        className="p-1"
                        data-testid={`gate-sleep-quality-${q}`}
                      >
                        <Star
                          className={`h-5 w-5 ${
                            sleepQuality && q <= sleepQuality
                              ? "text-yellow-400 fill-yellow-400"
                              : "text-muted-foreground/30"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={handleSleepSubmit}
                    disabled={sleepMutation.isPending || !sleepHours}
                    data-testid="gate-submit-sleep"
                  >
                    {sleepMutation.isPending ? "Saving…" : "Save"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowSleepForm(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {status.hasSleep && (
              <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-secondary/10">
                <Moon className="h-4 w-4 text-primary shrink-0" />
                <p className="text-sm font-medium flex-1 min-w-0 text-muted-foreground">Sleep logged</p>
                <Check className="h-4 w-4 text-green-500 shrink-0" />
              </div>
            )}

            {/* Weight row */}
            {!status.hasWeight && !showWeightForm && (
              <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-secondary/10">
                <Scale className="h-4 w-4 text-primary shrink-0" />
                <p className="text-sm font-medium flex-1 min-w-0">Log today's weight</p>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs h-7 px-3 shrink-0 border-primary/40 text-primary/80"
                  onClick={() => setShowWeightForm(true)}
                  data-testid="gate-cta-weight"
                >
                  Log
                </Button>
              </div>
            )}

            {!status.hasWeight && showWeightForm && (
              <div className="p-3 rounded-lg border border-primary/30 bg-secondary/10 space-y-3">
                <div className="flex items-center gap-2">
                  <Scale className="h-4 w-4 text-primary" />
                  <Label className="text-sm font-medium">Morning weight (kg)</Label>
                </div>
                <Input
                  type="number"
                  step="0.1"
                  min="20"
                  max="300"
                  placeholder="e.g., 72.4"
                  value={weightInput}
                  onChange={(e) => setWeightInput(e.target.value)}
                  autoFocus
                  data-testid="gate-input-weight"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={handleWeightSubmit}
                    disabled={weightMutation.isPending || !weightInput}
                    data-testid="gate-submit-weight"
                  >
                    {weightMutation.isPending ? "Saving…" : "Save"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowWeightForm(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {status.hasWeight && (
              <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-secondary/10">
                <Scale className="h-4 w-4 text-primary shrink-0" />
                <p className="text-sm font-medium flex-1 min-w-0 text-muted-foreground">Weight logged</p>
                <Check className="h-4 w-4 text-green-500 shrink-0" />
              </div>
            )}

            {/* Training row */}
            <div className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-secondary/10">
              <Dumbbell className="h-4 w-4 text-primary shrink-0" />
              <p className="text-sm font-medium flex-1 min-w-0">
                {status.hasPlannedTraining ? "Session created" : "Create today's session"}
              </p>
              {status.hasPlannedTraining ? (
                <Check className="h-4 w-4 text-green-500 shrink-0" />
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs h-7 px-3 shrink-0 border-primary/40 text-primary/80"
                  onClick={navigateToTraining}
                  data-testid="gate-cta-training"
                >
                  Add
                </Button>
              )}
            </div>
          </div>

          {!allDone && (
            <p className="text-xs text-muted-foreground text-center leading-relaxed">
              Your macro and fuel targets will be less accurate
            </p>
          )}

          <Button
            className="w-full"
            onClick={handleContinue}
            data-testid="button-gate-continue"
          >
            Continue
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
