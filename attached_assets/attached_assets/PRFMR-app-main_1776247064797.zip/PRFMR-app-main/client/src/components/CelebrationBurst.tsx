import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { celebrationBus, type CelebrationEvent } from "@/lib/celebration";

interface Particle {
  id: number;
  emoji: string;
  xOffset: number;
  delay: number;
  scale: number;
}

let pid = 0;

const SPREAD_OFFSETS = [-60, -30, 0, 30, 60];

export function CelebrationBurst() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const handler = (e: Event) => {
      const emoji = (e as CustomEvent<CelebrationEvent>).detail.emoji;
      const batch: Particle[] = SPREAD_OFFSETS.map((xOffset, i) => ({
        id: pid++,
        emoji,
        xOffset: xOffset + (Math.random() - 0.5) * 15,
        delay: i * 0.06,
        scale: 0.85 + Math.random() * 0.45,
      }));
      setParticles((prev) => [...prev, ...batch]);
      setTimeout(() => {
        const ids = new Set(batch.map((p) => p.id));
        setParticles((prev) => prev.filter((p) => !ids.has(p.id)));
      }, 1800);
    };

    celebrationBus.addEventListener("celebrate", handler);
    return () => celebrationBus.removeEventListener("celebrate", handler);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[200]" aria-hidden>
      <AnimatePresence>
        {particles.map((p) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 1, y: 0, x: p.xOffset, scale: p.scale * 0.7 }}
            animate={{
              opacity: 0,
              y: -160,
              x: p.xOffset + (Math.random() - 0.5) * 25,
              scale: p.scale,
            }}
            exit={{}}
            transition={{ duration: 1.25, delay: p.delay, ease: [0.2, 0.8, 0.4, 1] }}
            style={{
              position: "absolute",
              bottom: "96px",
              left: "50%",
              fontSize: "1.6rem",
              lineHeight: 1,
              userSelect: "none",
            }}
          >
            {p.emoji}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
