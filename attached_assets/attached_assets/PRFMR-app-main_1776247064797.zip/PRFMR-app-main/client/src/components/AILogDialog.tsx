/**
 * AI-Assisted Logging Dialog
 *
 * Flow: Input → Parse → Review → Confirm → Save (via existing APIs)
 * The user must always confirm before anything is saved.
 * See docs/ai_assisted_logging.md for full documentation.
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, addDays, parseISO } from "date-fns";
import { Mic, MicOff, Loader2, CheckCircle2, XCircle, ArrowLeft, Sparkles, Edit2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  parseAiLogInput,
  type ParseResult,
  type ParsedFood,
  type ParsedWeight,
  type ParsedTraining,
  type ParsedSupplements,
  type ParsedRecurring,
  type FoodItem,
} from "@/lib/aiLogParser";
import { getCoreFoodUnit, computeUnitGrams } from "@/lib/coreFoodUnits";
import type { UnitSize } from "@/lib/coreFoodUnits";

interface AILogDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  date: string;
  onSuccess?: () => void;
}

type DialogState = "input" | "review" | "saving" | "done";

// ─── Ingredient matching ─────────────────────────────────────────────────────

interface Ingredient {
  name: string;
  calories_per_100g: number;
  protein_g_per_100g: number;
  carbs_g_per_100g: number;
  fat_g_per_100g: number;
  fibre_g_per_100g?: number;
}

interface ResolvedFoodItem {
  originalItem: FoodItem;
  ingredient: Ingredient | null;
  ingredientIndex: number | null;
  grams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fibre: number;
  confirmed: boolean;
}

function matchIngredient(
  query: string,
  ingredients: Ingredient[]
): { ingredient: Ingredient; index: number } | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  let best: { ingredient: Ingredient; index: number; score: number } | null = null;

  for (let i = 0; i < ingredients.length; i++) {
    const ing = ingredients[i];
    const name = ing.name.toLowerCase();
    let score = 0;

    if (name === q) { score = 100; }
    else if (name.startsWith(q)) { score = 80; }
    else if (name.includes(q)) { score = 60; }
    else if (q.includes(name)) { score = 50; }
    else {
      // Word-by-word overlap
      const qWords = q.split(/\s+/);
      const nWords = name.split(/[\s()]+/);
      const overlap = qWords.filter(w => w.length > 2 && nWords.some(nw => nw.includes(w) || w.includes(nw)));
      if (overlap.length > 0) score = overlap.length * 15;
    }

    if (score > 0 && (!best || score > best.score)) {
      best = { ingredient: ing, index: i, score };
    }
  }

  return best ? { ingredient: best.ingredient, index: best.index } : null;
}

function calcMacros(ing: Ingredient, grams: number) {
  const ratio = grams / 100;
  return {
    calories: Math.round(ing.calories_per_100g * ratio),
    protein: Math.round(ing.protein_g_per_100g * ratio),
    carbs: Math.round(ing.carbs_g_per_100g * ratio),
    fat: Math.round(ing.fat_g_per_100g * ratio),
    fibre: Math.round((ing.fibre_g_per_100g ?? 0) * ratio),
  };
}

function resolveGrams(item: FoodItem, ingredient: Ingredient | null): number {
  if (item.gramsHint) return item.gramsHint;
  if (ingredient && item.count) {
    const unit = getCoreFoodUnit(ingredient.name);
    if (unit) {
      const size: UnitSize = item.sizeHint ?? "medium";
      return computeUnitGrams(unit, item.count, size);
    }
    return Math.round(100 * item.count);
  }
  if (item.count) return Math.round(100 * item.count);
  return 100;
}

// ─── Supplement matching ─────────────────────────────────────────────────────

interface Supplement {
  id: number;
  name: string;
  stackId?: number | null;
}

function matchSupplement(
  query: string,
  supplements: Supplement[]
): Supplement | null {
  const q = query.toLowerCase().trim();
  let best: { sup: Supplement; score: number } | null = null;
  for (const sup of supplements) {
    const name = sup.name.toLowerCase();
    let score = 0;
    if (name === q) score = 100;
    else if (name.includes(q) || q.includes(name)) score = 60;
    else {
      const qw = q.split(/\s+/);
      const nw = name.split(/\s+/);
      const overlap = qw.filter(w => w.length > 2 && nw.some(nw2 => nw2.includes(w) || w.includes(nw2)));
      if (overlap.length) score = overlap.length * 20;
    }
    if (score > 0 && (!best || score > best.score)) best = { sup, score };
  }
  return best ? best.sup : null;
}

// ─── Next weekday helper ─────────────────────────────────────────────────────

const DAY_IDX: Record<string, 0 | 1 | 2 | 3 | 4 | 5 | 6> = {
  Sunday: 0, Monday: 1, Tuesday: 2, Wednesday: 3,
  Thursday: 4, Friday: 5, Saturday: 6,
};

function getNextDayDate(dayOfWeek: string): string {
  const targetDay = DAY_IDX[dayOfWeek];
  if (targetDay === undefined) return format(new Date(), "yyyy-MM-dd");
  const today = new Date();
  const todayDay = today.getDay();
  let daysAhead = targetDay - todayDay;
  if (daysAhead <= 0) daysAhead += 7;
  return format(addDays(today, daysAhead), "yyyy-MM-dd");
}

// ─── Confidence badge ────────────────────────────────────────────────────────

function ConfidenceBadge({ confidence }: { confidence: string }) {
  if (confidence === "high") return <Badge className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs">High confidence</Badge>;
  if (confidence === "medium") return <Badge className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 text-xs">Review carefully</Badge>;
  return <Badge className="bg-red-500/20 text-red-400 border border-red-500/30 text-xs">Low confidence</Badge>;
}

// ─── Main Dialog ──────────────────────────────────────────────────────────────

export function AILogDialog({ open, onOpenChange, date, onSuccess }: AILogDialogProps) {
  const { toast } = useToast();
  const qc = useQueryClient();

  const [state, setDialogState] = useState<DialogState>("input");
  const [inputText, setInputText] = useState("");
  const [parsed, setParsed] = useState<ParseResult | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [interimText, setInterimText] = useState("");
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Food-specific state
  const [resolvedItems, setResolvedItems] = useState<ResolvedFoodItem[]>([]);

  // Supplement-specific state
  const [selectedSupplements, setSelectedSupplements] = useState<Array<{
    raw: string;
    matched: Supplement | null;
    included: boolean;
  }>>([]);

  // Training-specific state
  const [trainingEdits, setTrainingEdits] = useState({
    activityName: "",
    durationMinutes: 60,
    timeOfDay: "morning" as "morning" | "afternoon" | "evening",
    timeLabel: "",
  });
  const [activitySearchQ, setActivitySearchQ] = useState("");

  // Activity catalog suggestions (debounced via state + staleTime)
  const { data: activitySuggestions = [] } = useQuery<{ id: number; name: string; metValue?: number; activityType?: string }[]>({
    queryKey: ["/api/activities", activitySearchQ],
    queryFn: async () => {
      if (!activitySearchQ.trim()) return [];
      const res = await fetch(`/api/activities?query=${encodeURIComponent(activitySearchQ)}`, { credentials: "include" });
      if (!res.ok) return [];
      const all = await res.json();
      return Array.isArray(all) ? all.slice(0, 5) : [];
    },
    enabled: activitySearchQ.trim().length >= 2,
    staleTime: 60_000,
  });

  // Weight-specific state
  const [weightValue, setWeightValue] = useState<number>(0);

  // Load ingredients for food matching
  const { data: ingredients = [] } = useQuery<Ingredient[]>({
    queryKey: ["/api/ingredients"],
    enabled: !!open,
    staleTime: 5 * 60 * 1000,
  });

  // Load user supplements for supplement matching
  const { data: userSupplements = [] } = useQuery<Supplement[]>({
    queryKey: ["/api/me/supplements"],
    enabled: !!open,
  });

  // Reset when dialog closes
  useEffect(() => {
    if (!open) {
      setDialogState("input");
      setInputText("");
      setParsed(null);
      setResolvedItems([]);
      setSelectedSupplements([]);
      setIsListening(false);
    }
  }, [open]);

  // ── Voice input ────────────────────────────────────────────────────────────

  const SILENCE_TIMEOUT_MS = 3000;

  const stopListening = useCallback(() => {
    if (silenceTimerRef.current) { clearTimeout(silenceTimerRef.current); silenceTimerRef.current = null; }
    recognitionRef.current?.stop();
    setIsListening(false);
    setInterimText("");
  }, []);

  const toggleVoice = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast({ title: "Voice not supported", description: "Use text input instead.", variant: "destructive" });
      return;
    }

    if (isListening) {
      stopListening();
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-GB";
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    const resetSilenceTimer = () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = setTimeout(() => {
        stopListening();
      }, SILENCE_TIMEOUT_MS);
    };

    recognition.onresult = (event: any) => {
      let finalTranscript = "";
      let interimTranscript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalTranscript += result[0].transcript;
        } else {
          interimTranscript += result[0].transcript;
        }
      }
      if (finalTranscript) {
        setInputText(prev => (prev ? prev + " " : "") + finalTranscript.trim());
        setInterimText("");
      } else {
        setInterimText(interimTranscript);
      }
      resetSilenceTimer();
    };

    recognition.onerror = () => stopListening();
    recognition.onend = () => {
      setIsListening(false);
      setInterimText("");
    };

    recognition.start();
    setIsListening(true);
    resetSilenceTimer();
  }, [isListening, stopListening, toast]);

  // ── Parse handler ──────────────────────────────────────────────────────────

  const handleParse = useCallback(() => {
    if (!inputText.trim()) return;
    const result = parseAiLogInput(inputText.trim());
    setParsed(result);

    if (result.intent === "log_food") {
      const items = result.items.map(item => {
        const match = matchIngredient(item.normalizedName, ingredients);
        const grams = resolveGrams(item, match?.ingredient ?? null);
        const macros = match ? calcMacros(match.ingredient, grams) : { calories: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 };
        return {
          originalItem: item,
          ingredient: match?.ingredient ?? null,
          ingredientIndex: match?.index ?? null,
          grams,
          ...macros,
          confirmed: true,
        };
      });
      setResolvedItems(items);
    }

    if (result.intent === "log_supplements") {
      const matched = result.items.map(raw => ({
        raw,
        matched: matchSupplement(raw, userSupplements),
        included: true,
      }));
      setSelectedSupplements(matched);
    }

    if (result.intent === "log_training_session") {
      setTrainingEdits({
        activityName: result.activityName,
        durationMinutes: result.durationMinutes,
        timeOfDay: result.timeOfDay,
        timeLabel: result.timeLabel ?? "",
      });
      setActivitySearchQ(result.activityName);
    }

    if (result.intent === "log_weight") {
      setWeightValue(result.weightKg);
    }

    if (result.intent === "create_recurring_training_schedule") {
      // Sessions pulled from parse result directly
    }

    setDialogState("review");
  }, [inputText, ingredients, userSupplements]);

  // ── Confirm handlers ──────────────────────────────────────────────────────

  const confirmFood = useMutation({
    mutationFn: async (p: ParsedFood) => {
      const toSave = resolvedItems.filter(r => r.confirmed && r.ingredient !== null);
      if (toSave.length === 0) throw new Error("No confirmed food items with matched ingredients.");

      for (const item of toSave) {
        await apiRequest("POST", "/api/food", {
          date,
          name: item.ingredient!.name,
          grams: item.grams,
          calories: item.calories,
          protein: item.protein,
          carbs: item.carbs,
          fat: item.fat,
          fibre: item.fibre,
          meal: p.meal,
          sourceType: "ingredient",
          ingredientIndex: item.ingredientIndex,
          macroSource: "ingredient",
          microSource: "ingredient",
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [`/api/me/food/${date}`] });
      qc.invalidateQueries({ queryKey: ["/api/me/amqs/score"] });
      toast({ title: `${resolvedItems.filter(r => r.confirmed && r.ingredient).length} item(s) logged` });
      setDialogState("done");
    },
    onError: (err: any) => toast({ title: "Failed to save", description: err.message, variant: "destructive" }),
  });

  const confirmWeight = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/weights", { date, weight: weightValue });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/me/weights/range"] });
      qc.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      qc.invalidateQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      qc.invalidateQueries({ queryKey: ["/api/me/morning-status"] });
      toast({ title: `Weight logged — ${weightValue} kg` });
      setDialogState("done");
    },
    onError: (err: any) => toast({ title: "Failed to save", description: err.message, variant: "destructive" }),
  });

  const confirmTraining = useMutation({
    mutationFn: async () => {
      const session = await apiRequest("POST", "/api/workouts/sessions", {
        date,
        timeOfDay: trainingEdits.timeOfDay,
        title: trainingEdits.activityName,
        intensity: "moderate",
      });
      const sessionData = await session.json();

      // Search activity catalog for best match
      const catalogRes = await fetch(
        `/api/activities?query=${encodeURIComponent(trainingEdits.activityName)}`,
        { credentials: "include" }
      );
      const catalog: any[] = catalogRes.ok ? await catalogRes.json() : [];
      const bestActivity = catalog[0];

      await apiRequest("POST", `/api/workouts/sessions/${sessionData.id}/activities`, {
        name: trainingEdits.activityName,
        durationMinutes: trainingEdits.durationMinutes,
        intensity: "moderate",
        activityType: "cardio",
        metValue: bestActivity?.metValue ?? 6,
        activityCatalogId: bestActivity?.id ?? null,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/workouts/sessions"] });
      qc.invalidateQueries({ queryKey: ["/api/me/training/summary"] });
      qc.invalidateQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      toast({ title: "Training session logged" });
      setDialogState("done");
    },
    onError: (err: any) => toast({ title: "Failed to save", description: err.message, variant: "destructive" }),
  });

  const confirmSupplements = useMutation({
    mutationFn: async () => {
      const toSave = selectedSupplements.filter(s => s.included && s.matched);
      if (toSave.length === 0) throw new Error("No matched supplements to log.");
      for (const item of toSave) {
        await apiRequest("POST", "/api/supplement-intakes", {
          supplementId: item.matched!.id,
          stackId: item.matched!.stackId ?? null,
          date,
          taken: true,
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [`/api/me/supplement-intakes/${date}`] });
      toast({ title: `${selectedSupplements.filter(s => s.included && s.matched).length} supplement(s) marked taken` });
      setDialogState("done");
    },
    onError: (err: any) => toast({ title: "Failed to save", description: err.message, variant: "destructive" }),
  });

  const confirmRecurring = useMutation({
    mutationFn: async (p: ParsedRecurring) => {
      const targetDate = getNextDayDate(p.dayOfWeek);
      for (const sess of p.sessions) {
        const sessionRes = await apiRequest("POST", "/api/workouts/sessions", {
          date: targetDate,
          timeOfDay: sess.timeOfDay,
          title: sess.activityName,
          intensity: "moderate",
        });
        const sessionData = await sessionRes.json();
        const catalogRes = await fetch(
          `/api/activities?query=${encodeURIComponent(sess.activityName)}`,
          { credentials: "include" }
        );
        const catalog: any[] = catalogRes.ok ? await catalogRes.json() : [];
        const bestActivity = catalog[0];
        await apiRequest("POST", `/api/workouts/sessions/${sessionData.id}/activities`, {
          name: sess.activityName,
          durationMinutes: sess.durationMinutes,
          intensity: "moderate",
          activityType: "cardio",
          metValue: bestActivity?.metValue ?? 6,
          activityCatalogId: bestActivity?.id ?? null,
        });
      }
    },
    onSuccess: (_, p) => {
      qc.invalidateQueries({ queryKey: ["/api/workouts/sessions"] });
      qc.invalidateQueries({ queryKey: ["/api/me/training/summary"] });
      toast({ title: `Sessions created for next ${p.dayOfWeek}` });
      setDialogState("done");
    },
    onError: (err: any) => toast({ title: "Failed to save", description: err.message, variant: "destructive" }),
  });

  const isSaving =
    confirmFood.isPending ||
    confirmWeight.isPending ||
    confirmTraining.isPending ||
    confirmSupplements.isPending ||
    confirmRecurring.isPending;

  // ── Render helpers ────────────────────────────────────────────────────────

  function renderFoodReview(p: ParsedFood) {
    const confirmed = resolvedItems.filter(r => r.confirmed && r.ingredient);
    const unmatched = resolvedItems.filter(r => !r.ingredient);
    const totalCal = confirmed.reduce((s, r) => s + r.calories, 0);
    const totalPro = confirmed.reduce((s, r) => s + r.protein, 0);

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="capitalize">{p.meal}</Badge>
          <ConfidenceBadge confidence={p.confidence} />
        </div>

        <p className="text-sm font-medium">Log this meal?</p>

        <div className="space-y-2">
          {resolvedItems.map((item, i) => (
            <div key={i} className={`flex items-start gap-3 rounded-lg border p-3 text-sm transition-opacity ${item.confirmed ? "bg-card" : "opacity-40"}`}>
              <button
                className="mt-0.5 flex-shrink-0"
                onClick={() => setResolvedItems(prev => prev.map((r, j) => j === i ? { ...r, confirmed: !r.confirmed } : r))}
                data-testid={`ai-food-toggle-${i}`}
                type="button"
              >
                {item.confirmed
                  ? <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  : <XCircle className="h-4 w-4 text-muted-foreground" />
                }
              </button>
              <div className="flex-1 min-w-0">
                {item.ingredient ? (
                  <>
                    <div className="font-medium truncate">{item.ingredient.name}</div>
                    <div className="text-xs text-muted-foreground flex gap-3 mt-0.5">
                      <span>
                        <input
                          className="w-14 bg-secondary/50 rounded px-1 py-0.5 text-xs text-center font-mono"
                          type="number"
                          min={1}
                          value={item.grams}
                          data-testid={`ai-food-grams-${i}`}
                          onChange={e => {
                            const g = parseInt(e.target.value) || 100;
                            const m = calcMacros(item.ingredient!, g);
                            setResolvedItems(prev => prev.map((r, j) => j === i ? { ...r, grams: g, ...m } : r));
                          }}
                        />g
                      </span>
                      <span>{item.calories} kcal</span>
                      <span>{item.protein}g P</span>
                      <span>{item.carbs}g C</span>
                      <span>{item.fat}g F</span>
                    </div>
                  </>
                ) : (
                  <div className="text-muted-foreground italic">
                    Unrecognised: "{item.originalItem.normalizedName}" — deselected
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {unmatched.length > 0 && (
          <p className="text-xs text-muted-foreground">
            {unmatched.length} item(s) not matched to the ingredient list — they will be skipped. Use "Add Food" to log them manually.
          </p>
        )}

        {confirmed.length > 0 && (
          <div className="rounded-lg bg-secondary/40 px-3 py-2 text-xs text-muted-foreground flex gap-4">
            <span>Total: {totalCal} kcal</span>
            <span>{totalPro}g protein</span>
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <Button
            size="sm"
            disabled={confirmed.length === 0 || isSaving}
            onClick={() => confirmFood.mutate(p)}
            data-testid="ai-confirm-food"
          >
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : null}
            Log {confirmed.length} item(s)
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
      </div>
    );
  }

  function renderWeightReview(_p: ParsedWeight) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <ConfidenceBadge confidence={_p.confidence} />
        </div>
        <p className="text-sm font-medium">Log morning weight?</p>
        <div className="flex items-center gap-3 rounded-lg border bg-card p-3">
          <div className="text-2xl font-mono font-bold">{weightValue}</div>
          <div className="text-muted-foreground">kg</div>
          <input
            className="ml-auto w-20 bg-secondary/50 rounded px-2 py-1 text-sm font-mono text-center"
            type="number"
            step={0.1}
            min={30}
            max={250}
            value={weightValue}
            data-testid="ai-weight-input"
            onChange={e => setWeightValue(parseFloat(e.target.value) || 0)}
          />
        </div>
        <p className="text-xs text-muted-foreground">Date: {format(parseISO(date), "EEE d MMM yyyy")}</p>
        <div className="flex gap-2 pt-1">
          <Button size="sm" disabled={!weightValue || isSaving} onClick={() => confirmWeight.mutate()} data-testid="ai-confirm-weight">
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : null}
            Confirm
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
      </div>
    );
  }

  function renderTrainingReview(_p: ParsedTraining) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <ConfidenceBadge confidence={_p.confidence} />
        </div>
        <p className="text-sm font-medium">Log this training session?</p>
        <div className="rounded-lg border bg-card p-3 space-y-3 text-sm">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground w-20">Activity</span>
              <input
                className="flex-1 bg-secondary/50 rounded px-2 py-1 text-sm"
                value={trainingEdits.activityName}
                data-testid="ai-training-activity"
                onChange={e => {
                  setTrainingEdits(prev => ({ ...prev, activityName: e.target.value }));
                  setActivitySearchQ(e.target.value);
                }}
              />
            </div>
            {activitySuggestions.length > 0 && (
              <div className="ml-20 flex flex-wrap gap-1.5" data-testid="activity-suggestions">
                {activitySuggestions.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    data-testid={`activity-suggestion-${a.id}`}
                    onClick={() => {
                      setTrainingEdits(prev => ({ ...prev, activityName: a.name }));
                      setActivitySearchQ("");
                    }}
                    className="text-[11px] px-2 py-0.5 rounded-full border border-primary/30 bg-primary/5 text-primary hover:bg-primary/15 transition-colors"
                  >
                    {a.name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground w-20">Duration</span>
            <input
              className="w-20 bg-secondary/50 rounded px-2 py-1 text-sm font-mono"
              type="number"
              min={1}
              value={trainingEdits.durationMinutes}
              data-testid="ai-training-duration"
              onChange={e => setTrainingEdits(prev => ({ ...prev, durationMinutes: parseInt(e.target.value) || 60 }))}
            />
            <span className="text-muted-foreground">min</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground w-20">Time</span>
            <select
              className="bg-secondary/50 rounded px-2 py-1 text-sm"
              value={trainingEdits.timeOfDay}
              data-testid="ai-training-timeoday"
              onChange={e => setTrainingEdits(prev => ({ ...prev, timeOfDay: e.target.value as any }))}
            >
              <option value="morning">Morning</option>
              <option value="afternoon">Afternoon</option>
              <option value="evening">Evening</option>
            </select>
            {trainingEdits.timeLabel && (
              <span className="text-xs text-muted-foreground">({trainingEdits.timeLabel})</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground w-20">Date</span>
            <span className="text-sm">{format(parseISO(date), "EEE d MMM")}</span>
          </div>
        </div>
        {_p.missingFields.includes("duration") && (
          <p className="text-xs text-yellow-400">Duration was not detected — defaulted to 60 min. Please adjust above.</p>
        )}
        <div className="flex gap-2 pt-1">
          <Button size="sm" disabled={!trainingEdits.activityName || isSaving} onClick={() => confirmTraining.mutate()} data-testid="ai-confirm-training">
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : null}
            Log Session
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
      </div>
    );
  }

  function renderSupplementsReview(_p: ParsedSupplements) {
    const hasMatches = selectedSupplements.some(s => s.matched && s.included);

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <ConfidenceBadge confidence={_p.confidence} />
        </div>
        <p className="text-sm font-medium">Mark as taken?</p>
        <div className="space-y-2">
          {selectedSupplements.map((item, i) => (
            <div key={i} className={`flex items-center gap-3 rounded-lg border p-3 text-sm ${item.included ? "bg-card" : "opacity-40"}`}>
              <button
                className="flex-shrink-0"
                onClick={() => setSelectedSupplements(prev => prev.map((s, j) => j === i ? { ...s, included: !s.included } : s))}
                data-testid={`ai-supp-toggle-${i}`}
                type="button"
              >
                {item.included
                  ? <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  : <XCircle className="h-4 w-4 text-muted-foreground" />
                }
              </button>
              <div className="flex-1">
                <div className="font-medium">{item.raw}</div>
                {item.matched ? (
                  <div className="text-xs text-muted-foreground">→ {item.matched.name}</div>
                ) : (
                  <div className="text-xs text-yellow-400">Not found in your supplements — will be skipped</div>
                )}
              </div>
            </div>
          ))}
        </div>
        {!hasMatches && (
          <p className="text-xs text-muted-foreground">
            None of the named supplements matched your saved list. Add them in the Supplements section first, then log them here.
          </p>
        )}
        <div className="flex gap-2 pt-1">
          <Button size="sm" disabled={!hasMatches || isSaving} onClick={() => confirmSupplements.mutate()} data-testid="ai-confirm-supplements">
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : null}
            Mark Taken
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
      </div>
    );
  }

  function renderRecurringReview(p: ParsedRecurring) {
    const nextDate = getNextDayDate(p.dayOfWeek);
    const formatted = format(parseISO(nextDate), "EEE d MMM");

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <ConfidenceBadge confidence={p.confidence} />
          {p.scope === "fight camp" && <Badge variant="outline" className="text-xs">Fight Camp</Badge>}
        </div>
        <p className="text-sm font-medium">Create {p.dayOfWeek} sessions?</p>
        <p className="text-xs text-muted-foreground">
          V1: This will create sessions for the <strong>next {p.dayOfWeek}</strong> ({formatted}) only.
          Full recurring scheduling can be set up in the Training Log.
        </p>
        <div className="space-y-2">
          {p.sessions.map((sess, i) => (
            <div key={i} className="rounded-lg border bg-card p-3 text-sm">
              <div className="font-medium">{sess.activityName}</div>
              <div className="text-xs text-muted-foreground mt-1 flex gap-3">
                {sess.timeLabel && <span>{sess.timeLabel}</span>}
                <span className="capitalize">{sess.timeOfDay}</span>
                <span>{sess.durationMinutes} min</span>
              </div>
            </div>
          ))}
        </div>
        <div className="flex gap-2 pt-1">
          <Button size="sm" disabled={isSaving} onClick={() => confirmRecurring.mutate(p)} data-testid="ai-confirm-recurring">
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : null}
            Create Next {p.dayOfWeek}
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
            <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
      </div>
    );
  }

  function renderUnknown() {
    const hint = parsed?.intent === "unknown" ? parsed.clarificationHint : "";
    return (
      <div className="space-y-4">
        <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-4 text-sm text-yellow-300">
          <p className="font-medium mb-1">Not sure what to log</p>
          <p className="text-xs opacity-80">{hint}</p>
        </div>
        <div className="text-xs text-muted-foreground space-y-1">
          <p>Try phrases like:</p>
          <ul className="list-disc list-inside space-y-0.5 opacity-70">
            <li>"2 eggs and 2 slices of toast for breakfast"</li>
            <li>"Morning weight 71.8"</li>
            <li>"Pads for 60 min at 7pm"</li>
            <li>"Creatine and Vitamin D taken"</li>
          </ul>
        </div>
        <Button size="sm" variant="ghost" onClick={() => setDialogState("input")} data-testid="ai-edit-back">
          <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Try again
        </Button>
      </div>
    );
  }

  function renderDone() {
    return (
      <div className="flex flex-col items-center gap-4 py-4">
        <CheckCircle2 className="h-12 w-12 text-emerald-400" />
        <p className="text-sm font-medium">Logged successfully</p>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setDialogState("input");
            setInputText("");
            setParsed(null);
            onSuccess?.();
          }}
          data-testid="ai-log-another"
        >
          Log another
        </Button>
      </div>
    );
  }

  function renderReview() {
    if (!parsed) return null;
    switch (parsed.intent) {
      case "log_food": return renderFoodReview(parsed);
      case "log_weight": return renderWeightReview(parsed);
      case "log_training_session": return renderTrainingReview(parsed);
      case "log_supplements": return renderSupplementsReview(parsed);
      case "create_recurring_training_schedule": return renderRecurringReview(parsed);
      case "unknown": return renderUnknown();
    }
  }

  // ── SpeechRecognition availability ────────────────────────────────────────
  const hasSpeech = typeof window !== "undefined" &&
    !!(((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Quick Log
          </DialogTitle>
        </DialogHeader>

        {state === "input" && (
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Describe what you want to log in plain language. You'll review everything before it's saved.
            </p>
            <div className="relative">
              <Textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="e.g. '2 eggs and toast for breakfast' · 'Morning weight 71.8' · 'Pads 60 min at 7pm'"
                className="pr-10 resize-none min-h-[80px]"
                data-testid="ai-log-input"
                onKeyDown={e => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleParse();
                }}
              />
              {hasSpeech && (
                <button
                  type="button"
                  className={`absolute right-2 top-2 p-1.5 rounded-md transition-colors ${isListening ? "text-red-400 bg-red-500/10" : "text-muted-foreground hover:text-foreground"}`}
                  onClick={toggleVoice}
                  data-testid="ai-mic-button"
                  title={isListening ? "Stop listening" : "Speak to log"}
                >
                  {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </button>
              )}
            </div>
            {isListening && (
              <div className="space-y-1">
                <p className="text-xs text-red-400 flex items-center gap-1">
                  <span className="inline-block h-2 w-2 rounded-full bg-red-400 animate-pulse" />
                  Listening — speak naturally, stops after 3s silence
                </p>
                {interimText && (
                  <p className="text-xs text-muted-foreground italic pl-3">"{interimText}"</p>
                )}
              </div>
            )}
            <div className="flex gap-2">
              <Button
                size="sm"
                disabled={!inputText.trim()}
                onClick={handleParse}
                className="flex-1"
                data-testid="ai-parse-button"
              >
                <Edit2 className="h-3.5 w-3.5 mr-1.5" />
                Review
              </Button>
              <Button size="sm" variant="ghost" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground text-center opacity-60">
              Cmd/Ctrl+Enter to review · Nothing is saved until you confirm
            </p>
          </div>
        )}

        {state === "review" && renderReview()}
        {state === "done" && renderDone()}
      </DialogContent>
    </Dialog>
  );
}
