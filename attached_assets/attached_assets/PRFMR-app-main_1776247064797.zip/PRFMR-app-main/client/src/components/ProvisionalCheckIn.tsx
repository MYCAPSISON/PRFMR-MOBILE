import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, CheckCircle2, Pencil } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface ProvisionalCheckin {
  id: number;
  userId: number;
  date: string;
  feelToday: "fresh" | "okay" | "tired";
  fueledToday: "yes" | "somewhat" | "no";
  plannedIntensity: "light" | "moderate" | "hard";
  trainedYesterday: boolean | null;
  yesterdayTrainingIntensity: "light" | "moderate" | "hard" | null;
}

interface ReadinessData {
  provisional: boolean;
  hasYesterdayTraining: boolean;
  checkin: ProvisionalCheckin | null;
}

const FEEL_OPTIONS = [
  { value: "fresh", label: "Fresh", emoji: "💪" },
  { value: "okay", label: "Okay", emoji: "😐" },
  { value: "tired", label: "Tired", emoji: "😴" },
] as const;

const FUEL_OPTIONS = [
  { value: "yes", label: "Yes", emoji: "🟢" },
  { value: "somewhat", label: "Somewhat", emoji: "🟡" },
  { value: "no", label: "Not really", emoji: "🔴" },
] as const;

const INTENSITY_OPTIONS = [
  { value: "light", label: "Light", emoji: "🚶" },
  { value: "moderate", label: "Moderate", emoji: "🏃" },
  { value: "hard", label: "Hard", emoji: "🔥" },
] as const;

const TRAINED_OPTIONS = [
  { value: true, label: "Yes", emoji: "✅" },
  { value: false, label: "No / Rest", emoji: "😴" },
] as const;

function ToggleGroup<T extends string>({
  options,
  value,
  onChange,
  testId,
}: {
  options: readonly { value: T; label: string; emoji: string }[];
  value: T | null;
  onChange: (v: T) => void;
  testId: string;
}) {
  return (
    <div className="flex gap-2">
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          onClick={() => onChange(opt.value)}
          data-testid={`${testId}-${opt.value}`}
          className={`flex-1 flex flex-col items-center gap-1 py-2.5 px-1 rounded-lg text-xs border transition-all ${
            value === opt.value
              ? "border-primary bg-primary/10 text-primary font-semibold"
              : "border-border/40 bg-secondary/20 text-muted-foreground hover:border-border hover:bg-secondary/40"
          }`}
        >
          <span className="text-lg leading-none">{opt.emoji}</span>
          <span>{opt.label}</span>
        </button>
      ))}
    </div>
  );
}

function BoolToggleGroup({
  options,
  value,
  onChange,
  testId,
}: {
  options: readonly { value: boolean; label: string; emoji: string }[];
  value: boolean | null;
  onChange: (v: boolean) => void;
  testId: string;
}) {
  return (
    <div className="flex gap-2">
      {options.map((opt) => (
        <button
          key={String(opt.value)}
          type="button"
          onClick={() => onChange(opt.value)}
          data-testid={`${testId}-${opt.value}`}
          className={`flex-1 flex flex-col items-center gap-1 py-2.5 px-1 rounded-lg text-xs border transition-all ${
            value === opt.value
              ? "border-primary bg-primary/10 text-primary font-semibold"
              : "border-border/40 bg-secondary/20 text-muted-foreground hover:border-border hover:bg-secondary/40"
          }`}
        >
          <span className="text-lg leading-none">{opt.emoji}</span>
          <span>{opt.label}</span>
        </button>
      ))}
    </div>
  );
}

export function ProvisionalCheckIn({ date }: { date: string }) {
  const [editing, setEditing] = useState(false);
  const [feelToday, setFeelToday] = useState<"fresh" | "okay" | "tired" | null>(null);
  const [fueledToday, setFueledToday] = useState<"yes" | "somewhat" | "no" | null>(null);
  const [plannedIntensity, setPlannedIntensity] = useState<"light" | "moderate" | "hard" | null>(null);
  const [trainedYesterday, setTrainedYesterday] = useState<boolean | null>(null);
  const [yesterdayTrainingIntensity, setYesterdayTrainingIntensity] = useState<"light" | "moderate" | "hard" | null>(null);

  const { data: readiness } = useQuery<ReadinessData>({
    queryKey: ["/api/me/readiness", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/readiness/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const mutation = useMutation({
    mutationFn: async (body: {
      feelToday: string;
      fueledToday: string;
      plannedIntensity: string;
      trainedYesterday?: boolean | null;
      yesterdayTrainingIntensity?: string | null;
    }) => {
      return apiRequest("PUT", `/api/me/provisional-checkin/${date}`, body);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness", date] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel", date] });
      setEditing(false);
    },
  });

  if (!readiness?.provisional) return null;

  const askYesterdayTraining = !readiness.hasYesterdayTraining;
  const existingCheckin = readiness.checkin;
  const isComplete = !!existingCheckin;
  const showForm = !isComplete || editing;

  const coreAnswered = feelToday && fueledToday && plannedIntensity;
  const trainingAnswered = !askYesterdayTraining || trainedYesterday !== null;
  const canSubmit = coreAnswered && trainingAnswered;

  function handleSubmit() {
    if (!canSubmit) return;
    mutation.mutate({
      feelToday: feelToday!,
      fueledToday: fueledToday!,
      plannedIntensity: plannedIntensity!,
      trainedYesterday: askYesterdayTraining ? trainedYesterday : null,
      yesterdayTrainingIntensity:
        askYesterdayTraining && trainedYesterday
          ? yesterdayTrainingIntensity
          : null,
    });
  }

  function startEdit() {
    if (existingCheckin) {
      setFeelToday(existingCheckin.feelToday);
      setFueledToday(existingCheckin.fueledToday);
      setPlannedIntensity(existingCheckin.plannedIntensity);
      setTrainedYesterday(existingCheckin.trainedYesterday ?? null);
      setYesterdayTrainingIntensity(existingCheckin.yesterdayTrainingIntensity ?? null);
    }
    setEditing(true);
  }

  if (isComplete && !editing) {
    const feelLabel = FEEL_OPTIONS.find(o => o.value === existingCheckin.feelToday);
    const fuelLabel = FUEL_OPTIONS.find(o => o.value === existingCheckin.fueledToday);
    const intensityLabel = INTENSITY_OPTIONS.find(o => o.value === existingCheckin.plannedIntensity);

    return (
      <Card data-testid="card-provisional-checkin">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-display font-semibold">Quick Check-in</h3>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="text-xs text-blue-300 border-blue-300/30 bg-blue-300/10">Estimated</Badge>
              <button
                onClick={startEdit}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-edit-checkin"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs text-center">
            <div className="bg-secondary/20 rounded p-2">
              <div className="text-lg mb-1">{feelLabel?.emoji}</div>
              <div className="text-muted-foreground">Feeling</div>
              <div className="font-medium">{feelLabel?.label}</div>
            </div>
            <div className="bg-secondary/20 rounded p-2">
              <div className="text-lg mb-1">{fuelLabel?.emoji}</div>
              <div className="text-muted-foreground">Fueled</div>
              <div className="font-medium">{fuelLabel?.label}</div>
            </div>
            <div className="bg-secondary/20 rounded p-2">
              <div className="text-lg mb-1">{intensityLabel?.emoji}</div>
              <div className="text-muted-foreground">Today's plan</div>
              <div className="font-medium capitalize">{intensityLabel?.label}</div>
            </div>
          </div>

          {existingCheckin.trainedYesterday !== null && (
            <div className="text-xs text-muted-foreground flex items-center gap-1.5">
              <span>{existingCheckin.trainedYesterday ? "✅" : "😴"}</span>
              <span>
                {existingCheckin.trainedYesterday
                  ? `Trained yesterday${existingCheckin.yesterdayTrainingIntensity ? ` — ${existingCheckin.yesterdayTrainingIntensity}` : ""}`
                  : "Rest day yesterday"}
              </span>
            </div>
          )}

          <p className="text-[10px] text-muted-foreground italic">
            Readiness and fuel status are estimated from your self-report — not objective data. Log yesterday's food and training for a complete assessment.
          </p>
        </CardContent>
      </Card>
    );
  }

  const questionCount = askYesterdayTraining ? 4 : 3;

  return (
    <Card data-testid="card-provisional-checkin">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center gap-2">
          <ClipboardList className="h-4 w-4 text-primary" />
          <div>
            <h3 className="text-sm font-display font-semibold">Quick Check-in</h3>
            <p className="text-xs text-muted-foreground">{questionCount} questions — drives estimated readiness & fuel status</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <p className="text-xs font-medium" data-testid="label-feel-today">How do you feel today?</p>
            <ToggleGroup
              options={FEEL_OPTIONS}
              value={feelToday}
              onChange={setFeelToday}
              testId="toggle-feel"
            />
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium" data-testid="label-fueled-today">Did you fuel well yesterday?</p>
            <ToggleGroup
              options={FUEL_OPTIONS}
              value={fueledToday}
              onChange={setFueledToday}
              testId="toggle-fuel"
            />
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium" data-testid="label-planned-intensity">Planned session intensity</p>
            <ToggleGroup
              options={INTENSITY_OPTIONS}
              value={plannedIntensity}
              onChange={setPlannedIntensity}
              testId="toggle-intensity"
            />
          </div>

          {askYesterdayTraining && (
            <div className="space-y-2">
              <p className="text-xs font-medium" data-testid="label-trained-yesterday">Did you train yesterday?</p>
              <BoolToggleGroup
                options={TRAINED_OPTIONS}
                value={trainedYesterday}
                onChange={setTrainedYesterday}
                testId="toggle-trained-yesterday"
              />
              {trainedYesterday && (
                <div className="space-y-1.5 pt-1">
                  <p className="text-xs text-muted-foreground">How hard was yesterday's session?</p>
                  <ToggleGroup
                    options={INTENSITY_OPTIONS}
                    value={yesterdayTrainingIntensity}
                    onChange={setYesterdayTrainingIntensity}
                    testId="toggle-yesterday-intensity"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex gap-2">
          {editing && (
            <Button
              variant="outline"
              size="sm"
              className="flex-1 h-9 text-sm"
              onClick={() => setEditing(false)}
              data-testid="button-cancel-checkin"
            >
              Cancel
            </Button>
          )}
          <Button
            size="sm"
            className="flex-1 h-9 text-sm"
            disabled={!canSubmit || mutation.isPending}
            onClick={handleSubmit}
            data-testid="button-submit-checkin"
          >
            {mutation.isPending ? "Saving…" : editing ? "Update" : "Submit check-in"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
