import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Fuel, AlertTriangle, Zap, Info } from "lucide-react";

interface ProvisionalFuel {
  fuelStatus: "Adequate" | "Low";
  fuelRisk: "Low" | "Elevated" | "Unclear";
  message: string;
  suggestedFix: string;
}

interface FuelData {
  fuelStatus: "High" | "Adequate" | "Low";
  glycogenRisk: "Low" | "Moderate" | "High";
  constraint: string;
  suggestedFix: string;
  eaValue: number | null;
  carbsPerKg: number | null;
  plannedIntensity: string;
  hasPlannedTraining: boolean;
  provisional: boolean;
  hasYesterdayFood: boolean;
  hasYesterdayTraining: boolean;
  bodyweightSource: "today" | "recent" | "profile" | null;
  bodyweightKg: number | null;
  checkin: { fueledToday: string; plannedIntensity: string } | null;
  provisionalFuel: ProvisionalFuel | null;
  fuelLoadWarning?: string | null;
  backToBackHardDays?: boolean;
  highLoadCluster?: boolean;
  threeDayStreak?: boolean;
}

const fuelColors: Record<string, string> = {
  High: "text-green-400 border-green-400/30 bg-green-400/10",
  Adequate: "text-green-400 border-green-400/30 bg-green-400/10",
  Low: "text-red-400 border-red-400/30 bg-red-400/10",
};

const glycogenRiskColors: Record<string, string> = {
  Low: "text-green-400 border-green-400/30 bg-green-400/10",
  Moderate: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  High: "text-red-400 border-red-400/30 bg-red-400/10",
};

const fuelRiskColors: Record<string, string> = {
  Low: "text-green-400 border-green-400/30 bg-green-400/10",
  Elevated: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  Unclear: "text-muted-foreground border-border/40 bg-secondary/20",
};

export function FuelAvailability({ date }: { date: string }) {
  const { data, isLoading } = useQuery<FuelData>({
    queryKey: ["/api/me/fuel", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/fuel/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <Card data-testid="card-fuel-availability">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-secondary rounded w-1/3" />
            <div className="h-6 bg-secondary rounded w-1/2" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const pf = data.provisionalFuel;
  const isProvisionalWithCheckin = data.provisional && !!pf;

  const displayFuelStatus = isProvisionalWithCheckin ? pf!.fuelStatus : data.fuelStatus;
  const displayFix = isProvisionalWithCheckin ? pf!.suggestedFix : data.suggestedFix;

  const showObjectiveWarning = !data.provisional && (data.fuelStatus === "Low" || data.glycogenRisk === "High");

  return (
    <Card data-testid="card-fuel-availability">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Fuel className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-display font-semibold">Fuel Status</h3>
          </div>
          <div className="flex gap-1.5">
            {data.provisional && !pf ? (
              <Badge className="text-xs text-blue-300 border-blue-300/30 bg-blue-300/10" data-testid="badge-fuel-status">
                Provisional
              </Badge>
            ) : (
              <Badge className={`text-xs ${fuelColors[displayFuelStatus]}`} data-testid="badge-fuel-status">
                {displayFuelStatus}
              </Badge>
            )}
          </div>
        </div>

        {data.provisional && (
          <div className="flex items-start gap-2 text-xs text-blue-300/80 bg-blue-400/5 border border-blue-300/10 p-2 rounded" data-testid="notice-fuel-provisional">
            <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <span>
              {pf
                ? "Provisional estimate — based on self-report · log yesterday's food and training for a complete assessment"
                : !data.hasYesterdayFood
                  ? "No food logged yesterday — complete the check-in below for a fuel estimate"
                  : "No training logged yesterday — complete the check-in below for a fuel estimate"}
            </span>
          </div>
        )}

        {isProvisionalWithCheckin ? (
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Fuel Availability Risk</span>
            <Badge
              variant="outline"
              className={`text-xs ${fuelRiskColors[pf!.fuelRisk] || fuelRiskColors.Unclear}`}
              data-testid="badge-glycogen-risk"
            >
              {pf!.fuelRisk}
            </Badge>
          </div>
        ) : (
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Glycogen Risk</span>
            <Badge
              variant="outline"
              className={`text-xs ${glycogenRiskColors[data.glycogenRisk] || glycogenRiskColors.Moderate}`}
              data-testid="badge-glycogen-risk"
            >
              {data.glycogenRisk}
            </Badge>
          </div>
        )}

        {isProvisionalWithCheckin && (
          <div className="flex items-start gap-2 text-xs bg-secondary/20 p-2 rounded">
            <span className="text-muted-foreground" data-testid="text-provisional-fuel-message">{pf!.message}</span>
          </div>
        )}

        {showObjectiveWarning && (
          <div className="flex items-start gap-2 text-xs bg-secondary/20 p-2 rounded">
            <AlertTriangle className="h-3.5 w-3.5 text-orange-400 shrink-0 mt-0.5" />
            <span data-testid="text-fuel-constraint">{data.constraint}</span>
          </div>
        )}

        {!data.provisional && data.fuelLoadWarning && (
          <p className="text-xs text-orange-400/70" data-testid="text-fuel-load-warning">{data.fuelLoadWarning}</p>
        )}

        <div className="flex items-start gap-2">
          <Zap className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground" data-testid="text-fuel-fix">{displayFix}</p>
        </div>

        {!data.provisional && data.eaValue !== null && data.carbsPerKg !== null && (
          <div className="flex gap-4 text-[10px] text-muted-foreground pt-1 border-t border-border/30">
            <span>EA: {data.eaValue} kcal/kg</span>
            <span>Carbs: {data.carbsPerKg} g/kg</span>
            <span>Intensity: {data.plannedIntensity}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
