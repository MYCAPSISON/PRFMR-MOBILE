import { useState } from "react";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertTriangle, TrendingUp, BarChart2, CheckCircle2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export interface TrainingLoadAnalysis {
  date: string;
  totalLoad: number;
  classification: "light" | "moderate" | "hard" | "very_hard";
  warnings: string[];
  acuteLoad: number;
  acuteDaily: number;
  baselineLoad: number | null;
  baselineDaysUsed: number | null;
  acwr: number | null;
  relativeLoad: number | null;
  highStress: boolean;
  veryHighStress: boolean;
  highLoadCluster: boolean;
  threeDayStreak: boolean;
  activeDaysInWindow?: number;
  insufficientHistory?: boolean;
}

interface TrainingLoadWarningModalProps {
  open: boolean;
  analysis: TrainingLoadAnalysis | null;
  onClose: () => void;
}

const classificationLabels: Record<string, string> = {
  light: "Light",
  moderate: "Moderate",
  hard: "Hard",
  very_hard: "Very Hard",
};

const classificationColors: Record<string, string> = {
  light: "bg-green-500/20 text-green-400 border-green-500/30",
  moderate: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  hard: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  very_hard: "bg-red-500/20 text-red-400 border-red-500/30",
};

function warningIcon(w: string) {
  if (w.includes("spike")) return <TrendingUp className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />;
  if (w.includes("elevated")) return <TrendingUp className="h-4 w-4 text-orange-400 shrink-0 mt-0.5" />;
  return <AlertTriangle className="h-4 w-4 text-yellow-400 shrink-0 mt-0.5" />;
}

export function TrainingLoadWarningModal({
  open,
  analysis,
  onClose,
}: TrainingLoadWarningModalProps) {
  const [, navigate] = useLocation();
  const [override, setOverride] = useState<string>("");
  const [saving, setSaving] = useState(false);

  if (!analysis) return null;

  const hasBaseline = analysis.baselineLoad !== null;

  async function handleAcknowledge() {
    if (override && override !== "keep") {
      setSaving(true);
      try {
        await apiRequest("POST", `/api/me/training/load-override/${analysis.date}`, {
          classification: override,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/me/training-load", analysis.date] });
      } catch {
        // non-critical
      } finally {
        setSaving(false);
      }
    }
    // Clear sessionStorage for this date so modal doesn't re-open
    sessionStorage.removeItem(`load_warning_${analysis.date}`);
    onClose();
  }

  function handleViewTrend() {
    // Navigate to trend page but do NOT close or clear — modal re-opens on return
    navigate("/load-trend");
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        // Only allow closing via the Acknowledge button, not outside click / Escape
        if (!o) return;
      }}
    >
      <DialogContent
        className="max-w-sm w-[calc(100%-2rem)] rounded-xl p-0 gap-0 overflow-hidden"
        data-testid="modal-load-warning"
        onInteractOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <div className="p-5 space-y-4">
          <DialogHeader className="space-y-1">
            <DialogTitle className="font-display text-base font-semibold flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
              Training Load Insight
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Here's what stands out from your recent training.
            </DialogDescription>
          </DialogHeader>

          {/* Metrics row */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-lg bg-secondary/20 p-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Today</p>
              <p className="text-sm font-semibold">{analysis.totalLoad}</p>
              <p className="text-[10px] text-muted-foreground">load pts</p>
            </div>
            <div className="rounded-lg bg-secondary/20 p-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Baseline</p>
              <p className="text-sm font-semibold">
                {hasBaseline ? Math.round(analysis.baselineLoad!) : "—"}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {hasBaseline ? `${analysis.baselineDaysUsed}d avg` : "< 7 days"}
              </p>
            </div>
            <div className="rounded-lg bg-secondary/20 p-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">ACWR</p>
              <p className="text-sm font-semibold">
                {analysis.acwr !== null ? analysis.acwr.toFixed(2) : "—"}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {analysis.insufficientHistory ? "building baseline" : "ratio"}
              </p>
            </div>
          </div>

          {/* Sparse history notice */}
          {analysis.insufficientHistory && (
            <p className="text-[11px] text-muted-foreground/70 leading-relaxed bg-secondary/20 rounded-lg px-3 py-2">
              We're still building your training baseline. Until you have at least 7 training days logged, load insights use simple thresholds.
            </p>
          )}

          {/* Current classification */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">System estimate:</span>
            <Badge
              variant="outline"
              className={`text-xs ${classificationColors[analysis.classification] ?? ""}`}
            >
              {classificationLabels[analysis.classification] ?? analysis.classification}
            </Badge>
          </div>

          {/* Warnings */}
          <div className="space-y-2">
            {analysis.warnings.map((w, i) => (
              <div
                key={i}
                className="flex items-start gap-2 p-2.5 rounded-lg bg-yellow-500/5 border border-yellow-500/20"
                data-testid={`load-warning-${i}`}
              >
                {warningIcon(w)}
                <p className="text-xs leading-relaxed">{w}</p>
              </div>
            ))}
          </div>

          {/* Override classification */}
          <div className="space-y-1.5">
            <p className="text-xs text-muted-foreground">
              Does this match how the day felt for you?
            </p>
            <Select value={override} onValueChange={setOverride}>
              <SelectTrigger className="h-8 text-xs" data-testid="select-load-override">
                <SelectValue placeholder="Use system estimate" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="keep">Use system estimate</SelectItem>
                <SelectItem value="light">Light day</SelectItem>
                <SelectItem value="moderate">Moderate day</SelectItem>
                <SelectItem value="hard">Hard day</SelectItem>
                <SelectItem value="very_hard">Very hard day</SelectItem>
              </SelectContent>
            </Select>
            {override && override !== "keep" && (
              <p className="text-[10px] text-muted-foreground">
                Your rating will be saved for this day and used to reduce unnecessary warnings.
              </p>
            )}
          </div>

          {!hasBaseline && (
            <p className="text-[10px] text-muted-foreground bg-secondary/20 rounded-lg p-2 leading-relaxed">
              You have fewer than 7 days of data. Thresholds are based on absolute load until your baseline is established.
            </p>
          )}

          {/* Actions */}
          <div className="flex flex-col gap-2">
            <Button
              className="w-full gap-2"
              onClick={handleAcknowledge}
              disabled={saving}
              data-testid="button-load-acknowledge"
            >
              <CheckCircle2 className="h-4 w-4" />
              {saving ? "Saving…" : "Continue"}
            </Button>
            <Button
              variant="outline"
              className="w-full gap-2 text-xs"
              onClick={handleViewTrend}
              data-testid="button-view-load-trend"
            >
              <BarChart2 className="h-4 w-4" />
              View 28-day load trend
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
