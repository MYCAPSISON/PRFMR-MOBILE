import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  target?: string | number;
  unit?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "neutral";
  className?: string;
}

export function StatCard({ title, value, target, unit, icon, trend, className }: StatCardProps) {
  const rawPercentage = target 
    ? Math.round((Number(value) / Number(target)) * 100)
    : 0;
  const barWidth = Math.min(rawPercentage, 100);
  const isOverTarget = rawPercentage > 110;

  const [animatedWidth, setAnimatedWidth] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setAnimatedWidth(barWidth), 50);
    return () => clearTimeout(timer);
  }, [barWidth]);

  return (
    <div className={cn(
      "bg-card border border-border/40 rounded-xl p-5 card-elevated card-hover",
      className
    )}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-semibold tracking-wide text-muted-foreground">{title}</h3>
        {icon && <div className="text-muted-foreground/40">{icon}</div>}
      </div>
      
      <div className="flex items-baseline gap-1.5">
        <span className={cn(
          "text-3xl font-bold font-mono tracking-tight number-animate",
          isOverTarget && "text-amber-500"
        )}>{value}</span>
        {unit && <span className="text-xs text-muted-foreground/70 font-medium">{unit}</span>}
      </div>
      
      {target && (
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>Target: {target}</span>
            <span className={cn(isOverTarget && "text-amber-500 font-medium")}>{rawPercentage}%</span>
          </div>
          <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full rounded-full progress-bar-animated",
                isOverTarget ? "bg-amber-500" : "bg-primary"
              )}
              style={{ width: `${animatedWidth}%` }}
            />
          </div>
          {isOverTarget && (
            <p className="text-[10px] text-amber-500/80" data-testid="text-over-target-pct">
              {rawPercentage - 100}% above target
            </p>
          )}
        </div>
      )}
    </div>
  );
}
