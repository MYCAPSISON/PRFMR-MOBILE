import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import prfmrLogo from "@assets/no_back_logo_1775476772001.png";
import {
  Activity,
  BookOpen,
  User,
  LogOut,
  Pill,
  Dumbbell,
  MessageSquare,
} from "lucide-react";
import { useLogout } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { useReminderEngine } from "@/hooks/use-reminder-engine";

function useVersionInfo() {
  return useQuery<{ version: string; environment: string }>({
    queryKey: ["/api/meta"],
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { mutate: logout } = useLogout();
  const { data: versionInfo } = useVersionInfo();

  useReminderEngine();

  const handleLogout = () => {
    logout();
  };

  const navItems = [
    { href: "/dashboard", icon: Activity, label: "Dashboard" },
    { href: "/training", icon: Dumbbell, label: "Training" },
    { href: "/supplements", icon: Pill, label: "Supplements" },
    { href: "/playbook", icon: BookOpen, label: "Playbook" },
    { href: "/profile", icon: User, label: "Profile" },
    { href: "/feedback", icon: MessageSquare, label: "Feedback" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 sm:px-6">
          <Link href="/dashboard" className="flex items-center">
            <img src={prfmrLogo} alt="PRFMR" className="h-9 w-auto" />
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === item.href
                    ? "text-primary"
                    : "text-muted-foreground",
                )}
              >
                {item.label}
              </Link>
            ))}
            <button
              onClick={handleLogout}
              data-testid="button-logout"
              className="text-sm font-medium text-muted-foreground hover:text-destructive transition-colors ml-4"
            >
              Log out
            </button>
          </nav>

          <div className="md:hidden">
            {/* Mobile menu trigger could go here, but focusing on bottom nav for mobile */}
          </div>
        </div>
      </header>
      <main className="flex-1 container px-4 py-8 sm:px-6 lg:py-10 max-w-5xl mx-auto">
        {children}
      </main>
      {/* Global Disclaimer Footer - controlled by SHOW_FOOTER_TAGLINE env var */}
      {import.meta.env.VITE_SHOW_FOOTER_TAGLINE !== "false" && (
        <footer className="hidden md:block border-t py-4 px-6 text-center">
          <p className="text-[11px] text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            This app provides educational estimates only and does not offer
            medical, nutritional, or training advice. Intended for healthy
            individuals without medical conditions. Consult a professional if you
            have any health concerns.
          </p>
        </footer>
      )}
      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-background px-1 py-2 pb-safe z-50 flex justify-around items-center">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center gap-0.5 p-1.5 rounded-lg transition-colors min-w-0",
              location === item.href
                ? "text-primary bg-secondary"
                : "text-muted-foreground",
            )}
          >
            <item.icon className="h-5 w-5" />
            <span className="text-[9px] font-medium leading-tight">{item.label}</span>
          </Link>
        ))}
        <button
          onClick={handleLogout}
          data-testid="button-logout-mobile"
          className="flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-muted-foreground hover:bg-secondary/50 min-w-0"
        >
          <LogOut className="h-5 w-5" />
          <span className="text-[9px] font-medium leading-tight">Log out</span>
        </button>
      </nav>
      <div className="md:hidden h-20" /> {/* Spacer for bottom nav */}
      <div
        className="hidden md:block"
        style={{
          position: "fixed",
          bottom: 6,
          right: 8,
          fontSize: 10,
          opacity: 0.35,
          zIndex: 40,
          pointerEvents: "none",
          fontFamily: "monospace",
          letterSpacing: "0.02em",
        }}
        data-testid="text-app-version"
      >
        v{versionInfo?.version || "..."} • {versionInfo?.environment || "..."}
      </div>
    </div>
  );
}
