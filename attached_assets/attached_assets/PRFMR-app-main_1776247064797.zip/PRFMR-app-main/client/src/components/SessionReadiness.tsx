import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, AlertTriangle, Zap, Brain, Info } from "lucide-react";
import { useState } from "react";

interface ReadinessComponent {
  name: string;
  score: number;
  maxPoints: number;
  detail?: string;
}

interface ProvisionalCheckin {
  feelToday: "fresh" | "okay" | "tired";
  fueledToday: "yes" | "somewhat" | "no";
  plannedIntensity: "light" | "moderate" | "hard";
}

interface ProvisionalReadiness {
  score: number;
  label: "Good" | "Moderate" | "Caution" | "Low";
  feelScore: number;
  fuelScore: number;
  intensityScore: number;
  message: string;
  suggestedFix: string;
}

interface ReadinessData {
  total: number;
  label: "High" | "Moderate" | "Low" | "Poor" | "Provisional";
  primaryLimiter: string;
  suggestedFix: string;
  components: ReadinessComponent[];
  incomplete: boolean;
  provisional: boolean;
  missingData: string[];
  plannedIntensity: string;
  hasPlannedTraining: boolean;
  bodyweightSource: "today" | "recent" | "profile" | null;
  bodyweightKg: number | null;
  checkin: ProvisionalCheckin | null;
  provisionalReadiness: ProvisionalReadiness | null;
  crossSignal: string | null;
  todayClassification?: string;
  loadWarnings?: string[];
  backToBackHardDays?: boolean;
  highLoadCluster?: boolean;
  threeDayStreak?: boolean;
}

const labelColors: Record<string, string> = {
  High: "text-green-400 border-green-400/30 bg-green-400/10",
  Moderate: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  Low: "text-orange-400 border-orange-400/30 bg-orange-400/10",
  Poor: "text-red-400 border-red-400/30 bg-red-400/10",
  Provisional: "text-blue-300 border-blue-300/30 bg-blue-300/10",
};

const labelProgressColors: Record<string, string> = {
  High: "[&>div]:bg-green-400",
  Moderate: "[&>div]:bg-yellow-400",
  Low: "[&>div]:bg-orange-400",
  Poor: "[&>div]:bg-red-400",
  Provisional: "[&>div]:bg-blue-300",
};

export function SessionReadiness({ date }: { date: string }) {
  const [open, setOpen] = useState(false);

  const { data, isLoading } = useQuery<ReadinessData>({
    queryKey: ["/api/me/readiness", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/readiness/${date}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <Card data-testid="card-session-readiness">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-secondary rounded w-1/3" />
            <div className="h-8 bg-secondary rounded w-1/2" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const pr = data.provisionalReadiness;
  const displayScore = data.provisional && pr ? pr.score : data.total;
  const displayLabel = data.provisional && pr ? pr.label : data.label;
  const displayFix = data.provisional && pr ? pr.suggestedFix : data.suggestedFix;
  const displayLimiter = data.provisional && pr ? pr.message : data.primaryLimiter;

  const colorClass = labelColors[displayLabel] || labelColors.Moderate;
  const progressColor = labelProgressColors[displayLabel] || labelProgressColors.Moderate;

  return (
    <Card data-testid="card-session-readiness">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-display font-semibold">Session Readiness</h3>
          </div>
          <Badge className={`text-xs ${colorClass}`} data-testid="badge-readiness-label">
            {data.provisional && pr ? `~${displayScore}` : displayScore} — {displayLabel}
          </Badge>
        </div>

        <Progress value={displayScore} className={`h-2 ${progressColor}`} data-testid="progress-readiness" />

        {data.provisional && (
          <div className="flex items-start gap-2 text-xs text-blue-300/80 bg-blue-400/5 border border-blue-300/10 p-2 rounded" data-testid="notice-provisional">
            <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <div>
              {pr ? (
                <>
                  <span className="font-medium">Provisional — based on today's check-in</span>
                  <span className="text-muted-foreground"> · log {data.missingData.join(", ")} for full accuracy</span>
                </>
              ) : (
                <>
                  <span className="font-medium">Provisional score</span>
                  <span className="text-muted-foreground"> — complete the quick check-in below for an estimate</span>
                </>
              )}
            </div>
          </div>
        )}

        <div className="space-y-1">
          <div className="flex items-start gap-2">
            <Zap className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium" data-testid="text-primary-limiter">{displayLimiter}</p>
              <p className="text-xs text-muted-foreground" data-testid="text-suggested-fix">{displayFix}</p>
              {data.crossSignal && !data.provisional && (
                <p className="text-xs text-amber-400/80 mt-0.5" data-testid="text-cross-signal">{data.crossSignal}</p>
              )}
              {!data.provisional && (data.backToBackHardDays || data.highLoadCluster || data.threeDayStreak) && (
                <p className="text-xs text-orange-400/70 mt-0.5" data-testid="text-load-stacking">
                  {data.threeDayStreak
                    ? "Three consecutive high-load days — consider recovery support"
                    : data.highLoadCluster
                    ? "Training load is clustering across consecutive days"
                    : "Back-to-back hard training days — recovery demand is elevated"}
                </p>
              )}
            </div>
          </div>
        </div>

        {!data.hasPlannedTraining && (
          <p className="text-xs text-muted-foreground italic">
            No training session planned — using moderate defaults
          </p>
        )}

        <Collapsible open={open} onOpenChange={setOpen}>
          <CollapsibleTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors" data-testid="button-readiness-details">
            <ChevronDown className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
            Details
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-2">
            {data.provisional && pr ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">Wellness</span>
                  <span className="font-mono text-muted-foreground">{pr.feelScore}/40</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">Perceived fueling</span>
                  <span className="font-mono text-muted-foreground">{pr.fuelScore}/40</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">Session demand</span>
                  <span className="font-mono text-muted-foreground">{pr.intensityScore}/20</span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {data.components.map((comp) => (
                  <div key={comp.name} className="flex items-center justify-between text-xs">
                    <div className="flex-1">
                      <span className="font-medium">{comp.name}</span>
                      {comp.detail && (
                        <span className="text-muted-foreground ml-1.5">({comp.detail})</span>
                      )}
                    </div>
                    <span className="font-mono text-muted-foreground">
                      {comp.score}/{comp.maxPoints}
                    </span>
                  </div>
                ))}
                {data.bodyweightSource && data.bodyweightKg && (
                  <div className="flex items-center justify-between text-xs text-muted-foreground/60 pt-1 border-t border-border/20">
                    <span>Bodyweight used</span>
                    <span className="font-mono">{data.bodyweightKg} kg ({data.bodyweightSource})</span>
                  </div>
                )}
              </div>
            )}
            <p className="text-[10px] text-muted-foreground mt-2 italic">
              {data.provisional
                ? "Provisional estimate based on self-report only — not a substitute for logged nutrition and training data."
                : "This is a performance guidance estimate, not medical advice."}
            </p>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}
