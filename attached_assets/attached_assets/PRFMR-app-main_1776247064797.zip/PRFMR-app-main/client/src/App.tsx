import { Switch, Route, useLocation } from "wouter";
import { useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ProtectedRoute, PublicOnlyRoute, OnboardingGuard } from "@/components/protected-route";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import StartPage from "@/pages/start";
import SignupPage from "@/pages/signup";
import OnboardingPage from "@/pages/onboarding";
import Dashboard from "@/pages/dashboard";
import Playbook from "@/pages/playbook";
import Profile from "@/pages/profile";
import Supplements from "@/pages/supplements";
import Training from "@/pages/training";
import VerifyEmailPage from "@/pages/verify-email";
import ForgotPasswordPage from "@/pages/forgot-password";
import ResetPasswordPage from "@/pages/reset-password";
import FeedbackPage from "@/pages/feedback";
import MicronutrientsPage from "@/pages/micronutrients";
import LoadTrendPage from "@/pages/load-trend";
import ReadinessPage from "@/pages/readiness";
import { MorningCheckInGate } from "@/components/MorningCheckInGate";

function StacksRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => { navigate("/supplements", { replace: true }); }, []);
  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/">
        <PublicOnlyRoute><LoginPage /></PublicOnlyRoute>
      </Route>
      <Route path="/login">
        <PublicOnlyRoute><LoginPage /></PublicOnlyRoute>
      </Route>
      <Route path="/register">
        <PublicOnlyRoute><StartPage /></PublicOnlyRoute>
      </Route>
      <Route path="/start">
        <PublicOnlyRoute><StartPage /></PublicOnlyRoute>
      </Route>
      <Route path="/signup">
        <PublicOnlyRoute><SignupPage /></PublicOnlyRoute>
      </Route>
      <Route path="/verify-email" component={VerifyEmailPage} />
      <Route path="/forgot-password">
        <PublicOnlyRoute><ForgotPasswordPage /></PublicOnlyRoute>
      </Route>
      <Route path="/reset-password">
        <PublicOnlyRoute><ResetPasswordPage /></PublicOnlyRoute>
      </Route>
      <Route path="/onboarding">
        <OnboardingGuard><OnboardingPage /></OnboardingGuard>
      </Route>
      <Route path="/dashboard">
        <ProtectedRoute><Dashboard /></ProtectedRoute>
      </Route>
      <Route path="/playbook">
        <ProtectedRoute><Playbook /></ProtectedRoute>
      </Route>
      <Route path="/profile">
        <ProtectedRoute><Profile /></ProtectedRoute>
      </Route>
      <Route path="/supplements">
        <ProtectedRoute><Supplements /></ProtectedRoute>
      </Route>
      <Route path="/stacks">
        <StacksRedirect />
      </Route>
      <Route path="/training">
        <ProtectedRoute><Training /></ProtectedRoute>
      </Route>
      <Route path="/feedback">
        <ProtectedRoute><FeedbackPage /></ProtectedRoute>
      </Route>
      <Route path="/micronutrients">
        <ProtectedRoute><MicronutrientsPage /></ProtectedRoute>
      </Route>
      <Route path="/load-trend">
        <ProtectedRoute><LoadTrendPage /></ProtectedRoute>
      </Route>
      <Route path="/readiness">
        <ProtectedRoute><ReadinessPage /></ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <MorningCheckInGate />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
