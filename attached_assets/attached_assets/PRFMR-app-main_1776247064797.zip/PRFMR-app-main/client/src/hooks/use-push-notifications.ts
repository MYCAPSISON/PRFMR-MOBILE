import { useState, useEffect, useCallback, useMemo } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Detect if running on iOS
function isIOS(): boolean {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) || 
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

// Detect if running as installed PWA (standalone mode)
function isPWA(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true;
}

export type PushNotificationStatus = 
  | "supported"           // Can enable notifications
  | "ios_safari"          // iOS but not installed as PWA
  | "ios_pwa"             // iOS PWA - can enable notifications
  | "unsupported_browser" // Browser doesn't support push
  | "server_disabled";    // VAPID keys not configured

export function usePushNotifications() {
  const { toast } = useToast();
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [swRegistration, setSwRegistration] = useState<ServiceWorkerRegistration | null>(null);
  const [isIOSDevice, setIsIOSDevice] = useState(false);
  const [isInstalledPWA, setIsInstalledPWA] = useState(false);

  const { data: pushStatus } = useQuery({
    queryKey: ["/api/auth/notifications/status"],
    queryFn: async () => {
      const res = await fetch("/api/auth/notifications/status");
      if (!res.ok) return { enabled: false };
      return res.json() as Promise<{ enabled: boolean }>;
    },
  });

  const isPushEnabled = pushStatus?.enabled ?? false;

  // Compute the notification status for clearer UI messaging
  const notificationStatus = useMemo((): PushNotificationStatus => {
    if (!isPushEnabled) return "server_disabled";
    if (!isSupported) {
      if (isIOSDevice && !isInstalledPWA) return "ios_safari";
      return "unsupported_browser";
    }
    if (isIOSDevice) return "ios_pwa";
    return "supported";
  }, [isPushEnabled, isSupported, isIOSDevice, isInstalledPWA]);

  useEffect(() => {
    const checkSupport = async () => {
      // Detect iOS and PWA status first
      const iosDevice = isIOS();
      const installedPwa = isPWA();
      setIsIOSDevice(iosDevice);
      setIsInstalledPWA(installedPwa);
      
      console.log("[push] Device detection - iOS:", iosDevice, "PWA:", installedPwa);

      // Check basic support
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
        console.warn("[push] Push notifications not supported in this browser");
        setIsSupported(false);
        return;
      }
      
      // iOS Safari (not PWA) doesn't support push
      if (iosDevice && !installedPwa) {
        console.log("[push] iOS Safari detected - push requires PWA installation");
        setIsSupported(false);
        return;
      }
      
      setIsSupported(true);
      setPermission(Notification.permission);

      try {
        const registration = await navigator.serviceWorker.register("/sw.js");
        setSwRegistration(registration);
        console.log("[push] Service worker registered successfully");
        
        const subscription = await registration.pushManager.getSubscription();
        setIsSubscribed(!!subscription);
        console.log("[push] Current subscription:", !!subscription);
      } catch (error) {
        console.error("[push] Service worker registration failed:", error);
      }
    };

    checkSupport();
  }, []);

  const subscribeMutation = useMutation({
    mutationFn: async () => {
      if (!swRegistration) throw new Error("Service worker not registered");

      const keyRes = await fetch("/api/auth/notifications/vapid-public-key");
      if (!keyRes.ok) throw new Error("Failed to get VAPID key");
      const { publicKey } = await keyRes.json();

      const subscription = await swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey),
      });

      const res = await fetch("/api/auth/notifications/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(subscription.toJSON()),
      });

      if (!res.ok) throw new Error("Failed to save subscription");
      return subscription;
    },
    onSuccess: () => {
      setIsSubscribed(true);
      setPermission(Notification.permission);
      toast({ title: "Notifications enabled", description: "You'll receive push notifications for reminders." });
    },
    onError: (error) => {
      console.error("[push] Subscribe error:", error);
      toast({ title: "Failed to enable notifications", variant: "destructive" });
    },
  });

  const unsubscribeMutation = useMutation({
    mutationFn: async () => {
      if (!swRegistration) throw new Error("Service worker not registered");

      const subscription = await swRegistration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        await fetch("/api/auth/notifications/unsubscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ endpoint: subscription.endpoint }),
        });
      }
    },
    onSuccess: () => {
      setIsSubscribed(false);
      toast({ title: "Notifications disabled" });
    },
    onError: (error) => {
      console.error("[push] Unsubscribe error:", error);
      toast({ title: "Failed to disable notifications", variant: "destructive" });
    },
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/auth/notifications/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error("Failed to send test notification");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.sent > 0) {
        toast({ title: "Test notification sent" });
      } else {
        toast({ title: "No subscriptions found", description: "Enable notifications first.", variant: "destructive" });
      }
    },
    onError: (error) => {
      console.error("[push] Test error:", error);
      toast({ title: "Failed to send test notification", variant: "destructive" });
    },
  });

  const requestPermission = useCallback(async () => {
    if (!isSupported) return false;
    const result = await Notification.requestPermission();
    setPermission(result);
    return result === "granted";
  }, [isSupported]);

  const subscribe = useCallback(async () => {
    if (!isSupported || !isPushEnabled) return;
    
    if (permission !== "granted") {
      const granted = await requestPermission();
      if (!granted) {
        toast({ title: "Permission denied", description: "Please allow notifications in your browser settings.", variant: "destructive" });
        return;
      }
    }
    
    subscribeMutation.mutate();
  }, [isSupported, isPushEnabled, permission, requestPermission, subscribeMutation, toast]);

  const unsubscribe = useCallback(() => {
    unsubscribeMutation.mutate();
  }, [unsubscribeMutation]);

  const sendTestNotification = useCallback(() => {
    testMutation.mutate();
  }, [testMutation]);

  return {
    isSupported,
    isPushEnabled,
    permission,
    isSubscribed,
    isLoading: subscribeMutation.isPending || unsubscribeMutation.isPending,
    subscribe,
    unsubscribe,
    sendTestNotification,
    notificationStatus,
    isIOSDevice,
    isInstalledPWA,
  };
}
