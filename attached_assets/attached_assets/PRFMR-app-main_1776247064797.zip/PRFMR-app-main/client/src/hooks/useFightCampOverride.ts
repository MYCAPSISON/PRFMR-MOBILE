import { useState, useEffect, useCallback } from "react";

export interface FightCampTargets {
  isLowEA?: boolean;
  isLowCarb?: boolean;
  isBelowPerformanceCarb?: boolean;
  performanceCarbWarning?: string | null;
  eaValue?: number;
  carbsPerKg?: number;
  eaRecommendedCalories?: number;
  carbRecommendedG?: number;
  targetCalories?: number;
  targetProtein?: number;
  targetCarbs?: number;
  targetFat?: number;
  trainingKcalToday?: number;
  ffmKg?: number;
  planId?: number;
  planFightDate?: string;
  planTargetWeight?: number;
}

interface StoredDecisions {
  ea?: "accepted" | "declined";
  carb?: "accepted" | "declined";
  perfToastShown?: boolean;
}

interface UseFightCampOverrideOptions {
  userId: number | undefined;
  date: string;
  effectiveTargets: FightCampTargets | undefined;
  isFightCamp: boolean;
  /** Fingerprint of key plan fields — changes whenever the user modifies fight camp details,
   *  which causes new storage keys to be created and consent modals to re-trigger. */
  planFingerprint?: string;
}

export interface FightCampOverrideResult {
  eaModalOpen: boolean;
  carbModalOpen: boolean;
  overrideCalories: number | null;
  overrideCarbs: number | null;
  eaDecision: "accepted" | "declined" | null;
  carbDecision: "accepted" | "declined" | null;
  shouldShowPerfToast: boolean;
  markPerfToastShown: () => void;
  acceptEA: () => void;
  declineEA: () => void;
  closeEAModal: () => void;
  acceptCarb: () => void;
  declineCarb: () => void;
  closeCarbModal: () => void;
  openEAModal: () => void;
  openCarbModal: () => void;
}

export function useFightCampOverride(opts: UseFightCampOverrideOptions): FightCampOverrideResult {
  const { userId, date, effectiveTargets, isFightCamp, planFingerprint } = opts;

  // Include planFingerprint in the key so that any change to fight camp details
  // (fight date, target weight, new plan) generates a new key, clearing stored decisions
  // and causing consent modals to re-trigger automatically.
  const storageKey = userId
    ? planFingerprint
      ? `fightCamp:${userId}:${date}:${planFingerprint}`
      : `fightCamp:${userId}:${date}`
    : null;

  const [eaModalOpen, setEaModalOpen] = useState(false);
  const [carbModalOpen, setCarbModalOpen] = useState(false);
  const [decisions, setDecisions] = useState<StoredDecisions>({});
  const [overrideCalories, setOverrideCalories] = useState<number | null>(null);
  const [overrideCarbs, setOverrideCarbs] = useState<number | null>(null);

  const readStorage = useCallback((): StoredDecisions => {
    if (!storageKey) return {};
    try { return JSON.parse(localStorage.getItem(storageKey) || "{}"); } catch { return {}; }
  }, [storageKey]);

  const writeStorage = useCallback((update: Partial<StoredDecisions>) => {
    if (!storageKey) return;
    const stored = readStorage();
    const next = { ...stored, ...update };
    localStorage.setItem(storageKey, JSON.stringify(next));
    setDecisions(next);
  }, [storageKey, readStorage]);

  // Restore persisted decisions when date, targets, or fight-camp mode changes.
  // effectiveTargets is included so that restoring works even if targets load after
  // isFightCamp first becomes true (e.g. on initial page load).
  useEffect(() => {
    if (!storageKey || !isFightCamp) return;
    const stored = readStorage();
    setDecisions(stored);

    if (stored.ea === "accepted" && effectiveTargets?.eaRecommendedCalories) {
      setOverrideCalories(effectiveTargets.eaRecommendedCalories);
    } else if (!stored.ea || stored.ea === "declined") {
      setOverrideCalories(null);
    }

    if (stored.carb === "accepted" && effectiveTargets?.carbRecommendedG) {
      setOverrideCarbs(effectiveTargets.carbRecommendedG);
    } else if (!stored.carb || stored.carb === "declined") {
      setOverrideCarbs(null);
    }
  }, [storageKey, date, isFightCamp, effectiveTargets?.eaRecommendedCalories, effectiveTargets?.carbRecommendedG]);

  // Auto-open modals when violations exist and the user has not yet responded today.
  useEffect(() => {
    if (!isFightCamp || !effectiveTargets || !storageKey) return;
    const stored = readStorage();

    if (effectiveTargets.isLowEA && !stored.ea) {
      setEaModalOpen(true);
    } else if (effectiveTargets.isLowCarb && !stored.carb) {
      setCarbModalOpen(true);
    }
  }, [isFightCamp, effectiveTargets?.isLowEA, effectiveTargets?.isLowCarb, storageKey]);

  const acceptEA = useCallback(() => {
    const cals = effectiveTargets?.eaRecommendedCalories;
    if (cals) setOverrideCalories(cals);
    writeStorage({ ea: "accepted" });
    setEaModalOpen(false);
    // Chain to carb modal if also low
    const stored = readStorage();
    if (effectiveTargets?.isLowCarb && !stored.carb) {
      setTimeout(() => setCarbModalOpen(true), 350);
    }
  }, [effectiveTargets, writeStorage, readStorage]);

  const declineEA = useCallback(() => {
    writeStorage({ ea: "declined" });
    setEaModalOpen(false);
    const stored = readStorage();
    if (effectiveTargets?.isLowCarb && !stored.carb) {
      setTimeout(() => setCarbModalOpen(true), 350);
    }
  }, [effectiveTargets, writeStorage, readStorage]);

  // Close EA modal WITHOUT recording a decision — allows it to re-appear on next load.
  // Used for backdrop clicks and Escape key so accidental dismissal is not permanent.
  const closeEAModal = useCallback(() => {
    setEaModalOpen(false);
  }, []);

  const acceptCarb = useCallback(() => {
    const carbs = effectiveTargets?.carbRecommendedG ?? 0;
    const protein = effectiveTargets?.targetProtein ?? 0;
    const fat = effectiveTargets?.targetFat ?? 0;
    setOverrideCarbs(carbs);
    const carbBasedCals = protein * 4 + fat * 9 + carbs * 4;
    const currentCals = overrideCalories ?? effectiveTargets?.targetCalories ?? 0;
    if (carbBasedCals > currentCals) setOverrideCalories(carbBasedCals);
    writeStorage({ carb: "accepted" });
    setCarbModalOpen(false);
  }, [effectiveTargets, overrideCalories, writeStorage]);

  const declineCarb = useCallback(() => {
    writeStorage({ carb: "declined" });
    setCarbModalOpen(false);
  }, [writeStorage]);

  // Close carb modal WITHOUT recording a decision.
  const closeCarbModal = useCallback(() => {
    setCarbModalOpen(false);
  }, []);

  const markPerfToastShown = useCallback(() => {
    writeStorage({ perfToastShown: true });
  }, [writeStorage]);

  return {
    eaModalOpen,
    carbModalOpen,
    overrideCalories,
    overrideCarbs,
    eaDecision: decisions.ea ?? null,
    carbDecision: decisions.carb ?? null,
    shouldShowPerfToast: !decisions.perfToastShown,
    markPerfToastShown,
    acceptEA,
    declineEA,
    closeEAModal,
    acceptCarb,
    declineCarb,
    closeCarbModal,
    openEAModal: () => setEaModalOpen(true),
    openCarbModal: () => setCarbModalOpen(true),
  };
}
