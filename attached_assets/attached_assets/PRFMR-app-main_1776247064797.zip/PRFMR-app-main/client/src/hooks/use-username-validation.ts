import { useState, useEffect, useRef, useCallback } from "react";
import { validateUsername, normalizeUsername } from "@shared/username-validation";

export type UsernameStatus = "idle" | "checking" | "available" | "taken" | "invalid";

interface UseUsernameValidationOptions {
  currentUsername?: string;
  debounceMs?: number;
}

interface UseUsernameValidationResult {
  value: string;
  displayValue: string;
  status: UsernameStatus;
  error: string | null;
  onChange: (raw: string) => void;
  reset: (initial?: string) => void;
  isValid: boolean;
}

export function useUsernameValidation(options: UseUsernameValidationOptions = {}): UseUsernameValidationResult {
  const { currentUsername, debounceMs = 500 } = options;
  const [displayValue, setDisplayValue] = useState("");
  const [status, setStatus] = useState<UsernameStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const checkAvailability = useCallback(async (normalized: string) => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setStatus("checking");

    try {
      const res = await fetch(`/api/username/available?username=${encodeURIComponent(normalized)}`, {
        signal: controller.signal,
      });
      if (controller.signal.aborted) return;
      const data = await res.json();

      if (!data.available && data.reason) {
        const isTaken = data.reason === "Username is already taken";
        setStatus(isTaken ? "taken" : "invalid");
        setError(data.reason);
      } else if (data.available) {
        setStatus("available");
        setError(null);
      } else {
        setStatus("taken");
        setError("That username is already taken.");
      }
    } catch (e: any) {
      if (e.name === "AbortError") return;
      setStatus("idle");
      setError(null);
    }
  }, []);

  const onChange = useCallback((raw: string) => {
    const formatted = raw.toLowerCase().replace(/\s/g, "");
    setDisplayValue(formatted);

    if (timerRef.current) clearTimeout(timerRef.current);
    abortRef.current?.abort();

    if (!formatted) {
      setStatus("idle");
      setError(null);
      return;
    }

    const result = validateUsername(formatted);

    if (!result.valid) {
      setStatus("invalid");
      setError(result.error);
      return;
    }

    if (currentUsername && result.normalized === currentUsername.toLowerCase()) {
      setStatus("idle");
      setError(null);
      return;
    }

    timerRef.current = setTimeout(() => {
      checkAvailability(result.normalized);
    }, debounceMs);
  }, [currentUsername, debounceMs, checkAvailability]);

  const reset = useCallback((initial?: string) => {
    setDisplayValue(initial || "");
    setStatus("idle");
    setError(null);
    if (timerRef.current) clearTimeout(timerRef.current);
    abortRef.current?.abort();
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      abortRef.current?.abort();
    };
  }, []);

  const normalized = normalizeUsername(displayValue);
  const localValidation = displayValue ? validateUsername(displayValue) : null;
  const isValid = status === "available" || (localValidation?.valid === true && status === "idle" && currentUsername !== undefined && normalized === currentUsername.toLowerCase());

  return {
    value: normalized,
    displayValue,
    status,
    error,
    onChange,
    reset,
    isValid,
  };
}
