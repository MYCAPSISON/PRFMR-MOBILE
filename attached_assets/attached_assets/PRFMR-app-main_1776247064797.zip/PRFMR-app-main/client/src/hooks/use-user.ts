import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { insertUserSchema, type OnboardingData } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const USERNAME_KEY = "fitness_app_username";

export function getStoredUsername() {
  return localStorage.getItem(USERNAME_KEY);
}

export function setStoredUsername(username: string) {
  localStorage.setItem(USERNAME_KEY, username);
}

export function syncUsernameFromProfile(username: string | null) {
  if (username) {
    localStorage.setItem(USERNAME_KEY, username);
  }
}

export const USER_ME_QUERY_KEY = ["/api/user/me"];

export function useUser() {
  return useQuery({
    queryKey: USER_ME_QUERY_KEY,
    queryFn: async () => {
      const res = await fetch("/api/user/me", { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch user profile");
      const data = await res.json();
      if (data.username) {
        syncUsernameFromProfile(data.username);
      }
      return data;
    },
    retry: false,
    staleTime: 1000 * 60 * 2,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (username: string) => {
      const res = await fetch(api.user.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username }),
      });
      if (!res.ok) throw new Error("Login failed");
      return api.user.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      setStoredUsername(data.username);
      queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
      toast({
        title: "Welcome back",
        description: `Signed in as ${data.username}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useOnboard() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: OnboardingData) => {
      const res = await fetch("/api/user/me/onboard", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error("Onboarding failed");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Profile Updated",
        description: "Your nutrition targets have been calculated.",
      });
    },
  });
}
