import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { insertLogSchema, insertFoodEntrySchema } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { createElement } from "react";
import { ToastAction } from "@/components/ui/toast";

let lastAmqsToastTime = 0;
const AMQS_TOAST_DEBOUNCE_MS = 5000;

function scrollToAmqsCard() {
  window.location.href = '/micronutrients';
}

export function useLogs() {
  return useQuery({
    queryKey: ["/api/me/logs"],
    queryFn: async () => {
      const res = await fetch("/api/me/logs", { credentials: "include", cache: "no-store" });
      if (!res.ok) {
        if (res.status === 401) return [];
        throw new Error("Failed to fetch logs");
      }
      return await res.json();
    },
  });
}

export function useCreateLog() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: z.infer<typeof insertLogSchema>) => {
      const res = await fetch(api.logs.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) throw new Error("Failed to create log");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      toast({
        title: "Log Saved",
        description: "Your daily progress has been recorded.",
      });
    },
  });
}

export function useUpdateLog() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<z.infer<typeof insertLogSchema>>) => {
      const url = buildUrl(api.logs.update.path, { id });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) throw new Error("Failed to update log");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      toast({
        title: "Log Updated",
        description: "Your changes have been saved.",
      });
    },
  });
}

export function useFoodEntries(date: string) {
  return useQuery({
    queryKey: ["/api/me/food", date],
    queryFn: async () => {
      const res = await fetch(`/api/me/food/${date}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) {
        if (res.status === 401) return [];
        throw new Error("Failed to fetch food entries");
      }
      return await res.json();
    },
    enabled: !!date,
  });
}

export function useFoodEntriesRange(startDate: string, endDate: string) {
  return useQuery({
    queryKey: ["/api/me/food-entries/range", startDate, endDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/food-entries/range?start=${startDate}&end=${endDate}`, {
        cache: "no-store",
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 401) return [];
        throw new Error("Failed to fetch food entries range");
      }
      return await res.json();
    },
    enabled: !!startDate && !!endDate,
    staleTime: 0,
    refetchOnMount: "always",
  });
}

export function useCreateFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: z.infer<typeof insertFoodEntrySchema>) => {
      console.log("[food][create][attempt]", {
        name: data.name,
        date: data.date,
        source: data.sourceType || "manual",
      });
      const res = await fetch(api.food.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) {
        const errorBody = await res.text().catch(() => "Unknown error");
        console.error("[food][create][error]", { status: res.status, body: errorBody });
        throw new Error(`Failed to add food (${res.status}): ${errorBody}`);
      }
      const entry = await res.json();
      if (!entry || typeof entry.id !== "number") {
        console.error("[food][create][error] Server returned OK but no valid entry id", entry);
        throw new Error("Server did not confirm the food entry was saved");
      }
      console.log("[food][create][success]", {
        id: entry.id,
        name: entry.name,
        date: entry.date,
        source: entry.sourceType || "manual",
      });
      return entry;
    },
    onSuccess: async (entry) => {
      const oldData = queryClient.getQueryData<any>(["/api/me/amqs/score", entry.date]);
      const oldScore = oldData?.score ?? null;
      const oldTopGap = oldData?.topGaps?.[0];

      queryClient.invalidateQueries({ queryKey: ["/api/me/food"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/food-entries/range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/supplement-micros"] });

      const now = Date.now();
      if (now - lastAmqsToastTime < AMQS_TOAST_DEBOUNCE_MS) {
        toast({ title: "Logged — dashboard updated", description: `${entry.name} added.` });
        return;
      }

      try {
        const res = await fetch(`/api/me/amqs/score/${entry.date}`, { credentials: "include", cache: "no-store" });
        if (res.ok) {
          const newData = await res.json();
          const newScore = newData?.score ?? null;
          const seeGapsAction = createElement(ToastAction, {
            altText: "See updated gaps",
            onClick: scrollToAmqsCard,
            "data-testid": "toast-see-gaps",
          }, "See updated gaps");

          if (oldScore !== null && newScore !== null && newScore > oldScore) {
            lastAmqsToastTime = now;
            toast({
              title: `AMQS +${newScore - oldScore}`,
              description: `${entry.name} boosted your micronutrient score.`,
              action: seeGapsAction,
            });
          } else if (oldTopGap && newData?.topGaps) {
            const matchingGap = newData.topGaps.find((g: any) => g.microKey === oldTopGap.microKey);
            if (matchingGap && matchingGap.pctOfTarget > oldTopGap.pctOfTarget) {
              const improvement = matchingGap.pctOfTarget - oldTopGap.pctOfTarget;
              lastAmqsToastTime = now;
              toast({
                title: `${oldTopGap.label} gap improved by ${improvement}%`,
                description: `${entry.name} added. Keep going.`,
                action: seeGapsAction,
              });
            } else {
              lastAmqsToastTime = now;
              toast({ title: "Logged — dashboard updated", description: `${entry.name} added. AMQS recalculating.` });
            }
          } else {
            lastAmqsToastTime = now;
            toast({ title: "Logged — dashboard updated", description: `${entry.name} added. AMQS recalculating.` });
          }
        } else {
          lastAmqsToastTime = now;
          toast({ title: "Logged — dashboard updated", description: `${entry.name} added. AMQS recalculating.` });
        }
      } catch {
        lastAmqsToastTime = now;
        toast({ title: "Logged — dashboard updated", description: `${entry.name} added. AMQS recalculating.` });
      }
    },
    onError: (error) => {
      console.error("[food][create][mutation-error]", error);
      toast({
        title: "Failed to add food",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    },
  });
}

export function useUpdateFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<z.infer<typeof insertFoodEntrySchema>>) => {
      console.log("[food][update][attempt]", { id, ...data });
      const res = await fetch(`/api/food/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) {
        const errorText = await res.text().catch(() => "Unknown error");
        console.error("[food][update][error]", { id, status: res.status, body: errorText });
        throw new Error(`Failed to update food entry: ${res.status} - ${errorText}`);
      }
      const result = await res.json();
      console.log("[food][update][success]", { id: result.id, name: result.name });
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/food"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/food-entries/range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"] });
      toast({
        title: "Entry Updated",
        description: "Food item and totals have been updated.",
      });
    },
    onError: (error) => {
      console.error("[food][update][mutation-error]", error);
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update food entry",
        variant: "destructive",
      });
    },
  });
}

export function useDeleteFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      console.log("[food][delete][attempt]", { id });
      const url = buildUrl(api.food.delete.path, { id });
      const res = await fetch(url, { method: "DELETE", credentials: "include", cache: "no-store" });
      if (!res.ok) {
        const errorText = await res.text().catch(() => "Unknown error");
        console.error("[food][delete][error]", { id, status: res.status, body: errorText });
        throw new Error(`Failed to delete food entry: ${res.status}`);
      }
      console.log("[food][delete][success]", { id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/food"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/food-entries/range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"] });
      toast({
        title: "Entry Removed",
        description: "Food item has been deleted.",
      });
    },
    onError: (error) => {
      console.error("[food][delete][mutation-error]", error);
      toast({
        title: "Delete Failed",
        description: "Failed to remove food entry.",
        variant: "destructive",
      });
    },
  });
}

export function useWeightsRange(startDate: string, endDate: string) {
  return useQuery({
    queryKey: ["/api/me/weights/range", startDate, endDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/weights/range?start=${startDate}&end=${endDate}`, {
        cache: "no-store",
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 401) return [];
        throw new Error("Failed to fetch weights range");
      }
      return await res.json();
    },
    enabled: !!startDate && !!endDate,
    staleTime: 0,
    refetchOnMount: "always",
  });
}

export function useUpsertWeight() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { userId: number; date: string; weight: number }) => {
      const res = await fetch("/api/weights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) throw new Error("Failed to save weight");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/weights/range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/weights/range"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/readiness"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/fuel"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/weight-cut"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status"], exact: false });
      toast({
        title: "Weight Saved",
        description: "Your weight and targets have been updated.",
      });
    },
  });
}

function invalidateFoodQueries(queryClient: ReturnType<typeof useQueryClient>) {
  queryClient.invalidateQueries({ queryKey: ["/api/me/food"] });
  queryClient.invalidateQueries({ queryKey: ["/api/me/food-entries/range"] });
  queryClient.invalidateQueries({ queryKey: ["/api/me/logs"] });
  queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"] });
  queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"] });
  queryClient.invalidateQueries({ queryKey: ["/api/me/supplement-micros"] });
}

export function useMealTemplates() {
  return useQuery({
    queryKey: ["/api/me/meals/templates"],
    queryFn: async () => {
      const res = await fetch("/api/me/meals/templates", { credentials: "include", cache: "no-store" });
      if (!res.ok) {
        if (res.status === 401) return [];
        throw new Error("Failed to fetch meal templates");
      }
      return await res.json();
    },
  });
}

export function useSaveMealTemplate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { date: string; meal: string; name: string }) => {
      const res = await fetch("/api/me/meals/templates/from-log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.text().catch(() => "Unknown error");
        throw new Error(err);
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/meals/templates"] });
      toast({ title: "Meal Saved", description: "Your meal has been saved as a template." });
    },
    onError: (error) => {
      toast({ title: "Failed to save meal", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" });
    },
  });
}

export function useLogMealTemplate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { templateId: number; date: string; meal: string }) => {
      const res = await fetch(`/api/me/meals/templates/${data.templateId}/log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: data.date, meal: data.meal }),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.text().catch(() => "Unknown error");
        throw new Error(err);
      }
      return await res.json();
    },
    onSuccess: (result) => {
      invalidateFoodQueries(queryClient);
      toast({ title: "Meal Logged", description: `${result.count} items added to your log.` });
    },
    onError: (error) => {
      toast({ title: "Failed to log meal", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" });
    },
  });
}

export function useCopyMeal() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { fromDate: string; fromMeal: string; toDate: string; toMeal?: string }) => {
      const res = await fetch("/api/me/meals/copy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.text().catch(() => "Unknown error");
        throw new Error(err);
      }
      return await res.json();
    },
    onSuccess: (result) => {
      invalidateFoodQueries(queryClient);
      toast({ title: "Meal Copied", description: `${result.count} items copied successfully.` });
    },
    onError: (error) => {
      toast({ title: "Failed to copy meal", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" });
    },
  });
}

export function useDeleteMealTemplate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/me/meals/templates/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete template");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/meals/templates"] });
      toast({ title: "Template Deleted", description: "Saved meal has been removed." });
    },
  });
}
