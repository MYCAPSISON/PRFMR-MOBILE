import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";

interface MorningStatus {
  hasSleep: boolean;
  hasWeight: boolean;
  hasPlannedTraining: boolean;
}

const GATE_PREFIX = "checkInGateSeen";

export function useMorningCheckInGate() {
  const today = format(new Date(), "yyyy-MM-dd");
  const storageKey = `${GATE_PREFIX}:${today}`;

  const alreadySeenInStorage =
    typeof localStorage !== "undefined"
      ? localStorage.getItem(storageKey) === "true"
      : true;

  const [markedSeen, setMarkedSeen] = useState(false);
  const alreadySeen = alreadySeenInStorage || markedSeen;

  const { data: user } = useQuery<{ id: number; targetCalories: number | null } | null>({
    queryKey: ["/api/user/me"],
    retry: false,
  });

  const isAuthenticated = !!user;
  const isOnboarded = !!user?.targetCalories;

  const { data: status } = useQuery<MorningStatus>({
    queryKey: ["/api/me/morning-status", today],
    queryFn: async () => {
      const res = await fetch(`/api/me/morning-status/${today}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: isAuthenticated && isOnboarded && !alreadySeen,
  });

  const allDone = !!(
    status?.hasSleep &&
    status?.hasWeight &&
    status?.hasPlannedTraining
  );

  const shouldShow = isAuthenticated && isOnboarded && !alreadySeen && !!status && !allDone;

  function markSeen() {
    localStorage.setItem(storageKey, "true");
    setMarkedSeen(true);
  }

  return { shouldShow, status, today, markSeen, allDone, isAuthenticated };
}
