/**
 * Core Food Units — config for count/size-based food logging.
 *
 * How to add a new food:
 * 1. Find the exact food name as it appears in data/ingredients.json
 * 2. Add an entry to CORE_FOOD_UNITS keyed by that exact name
 * 3. Set supportsSize: true and provide gramsBySize if sizes differ meaningfully
 * 4. Set supportsSize: false and provide gramsPerUnit for uniform-size items
 * 5. Set a sensible defaultCount and defaultSize
 *
 * How count/size converts to grams:
 * - supportsSize: gramsPerUnit = gramsBySize[selectedSize]; totalGrams = gramsPerUnit * count
 * - no size:     totalGrams = gramsPerUnit * count
 *
 * The resulting totalGrams replaces the manual grams input and feeds directly into
 * the existing nutrition pipeline (calculateMacro → per100 * grams / 100).
 *
 * Weights are sourced from USDA FDC standard portion sizes.
 */

export type UnitSize = "small" | "medium" | "large";

export interface CoreFoodUnit {
  supportsCount: true;
  supportsSize: boolean;
  defaultCount: number;
  defaultSize?: UnitSize;
  gramsBySize?: Record<UnitSize, number>;
  gramsPerUnit?: number;
  unitLabel: string;
}

const CORE_FOOD_UNITS: Record<string, CoreFoodUnit> = {

  // ── Eggs ─────────────────────────────────────────────────────────────────
  "Eggs, Whole (Raw)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 2,
    defaultSize: "medium",
    gramsBySize: { small: 38, medium: 44, large: 50 },
    unitLabel: "egg",
  },

  // ── Fruits ───────────────────────────────────────────────────────────────

  // Banana — USDA FDC #09040 (peeled weights)
  "Banana (Peeled)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 101, medium: 118, large: 136 },
    unitLabel: "banana",
  },

  // Apple — whole fruit with skin (USDA portion sizes)
  "Apple": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 149, medium: 182, large: 223 },
    unitLabel: "apple",
  },

  // Orange — flesh only (USDA FDC #09200)
  "Orange (Flesh Only)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 96, medium: 131, large: 184 },
    unitLabel: "orange",
  },

  // Pear — flesh only, no core (USDA FDC #09252)
  "Pear (Flesh Only, No Core)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 120, medium: 166, large: 209 },
    unitLabel: "pear",
  },

  // Peach (USDA FDC #09236)
  "Peach": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 130, medium: 147, large: 175 },
    unitLabel: "peach",
  },

  // Nectarine (USDA FDC #09191)
  "Nectarine": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 115, medium: 142, large: 170 },
    unitLabel: "nectarine",
  },

  // Plum — 1 plum averages ~66g (USDA FDC #09279)
  "Plum": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 66,
    unitLabel: "plum",
  },

  // Apricot — 1 fresh apricot averages ~35g (USDA FDC #09021)
  "Apricot": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 2,
    gramsPerUnit: 35,
    unitLabel: "apricot",
  },

  // Kiwi — peeled, average 69g (USDA FDC #09148)
  "Kiwi (Peeled)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 69,
    unitLabel: "kiwi",
  },

  // Mango — flesh only (USDA FDC #09176)
  "Mango (Flesh Only)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 120, medium: 165, large: 220 },
    unitLabel: "mango",
  },

  // Avocado — flesh only (USDA FDC #09037)
  "Avocado (Flesh Only)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 80, medium: 100, large: 150 },
    unitLabel: "avocado",
  },

  // Grapefruit — flesh only (USDA FDC #09116)
  "Grapefruit": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 150, medium: 200, large: 250 },
    unitLabel: "grapefruit",
  },

  // Lemon — whole fruit (USDA FDC #09150)
  "Lemon": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 50, medium: 65, large: 80 },
    unitLabel: "lemon",
  },

  // Lime — whole fruit (USDA FDC #09159)
  "Lime": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 44,
    unitLabel: "lime",
  },

  // Pineapple — per ring/slice (USDA portion)
  "Pineapple (Flesh Only)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 2,
    defaultSize: "medium",
    gramsBySize: { small: 50, medium: 84, large: 112 },
    unitLabel: "ring",
  },

  // Watermelon — per slice (flesh only, USDA portion)
  "Watermelon (Flesh Only)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 152, medium: 280, large: 400 },
    unitLabel: "slice",
  },

  // Figs — 1 fresh fig averages ~50g (USDA FDC #09089)
  "Figs (Fresh)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 2,
    gramsPerUnit: 50,
    unitLabel: "fig",
  },

  // Dates — 1 medjool date ~24g, deglet ~8g; use ~8g for standard
  "Dates (Dried)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 3,
    gramsPerUnit: 8,
    unitLabel: "date",
  },

  // Prunes — 1 prune ~9g (USDA FDC #09291)
  "Prunes": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 3,
    gramsPerUnit: 9,
    unitLabel: "prune",
  },

  // Dried Apricots — 1 dried half ~8g (USDA FDC #09032)
  "Dried Apricots": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 4,
    gramsPerUnit: 8,
    unitLabel: "apricot half",
  },

  // Cherries — 1 sweet cherry ~8g (USDA FDC #09070)
  "Cherries": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 10,
    gramsPerUnit: 8,
    unitLabel: "cherry",
  },

  // Pomegranate — logged by half fruit (seeds/arils; ~87g per half)
  "Pomegranate": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 87,
    unitLabel: "½ pomegranate",
  },

  // ── Vegetables ──────────────────────────────────────────────────────────

  // Tomato — whole (USDA FDC #11529)
  "Tomato": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 91, medium: 123, large: 182 },
    unitLabel: "tomato",
  },

  // Cherry Tomatoes — per tomato ~17g (USDA)
  "Cherry Tomatoes": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 8,
    gramsPerUnit: 17,
    unitLabel: "tomato",
  },

  // Bell Pepper — per pepper (USDA FDC)
  "Bell Pepper (Red)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 75, medium: 119, large: 164 },
    unitLabel: "pepper",
  },
  "Bell Pepper (Green)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 75, medium: 119, large: 164 },
    unitLabel: "pepper",
  },
  "Bell Pepper (Yellow)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 75, medium: 119, large: 164 },
    unitLabel: "pepper",
  },

  // Onion — whole (USDA FDC #11282)
  "Onion": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 90, medium: 148, large: 210 },
    unitLabel: "onion",
  },
  "Red Onion": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 90, medium: 148, large: 210 },
    unitLabel: "onion",
  },

  // Spring Onion / Scallion — per stalk ~15g (USDA FDC #11677)
  "Spring Onion (Scallion)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 3,
    gramsPerUnit: 15,
    unitLabel: "stalk",
  },

  // Mushrooms — per whole mushroom ~18g (USDA FDC #11260)
  "Mushrooms (White)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 4,
    gramsPerUnit: 18,
    unitLabel: "mushroom",
  },

  // Celery — per stalk ~40g (USDA FDC #11143)
  "Celery": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 2,
    gramsPerUnit: 40,
    unitLabel: "stalk",
  },

  // Carrots (Raw) — per carrot (USDA FDC #11124)
  "Carrots (Raw)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 50, medium: 61, large: 82 },
    unitLabel: "carrot",
  },

  // Sweet Potato (Raw) — per potato (USDA FDC)
  "Sweet Potato (Raw)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 100, medium: 150, large: 200 },
    unitLabel: "sweet potato",
  },

  // Sweet Potato (Baked) — per potato (yield slightly less after baking)
  "Sweet Potato (Baked)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 90, medium: 130, large: 180 },
    unitLabel: "sweet potato",
  },

  // Potato (Baked, with Skin) — per potato (USDA FDC #11357)
  "Potato (Baked, with Skin)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 138, medium: 173, large: 250 },
    unitLabel: "potato",
  },

  // Potato (Raw) — per potato
  "Potato (Raw)": {
    supportsCount: true,
    supportsSize: true,
    defaultCount: 1,
    defaultSize: "medium",
    gramsBySize: { small: 100, medium: 150, large: 213 },
    unitLabel: "potato",
  },

  // ── Bread & Wraps ─────────────────────────────────────────────────────────

  "Bread (White Sliced)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 2,
    gramsPerUnit: 30,
    unitLabel: "slice",
  },
  "Bread (Wholemeal)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 2,
    gramsPerUnit: 35,
    unitLabel: "slice",
  },
  "Bread (Sourdough)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 35,
    unitLabel: "slice",
  },
  "Pitta Bread": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 70,
    unitLabel: "pitta",
  },
  "Bagel (Plain)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 105,
    unitLabel: "bagel",
  },
  "Tortilla Wrap (Wheat)": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 1,
    gramsPerUnit: 45,
    unitLabel: "wrap",
  },
  "Rice Cakes": {
    supportsCount: true,
    supportsSize: false,
    defaultCount: 3,
    gramsPerUnit: 9,
    unitLabel: "rice cake",
  },
};

export function getCoreFoodUnit(foodName: string): CoreFoodUnit | null {
  return CORE_FOOD_UNITS[foodName] ?? null;
}

export function computeUnitGrams(
  unit: CoreFoodUnit,
  count: number,
  size: UnitSize
): number {
  if (unit.supportsSize && unit.gramsBySize) {
    return Math.round(unit.gramsBySize[size] * count);
  }
  return Math.round((unit.gramsPerUnit ?? 100) * count);
}

export default CORE_FOOD_UNITS;
