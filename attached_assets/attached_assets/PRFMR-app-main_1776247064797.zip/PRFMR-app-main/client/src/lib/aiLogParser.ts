/**
 * AI-Assisted Logging — Rule-Based Parser
 *
 * Converts natural-language input into structured intent objects.
 * ALL results have requiresConfirmation: true — nothing is saved without user action.
 *
 * See docs/ai_assisted_logging.md for full architecture documentation.
 */

// ─── Types ──────────────────────────────────────────────────────────────────

export type IntentType =
  | "log_food"
  | "log_weight"
  | "log_training_session"
  | "log_supplements"
  | "create_recurring_training_schedule"
  | "unknown";

export type Confidence = "high" | "medium" | "low";

export interface FoodItem {
  rawText: string;
  normalizedName: string;
  count?: number;
  sizeHint?: "small" | "medium" | "large";
  gramsHint?: number;
}

export interface ParsedFood {
  intent: "log_food";
  meal: "breakfast" | "lunch" | "dinner" | "snack";
  items: FoodItem[];
  rawInput: string;
  confidence: Confidence;
  requiresConfirmation: true;
  missingFields: string[];
}

export interface ParsedWeight {
  intent: "log_weight";
  weightKg: number;
  rawInput: string;
  confidence: Confidence;
  requiresConfirmation: true;
  missingFields: string[];
}

export interface ParsedTraining {
  intent: "log_training_session";
  activityName: string;
  durationMinutes: number;
  timeOfDay: "morning" | "afternoon" | "evening";
  timeLabel?: string;
  rawInput: string;
  confidence: Confidence;
  requiresConfirmation: true;
  missingFields: string[];
}

export interface ParsedSupplements {
  intent: "log_supplements";
  items: string[];
  rawInput: string;
  confidence: Confidence;
  requiresConfirmation: true;
  missingFields: string[];
}

export interface RecurringSession {
  activityName: string;
  timeLabel?: string;
  timeOfDay: "morning" | "afternoon" | "evening";
  durationMinutes: number;
}

export interface ParsedRecurring {
  intent: "create_recurring_training_schedule";
  dayOfWeek: string;
  scope?: "fight camp" | "general";
  sessions: RecurringSession[];
  rawInput: string;
  confidence: Confidence;
  requiresConfirmation: true;
  missingFields: string[];
}

export interface ParsedUnknown {
  intent: "unknown";
  confidence: "low";
  requiresConfirmation: true;
  clarificationHint: string;
  rawInput: string;
  missingFields: string[];
}

export type ParseResult =
  | ParsedFood
  | ParsedWeight
  | ParsedTraining
  | ParsedSupplements
  | ParsedRecurring
  | ParsedUnknown;

// ─── Keyword Banks ───────────────────────────────────────────────────────────

const TRAINING_ACTIVITY_KEYWORDS = [
  "muay thai", "thai boxing", "pads", "thai pads", "pad work", "sparring",
  "boxing", "bag work", "shadow boxing", "shadow",
  "bjj", "jiu jitsu", "jiu-jitsu", "grappling", "wrestling", "judo",
  "running", "run", "jog", "jogging",
  "cycling", "bike", "assault bike", "echo bike",
  "swimming", "swim",
  "rowing", "rower", "ski erg",
  "lifting", "weights", "strength training", "strength", "squats", "deadlifts", "bench",
  "cardio", "hiit", "crossfit", "circuit", "circuits",
  "yoga", "pilates", "stretching",
  "drill", "drills", "conditioning",
  "walk", "walking", "hike",
  "kettle", "kettlebell",
];

// Maps detected activity keywords to canonical catalog names for API search
const ACTIVITY_CANONICAL_NAME: Record<string, string> = {
  "lifting": "Strength Training",
  "weights": "Strength Training",
  "strength": "Strength Training",
  "strength training": "Strength Training",
  "squats": "Strength Training",
  "deadlifts": "Strength Training",
  "bench": "Strength Training",
  "muay thai": "Muay Thai",
  "thai boxing": "Muay Thai",
  "pads": "Muay Thai",
  "thai pads": "Muay Thai",
  "pad work": "Muay Thai",
  "boxing": "Boxing (sparring)",
  "bag work": "Boxing (bag work)",
  "shadow boxing": "Boxing (shadowboxing)",
  "bjj": "Judo/Jiu-Jitsu",
  "jiu jitsu": "Judo/Jiu-Jitsu",
  "jiu-jitsu": "Judo/Jiu-Jitsu",
  "grappling": "Judo/Jiu-Jitsu",
  "judo": "Judo/Jiu-Jitsu",
  "run": "Running (moderate)",
  "running": "Running (moderate)",
  "jog": "Jogging",
  "jogging": "Jogging",
  "cycling": "Cycling (moderate)",
  "bike": "Cycling (moderate)",
  "swimming": "Swimming Laps (moderate)",
  "swim": "Swimming Laps (moderate)",
  "rowing": "Rowing Machine (moderate)",
  "rower": "Rowing Machine (moderate)",
  "hiit": "HIIT",
  "crossfit": "CrossFit (general)",
  "circuit": "Circuit Training",
  "circuits": "Circuit Training",
  "walk": "Walking (brisk)",
  "walking": "Walking (brisk)",
  "hike": "Hiking",
  "kettlebell": "Kettlebell Swing",
  "kettle": "Kettlebell Swing",
  "yoga": "Yoga (hatha)",
  "pilates": "Pilates",
  "wrestling": "Wrestling",
  "sparring": "Boxing (sparring)",
};

const SUPPLEMENT_KEYWORDS = [
  "creatine", "creatine monohydrate",
  "vitamin d", "vitamin d3", "vitamin c", "vitamin b12", "vitamin b6", "vitamin a", "vitamin e", "vitamin k",
  "magnesium", "zinc", "iron", "iodine", "selenium", "folate", "folic acid",
  "fish oil", "omega 3", "omega-3",
  "whey", "protein shake", "protein powder",
  "bcaa", "eaa", "amino", "glutamine",
  "caffeine", "pre workout", "preworkout", "pre-workout",
  "electrolyte", "electrolytes",
  "melatonin", "ashwagandha", "turmeric", "curcumin",
  "hmb", "beta alanine", "beta-alanine", "l-theanine", "theanine",
  "probiotics", "probiotic", "collagen", "coq10",
];

const MEAL_KEYWORDS: Record<string, "breakfast" | "lunch" | "dinner" | "snack"> = {
  breakfast: "breakfast",
  "morning meal": "breakfast",
  lunch: "lunch",
  dinner: "dinner",
  supper: "dinner",
  tea: "dinner",
  snack: "snack",
  snacks: "snack",
};

const FOOD_TRIGGER_PHRASES = [
  "had", "ate", "eaten", "having", "eating",
  "for breakfast", "for lunch", "for dinner", "for tea",
  "for a snack", "as a snack",
  "logged", "add food", "i had", "just had",
];

const WEIGHT_TRIGGER_PHRASES = [
  "weight", "weigh", "weighed", "weighing", "morning weight",
  "bodyweight", "bw", "scale",
];

const DAYS_OF_WEEK = [
  "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
  "mon", "tue", "tues", "wed", "thu", "thur", "fri", "sat", "sun",
];

// ─── Utility Functions ───────────────────────────────────────────────────────

function norm(text: string): string {
  return text.toLowerCase().trim();
}

function extractDuration(text: string): number | null {
  const hourMin = text.match(/(\d+)\s*h(?:ours?)?\s*(?:and\s*)?(\d+)\s*m(?:ins?|inutes?)?/i);
  if (hourMin) return parseInt(hourMin[1]) * 60 + parseInt(hourMin[2]);

  const hourOnly = text.match(/(\d+)\s*h(?:ours?)?(?!\s*\d)/i);
  if (hourOnly) return parseInt(hourOnly[1]) * 60;

  const halfHour = text.match(/half\s+(?:an?\s+)?hour/i);
  if (halfHour) return 30;

  const minMatch = text.match(/(\d+)\s*(?:mins?|minutes?)/i);
  if (minMatch) return parseInt(minMatch[1]);

  return null;
}

function extractTime(text: string): { label: string; timeOfDay: "morning" | "afternoon" | "evening" } | null {
  const amPm = text.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i);
  if (amPm) {
    let hour = parseInt(amPm[1]);
    const mins = amPm[2] ? amPm[2] : "00";
    const meridiem = amPm[3].toLowerCase();
    if (meridiem === "pm" && hour < 12) hour += 12;
    if (meridiem === "am" && hour === 12) hour = 0;
    const label = `${amPm[1]}${amPm[2] ? ":" + amPm[2] : ""}${amPm[3].toLowerCase()}`;
    const timeOfDay: "morning" | "afternoon" | "evening" =
      hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    return { label, timeOfDay };
  }

  const h24 = text.match(/\b(\d{1,2}):(\d{2})\b/);
  if (h24) {
    const hour = parseInt(h24[1]);
    const label = `${h24[1]}:${h24[2]}`;
    const timeOfDay: "morning" | "afternoon" | "evening" =
      hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    return { label, timeOfDay };
  }

  if (/morning/i.test(text)) return { label: "morning", timeOfDay: "morning" };
  if (/afternoon/i.test(text)) return { label: "afternoon", timeOfDay: "afternoon" };
  if (/evening|tonight/i.test(text)) return { label: "evening", timeOfDay: "evening" };

  return null;
}

function extractWeightKg(text: string): number | null {
  const lbs = text.match(/(\d+\.?\d*)\s*(?:lbs?|pounds?)/i);
  if (lbs) return Math.round(parseFloat(lbs[1]) * 0.453592 * 10) / 10;

  const kg = text.match(/(\d+\.?\d*)\s*(?:kgs?|kilos?|kilograms?)/i);
  if (kg) return parseFloat(kg[1]);

  // "weight 71.8" or "morning weight 71.8"
  const afterWeight = text.match(/(?:weight|weigh(?:ed|ing)?)\s*[:\s]\s*(\d+\.?\d*)/i);
  if (afterWeight) return parseFloat(afterWeight[1]);

  // bare number that looks like bodyweight (40–200)
  const bare = text.match(/^[+-]?(\d{2,3}(?:\.\d{1,2})?)(?:\s*kg)?$/);
  if (bare) {
    const v = parseFloat(bare[1]);
    if (v >= 40 && v <= 250) return v;
  }

  return null;
}

function extractFoodItems(text: string): FoodItem[] {
  const items: FoodItem[] = [];
  let remaining = text;

  // Remove meal context
  remaining = remaining
    .replace(/\bfor\s+(breakfast|lunch|dinner|tea|supper|a snack|snack)\b/gi, "")
    .replace(/\b(breakfast|lunch|dinner|tea|supper|snack)\s*:/gi, "")
    .replace(/\b(i had|i ate|i've had|just had|had|ate|eaten|having|eating|add|log)\b/gi, "")
    .trim();

  // Split on "and", "with", "plus", ","
  const parts = remaining.split(/\band\b|\bwith\b|\bplus\b|,/i).map(p => p.trim()).filter(Boolean);

  for (const part of parts) {
    if (!part || part.length < 2) continue;

    let count: number | undefined;
    let sizeHint: "small" | "medium" | "large" | undefined;
    let gramsHint: number | undefined;
    let nameStr = part.trim();

    // Check for size hints
    if (/\bsmall\b/i.test(nameStr)) sizeHint = "small";
    else if (/\blarge\b/i.test(nameStr)) sizeHint = "large";
    else if (/\bmedium\b/i.test(nameStr)) sizeHint = "medium";

    // Extract grams: "100g of chicken" or "150 grams rice"
    const gramsMatch = nameStr.match(/(\d+\.?\d*)\s*(?:g|grams?)\s+(?:of\s+)?(.+)/i);
    if (gramsMatch) {
      gramsHint = parseFloat(gramsMatch[1]);
      nameStr = gramsMatch[2].trim();
    } else {
      // Extract count: "2 eggs", "3 slices of toast", "a banana"
      const countMatch = nameStr.match(/^(\d+(?:\.\d+)?|a|an)\s+(?:x\s+)?(.+)/i);
      if (countMatch) {
        count = countMatch[1] === "a" || countMatch[1] === "an" ? 1 : parseFloat(countMatch[1]);
        nameStr = countMatch[2].trim();
      }
    }

    // Clean up common descriptors
    nameStr = nameStr
      .replace(/\bslices?\s+of\b/i, "")
      .replace(/\bserving\s+of\b/i, "")
      .replace(/\bpiece[s]?\s+of\b/i, "")
      .replace(/\bportions?\s+of\b/i, "")
      .replace(/\bsmall|medium|large\b/gi, "")
      .replace(/\b(?:whole|boiled|scrambled|fried|poached|grilled|baked|raw|cooked)\b/gi, "")
      .trim();

    if (nameStr.length >= 2) {
      items.push({
        rawText: part,
        normalizedName: nameStr,
        count,
        sizeHint,
        gramsHint,
      });
    }
  }

  return items;
}

function extractSupplementNames(text: string): string[] {
  const found: string[] = [];
  const lower = norm(text);

  // Sort by length descending to match "creatine monohydrate" before "creatine"
  const sorted = [...SUPPLEMENT_KEYWORDS].sort((a, b) => b.length - a.length);

  for (const kw of sorted) {
    if (lower.includes(kw)) {
      // Avoid duplicates (e.g., don't match both "vitamin d" and "vitamin d3")
      if (!found.some(f => f.includes(kw) || kw.includes(f))) {
        found.push(kw);
      }
    }
  }

  return found;
}

function detectMeal(text: string): "breakfast" | "lunch" | "dinner" | "snack" {
  const lower = norm(text);
  for (const [kw, meal] of Object.entries(MEAL_KEYWORDS)) {
    if (lower.includes(kw)) return meal;
  }
  return "snack"; // fallback
}

// ─── Intent Scoring ──────────────────────────────────────────────────────────

function scoreWeight(text: string): number {
  const lower = norm(text);
  let score = 0;
  if (WEIGHT_TRIGGER_PHRASES.some(kw => lower.includes(kw))) score += 3;
  if (extractWeightKg(text) !== null) score += 4;
  return score;
}

function scoreTraining(text: string): number {
  const lower = norm(text);
  let score = 0;
  if (TRAINING_ACTIVITY_KEYWORDS.some(kw => lower.includes(kw))) score += 3;
  if (extractDuration(text) !== null) score += 2;
  if (extractTime(text) !== null) score += 1;
  return score;
}

function scoreSupplements(text: string): number {
  const lower = norm(text);
  let score = 0;
  const names = extractSupplementNames(text);
  score += names.length * 2;
  if (/\b(?:taken|took|had|taking|finished|done)\b/i.test(lower)) score += 2;
  return score;
}

function scoreFood(text: string): number {
  const lower = norm(text);
  let score = 0;
  if (FOOD_TRIGGER_PHRASES.some(kw => lower.includes(kw))) score += 2;
  if (Object.keys(MEAL_KEYWORDS).some(kw => lower.includes(kw))) score += 2;
  const items = extractFoodItems(text);
  score += Math.min(items.length * 2, 6);
  return score;
}

function scoreRecurring(text: string): number {
  const lower = norm(text);
  let score = 0;
  if (/every\s+(week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i.test(lower)) score += 4;
  if (DAYS_OF_WEEK.some(d => lower.includes(d))) score += 2;
  if (TRAINING_ACTIVITY_KEYWORDS.some(kw => lower.includes(kw))) score += 1;
  return score;
}

// ─── Sub-parsers ──────────────────────────────────────────────────────────────

function parseWeight(text: string): ParsedWeight | null {
  const weightKg = extractWeightKg(text);
  if (weightKg === null) return null;

  const missingFields: string[] = [];
  const confidence: Confidence =
    WEIGHT_TRIGGER_PHRASES.some(kw => norm(text).includes(kw)) ? "high" : "medium";

  return {
    intent: "log_weight",
    weightKg,
    rawInput: text,
    confidence,
    requiresConfirmation: true,
    missingFields,
  };
}

function parseTraining(text: string): ParsedTraining | null {
  const lower = norm(text);
  const foundActivity = TRAINING_ACTIVITY_KEYWORDS.find(kw => lower.includes(kw));
  if (!foundActivity) return null;

  const duration = extractDuration(text);
  const timeResult = extractTime(text);

  const missingFields: string[] = [];
  if (!duration) missingFields.push("duration");

  const timeOfDay: "morning" | "afternoon" | "evening" =
    timeResult?.timeOfDay ?? (lower.includes("morning") ? "morning" : "afternoon");

  // Use canonical catalog name if available, otherwise capitalize
  const activityName = ACTIVITY_CANONICAL_NAME[foundActivity] ??
    foundActivity
      .split(" ")
      .map(w => w.charAt(0).toUpperCase() + w.slice(1))
      .join(" ");

  const confidence: Confidence =
    duration && timeResult ? "high" : duration ? "medium" : "low";

  return {
    intent: "log_training_session",
    activityName,
    durationMinutes: duration ?? 60,
    timeOfDay,
    timeLabel: timeResult?.label,
    rawInput: text,
    confidence,
    requiresConfirmation: true,
    missingFields,
  };
}

function parseSupplements(text: string): ParsedSupplements | null {
  const names = extractSupplementNames(text);
  if (names.length === 0) return null;

  const confidence: Confidence =
    /\b(?:taken|took|had|taking)\b/i.test(text)
      ? names.length > 1 ? "high" : "medium"
      : "low";

  const displayNames = names.map(n =>
    n.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ")
  );

  return {
    intent: "log_supplements",
    items: displayNames,
    rawInput: text,
    confidence,
    requiresConfirmation: true,
    missingFields: [],
  };
}

function parseFood(text: string): ParsedFood | null {
  const items = extractFoodItems(text);
  if (items.length === 0) return null;

  const meal = detectMeal(text);
  const hasMealKeyword = Object.keys(MEAL_KEYWORDS).some(kw => norm(text).includes(kw));
  const hasFoodTrigger = FOOD_TRIGGER_PHRASES.some(kw => norm(text).includes(kw));
  const confidence: Confidence =
    hasMealKeyword && items.length >= 1 ? "high" :
    hasFoodTrigger && items.length >= 1 ? "medium" : "low";

  return {
    intent: "log_food",
    meal,
    items,
    rawInput: text,
    confidence,
    requiresConfirmation: true,
    missingFields: [],
  };
}

function parseRecurring(text: string): ParsedRecurring | null {
  const lower = norm(text);
  if (!/every\s+/i.test(lower)) return null;

  const dayMatch = lower.match(/every\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|tues|wed|thu|thur|fri|sat|sun)/i);
  if (!dayMatch) return null;

  const dayMap: Record<string, string> = {
    mon: "Monday", tue: "Tuesday", tues: "Tuesday", wed: "Wednesday",
    thu: "Thursday", thur: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday",
  };
  const dayRaw = dayMatch[1].toLowerCase();
  const dayOfWeek = dayMap[dayRaw] ?? (dayRaw.charAt(0).toUpperCase() + dayRaw.slice(1));

  const scope: "fight camp" | "general" | undefined = lower.includes("fight camp") ? "fight camp" : "general";

  // Extract sessions: split on "and" to find multiple activities
  const sessionTexts = text.split(/\band\b/i);
  const sessions: RecurringSession[] = [];

  for (const part of sessionTexts) {
    if (!part.trim()) continue;
    const foundActivity = TRAINING_ACTIVITY_KEYWORDS.find(kw => norm(part).includes(kw));
    if (!foundActivity) continue;

    const duration = extractDuration(part);
    const timeResult = extractTime(part);
    const timeOfDay: "morning" | "afternoon" | "evening" =
      timeResult?.timeOfDay ?? "afternoon";

    const activityName = ACTIVITY_CANONICAL_NAME[foundActivity] ??
      foundActivity
        .split(" ")
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ");

    sessions.push({
      activityName,
      timeLabel: timeResult?.label,
      timeOfDay,
      durationMinutes: duration ?? 60,
    });
  }

  if (sessions.length === 0) return null;

  const confidence: Confidence = sessions.length > 1 ? "medium" : "medium";

  return {
    intent: "create_recurring_training_schedule",
    dayOfWeek,
    scope,
    sessions,
    rawInput: text,
    confidence,
    requiresConfirmation: true,
    missingFields: [],
  };
}

// ─── Main Entry Point ─────────────────────────────────────────────────────────

/**
 * Parse a natural-language logging input into a structured intent.
 *
 * Rules:
 * - Always returns requiresConfirmation: true
 * - Never writes to the database
 * - Prefers deterministic rule-based matching over guessing
 * - Returns intent: "unknown" when confidence is too low
 */
export function parseAiLogInput(input: string): ParseResult {
  const text = input.trim();
  if (!text) {
    return {
      intent: "unknown",
      confidence: "low",
      requiresConfirmation: true,
      clarificationHint: "Type what you want to log — e.g. '2 eggs and toast for breakfast', 'Morning weight 71.8', or 'Pads for 60 min at 7pm'.",
      rawInput: input,
      missingFields: [],
    };
  }

  // Score each intent
  const scores = {
    recurring: scoreRecurring(text),
    weight: scoreWeight(text),
    training: scoreTraining(text),
    supplements: scoreSupplements(text),
    food: scoreFood(text),
  };

  // Pick the highest-scoring intent
  const sorted = Object.entries(scores).sort(([, a], [, b]) => b - a);
  const [topIntent] = sorted;

  if (topIntent[1] < 2) {
    return {
      intent: "unknown",
      confidence: "low",
      requiresConfirmation: true,
      clarificationHint:
        "I'm not sure what to log. Try: '2 eggs for breakfast', 'Morning weight 71.8', 'Pads 60 min at 7pm', or 'Creatine and Vitamin D taken'.",
      rawInput: input,
      missingFields: [],
    };
  }

  switch (topIntent[0]) {
    case "recurring": {
      const r = parseRecurring(text);
      if (r) return r;
      break;
    }
    case "weight": {
      const w = parseWeight(text);
      if (w) return w;
      break;
    }
    case "training": {
      const t = parseTraining(text);
      if (t) return t;
      break;
    }
    case "supplements": {
      const s = parseSupplements(text);
      if (s) return s;
      break;
    }
    case "food": {
      const f = parseFood(text);
      if (f) return f;
      break;
    }
  }

  return {
    intent: "unknown",
    confidence: "low",
    requiresConfirmation: true,
    clarificationHint:
      "I recognised a pattern but couldn't extract enough information. Try adding more detail — e.g. activity duration, weight value, or food names.",
    rawInput: input,
    missingFields: [],
  };
}
