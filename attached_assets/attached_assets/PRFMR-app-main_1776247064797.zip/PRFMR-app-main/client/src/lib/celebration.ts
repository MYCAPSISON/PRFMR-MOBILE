const celebrationBus = new EventTarget();

export interface CelebrationEvent {
  emoji: string;
}

export function fireCelebration(emoji: string) {
  celebrationBus.dispatchEvent(
    new CustomEvent<CelebrationEvent>("celebrate", { detail: { emoji } })
  );
}

export { celebrationBus };
