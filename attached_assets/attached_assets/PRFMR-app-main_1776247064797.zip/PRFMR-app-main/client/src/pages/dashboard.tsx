import { useEffect, useState, useRef } from "react";
import { useUser } from "@/hooks/use-user";
import { useLogs, useCreateLog, useUpdateLog, useFoodEntries, useCreateFoodEntry, useDeleteFoodEntry, useFoodEntriesRange, useWeightsRange, useUpsertWeight, useUpdateFoodEntry, useMealTemplates, useSaveMealTemplate, useLogMealTemplate, useCopyMeal, useDeleteMealTemplate } from "@/hooks/use-logs";
import { useFightCampOverride } from "@/hooks/useFightCampOverride";
import { Layout } from "@/components/layout";
import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flame, Beef, Wheat, Droplets, Plus, Scale, Trash2, Utensils, Search, Leaf, ChevronLeft, ChevronRight, Calendar, Pencil, Coffee, Sun, Moon, Cookie, Pill, Check, X, Dumbbell, Bookmark, Copy, BookOpen, MessageSquare, Loader2, UtensilsCrossed, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { MealType } from "@shared/schema";
import { format, parseISO, subDays, addDays } from "date-fns";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { getMicronutrientValue } from "@shared/utils";

interface RawIntake {
  id: number;
  supplementId: number;
  stackId: number | null;
  reminderId: number | null;
  taken: boolean;
  date: string;
}

import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TooltipProvider, Tooltip as UITooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ShieldCheck, Info, ChevronDown as ChevronDownIcon } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from "@/components/ui/collapsible";

import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";

import { WeightUpdateDialog } from "@/components/weight-update-dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getCoreFoodUnit, computeUnitGrams, type UnitSize } from "@/lib/coreFoodUnits";
import { useMutation } from "@tanstack/react-query";
import type { SupplementStack, StackReminder, Supplement, SupplementLog, StackSupplement } from "@shared/schema";
import { Link } from "wouter";
import { EmailVerificationBanner } from "@/components/email-verification-banner";
import { MorningCheckIn } from "@/components/MorningCheckIn";
import { ProvisionalCheckIn } from "@/components/ProvisionalCheckIn";
import { ReadinessSummaryCard } from "@/components/ReadinessSummaryCard";
import { WeightCutHero } from "@/components/WeightCutHero";
import { CelebrationBurst } from "@/components/CelebrationBurst";
import { AILogDialog } from "@/components/AILogDialog";
import { useToast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";

// Type for scheduled stacks API response - now flat slots
interface ScheduledSlot {
  stackId: number;
  stackName: string;
  reminderId: number;
  time: string;
  supplementId: number;
  supplementName: string;
  doseAmount: number | null;
  doseUnit: string | null;
}

// Type for supplement-level reminders
interface SupplementReminder {
  supplementId: number;
  supplementName: string;
  doseAmount: number | null;
  doseUnit: string | null;
  reminderTime: string;
}

function TodaysSupplements({ userId, selectedDate }: { userId: number; selectedDate: string }) {
  const displayDate = format(parseISO(selectedDate), "MMM d");
  const qc = useQueryClient();
  const { toast } = useToast();
  
  const intakeQueryKey = ["/api/me/supplement-intakes", selectedDate] as const;

  const { data: scheduledSlots = [], isLoading } = useQuery<ScheduledSlot[]>({
    queryKey: ["/api/me/stacks/scheduled", selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/stacks/scheduled?date=${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: suppReminders = [] } = useQuery<SupplementReminder[]>({
    queryKey: ["/api/me/supplements/reminders"],
    queryFn: async () => {
      const res = await fetch(`/api/me/supplements/reminders`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: rawIntakes = [] } = useQuery<RawIntake[]>({
    queryKey: intakeQueryKey,
    queryFn: async () => {
      const res = await fetch(`/api/me/supplement-intakes/${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const intakeSlotKey = (i: { supplementId: number; stackId: number | null; reminderId: number | null }) =>
    `${i.stackId ?? 0}-${i.reminderId ?? 0}-${i.supplementId}`;

  const takenSlotKeys = new Set(
    rawIntakes.filter(i => i.taken).map(i => intakeSlotKey(i))
  );

  const toggleMutation = useMutation({
    mutationFn: async (data: { supplementId: number; stackId: number; reminderId: number; taken: boolean }) => {
      const intakeResult = await apiRequest("POST", "/api/supplement-intakes", {
        supplementId: data.supplementId,
        stackId: data.stackId,
        reminderId: data.reminderId,
        date: selectedDate,
        taken: data.taken,
      });

      if (data.taken) {
        await apiRequest("POST", "/api/supplement-logs", {
          supplementId: data.supplementId,
          stackId: data.stackId,
          date: selectedDate,
          time: format(new Date(), "HH:mm"),
          taken: true,
        });
      }

      return intakeResult;
    },
    onMutate: async (data) => {
      await qc.cancelQueries({ queryKey: intakeQueryKey });
      const previous = qc.getQueryData<RawIntake[]>(intakeQueryKey);

      qc.setQueryData<RawIntake[]>(intakeQueryKey, (old = []) => {
        const key = intakeSlotKey(data);
        if (data.taken) {
          const alreadyExists = old.some(i => intakeSlotKey(i) === key);
          if (alreadyExists) {
            return old.map(i => intakeSlotKey(i) === key ? { ...i, taken: true } : i);
          }
          return [...old, {
            id: -Date.now(),
            supplementId: data.supplementId,
            stackId: data.stackId,
            reminderId: data.reminderId,
            taken: true,
            date: selectedDate,
          }];
        } else {
          return old.filter(i => intakeSlotKey(i) !== key);
        }
      });

      return { previous };
    },
    onError: (_err, _data, context) => {
      if (context?.previous) {
        qc.setQueryData(intakeQueryKey, context.previous);
      }
    },
    onSuccess: async (_data, variables) => {
      if (!variables.taken) return;
      const oldData = qc.getQueryData<any>(["/api/me/amqs/score", selectedDate]);
      const oldScore = oldData?.score ?? null;

      try {
        await new Promise(r => setTimeout(r, 300));
        const res = await fetch(`/api/me/amqs/score/${selectedDate}`, { credentials: "include", cache: "no-store" });
        if (res.ok) {
          const newData = await res.json();
          const newScore = newData?.score ?? null;
          const scrollToAmqs = () => { window.location.href = '/'; };
          if (oldScore !== null && newScore !== null && newScore > oldScore) {
            toast({
              title: `AMQS +${newScore - oldScore}`,
              description: "Supplement boosted your micronutrient score.",
              action: <ToastAction altText="See updated gaps" onClick={scrollToAmqs} data-testid="toast-see-gaps-supp">See updated gaps</ToastAction>,
            });
          } else {
            toast({ title: "Logged — dashboard updated", description: "Supplement marked as taken. AMQS recalculating." });
          }
        } else {
          toast({ title: "Logged — dashboard updated", description: "Supplement marked as taken. AMQS recalculating." });
        }
      } catch {
        toast({ title: "Logged — dashboard updated", description: "Supplement marked as taken. AMQS recalculating." });
      }
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: intakeQueryKey });
      qc.invalidateQueries({ queryKey: ["/api/me/supplement-logs"], exact: false });
      qc.invalidateQueries({ queryKey: ["/api/me/supplement-micros"], exact: false });
      qc.invalidateQueries({ queryKey: ["/api/me/supplement-micros-range"], exact: false });
      qc.invalidateQueries({ queryKey: ["/api/me/amqs/score"], exact: false });
      qc.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"], exact: false });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Supplements — {displayDate}
            </CardTitle>
            <CardDescription>Loading...</CardDescription>
          </div>
        </CardHeader>
      </Card>
    );
  }

  // Helper to generate slot key
  const getSlotKey = (slot: ScheduledSlot) => `${slot.stackId}-${slot.reminderId}-${slot.supplementId}`;
  const getSuppReminderKey = (s: SupplementReminder) => `0-0-${s.supplementId}`;

  const hasAny = scheduledSlots.length > 0 || suppReminders.length > 0;

  if (!hasAny) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Supplements — {displayDate}
            </CardTitle>
            <CardDescription>
              Today's scheduled supplements
            </CardDescription>
          </div>
          <Link href="/supplements">
            <Button variant="ghost" size="sm">Manage</Button>
          </Link>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No supplements scheduled today. Enable reminders on your supplements to see them here.</p>
        </CardContent>
      </Card>
    );
  }

  const takenCount = [
    ...scheduledSlots.filter(s => takenSlotKeys.has(getSlotKey(s))),
    ...suppReminders.filter(s => takenSlotKeys.has(getSuppReminderKey(s))),
  ].length;
  const totalCount = scheduledSlots.length + suppReminders.length;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Pill className="h-5 w-5" />
            Supplements — {displayDate}
          </CardTitle>
          <CardDescription>
            Scheduled for today ({takenCount} of {totalCount} taken)
          </CardDescription>
        </div>
        <Link href="/supplements">
          <Button variant="ghost" size="sm">Manage</Button>
        </Link>
      </CardHeader>
      <CardContent className="space-y-2">
        {scheduledSlots.map((slot) => {
          const slotKey = getSlotKey(slot);
          const taken = takenSlotKeys.has(slotKey);
          const doseLabel = slot.doseAmount && slot.doseUnit
            ? `${slot.doseAmount} ${slot.doseUnit}`
            : null;

          return (
            <div
              key={slotKey}
              className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                taken ? "bg-emerald-500/10 border-emerald-500/30" : "bg-secondary/30"
              }`}
              data-testid={`supp-slot-${slotKey}`}
            >
              <div className="flex-1">
                <p className={`font-medium text-sm ${taken ? "line-through text-muted-foreground" : ""}`}>
                  {slot.supplementName}
                  {doseLabel && <span className="text-muted-foreground font-normal"> ({doseLabel})</span>}
                </p>
                <p className="text-xs text-muted-foreground">
                  {slot.stackName} at {slot.time}
                </p>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant={taken ? "default" : "outline"}
                  className={`h-8 w-8 ${taken ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
                  onClick={() => toggleMutation.mutate({
                    supplementId: slot.supplementId,
                    stackId: slot.stackId,
                    reminderId: slot.reminderId,
                    taken: !taken
                  })}
                  disabled={toggleMutation.isPending}
                  data-testid={`button-take-${slotKey}`}
                >
                  {taken ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          );
        })}

        {suppReminders.map((supp) => {
          const slotKey = getSuppReminderKey(supp);
          const taken = takenSlotKeys.has(slotKey);
          const doseLabel = supp.doseAmount && supp.doseUnit
            ? `${supp.doseAmount} ${supp.doseUnit}`
            : null;

          return (
            <div
              key={slotKey}
              className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                taken ? "bg-emerald-500/10 border-emerald-500/30" : "bg-secondary/30"
              }`}
              data-testid={`supp-slot-${slotKey}`}
            >
              <div className="flex-1">
                <p className={`font-medium text-sm ${taken ? "line-through text-muted-foreground" : ""}`}>
                  {supp.supplementName}
                  {doseLabel && <span className="text-muted-foreground font-normal"> ({doseLabel})</span>}
                </p>
                <p className="text-xs text-muted-foreground">
                  at {supp.reminderTime}
                </p>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant={taken ? "default" : "outline"}
                  className={`h-8 w-8 ${taken ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
                  onClick={() => toggleMutation.mutate({
                    supplementId: supp.supplementId,
                    stackId: 0,
                    reminderId: 0,
                    taken: !taken
                  })}
                  disabled={toggleMutation.isPending}
                  data-testid={`button-take-${slotKey}`}
                >
                  {taken ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          );
        })}

        <p className="text-[10px] text-muted-foreground italic pt-2">
          Personal tracking only. Not medical advice.
        </p>
      </CardContent>
    </Card>
  );
}

interface SessionRaw {
  id: number;
  timeOfDay: string;
  title?: string;
  estimatedKcal: number;
  exercises: { id: number; estimatedKcal?: number }[];
  activities: { id: number; name: string; estimatedKcal: number }[];
}

interface SessionSummary {
  id: number;
  timeOfDay: string;
  exerciseCount: number;
  activityCount: number;
  totalCalories: number;
  isManual: boolean;
  manualLabel?: string;
}

function TodaysTraining({ selectedDate }: { selectedDate: string }) {
  const displayDate = format(parseISO(selectedDate), "MMM d");
  const [manualOpen, setManualOpen] = useState(false);
  const [manualKcal, setManualKcal] = useState("");
  const [manualDuration, setManualDuration] = useState("");
  const [manualLabel, setManualLabel] = useState("");
  const { toast } = useToast();
  const qc = useQueryClient();
  
  const { data: rawSessions = [], isLoading } = useQuery<SessionRaw[]>({
    queryKey: ["/api/workouts/sessions", selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/workouts/sessions?start=${selectedDate}&end=${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const manualBurnMutation = useMutation({
    mutationFn: async (data: { caloriesBurned: number; durationMinutes?: number; label?: string; date: string }) => {
      const res = await apiRequest("POST", "/api/me/training/manual-burn", data);
      return res.json();
    },
    onSuccess: (_data) => {
      toast({ title: "Manual burn logged", description: `${manualKcal} kcal added to today's training.` });
      qc.invalidateQueries({ queryKey: ["/api/workouts/sessions", selectedDate] });
      qc.invalidateQueries({ queryKey: ["/api/me/training/summary"] });
      qc.invalidateQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      setManualKcal("");
      setManualDuration("");
      setManualLabel("");
      setManualOpen(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to log manual burn.", variant: "destructive" });
    },
  });

  const handleManualSubmit = () => {
    const kcal = parseInt(manualKcal);
    if (!kcal || kcal < 1 || kcal > 5000) return;
    const dur = manualDuration ? parseInt(manualDuration) : undefined;
    manualBurnMutation.mutate({
      caloriesBurned: kcal,
      durationMinutes: dur && dur >= 1 && dur <= 600 ? dur : undefined,
      label: manualLabel.trim() || undefined,
      date: selectedDate,
    });
  };
  
  const sessions: SessionSummary[] = rawSessions.map(s => ({
    id: s.id,
    timeOfDay: s.timeOfDay,
    exerciseCount: s.exercises?.length || 0,
    activityCount: s.activities?.filter(a => !(a.name || "").startsWith("[Manual]"))?.length || 0,
    totalCalories: s.estimatedKcal || 0,
    isManual: !!(s.title && s.title.startsWith("[Manual]")),
    manualLabel: s.title?.startsWith("[Manual]") ? s.title.replace("[Manual] ", "") : undefined,
  }));

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2">
              <Dumbbell className="h-5 w-5" />
              Training — {displayDate}
            </CardTitle>
            <CardDescription>Loading...</CardDescription>
          </div>
        </CardHeader>
      </Card>
    );
  }

  const hasData = sessions.length > 0 && sessions.some(s => s.exerciseCount > 0 || s.activityCount > 0 || s.isManual);
  const totalExercises = sessions.reduce((sum, s) => sum + s.exerciseCount, 0);
  const totalActivities = sessions.reduce((sum, s) => sum + s.activityCount, 0);
  const manualCount = sessions.filter(s => s.isManual).length;
  const totalCaloriesBurned = sessions.reduce((sum, s) => sum + s.totalCalories, 0);

  const timeOfDayLabels: Record<string, string> = {
    morning: "Morning",
    afternoon: "Afternoon",
    evening: "Evening",
  };

  const descParts: string[] = [];
  if (totalExercises > 0) descParts.push(`${totalExercises} exercises`);
  if (totalActivities > 0) descParts.push(`${totalActivities} activities`);
  if (manualCount > 0) descParts.push(`${manualCount} manual`);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Dumbbell className="h-5 w-5" />
            Training — {displayDate}
          </CardTitle>
          <CardDescription>
            {hasData ? descParts.join(", ") : "No workouts logged"}
          </CardDescription>
        </div>
        <div className="flex items-center gap-1">
          <Dialog open={manualOpen} onOpenChange={setManualOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" data-testid="button-manual-burn">
                <Flame className="mr-1 h-3.5 w-3.5" />
                Manual
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle className="font-display">Log manual calories burned</DialogTitle>
                <DialogDescription>Enter calories from a wearable or external tracker.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label htmlFor="manual-kcal">Calories burned *</Label>
                  <Input
                    id="manual-kcal"
                    type="number"
                    placeholder="e.g. 500"
                    value={manualKcal}
                    onChange={(e) => setManualKcal(e.target.value)}
                    min={1}
                    max={5000}
                    data-testid="input-manual-kcal"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="manual-duration">Duration (minutes, optional)</Label>
                  <Input
                    id="manual-duration"
                    type="number"
                    placeholder="e.g. 60"
                    value={manualDuration}
                    onChange={(e) => setManualDuration(e.target.value)}
                    min={1}
                    max={600}
                    data-testid="input-manual-duration"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="manual-label">Source label (optional)</Label>
                  <Input
                    id="manual-label"
                    type="text"
                    placeholder="e.g. Apple Watch, Garmin"
                    value={manualLabel}
                    onChange={(e) => setManualLabel(e.target.value)}
                    maxLength={50}
                    data-testid="input-manual-label"
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={handleManualSubmit}
                  disabled={!manualKcal || parseInt(manualKcal) < 1 || manualBurnMutation.isPending}
                  data-testid="button-submit-manual-burn"
                >
                  {manualBurnMutation.isPending ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                  ) : (
                    "Log burn"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Link href="/training">
            <Button variant="ghost" size="sm" data-testid="button-log-training">
              <Dumbbell className="mr-1 h-3.5 w-3.5" />
              Log
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {!hasData ? (
          <div className="flex flex-col items-center py-4 text-center">
            <Dumbbell className="h-8 w-8 text-muted-foreground/20 mb-2" />
            <p className="text-sm text-muted-foreground">No training logged for this day.</p>
            <Link href="/training">
              <Button variant="ghost" size="sm" className="mt-2 text-primary" data-testid="button-plan-training">
                <Dumbbell className="mr-1 h-3.5 w-3.5" /> Plan training
              </Button>
            </Link>
          </div>
        ) : (
          <>
            {sessions.filter(s => s.exerciseCount > 0 || s.activityCount > 0 || s.isManual).map((session) => (
              <div
                key={session.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-secondary/30"
                data-testid={`training-session-${session.isManual ? "manual" : session.timeOfDay}`}
              >
                <div className="flex-1">
                  <p className="font-medium text-sm flex items-center gap-2">
                    {session.isManual ? (session.manualLabel || "Manual entry") : (timeOfDayLabels[session.timeOfDay] || session.timeOfDay)}
                    {session.isManual && (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 font-normal text-muted-foreground">manual</Badge>
                    )}
                  </p>
                  {!session.isManual && (
                    <p className="text-xs text-muted-foreground">
                      {session.exerciseCount > 0 && `${session.exerciseCount} exercises`}
                      {session.exerciseCount > 0 && session.activityCount > 0 && ", "}
                      {session.activityCount > 0 && `${session.activityCount} activities`}
                    </p>
                  )}
                </div>
                {session.totalCalories > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    ~{session.totalCalories} kcal
                  </Badge>
                )}
              </div>
            ))}
            {totalCaloriesBurned > 0 && (
              <div className="flex items-center justify-between pt-2 border-t">
                <span className="text-sm font-medium">Est. Calories Burned</span>
                <span className="text-sm font-bold text-primary" data-testid="text-total-calories-burned">~{totalCaloriesBurned} kcal</span>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function AMQSCard({ daily, weekly, hasFoodToday, hasSupplementsToday, onLogFirstMeal }: { daily: any, weekly: any, hasFoodToday: boolean, hasSupplementsToday?: boolean, onLogFirstMeal?: () => void }) {
  const hasWeeklyData = weekly && typeof weekly.averageScore === 'number';
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [goalsExpanded, setGoalsExpanded] = useState(false);

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Elite': return 'bg-emerald-500 text-white';
      case 'Optimal': return 'bg-blue-500 text-white';
      case 'Good': return 'bg-amber-500 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  const getConfidenceValue = (conf: string) => {
    switch (conf) {
      case 'High': return 100;
      case 'Medium': return 60;
      case 'Low': return 30;
      default: return 0;
    }
  };

  const getTopContributor = () => {
    if (!daily?.breakdown) return null;
    const combined: Record<string, number> = {};
    const food = (daily.breakdown.food || {}) as Record<string, number>;
    const supps = (daily.breakdown.supplements || {}) as Record<string, number>;
    for (const [k, v] of Object.entries(food)) { if (v > 0) combined[k] = (combined[k] || 0) + v; }
    for (const [k, v] of Object.entries(supps)) { if (v > 0) combined[k] = (combined[k] || 0) + v; }
    const entries = Object.entries(combined).filter(([, v]) => v > 0);
    if (entries.length === 0) return null;
    entries.sort((a, b) => b[1] - a[1]);
    const topKey = entries[0][0];
    const topVal = entries[0][1];
    const label = topKey.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    return { key: topKey, label, value: topVal };
  };

  const hasDataToday = hasFoodToday || !!hasSupplementsToday;

  const getWhatMovedIt = () => {
    if (!daily || !hasDataToday) return "Log a meal or supplement to see drivers";
    const contributor = getTopContributor();
    const topGap = daily.topGaps?.[0];
    const parts: string[] = [];
    if (contributor) parts.push(`+${Math.round(contributor.value)}% ${contributor.label}`);
    if (topGap) parts.push(`${topGap.label} at ${topGap.pctOfTarget >= 100 ? "Target met" : `${topGap.pctOfTarget}%`}`);
    return parts.length > 0 ? parts.join(' · ') : "Log one more meal to improve insight quality";
  };

  const isEmptyState = !daily || !hasDataToday;

  const exampleGaps = [
    { label: "Vitamin D", pctOfTarget: 15 },
    { label: "Magnesium", pctOfTarget: 32 },
    { label: "Omega-3", pctOfTarget: 8 },
  ];

  const microGoals = !isEmptyState && daily.topGaps
    ? daily.topGaps.slice(0, 3).filter((g: any) => g.suggestion).map((gap: any) => ({
        ...gap,
        pointEst: Math.max(2, Math.min(8, Math.round(((100 - gap.pctOfTarget) / 100) * 7))),
      }))
    : [];

  return (
    <>
    <div
      className={`bg-card rounded-xl p-6 amqs-card-glow space-y-6 ${!isEmptyState ? 'cursor-pointer amqs-card-interactive' : ''}`}
      data-testid="card-amqs"
      role={!isEmptyState ? "button" : undefined}
      tabIndex={!isEmptyState ? 0 : undefined}
      onClick={() => !isEmptyState && setDetailsOpen(true)}
      onKeyDown={(e) => { if (!isEmptyState && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); setDetailsOpen(true); } }}
    >
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Micronutrient Quality</h3>
          <p className="text-[10px] text-muted-foreground/60 uppercase tracking-wider mt-0.5">Athlete Score (AMQS)</p>
        </div>
        {!isEmptyState ? (
          <ChevronRight className="h-4 w-4 text-muted-foreground/40" />
        ) : (
          <ShieldCheck className="h-5 w-5 text-muted-foreground/30" />
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground/70">Daily Score</p>
          <div className="flex items-baseline gap-2">
            <div className="relative inline-block">
              <span
                className="text-4xl font-extrabold font-mono amqs-glow"
                data-testid="text-amqs-daily-score"
              >
                {isEmptyState ? "—" : daily.score}
              </span>
              <div className="absolute bottom-0 left-0 right-0 h-[2px] rounded-full bg-primary/30" />
            </div>
            <Badge className={isEmptyState ? "bg-slate-600 text-slate-300" : getTierColor(daily?.tier)} data-testid="badge-amqs-daily-tier">
              {isEmptyState ? "Estimated" : daily.tier}
            </Badge>
          </div>
          <p className="text-[10px] text-muted-foreground/70 mt-2 leading-tight truncate" data-testid="text-what-moved-it">
            {getWhatMovedIt()}
          </p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground/50">Weekly Avg</p>
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-semibold text-muted-foreground/60 font-mono" data-testid="text-amqs-weekly-score">
              {hasWeeklyData ? weekly.averageScore : "—"}
            </span>
            <Badge variant="outline" className="text-[10px] border-border/30 text-muted-foreground/60" data-testid="badge-amqs-weekly-tier">
              {hasWeeklyData ? weekly.tier : "—"}
            </Badge>
          </div>
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <p className="text-[10px] text-muted-foreground/50 font-medium">Data Confidence</p>
            <TooltipProvider>
              <UITooltip>
                <TooltipTrigger>
                  <Info className="h-2.5 w-2.5 text-muted-foreground/30" />
                </TooltipTrigger>
                <TooltipContent className="max-w-[240px] text-[11px]">
                  Measures how much of your logged data has micronutrient info. High = 75%+ coverage, Medium = 40-74%, Low = under 40% or no data.
                </TooltipContent>
              </UITooltip>
            </TooltipProvider>
          </div>
          <Badge variant="secondary" className="text-[10px] px-1.5 bg-secondary/50" data-testid="badge-amqs-confidence">
            {isEmptyState ? "Low" : daily.confidence}
          </Badge>
        </div>
        {isEmptyState ? (
          <div className="space-y-1">
            <Progress value={0} className="h-1" />
            <p className="text-[10px] text-muted-foreground/50">Building baseline — log your first meal</p>
          </div>
        ) : (
          <Progress value={getConfidenceValue(daily.confidence)} className="h-1" />
        )}
      </div>

      {hasWeeklyData && weekly.dailyScores && weekly.dailyScores.length > 1 && (
        <div className="space-y-1">
          <p className="text-[10px] text-muted-foreground/50 font-medium" data-testid="text-7day-trend-label">7-day trend</p>
          <div className="h-12">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weekly.dailyScores.map((d: any) => ({ date: d.date.slice(5), score: d.score }))}>
                <defs>
                  <linearGradient id="amqsTrendFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.1} />
                    <stop offset="100%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="score" stroke="hsl(var(--muted-foreground))" fill="url(#amqsTrendFill)" strokeWidth={1} dot={false} strokeOpacity={0.4} />
                <XAxis dataKey="date" tick={{ fontSize: 8, fill: 'hsl(var(--muted-foreground))', opacity: 0.4 }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} hide />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {isEmptyState ? (
        <div className="space-y-3 pt-3">
          <p className="text-[11px] font-semibold text-muted-foreground/50">Top gaps</p>
          <div className="space-y-2 opacity-30" aria-hidden="true">
            {exampleGaps.map((gap) => (
              <div key={gap.label} className="text-xs flex flex-col gap-1 p-2 rounded bg-secondary/15">
                <div className="flex justify-between">
                  <span className="font-medium">{gap.label}</span>
                  <span className="text-muted-foreground">{gap.pctOfTarget >= 100 ? "Target met" : `${gap.pctOfTarget}%`}</span>
                </div>
                <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-muted-foreground/30" style={{ width: `${gap.pctOfTarget}%` }} />
                </div>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground/40 italic">Example — updates after your first log</p>
          <Button
            variant="default"
            size="sm"
            onClick={onLogFirstMeal}
            data-testid="button-log-first-meal"
          >
            <Utensils className="mr-2 h-3 w-3" />
            Log first meal
          </Button>
        </div>
      ) : daily.allMet ? (
        <div className="pt-3" data-testid="amqs-all-met">
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0" />
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium leading-tight">
              Your fuelling, recovery, and nutrition are fully optimised for today.
            </p>
          </div>
        </div>
      ) : daily.topGaps && daily.topGaps.length > 0 ? (
        <div className="space-y-2.5 pt-3">
          <p className="text-[11px] font-semibold text-muted-foreground/50">Top gaps</p>
          <div className="space-y-2">
            {daily.topGaps.map((gap: any, idx: number) => (
              <div key={gap.microKey} className="text-xs flex flex-col gap-1 p-2 rounded bg-secondary/15" data-testid={`gap-${gap.microKey}`}>
                <div className="flex justify-between">
                  <span className="font-medium">{gap.label}</span>
                  <span className="text-muted-foreground/70">{gap.pctOfTarget >= 100 ? "Target met" : `${gap.pctOfTarget}%`}</span>
                </div>
                <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${idx === 0 ? 'bg-primary/70' : 'bg-muted-foreground/30'}`}
                    style={{ width: `${Math.min(gap.pctOfTarget, 100)}%` }}
                  />
                </div>
                {gap.suggestion && (
                  <p className="text-[10px] text-muted-foreground/60">
                    Try: <span className="text-foreground/80 font-medium">{gap.suggestion}</span>
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {microGoals.length > 0 && (
        <div className="space-y-2 pt-3 border-t border-border/15">
          <p className="text-[11px] font-semibold text-muted-foreground/50">Micro-goals</p>
          <div className="space-y-1">
            <div className="text-xs flex items-center gap-2 py-0.5" data-testid={`micro-goal-${microGoals[0].microKey}`}>
              <span className="text-primary/80 font-bold whitespace-nowrap">+{microGoals[0].pointEst}</span>
              <span className="text-muted-foreground/70">if you add <span className="text-foreground/80 font-medium">{microGoals[0].suggestion}</span> ({microGoals[0].label})</span>
            </div>
            {microGoals.length > 1 && !goalsExpanded && (
              <button
                className="text-[10px] text-muted-foreground/50 hover:text-muted-foreground transition-colors"
                onClick={(e) => { e.stopPropagation(); setGoalsExpanded(true); }}
                data-testid="button-see-micro-goals"
              >
                See {microGoals.length} micro-goals →
              </button>
            )}
            <AnimatePresence>
              {goalsExpanded && microGoals.slice(1).map((goal: any, i: number) => (
                <motion.div
                  key={goal.microKey}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2, delay: i * 0.05 }}
                  className="overflow-hidden"
                >
                  <div className="text-xs flex items-center gap-2 py-0.5" data-testid={`micro-goal-${goal.microKey}`}>
                    <span className="text-primary/80 font-bold whitespace-nowrap">+{goal.pointEst}</span>
                    <span className="text-muted-foreground/70">if you add <span className="text-foreground/80 font-medium">{goal.suggestion}</span> ({goal.label})</span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      <div className="pt-2 border-t border-border/15">
        <p className="text-[10px] text-muted-foreground/40 italic leading-tight">
          Includes logged foods + marked supplements. Estimates only; not medical advice.
        </p>
      </div>
    </div>

    {!isEmptyState && (
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-[400px] max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">AMQS Details</DialogTitle>
            <DialogDescription className="sr-only">Detailed breakdown of your Athlete Micronutrient Quality Score</DialogDescription>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div className="space-y-2">
              <p className="text-[11px] font-semibold text-muted-foreground/60">What moved it today</p>
              <p className="text-sm text-foreground" data-testid="text-modal-what-moved">
                {getWhatMovedIt()}
              </p>
            </div>

            {daily.topGaps && daily.topGaps.length > 0 && (
              <div className="space-y-3">
                <p className="text-[11px] font-semibold text-muted-foreground/60">Top gaps</p>
                <div className="space-y-2">
                  {daily.topGaps.map((gap: any, idx: number) => (
                    <div key={gap.microKey} className="text-xs flex flex-col gap-1.5 p-2 rounded bg-secondary/15">
                      <div className="flex justify-between">
                        <span className="font-medium">{gap.label}</span>
                        <span className="text-muted-foreground/60">{gap.pctOfTarget >= 100 ? "Target met" : `${gap.pctOfTarget}% of target`}</span>
                      </div>
                      <div className="h-1 w-full bg-secondary/40 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${idx === 0 ? 'bg-primary/70' : 'bg-muted-foreground/30'}`} style={{ width: `${Math.min(gap.pctOfTarget, 100)}%` }} />
                      </div>
                      {gap.suggestion && (
                        <p className="text-[10px] text-muted-foreground/60">
                          Try: <span className="text-foreground/80 font-medium">{gap.suggestion}</span>
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-3">
              <p className="text-[11px] font-semibold text-muted-foreground/60">Quick wins</p>
              <div className="space-y-2">
                {daily.topGaps && daily.topGaps.length > 0 ? (
                  <>
                    {daily.topGaps.slice(0, 2).map((gap: any) => gap.suggestion && (
                      <div key={gap.microKey} className="text-xs p-2 rounded bg-primary/5 border border-primary/10">
                        <span className="font-medium text-primary/80">Close {gap.label} gap</span>
                        <span className="text-muted-foreground/70"> — add {gap.suggestion}</span>
                      </div>
                    ))}
                  </>
                ) : (
                  <p className="text-xs text-muted-foreground">All key micronutrients are covered. Keep it up.</p>
                )}
              </div>
            </div>

            <div className="pt-2 border-t border-border/20">
              <p className="text-[10px] text-muted-foreground/40 italic leading-tight">
                Based on logged foods and supplements. Estimates only; not medical advice.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )}
    </>
  );
}

export default function Dashboard() {
  const { data: user, isLoading: userLoading } = useUser();
  const { data: logs, isLoading: logsLoading } = useLogs();
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [aiLogOpen, setAiLogOpen] = useState(false);
  const { data: foodEntries, isLoading: foodLoading } = useFoodEntries(selectedDate);
  const [, setLocation] = useLocation();
  
  // Date range for weekly AMQS (7 days ending on selected date)
  const weekStart = format(subDays(parseISO(selectedDate), 6), "yyyy-MM-dd");
  const { data: rangeEntries = [] } = useFoodEntriesRange(weekStart, selectedDate);
  
  // Weights for chart (last 30 days)
  const weightChartStart = format(subDays(parseISO(selectedDate), 30), "yyyy-MM-dd");
  const { data: weightsData = [] } = useWeightsRange(weightChartStart, selectedDate);
  
  // Fetch ingredients for food lookup (still needed for food entry display)
  const { data: ingredients = [] } = useQuery({
    queryKey: ["/api/ingredients"],
    queryFn: async () => {
      const res = await fetch("/api/ingredients", { credentials: "include", cache: "no-store" });
      if (!res.ok) throw new Error("Failed to fetch ingredients");
      return res.json();
    }
  });
  
  // AMQS API types
  interface AMQSScoreResult {
    date: string;
    score: number;
    tier: string;
    confidence: "Low" | "Medium" | "High";
    totals: Record<string, number>;
    targets: Record<string, number>;
    coverage: Record<string, { pctOfTarget: number; status: string }>;
    topGaps: { microKey: string; label: string; pctOfTarget: number; suggestion?: string }[];
    allMet: boolean;
    breakdown: { food: Record<string, number>; supplements: Record<string, number> };
  }
  
  interface WeeklyAMQSResult {
    startDate: string;
    endDate: string;
    averageScore: number;
    tier: string;
    dailyScores: { date: string; score: number; tier: string }[];
  }
  
  // Fetch daily AMQS score from server (merged food + supplements)
  const { data: dailyAMQS } = useQuery<AMQSScoreResult | null>({
    queryKey: ["/api/me/amqs/score", selectedDate],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch(`/api/me/amqs/score/${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return null;
      return res.json();
    }
  });
  

  // Current date's log
  const selectedLog = logs?.find((l: any) => l.date === selectedDate);
  
  // Training summary for selected date - fetch calories burned
  interface TrainingSummary {
    date: string;
    totalKcal: number;
    totalKcalAdjusted?: number;
    sessions: { id: number; timeOfDay: string; estimatedKcal: number; exerciseCount: number; activityCount: number }[];
  }
  
  const { data: trainingSummary } = useQuery<TrainingSummary>({
    queryKey: ["/api/me/training/summary", selectedDate],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch(`/api/me/training/summary/${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return { date: selectedDate, totalKcal: 0, sessions: [] };
      return res.json();
    }
  });

  // Fight-camp-aware effective targets from server
  const { data: effectiveTargets } = useQuery<{
    mode: string;
    modeLabel: string;
    modeNote: string | null;
    targetCalories: number;
    targetProtein: number;
    targetCarbs: number;
    targetFat: number;
    tdee: number;
    dailyDeficit: number;
    trainingCalorieCreditPct: number;
    weeklyRate?: number;
    weeklyRatePct?: number;
    daysUntil?: number;
    // Fight camp v2 fields
    dayType?: string;
    ffmKg?: number;
    eaValue?: number;
    carbsPerKg?: number;
    isLowEA?: boolean;
    isLowCarb?: boolean;
    isBelowPerformanceCarb?: boolean;
    performanceCarbWarning?: string | null;
    trainingKcalToday?: number;
    trainingKcalAddedBack?: number;
    exerciseAddBackPct?: number;
    plannedCalories?: number;
    eaRecommendedCalories?: number;
    carbRecommendedG?: number;
    planId?: number;
    planFightDate?: string;
    planTargetWeight?: number;
  }>({
    queryKey: ["/api/me/targets/effective", selectedDate],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch(`/api/me/targets/effective?date=${selectedDate}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch targets");
      return res.json();
    },
  });
  
  // ── Fight camp override hook ─────────────────────────────────────────
  const fcOverride = useFightCampOverride({
    userId: user?.id,
    date: selectedDate,
    effectiveTargets: effectiveTargets ?? undefined,
    isFightCamp: effectiveTargets?.mode === "fight_camp",
    // Fingerprint changes whenever the user modifies their fight camp plan (fight date, target weight,
    // or entirely new plan). This causes new storage keys → consent modals re-trigger automatically.
    planFingerprint: effectiveTargets?.planId != null
      ? `${effectiveTargets.planId}:${effectiveTargets.planFightDate}:${effectiveTargets.planTargetWeight}`
      : undefined,
  });

  // Performance carb toast (shown once per day per user in fight camp)
  useEffect(() => {
    if (!effectiveTargets || effectiveTargets.mode !== "fight_camp") return;
    if (!effectiveTargets.isBelowPerformanceCarb || !effectiveTargets.performanceCarbWarning) return;
    if (!fcOverride.shouldShowPerfToast) return;
    // Small delay so page loads first
    const t = setTimeout(() => {
      toast({ title: "Performance note", description: effectiveTargets.performanceCarbWarning! });
      fcOverride.markPerfToastShown();
    }, 1500);
    return () => clearTimeout(t);
  }, [effectiveTargets?.isBelowPerformanceCarb, fcOverride.shouldShowPerfToast, selectedDate]);

  // Training calorie credit percentages by goal
  // Research rationale documented in server/routes.ts
  const TRAINING_CALORIE_CREDIT_PCT: Record<string, number> = {
    fat_loss: 0.5,
    maintenance: 0.75,
    weight_gain: 1.0,
    fight_camp: 0.5,
  };
  
  // Compute adjusted targets based on training calories
  // Uses fight-camp-aware effective targets when available (priority: fight camp > profile goal)
  const computeAdjustedTargets = () => {
    if (!user) return null;

    const isFightCamp = effectiveTargets?.mode === "fight_camp";
    const goal        = effectiveTargets?.mode ?? user.goal ?? "fat_loss";
    // Use RPE-adjusted total when available; fall back to raw total (e.g. for sessions without RPE data)
    const trainingKcal = trainingSummary?.totalKcalAdjusted ?? trainingSummary?.totalKcal ?? 0;
    const bodyWeightKg = user.currentWeight || 75;

    // ── Fight camp: server owns the full calorie target; client applies overrides ──
    if (isFightCamp) {
      // User may have accepted EA or carb recommendations — apply those first
      const serverCals  = effectiveTargets?.targetCalories ?? 0;
      const serverCarbs = effectiveTargets?.targetCarbs    ?? 0;
      const serverProt  = effectiveTargets?.targetProtein  ?? user.targetProtein  ?? 0;
      const serverFat   = effectiveTargets?.targetFat      ?? user.targetFat      ?? 0;

      // Override calories if user accepted EA fix (or carb fix bumped them up)
      const finalCals  = fcOverride.overrideCalories ?? serverCals;
      // Override carbs if user accepted carb fix; otherwise recompute from finalCals
      let finalCarbs: number;
      if (fcOverride.overrideCarbs != null) {
        finalCarbs = fcOverride.overrideCarbs;
      } else if (fcOverride.overrideCalories != null) {
        // EA fix accepted — carbs absorb the extra calories
        const carbCals = Math.max(0, fcOverride.overrideCalories - serverProt * 4 - serverFat * 9);
        finalCarbs = Math.round(carbCals / 4);
      } else {
        finalCarbs = serverCarbs;
      }

      // Effective EA from the final calorie target (for display)
      const exerciseKcal    = effectiveTargets?.trainingKcalToday ?? 0;
      const serverAddedBack = effectiveTargets?.trainingKcalAddedBack ?? Math.round(exerciseKcal * 0.8);
      // When EA override is active, the displayed "added back" is how much more than the
      // no-training baseline (tdeeNoExercise − deficit) the user eats under the EA target.
      // i.e. eaRecommendedCalories − (baselineTdee − dailyDeficit), NOT the full exerciseKcal.
      const baselineNoTraining = (effectiveTargets?.baselineTdee ?? 0) - (effectiveTargets?.dailyDeficit ?? 0);
      const actualAddedBack = fcOverride.overrideCalories != null
        ? Math.round(fcOverride.overrideCalories - baselineNoTraining)
        : serverAddedBack;
      const eaOverrideActive = fcOverride.overrideCalories != null && exerciseKcal > 0;
      const ffmKg           = effectiveTargets?.ffmKg ?? 1;
      const effectiveEA     = parseFloat(((finalCals - exerciseKcal) / ffmKg).toFixed(1));
      const effectiveCarbsPerKg = parseFloat((finalCarbs / bodyWeightKg).toFixed(2));

      return {
        base:     { calories: finalCals, protein: serverProt, carbs: finalCarbs, fat: serverFat },
        adjusted: { calories: finalCals, protein: serverProt, carbs: finalCarbs, fat: serverFat },
        trainingKcal: exerciseKcal,
        trainingKcalAddedBack: actualAddedBack,
        eaOverrideActive,
        addedBack:    0,
        creditPct:    0,
        goal,
        isFightCamp:  true,
        modeLabel:    effectiveTargets?.modeLabel ?? "Fight Camp Fat Loss",
        modeNote:     effectiveTargets?.modeNote ?? null,
        tdee:         effectiveTargets?.tdee,
        dailyDeficit: effectiveTargets?.dailyDeficit,
        hasTraining:  exerciseKcal > 0,
        eaValue:              effectiveEA,
        isLowEA:              effectiveEA < 30,
        // Server's original flag — remains true even after override brings EA to exactly 30
        originallyLowEA:      effectiveTargets?.isLowEA ?? false,
        originallyLowCarb:    effectiveTargets?.isLowCarb ?? false,
        isLowCarb:            effectiveCarbsPerKg < 3 && exerciseKcal > 0,
        isBelowPerformanceCarb: effectiveTargets?.isBelowPerformanceCarb,
        performanceCarbWarning: effectiveTargets?.performanceCarbWarning,
        dayType:      effectiveTargets?.dayType,
      };
    }

    // ── Standard (non-fight-camp) path ────────────────────────────────────
    const baseCalories = effectiveTargets?.targetCalories ?? user.targetCalories ?? 0;
    const baseProtein  = effectiveTargets?.targetProtein  ?? user.targetProtein  ?? 0;
    const baseCarbs    = effectiveTargets?.targetCarbs    ?? user.targetCarbs    ?? 0;
    const baseFat      = effectiveTargets?.targetFat      ?? user.targetFat      ?? 0;

    // Training calorie credit percentage
    const creditPct = effectiveTargets?.trainingCalorieCreditPct
      ?? TRAINING_CALORIE_CREDIT_PCT[goal]
      ?? 0.5;

    // 1) Add back training calories
    let adjustedCalories = baseCalories + Math.round(trainingKcal * creditPct);

    // 2) For fat-loss modes: cap deficit at 1% BW/week
    if (goal === "fat_loss") {
      const weeklyLossMaxKg = 0.01 * bodyWeightKg;
      const maxDailyDeficit = Math.round((weeklyLossMaxKg * 7700) / 7);
      const estimatedMaintenance = effectiveTargets?.tdee ?? baseCalories + 500;
      const deficit = estimatedMaintenance - adjustedCalories;
      if (deficit > maxDailyDeficit) {
        adjustedCalories = estimatedMaintenance - maxDailyDeficit;
      }
    }

    // 3) Adjust macros: keep protein/fat stable, push extra into carbs
    const adjustedProtein  = baseProtein;
    const adjustedFat      = baseFat;
    const extraCalories    = Math.max(0, adjustedCalories - baseCalories);
    const adjustedCarbs    = baseCarbs + Math.round(extraCalories / 4);

    return {
      base:        { calories: baseCalories, protein: baseProtein, carbs: baseCarbs, fat: baseFat },
      adjusted:    { calories: adjustedCalories, protein: adjustedProtein, carbs: adjustedCarbs, fat: adjustedFat },
      trainingKcal,
      addedBack:   Math.round(trainingKcal * creditPct),
      creditPct,
      goal,
      isFightCamp: effectiveTargets?.mode === "fight_camp",
      modeLabel:   effectiveTargets?.modeLabel ?? (goal === "weight_gain" ? "Weight Gain" : goal === "maintenance" ? "Maintenance" : "Fat Loss"),
      modeNote:    effectiveTargets?.modeNote ?? null,
      tdee:        effectiveTargets?.tdee,
      dailyDeficit: effectiveTargets?.dailyDeficit,
      hasTraining: trainingKcal > 0,
      eaValue:     undefined,
      isLowEA:     false,
      isLowCarb:   false,
      isBelowPerformanceCarb: false,
      performanceCarbWarning: null,
      dayType:     undefined,
    };
  };
  
  const adjustedTargets = computeAdjustedTargets();
  
  // Date navigation functions
  const goToPreviousDay = () => setSelectedDate(format(subDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToNextDay = () => setSelectedDate(format(addDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToToday = () => setSelectedDate(format(new Date(), "yyyy-MM-dd"));
  const isToday = selectedDate === format(new Date(), "yyyy-MM-dd");
  useEffect(() => {
    if (!userLoading && !user) {
      setLocation("/");
    } else if (user && !user.targetCalories) {
      setLocation("/onboarding");
    }
  }, [user, userLoading, setLocation]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has("openAddFood")) {
      const timer = setTimeout(() => {
        const addFoodBtn = document.querySelector('[data-testid="button-add-food"]') as HTMLButtonElement | null;
        if (addFoodBtn) addFoodBtn.click();
      }, 600);
      window.history.replaceState({}, '', window.location.pathname);
      return () => clearTimeout(timer);
    }
  }, []);

  if (userLoading || logsLoading) {
    return <DashboardSkeleton />;
  }

  if (!user) return null;

  // Aggregate macros from food entries if they exist
  const aggregateMacros = foodEntries?.reduce((acc: any, entry: any) => ({
    calories: acc.calories + entry.calories,
    protein: acc.protein + entry.protein,
    carbs: acc.carbs + entry.carbs,
    fat: acc.fat + entry.fat,
    fibre: acc.fibre + (entry.fibre || 0),
  }), { calories: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 }) || { calories: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 };

  // Use manual log if it exists and has values, otherwise use aggregate
  const displayMacros = {
    calories: selectedLog?.calories || aggregateMacros.calories,
    protein: selectedLog?.protein || aggregateMacros.protein,
    carbs: selectedLog?.carbs || aggregateMacros.carbs,
    fat: selectedLog?.fat || aggregateMacros.fat,
    fibre: selectedLog?.fibre || aggregateMacros.fibre,
  };

  // Weight chart data from weights API
  const chartData = weightsData
    .map((w: any) => ({
      date: format(parseISO(w.date), "MMM d"),
      weight: w.weight
    }));


  return (
    <Layout>
      <CelebrationBurst />
      <AILogDialog
        open={aiLogOpen}
        onOpenChange={setAiLogOpen}
        date={selectedDate}
        onSuccess={() => setAiLogOpen(false)}
      />
      <div className="space-y-8">
        <EmailVerificationBanner />
        <WeightCutHero />
        <MorningCheckIn date={selectedDate} />
        <div className="pt-2">
          <ReadinessSummaryCard date={selectedDate} />
        </div>

        <ProvisionalCheckIn date={selectedDate} />

        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-1 space-y-0 pb-2">
            <div>
              <CardTitle className="flex items-center gap-2 flex-wrap">
                Daily Intake Estimates
                {adjustedTargets?.isFightCamp && (
                  <Badge className="text-xs font-normal bg-orange-500/20 text-orange-400 border border-orange-500/30 hover:bg-orange-500/20" data-testid="badge-fight-camp-mode">
                    Fight Camp
                  </Badge>
                )}
                {adjustedTargets?.hasTraining && (
                  <Badge variant="outline" className="text-xs font-normal" data-testid="badge-training-calories">
                    +{adjustedTargets.trainingKcal} kcal training
                    {adjustedTargets.isFightCamp && adjustedTargets.trainingKcalAddedBack != null && (
                      <span className="text-orange-400/80 ml-1">
                        {adjustedTargets.eaOverrideActive
                          ? `· ${adjustedTargets.trainingKcalAddedBack} added (EA)`
                          : `· ${adjustedTargets.trainingKcalAddedBack} added (80%)`}
                      </span>
                    )}
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                {adjustedTargets?.isFightCamp
                  ? adjustedTargets.hasTraining
                    ? adjustedTargets.eaOverrideActive
                      ? "EA target active · Full training kcal included to meet 30 kcal/kg threshold."
                      : "Fight camp plan · 80% of training kcal added to target."
                    : "Targets controlled by fight camp plan."
                  : adjustedTargets?.hasTraining
                    ? `Adjusted for ${format(parseISO(selectedDate), "MMM d")} training`
                    : "Estimated targets based on your metrics"
                }
              </CardDescription>
            </div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="button-targets-info">
                  <Info className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent side="left" className="max-w-[320px] text-xs space-y-2">
                <p>
                  <strong>Goal Mode: {adjustedTargets?.modeLabel ?? "Fat Loss"}</strong>
                </p>
                {adjustedTargets?.modeNote && (
                  <p className="text-primary">{adjustedTargets.modeNote}</p>
                )}
                <p>
                  {adjustedTargets?.goal === 'fight_camp' && "Training is baked into the calorie target. An EA floor of 30 kcal/kg FFM prevents under-fuelling. Macros adapt to your training load each day."}
                  {adjustedTargets?.goal === 'weight_gain' && "We add 100% of training calories back to maintain your surplus."}
                  {adjustedTargets?.goal === 'maintenance' && "We add 75% of training calories back to maintain your weight."}
                  {(!adjustedTargets?.goal || adjustedTargets?.goal === 'fat_loss') && "We add 50% of training calories back (conservative). Max ~1% BW loss/week to preserve performance."}
                </p>
                {adjustedTargets?.isFightCamp && adjustedTargets.dailyDeficit && (
                  <p className="text-muted-foreground">
                    Daily deficit: {adjustedTargets.dailyDeficit} kcal · TDEE: {adjustedTargets.tdee} kcal
                  </p>
                )}
                <p className="text-muted-foreground">
                  These are estimates only. Adjust based on trends and performance. Not medical advice.
                </p>
              </PopoverContent>
            </Popover>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-3xl font-extrabold font-mono" data-testid="text-target-calories">
                  {adjustedTargets?.adjusted.calories || user.targetCalories}
                </div>
                <div className="text-[10px] text-muted-foreground/70 tracking-wide mt-0.5">Calories</div>
                {adjustedTargets?.hasTraining && adjustedTargets.addedBack > 0 && (
                  <div className="text-[9px] text-muted-foreground/40 mt-1" data-testid="text-calories-breakdown">
                    Base: {adjustedTargets.base.calories} +{adjustedTargets.addedBack}
                  </div>
                )}
              </div>
              <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-3xl font-extrabold font-mono" data-testid="text-target-protein">
                  {adjustedTargets?.adjusted.protein || user.targetProtein}g
                </div>
                <div className="text-[10px] text-muted-foreground/70 tracking-wide mt-0.5">Protein</div>
              </div>
              <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-3xl font-extrabold font-mono" data-testid="text-target-carbs">
                  {adjustedTargets?.adjusted.carbs || user.targetCarbs}g
                </div>
                <div className="text-[10px] text-muted-foreground/70 tracking-wide mt-0.5">Carbs</div>
                {adjustedTargets?.hasTraining && adjustedTargets.adjusted.carbs > adjustedTargets.base.carbs && (
                  <div className="text-[9px] text-muted-foreground/40 mt-1" data-testid="text-carbs-breakdown">
                    Base: {adjustedTargets.base.carbs}g
                  </div>
                )}
              </div>
              <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-3xl font-extrabold font-mono" data-testid="text-target-fat">
                  {adjustedTargets?.adjusted.fat || user.targetFat}g
                </div>
                <div className="text-[10px] text-muted-foreground/70 tracking-wide mt-0.5">Fat</div>
              </div>
            </div>

            {/* Calorie priority callout */}
            {adjustedTargets?.isFightCamp && (
              <div className="flex items-start gap-2 rounded-lg bg-orange-500/8 border border-orange-500/20 px-3 py-2.5">
                <span className="text-orange-400 mt-0.5 flex-shrink-0 text-sm">🥊</span>
                <div className="text-xs text-orange-300/90 leading-relaxed">
                  Fight Camp plan is controlling your targets. Training kcal are added back dynamically when logging activities.
                </div>
              </div>
            )}

            {/* Fight Camp EA display + warnings */}
            {adjustedTargets?.isFightCamp && adjustedTargets.eaValue != null && (
              <div className="space-y-1.5">
                {/* Energy Availability row */}
                <div
                  className={`flex items-center justify-between rounded-md px-3 py-2 text-xs ${
                    adjustedTargets.isLowEA && fcOverride.eaDecision !== "accepted"
                      ? "bg-orange-500/10 border border-orange-500/30 text-orange-400"
                      : "bg-secondary/50 text-muted-foreground"
                  }`}
                  data-testid="text-ea-value"
                >
                  <span className="font-medium">Energy Availability</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold">{adjustedTargets.eaValue} kcal/kg FFM</span>
                    {adjustedTargets.isLowEA && fcOverride.eaDecision !== "accepted" && (
                      <button
                        onClick={fcOverride.openEAModal}
                        className="text-[10px] underline underline-offset-2 opacity-80 hover:opacity-100"
                        data-testid="button-ea-review"
                      >
                        {fcOverride.eaDecision === "declined" ? "Review" : "Review →"}
                      </button>
                    )}
                    {adjustedTargets.originallyLowEA && fcOverride.eaDecision === "accepted" && (
                      <span className="text-[10px] flex items-center gap-1.5 text-muted-foreground">
                        · adjusted ✓
                        <button
                          onClick={fcOverride.openEAModal}
                          className="text-primary underline underline-offset-2 hover:text-primary/80"
                          data-testid="button-ea-review-accepted"
                        >
                          Review
                        </button>
                      </span>
                    )}
                  </div>
                </div>

                {/* Low carb warning row */}
                {adjustedTargets.isLowCarb && fcOverride.carbDecision !== "accepted" && (
                  <div
                    className="flex items-center justify-between rounded-md px-3 py-2 text-xs bg-yellow-500/10 border border-yellow-500/30 text-yellow-400"
                    data-testid="text-low-carb-warning"
                  >
                    <span>Carbs below 3 g/kg</span>
                    <button
                      onClick={fcOverride.openCarbModal}
                      className="text-[10px] underline underline-offset-2 opacity-80 hover:opacity-100"
                      data-testid="button-carb-review"
                    >
                      {fcOverride.carbDecision === "declined" ? "Review" : "Review →"}
                    </button>
                  </div>
                )}
                {adjustedTargets.originallyLowCarb && fcOverride.carbDecision === "accepted" && (
                  <div className="flex items-center justify-between rounded-md px-3 py-2 text-xs bg-secondary/50 text-muted-foreground" data-testid="text-carb-adjusted">
                    <span>Carbs adjusted to 3 g/kg</span>
                    <span className="text-[10px] flex items-center gap-1.5 text-muted-foreground">
                      · adjusted ✓
                      <button
                        onClick={fcOverride.openCarbModal}
                        className="text-primary underline underline-offset-2 hover:text-primary/80"
                        data-testid="button-carb-review-accepted"
                      >
                        Review
                      </button>
                    </span>
                  </div>
                )}
              </div>
            )}

            <p className="text-[10px] text-muted-foreground italic leading-tight px-1" data-testid="text-disclaimer">
              These values are estimates based on logged activity and body metrics. They are not medical or nutrition advice.
            </p>
            
            {/* How estimates are calculated - expandable section */}
            <Collapsible className="mt-4">
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full justify-start text-xs text-muted-foreground hover:text-foreground gap-2 p-2" data-testid="button-how-calculated">
                  <ChevronDownIcon className="h-3 w-3" />
                  How estimates are calculated
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3 pb-1 px-2">
                <div className="text-[11px] text-muted-foreground leading-relaxed">
                  <p className="italic border-t border-border/50 pt-1">
                    All values are estimates for personal tracking only. These are not prescriptions or medical recommendations. If you have a medical condition, eating disorder history, or are under 18, consult a qualified professional.
                  </p>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </CardContent>
        </Card>

        {/* Date Navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" onClick={goToPreviousDay} data-testid="button-prev-day">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <Input 
                type="date" 
                value={selectedDate} 
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-[160px] font-medium"
                data-testid="input-date-picker"
              />
            </div>
            <Button variant="outline" size="icon" onClick={goToNextDay} data-testid="button-next-day">
              <ChevronRight className="h-4 w-4" />
            </Button>
            {!isToday && (
              <Button variant="ghost" size="sm" onClick={goToToday} data-testid="button-today">
                Today
              </Button>
            )}
          </div>
          <div className="flex gap-2 flex-wrap">
            <WeightUpdateDialog 
              date={selectedDate} 
              userId={user.id} 
              existingLog={selectedLog}
            />
            <FoodEntryDialog date={selectedDate} existingEntries={foodEntries || []} isPrimary={true} />
            <Button
              variant="outline"
              size="default"
              onClick={() => setAiLogOpen(true)}
              data-testid="button-ai-log"
            >
              <Sparkles className="mr-2 h-4 w-4" />
              Quick Log
            </Button>
            <LogEntryDialog 
              existingLog={selectedLog} 
              date={selectedDate}
            />
          </div>
        </div>

        {/* Header */}
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">
            Hello, {user.username}
          </h1>
          <p className="text-muted-foreground">
            {isToday ? "Here is your daily nutrition summary." : `Viewing ${format(parseISO(selectedDate), "MMMM d, yyyy")}`}
          </p>
        </div>

        {/* Stats Grid - uses adjusted targets based on training */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard
            title="Calories"
            value={displayMacros.calories}
            target={adjustedTargets?.adjusted.calories || user.targetCalories || 2000}
            unit="kcal"
            icon={<Flame className="h-4 w-4" />}
            className="border-l-4 border-l-primary"
          />
          <StatCard
            title="Protein"
            value={displayMacros.protein}
            target={adjustedTargets?.adjusted.protein || user.targetProtein || 150}
            unit="g"
            icon={<Beef className="h-4 w-4" />}
            className="border-l-4 border-l-blue-500"
          />
          <StatCard
            title="Carbs"
            value={displayMacros.carbs}
            target={adjustedTargets?.adjusted.carbs || user.targetCarbs || 200}
            unit="g"
            icon={<Wheat className="h-4 w-4" />}
            className="border-l-4 border-l-amber-500"
          />
          <StatCard
            title="Fat"
            value={displayMacros.fat}
            target={adjustedTargets?.adjusted.fat || user.targetFat || 60}
            unit="g"
            icon={<Droplets className="h-4 w-4" />}
            className="border-l-4 border-l-yellow-500"
          />
          <StatCard
            title="Fibre"
            value={displayMacros.fibre}
            target={30}
            unit="g"
            icon={<Leaf className="h-4 w-4" />}
            className="border-l-4 border-l-emerald-500"
          />
        </div>

        {(() => {
          const targets = {
            calories: adjustedTargets?.adjusted.calories || user.targetCalories || 2000,
            protein: adjustedTargets?.adjusted.protein || user.targetProtein || 150,
            carbs: adjustedTargets?.adjusted.carbs || user.targetCarbs || 200,
            fat: adjustedTargets?.adjusted.fat || user.targetFat || 60,
          };

          // Calorie ratio is the primary decision driver
          const calRatio = targets.calories > 0
            ? displayMacros.calories / targets.calories
            : 0;

          // Secondary: any individual macro notably elevated (>110%)
          const anyMacroElevated = (
            displayMacros.protein / targets.protein > 1.1 ||
            displayMacros.carbs   / targets.carbs   > 1.1 ||
            displayMacros.fat     / targets.fat     > 1.1
          );

          // Case A: total calories above target (>105%) → show "ran higher" guidance
          if (calRatio > 1.05) {
            return (
              <div className="rounded-xl border bg-amber-500/10 border-amber-500/20 px-4 py-3" data-testid="text-over-target-message">
                <p className="text-sm text-foreground">
                  Today ran a bit higher than planned. The best approach is to return to your normal routine tomorrow — consistency beats compensation.
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  There's no need to reduce intake or "make up for it" the next day.
                </p>
              </div>
            );
          }

          // Case B: calories still below target (<95%) but a macro is elevated — calmer note only
          if (calRatio < 0.95 && anyMacroElevated) {
            return (
              <div className="rounded-xl border bg-card/60 border-border/40 px-4 py-3" data-testid="text-macro-note-message">
                <p className="text-sm text-foreground">
                  A few individual nutrients ran a bit high, but total calorie intake stayed below plan.
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Isolated macro overages are normal when overall energy intake is on or below target.
                </p>
              </div>
            );
          }

          // On target or no notable deviation — no card shown
          return null;
        })()}

        {/* AMQS Mini CTA — links to full /micronutrients page */}
        <div
          className="rounded-xl border border-border/50 bg-card p-4 flex items-center justify-between cursor-pointer hover:bg-secondary/20 transition-colors"
          onClick={() => setLocation("/micronutrients")}
          data-testid="card-amqs-cta"
          role="button"
          tabIndex={0}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") setLocation("/micronutrients"); }}
        >
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-5 w-5 text-muted-foreground/60 shrink-0" />
            <div>
              <p className="text-sm font-semibold leading-tight">Micronutrient Score</p>
              {dailyAMQS ? (
                <p className="text-xs text-muted-foreground" data-testid="text-amqs-mini-summary">
                  {dailyAMQS.score} — {dailyAMQS.tier}
                  {dailyAMQS.topGaps && dailyAMQS.topGaps.length > 0 && (
                    <> · <span className="text-foreground/70">{dailyAMQS.topGaps[0].label} gap</span></>
                  )}
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">Log your first meal to start tracking</p>
              )}
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground/40" />
        </div>

        <TodaysSupplements userId={user.id} selectedDate={selectedDate} />
        
        <TodaysTraining selectedDate={selectedDate} />

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
             {/* Weight Chart */}
            <div className="bg-card border border-border/40 rounded-xl p-6 card-elevated">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-display font-semibold">Weight Trend</h3>
                  <p className="text-sm text-muted-foreground">Last 7 recorded entries</p>
                </div>
                <div className="bg-secondary p-2 rounded-lg">
                  <Scale className="h-5 w-5 text-muted-foreground" />
                </div>
              </div>

              <div className="h-[250px] w-full">
                {chartData.length > 1 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <defs>
                        <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="date" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                        dy={10}
                      />
                      <YAxis 
                        domain={['auto', 'auto']} 
                        axisLine={false} 
                        tickLine={false}
                        tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                        width={30}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          borderRadius: '8px', 
                          border: '1px solid hsl(var(--border))',
                          boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                        }}
                        itemStyle={{ color: 'hsl(var(--foreground))' }}
                        labelStyle={{ color: 'hsl(var(--muted-foreground))', marginBottom: '0.25rem' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="weight" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorWeight)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                    Record more weight data to see trends
                  </div>
                )}
              </div>
            </div>

            {/* Food Entries List - Grouped by Meal */}
            <div className="bg-card border border-border/40 rounded-xl p-6 card-elevated">
              <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
                <h3 className="text-lg font-display font-semibold">{isToday ? "Today's Meals" : `Meals — ${format(parseISO(selectedDate), "MMM d")}`}</h3>
                <SavedMealsDialog selectedDate={selectedDate} />
              </div>
              {foodLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : foodEntries && foodEntries.length > 0 ? (
                <MealGroupedEntries entries={foodEntries} allEntries={foodEntries} selectedDate={selectedDate} />
              ) : (
                <div className="flex flex-col items-center py-6 text-center border border-dashed border-border/50 rounded-lg">
                  <Utensils className="h-8 w-8 text-muted-foreground/20 mb-3" />
                  <p className="text-sm text-muted-foreground mb-1">No food logged for this date.</p>
                  <p className="text-xs text-muted-foreground/60">Use the "Add Food" button above to start tracking.</p>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground mt-4 italic">
                Note: Nutrition values are approximate per 100g. Fibre applies mainly to plant foods.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Quick Actions / Today's Weight */}
            <div className="bg-card border border-border/40 rounded-xl p-6 card-elevated h-fit">
              <h3 className="text-lg font-display font-semibold mb-2">Current Weight</h3>
              <div className="text-4xl font-mono font-bold tracking-tight">
                {weightsData.find((w: any) => w.date === selectedDate)?.weight || user.currentWeight || "--"} <span className="text-lg font-sans font-medium text-muted-foreground">kg</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                {weightsData.find((w: any) => w.date === selectedDate)
                  ? (isToday ? "Recorded today" : `Recorded on ${format(parseISO(selectedDate), "MMM d")}`)
                  : (isToday ? "No weight recorded today" : "No weight recorded for this date")}
              </p>

              <div className="mt-8 space-y-3">
                <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      Weight naturally fluctuates day to day (water, salt, sleep, carbs). Focus on trends over time, not individual readings.
                    </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Card data-testid="card-beta-feedback" className="card-elevated">
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <div className="space-y-1.5">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Beta Feedback
              </CardTitle>
              <CardDescription>
                Help us improve PRFMR by sharing your thoughts
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <Link href="/feedback">
              <Button variant="outline" data-testid="button-send-feedback">
                <MessageSquare className="mr-2 h-4 w-4" />
                Send Feedback
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <button
        onClick={() => {
          const addFoodBtn = document.querySelector('[data-testid="button-add-food"]') as HTMLButtonElement | null;
          if (addFoodBtn) addFoodBtn.click();
        }}
        className="fixed bottom-24 right-4 z-40 md:hidden w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center fab-shadow transition-transform"
        data-testid="fab-add-food"
        aria-label="Add Food"
      >
        <Plus className="h-6 w-6" />
      </button>

      {/* ── Fight Camp: Low Energy Availability modal ─────────────────── */}
      <Dialog open={fcOverride.eaModalOpen} onOpenChange={(o) => { if (!o) fcOverride.closeEAModal(); }}>
        <DialogContent className="sm:max-w-sm" data-testid="dialog-ea-warning">
          <DialogHeader>
            <DialogTitle className="font-display">Low energy availability</DialogTitle>
            <DialogDescription className="text-sm leading-relaxed pt-1">
              Your current intake appears to be below the level typically used to support recovery and performance (&lt;30 kcal/kg FFM).

              Increasing your intake may help improve energy levels, training quality, and recovery. This may slightly slow the rate of weight loss, but can better support performance during training.

              This is general performance guidance, not medical advice.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Current EA</span>
              <span className="font-semibold tabular-nums text-right">
                {effectiveTargets?.eaValue ?? "—"} kcal/kg FFM
                <span className="block text-xs font-normal text-muted-foreground">
                  {effectiveTargets?.targetCalories != null ? `${effectiveTargets.targetCalories} kcal/day` : ""}
                </span>
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Calories needed for EA 30</span>
              <span className="font-semibold tabular-nums text-primary">
                {effectiveTargets?.eaRecommendedCalories ?? "—"} kcal
              </span>
            </div>
          </div>
          <div className="flex flex-col gap-2 pt-1">
            <Button
              onClick={fcOverride.acceptEA}
              className="w-full"
              data-testid="button-ea-accept"
            >
              Adjust target to {effectiveTargets?.eaRecommendedCalories ?? "—"} kcal
            </Button>
            <Button
              variant="outline"
              onClick={fcOverride.declineEA}
              className="w-full"
              data-testid="button-ea-decline"
            >
              Keep current plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Fight Camp: Low Carbohydrate modal ───────────────────────── */}
      <Dialog open={fcOverride.carbModalOpen} onOpenChange={(o) => { if (!o) fcOverride.closeCarbModal(); }}>
        <DialogContent className="sm:max-w-sm" data-testid="dialog-carb-warning">
          <DialogHeader>
            <DialogTitle className="font-display">Low carbohydrate intake</DialogTitle>
            <DialogDescription className="text-sm leading-relaxed pt-1">
              Carbohydrate intake is below the minimum recommended for athletes
              (~3 g/kg bodyweight). This may impact training performance and recovery
              (IOC / ISSN guidelines).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Current carbs</span>
              <span className="font-semibold tabular-nums">
                {effectiveTargets?.carbsPerKg != null
                  ? `${effectiveTargets.carbsPerKg} g/kg`
                  : "—"}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Suggested minimum</span>
              <span className="font-semibold tabular-nums text-primary">
                {effectiveTargets?.carbRecommendedG != null
                  ? `${effectiveTargets.carbRecommendedG} g (3 g/kg)`
                  : "—"}
              </span>
            </div>
          </div>
          <div className="flex flex-col gap-2 pt-1">
            <Button
              onClick={fcOverride.acceptCarb}
              className="w-full"
              data-testid="button-carb-accept"
            >
              Adjust carbs to {effectiveTargets?.carbRecommendedG ?? "—"}g
            </Button>
            <Button
              variant="outline"
              onClick={fcOverride.declineCarb}
              className="w-full"
              data-testid="button-carb-decline"
            >
              Keep current plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>

    </Layout>
  );
}

function SaveMealDialog({ date, meal, mealLabel }: { date: string; meal: string; mealLabel: string }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const saveMutation = useSaveMealTemplate();

  const handleSave = () => {
    if (!name.trim()) return;
    saveMutation.mutate({ date, meal, name: name.trim() }, {
      onSuccess: () => { setOpen(false); setName(""); },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost" data-testid={`button-save-meal-${meal}`}>
          <Bookmark className="h-3.5 w-3.5" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Save {mealLabel} as Template</DialogTitle>
          <DialogDescription>Save this meal so you can quickly log it again on another day.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          <div>
            <Label htmlFor="template-name">Template Name</Label>
            <Input
              id="template-name"
              placeholder={`e.g. My ${mealLabel}`}
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
              data-testid="input-template-name"
            />
          </div>
          <Button onClick={handleSave} disabled={!name.trim() || saveMutation.isPending} className="w-full" data-testid="button-confirm-save-meal">
            {saveMutation.isPending ? "Saving..." : "Save Template"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CopyMealDialog({ fromDate, fromMeal, mealLabel }: { fromDate: string; fromMeal: string; mealLabel: string }) {
  const [open, setOpen] = useState(false);
  const [toDate, setToDate] = useState("");
  const [toMeal, setToMeal] = useState(fromMeal);
  const copyMutation = useCopyMeal();

  const handleCopy = () => {
    if (!toDate) return;
    copyMutation.mutate({ fromDate, fromMeal, toDate, toMeal }, {
      onSuccess: () => { setOpen(false); setToDate(""); },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost" data-testid={`button-copy-meal-${fromMeal}`}>
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Copy {mealLabel}</DialogTitle>
          <DialogDescription>Copy all items from this meal to another day.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          <div>
            <Label htmlFor="copy-to-date">Target Date</Label>
            <Input id="copy-to-date" type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} data-testid="input-copy-to-date" />
          </div>
          <div>
            <Label>Target Meal</Label>
            <Select value={toMeal} onValueChange={setToMeal}>
              <SelectTrigger data-testid="select-copy-to-meal">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="breakfast">Breakfast</SelectItem>
                <SelectItem value="lunch">Lunch</SelectItem>
                <SelectItem value="dinner">Dinner</SelectItem>
                <SelectItem value="snack">Snack</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleCopy} disabled={!toDate || copyMutation.isPending} className="w-full" data-testid="button-confirm-copy-meal">
            {copyMutation.isPending ? "Copying..." : "Copy Meal"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SavedMealsDialog({ selectedDate }: { selectedDate: string }) {
  const [open, setOpen] = useState(false);
  const { data: templates = [], isLoading } = useMealTemplates();
  const logMutation = useLogMealTemplate();
  const deleteMutation = useDeleteMealTemplate();
  const [logTarget, setLogTarget] = useState<{ id: number; name: string } | null>(null);
  const [logDate, setLogDate] = useState(selectedDate);
  const [logMeal, setLogMeal] = useState("lunch");

  const handleLog = () => {
    if (!logTarget) return;
    logMutation.mutate({ templateId: logTarget.id, date: logDate, meal: logMeal }, {
      onSuccess: () => { setLogTarget(null); },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" data-testid="button-saved-meals">
          <BookOpen className="h-4 w-4 mr-1" /> Saved Meals
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">Saved Meals</DialogTitle>
          <DialogDescription>Log a saved meal template into any day.</DialogDescription>
        </DialogHeader>
        {logTarget ? (
          <div className="space-y-3 pt-2">
            <p className="text-sm font-medium">Log "{logTarget.name}"</p>
            <div>
              <Label>Date</Label>
              <Input type="date" value={logDate} onChange={(e) => setLogDate(e.target.value)} data-testid="input-log-template-date" />
            </div>
            <div>
              <Label>Meal</Label>
              <Select value={logMeal} onValueChange={setLogMeal}>
                <SelectTrigger data-testid="select-log-template-meal">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast">Breakfast</SelectItem>
                  <SelectItem value="lunch">Lunch</SelectItem>
                  <SelectItem value="dinner">Dinner</SelectItem>
                  <SelectItem value="snack">Snack</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setLogTarget(null)} className="flex-1">Back</Button>
              <Button onClick={handleLog} disabled={logMutation.isPending} className="flex-1" data-testid="button-confirm-log-template">
                {logMutation.isPending ? "Logging..." : "Log Meal"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-2 pt-2">
            {isLoading ? (
              <Skeleton className="h-16 w-full" />
            ) : templates.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No saved meals yet. Use the bookmark icon next to a meal to save it.</p>
            ) : (
              templates.map((t: any) => (
                <div key={t.id} className="flex items-center justify-between p-3 rounded-lg border bg-secondary/30" data-testid={`template-${t.id}`}>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{t.name}</p>
                    <div className="flex gap-2 text-xs text-muted-foreground flex-wrap">
                      {t.defaultMeal && <Badge variant="secondary" className="text-[10px]">{t.defaultMeal}</Badge>}
                      <span>{t.items?.length || 0} items</span>
                      <span>
                        {t.items?.reduce((sum: number, i: any) => sum + (i.calories || 0), 0)} kcal
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" onClick={() => { setLogTarget({ id: t.id, name: t.name }); setLogDate(selectedDate); setLogMeal(t.defaultMeal || "lunch"); }} data-testid={`button-log-template-${t.id}`}>
                      Log
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(t.id)} disabled={deleteMutation.isPending} data-testid={`button-delete-template-${t.id}`}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function MealGroupedEntries({ entries, allEntries, selectedDate }: { entries: any[]; allEntries: any[]; selectedDate: string }) {
  const breakfast = entries.filter(e => e.meal === "breakfast");
  const lunch = entries.filter(e => e.meal === "lunch" || !e.meal);
  const dinner = entries.filter(e => e.meal === "dinner");
  const snacks = entries.filter(e => e.meal === "snack");
  
  const snackGroups: Record<number, any[]> = {};
  snacks.forEach(s => {
    const idx = s.snackIndex ?? 1;
    if (!snackGroups[idx]) snackGroups[idx] = [];
    snackGroups[idx].push(s);
  });
  const sortedSnackIndices = Object.keys(snackGroups).map(Number).sort((a, b) => a - b);

  const renderEntry = (entry: any) => (
    <motion.div 
      key={entry.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex items-center justify-between p-3 rounded-lg border bg-secondary/30 group"
    >
      <div className="flex-1">
        <p className="font-medium">{entry.name} <span className="text-xs text-muted-foreground font-normal">({entry.grams}g{entry.enteredBasis ? ` ${entry.enteredBasis}` : ""})</span></p>
        <div className="flex gap-3 text-xs text-muted-foreground">
          <span>{entry.calories} kcal</span>
          <span>P: {entry.protein}g</span>
          <span>C: {entry.carbs}g</span>
          <span>F: {entry.fat}g</span>
          {entry.fibre !== null && entry.fibre !== undefined && entry.fibre > 0 && <span>Fi: {entry.fibre}g</span>}
        </div>
      </div>
      <div className="flex gap-1">
        <CopyFoodDialog entry={entry} />
        <EditFoodDialog entry={entry} existingEntries={allEntries} />
        <DeleteFoodButton id={entry.id} />
      </div>
    </motion.div>
  );

  const renderMealSection = (label: string, Icon: any, items: any[], mealKey: string) => {
    if (items.length === 0) return null;
    const totalCals = items.reduce((s, e) => s + (e.calories || 0), 0);
    const totalProtein = items.reduce((s, e) => s + (e.protein || 0), 0);
    const totalCarbs = items.reduce((s, e) => s + (e.carbs || 0), 0);
    const totalFat = items.reduce((s, e) => s + (e.fat || 0), 0);
    const totalFibre = items.reduce((s, e) => s + (e.fibre || 0), 0);
    return (
      <div className="space-y-2" key={label}>
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground flex-wrap">
          <Icon className="h-4 w-4" />
          <span>{label}</span>
          <Badge variant="secondary" className="text-[10px] px-1.5">{items.length}</Badge>
          <div className="ml-auto flex gap-0.5" style={{ visibility: items.length > 0 ? "visible" : "hidden" }}>
            <SaveMealDialog date={selectedDate} meal={mealKey} mealLabel={label} />
            <CopyMealDialog fromDate={selectedDate} fromMeal={mealKey} mealLabel={label} />
          </div>
        </div>
        <div className="text-[11px] text-muted-foreground/60 font-mono pl-1" data-testid={`meal-totals-${mealKey}`}>
          {totalCals} kcal · P {totalProtein}g · C {totalCarbs}g · F {totalFat}g{totalFibre > 0 ? ` · Fi ${totalFibre}g` : ""}
        </div>
        <AnimatePresence>
          {items.map(renderEntry)}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {renderMealSection("Breakfast", Coffee, breakfast, "breakfast")}
      {renderMealSection("Lunch", Sun, lunch, "lunch")}
      {renderMealSection("Dinner", Moon, dinner, "dinner")}
      {sortedSnackIndices.map(idx => (
        renderMealSection(`Snack #${idx}`, Cookie, snackGroups[idx], "snack")
      ))}
    </div>
  );
}

const CORE_FOODS = [
  { name: "Porridge (oats + milk)", serving: 250, calories: 185, protein: 7, carbs: 27, fat: 5, fibre: 3 },
  { name: "Porridge (oats + water)", serving: 250, calories: 130, protein: 5, carbs: 23, fat: 2, fibre: 3 },
  { name: "Cappuccino (whole milk)", serving: 240, calories: 120, protein: 6, carbs: 10, fat: 6, fibre: 0 },
  { name: "Latte (whole milk)", serving: 350, calories: 180, protein: 9, carbs: 14, fat: 9, fibre: 0 },
  { name: "Flat White", serving: 200, calories: 120, protein: 6, carbs: 10, fat: 6, fibre: 0 },
  { name: "Cappuccino (oat milk)", serving: 240, calories: 100, protein: 3, carbs: 16, fat: 3, fibre: 1 },
  { name: "Toast with Butter (white)", serving: 45, calories: 155, protein: 3, carbs: 17, fat: 8, fibre: 1 },
  { name: "Toast without Butter (white)", serving: 30, calories: 80, protein: 3, carbs: 15, fat: 1, fibre: 1 },
  { name: "Toast with Butter (wholemeal)", serving: 50, calories: 165, protein: 5, carbs: 18, fat: 8, fibre: 3 },
  { name: "Mashed Potato", serving: 200, calories: 180, protein: 4, carbs: 30, fat: 5, fibre: 2 },
  { name: "Scrambled Eggs (2 eggs, butter)", serving: 130, calories: 220, protein: 14, carbs: 2, fat: 17, fibre: 0 },
  { name: "Protein Shake (whey + water)", serving: 350, calories: 130, protein: 25, carbs: 3, fat: 2, fibre: 0 },
  { name: "Protein Shake (whey + milk)", serving: 350, calories: 280, protein: 35, carbs: 18, fat: 8, fibre: 0 },
  { name: "Overnight Oats", serving: 300, calories: 320, protein: 12, carbs: 45, fat: 10, fibre: 5 },
  { name: "Beans on Toast", serving: 260, calories: 280, protein: 14, carbs: 42, fat: 5, fibre: 8 },
  { name: "Tuna Mayo Sandwich", serving: 200, calories: 350, protein: 22, carbs: 30, fat: 14, fibre: 2 },
  { name: "Chicken Wrap", serving: 250, calories: 380, protein: 28, carbs: 35, fat: 12, fibre: 2 },
  { name: "Greek Yoghurt with Honey", serving: 170, calories: 180, protein: 14, carbs: 22, fat: 5, fibre: 0 },
  { name: "PB&J Sandwich", serving: 130, calories: 380, protein: 12, carbs: 45, fat: 16, fibre: 3 },
  { name: "Cereal with Milk", serving: 270, calories: 250, protein: 8, carbs: 42, fat: 5, fibre: 3 },
];

function FoodEntryDialog({ date, existingEntries = [], isPrimary = false }: { date: string; existingEntries?: any[]; isPrimary?: boolean }) {
  const [open, setOpen] = useState(false);
  const { mutate: createEntry, isPending } = useCreateFoodEntry();
  const { data: user } = useUser();
  const { toast } = useToast();
  const foodToastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIngredient, setSelectedIngredient] = useState<any>(null);
  const [grams, setGrams] = useState("100");
  const [enteredBasis, setEnteredBasis] = useState<"raw" | "cooked">("cooked");
  const [unitMode, setUnitMode] = useState<"count" | "grams">("grams");
  const [unitCount, setUnitCount] = useState(1);
  const [unitSize, setUnitSize] = useState<UnitSize>("medium");
  const [barcode, setBarcode] = useState("");
  const [barcodeResult, setBarcodeResult] = useState<any>(null);
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [barcodeError, setBarcodeError] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [scannerUnavailableReason, setScannerUnavailableReason] = useState<string | null>(null);
  const [showScannerDebug, setShowScannerDebug] = useState(false);
  const [debugInfo, setDebugInfo] = useState<{
    secureContext: boolean;
    origin: string;
    userAgent: string;
    hasMediaDevices: boolean;
    cameraCount: number;
    lastError: string;
    startCount: number;
  } | null>(null);
  
  // Scanner refs for proper state management (prevents crashes)
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isRunningRef = useRef(false);
  const startingRef = useRef(false);
  const stoppingRef = useRef(false);
  const didDecodeRef = useRef(false);
  const cancelledRef = useRef(false); // Tracks if close/unmount happened during start
  const startCountRef = useRef(0);
  const readerRef = useRef<HTMLDivElement>(null);
  const [selectedMeal, setSelectedMeal] = useState<MealType>("lunch");
  const [selectedSnackIndex, setSelectedSnackIndex] = useState<number | null>(null);
  const [justAdded, setJustAdded] = useState<string | null>(null);
  const justAddedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showJustAdded = (name: string) => {
    setJustAdded(name);
    if (justAddedTimerRef.current) clearTimeout(justAddedTimerRef.current);
    justAddedTimerRef.current = setTimeout(() => setJustAdded(null), 2500);
    if (foodToastTimerRef.current) clearTimeout(foodToastTimerRef.current);
    foodToastTimerRef.current = setTimeout(() => {
      toast({ title: "Logged — dashboard updated", description: `${name} added. Micro scores recalculating.` });
    }, 5000);
  };
  useEffect(() => {
    return () => {
      if (foodToastTimerRef.current) clearTimeout(foodToastTimerRef.current);
      if (justAddedTimerRef.current) clearTimeout(justAddedTimerRef.current);
    };
  }, []);
  const [customMacros, setCustomMacros] = useState({
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    fibre: "",
  });
  
  // Ingredient mapping for barcode scans (for micros)
  const [selectedMappingIngredient, setSelectedMappingIngredient] = useState<any>(null);
  const [mappingSearchTerm, setMappingSearchTerm] = useState("");
  const [isSavingMapping, setIsSavingMapping] = useState(false);
  const [skipMicros, setSkipMicros] = useState(false);
  
  // Custom food creation (My Foods)
  const [showCreateFoodDialog, setShowCreateFoodDialog] = useState(false);
  const [newFoodData, setNewFoodData] = useState({
    name: "",
    brand: "",
    barcode: "",
    kcalPer100g: "",
    proteinPer100g: "",
    carbsPer100g: "",
    fatPer100g: "",
    fibrePer100g: "",
  });
  const [isCreatingFood, setIsCreatingFood] = useState(false);

  // OFF food search state
  const [offSearchQuery, setOffSearchQuery] = useState("");
  const [offSearchResults, setOffSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedOffFood, setSelectedOffFood] = useState<any>(null);
  const [offGrams, setOffGrams] = useState("100");
  const offSearchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Client-side cache for recent OFF search results (last 20 unique queries)
  const offCacheRef = useRef<Map<string, any[]>>(new Map());

  const handleOffSearch = (query: string) => {
    setOffSearchQuery(query);
    if (offSearchTimerRef.current) clearTimeout(offSearchTimerRef.current);
    const key = query.trim().toLowerCase();
    if (key.length < 2) {
      setOffSearchResults([]);
      setIsSearching(false);
      return;
    }
    // Return cached result immediately if available (also shows while re-fetching)
    const cached = offCacheRef.current.get(key);
    if (cached) {
      setOffSearchResults(cached);
      setIsSearching(false);
      return;
    }
    setIsSearching(true);
    offSearchTimerRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/foods/search?q=${encodeURIComponent(query.trim())}`, { credentials: "include" });
        if (res.ok) {
          const data = await res.json();
          // Store in client cache (keep last 20 entries)
          offCacheRef.current.set(key, data);
          if (offCacheRef.current.size > 20) {
            const firstKey = offCacheRef.current.keys().next().value;
            if (firstKey) offCacheRef.current.delete(firstKey);
          }
          setOffSearchResults(data);
        }
      } catch {
        setOffSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 250);
  };

  const [offSuggestions, setOffSuggestions] = useState<any>(null);
  const [offMappingIngredient, setOffMappingIngredient] = useState<any>(null);
  const [offMappingSearch, setOffMappingSearch] = useState("");
  const [offSkipMicros, setOffSkipMicros] = useState(false);
  const handleSelectOffFood = async (food: any) => {
    setSelectedOffFood(food);
    setOffGrams("100");
    setOffSearchResults([]);
    setOffMappingIngredient(null);
    setOffMappingSearch("");
    setOffSkipMicros(false);
    setOffSuggestions(null);

    try {
      const res = await fetch("/api/foods/search/match", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: food.name,
          brand: food.brand,
          calories: food.calories,
          protein: food.protein,
          carbs: food.carbs,
          fat: food.fat,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setOffSuggestions(data.suggestions);
        if (data.suggestions?.best?.confidence === "high" && data.suggestions.best.ingredientIndex !== undefined) {
          const ingRes = await fetch("/api/ingredients", { credentials: "include", cache: "no-store" });
          if (ingRes.ok) {
            const allIng = await ingRes.json();
            const matched = allIng[data.suggestions.best.ingredientIndex];
            if (matched) {
              setOffMappingIngredient({ ...matched, index: data.suggestions.best.ingredientIndex });
            }
          }
        }
      }
    } catch (e) {
      if (process.env.NODE_ENV === "development") console.error("[search] match error:", e);
    }
  };

  const saveOffMapping = (ingredient: any, ingredientIndex: number) => {
    setOffMappingIngredient({ ...ingredient, index: ingredientIndex });
    setOffMappingSearch("");
    setOffSkipMicros(false);
  };

  const calculateOffMacro = (per100g: number) => {
    const g = parseFloat(offGrams) || 0;
    return Math.round(per100g * g / 100);
  };

  const handleOffFoodSubmit = () => {
    if (!user || !selectedOffFood) return;
    const snackIdx = selectedMeal === "snack"
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;

    const entryPayload: any = {
      userId: user.id,
      date,
      name: selectedOffFood.name + (selectedOffFood.brand ? ` (${selectedOffFood.brand})` : ""),
      grams: parseInt(offGrams) || 100,
      calories: calculateOffMacro(selectedOffFood.calories),
      protein: calculateOffMacro(selectedOffFood.protein),
      carbs: calculateOffMacro(selectedOffFood.carbs),
      fat: calculateOffMacro(selectedOffFood.fat),
      fibre: calculateOffMacro(selectedOffFood.fibre || 0),
      meal: selectedMeal,
      snackIndex: snackIdx,
      sourceType: "off",
      offBarcode: selectedOffFood.barcode || undefined,
      macroSource: "off",
    };

    if (offMappingIngredient && !offSkipMicros) {
      entryPayload.ingredientIndex = offMappingIngredient.index;
      entryPayload.ingredientName = offMappingIngredient.name;
      entryPayload.microSource = "ingredient";
    } else {
      entryPayload.microSource = "none";
    }

    createEntry(entryPayload, {
      onSuccess: () => {
        showJustAdded(entryPayload.name);
        setSelectedOffFood(null);
        setOffGrams("100");
        setOffMappingIngredient(null);
        setOffSuggestions(null);
        setOffSkipMicros(false);
      },
    });
  };

  // Calculate next available snack index for this date
  const existingSnackIndices = existingEntries
    .filter(e => e.meal === "snack" && e.snackIndex !== null)
    .map(e => e.snackIndex as number);
  const maxSnackIndex = existingSnackIndices.length > 0 ? Math.max(...existingSnackIndices) : 0;
  const nextSnackIndex = maxSnackIndex + 1;
  
  // Get unique snack indices for dropdown
  const uniqueSnackIndices = Array.from(new Set(existingSnackIndices)).sort((a, b) => a - b);

  // Gather debug info for scanner troubleshooting
  const gatherDebugInfo = async (lastError = "") => {
    if (typeof window === "undefined") return;
    
    let cameraCount = 0;
    try {
      if (navigator.mediaDevices?.enumerateDevices) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        cameraCount = devices.filter(d => d.kind === "videoinput").length;
      }
    } catch {}
    
    setDebugInfo({
      secureContext: !!window.isSecureContext,
      origin: window.location.origin,
      userAgent: navigator.userAgent.slice(0, 100) + "...",
      hasMediaDevices: !!navigator.mediaDevices?.getUserMedia,
      cameraCount,
      lastError,
      startCount: startCountRef.current,
    });
  };

  // Check if scanner is available on mount
  useEffect(() => {
    if (typeof window === "undefined" || typeof navigator === "undefined") {
      setScannerUnavailableReason("Camera scanning requires a browser environment.");
      return;
    }
    if (!window.isSecureContext) {
      setScannerUnavailableReason("Camera scanning requires a secure connection (HTTPS).");
      gatherDebugInfo("Not a secure context");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setScannerUnavailableReason("Camera scanning is not supported on this device/browser.");
      gatherDebugInfo("mediaDevices.getUserMedia not available");
      return;
    }
    setScannerUnavailableReason(null);
    gatherDebugInfo();
  }, []);

  // Cleanup scanner on unmount (idempotent, handles race conditions)
  useEffect(() => {
    return () => {
      // Mark as cancelled so any pending start knows to stop immediately
      cancelledRef.current = true;
      
      const s = scannerRef.current;
      if (s) {
        // If running or start is pending, stop it
        if (isRunningRef.current && !stoppingRef.current) {
          stoppingRef.current = true;
          s.stop()
            .then(() => { try { s.clear(); } catch {} })
            .catch((err) => {
              // Ignore "scanner is not running" error
              if (!String(err).includes("scanner is not running") && !String(err).includes("not running or paused")) {
                console.error("Cleanup stop error:", err);
              }
              try { s.clear(); } catch {}
            })
            .finally(() => {
              isRunningRef.current = false;
              stoppingRef.current = false;
              scannerRef.current = null;
            });
        } else {
          // Scanner exists but not running - just clear it
          try { s.clear(); } catch {}
          scannerRef.current = null;
        }
      }
      startingRef.current = false;
      didDecodeRef.current = false;
    };
  }, []);

  const startScan = async () => {
    // Prevent double-start (guards for React strict mode too)
    if (startingRef.current || isRunningRef.current || stoppingRef.current) return;
    
    startingRef.current = true;
    didDecodeRef.current = false;
    cancelledRef.current = false; // Reset cancelled flag for fresh start
    setBarcodeError("");
    
    // Check environment requirements
    if (typeof window === "undefined" || typeof navigator === "undefined") {
      setBarcodeError("Camera scanning requires a browser environment.");
      startingRef.current = false;
      return;
    }
    if (!window.isSecureContext) {
      setBarcodeError("Camera scanning requires a secure connection (HTTPS). Use manual entry.");
      startingRef.current = false;
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setBarcodeError("Camera scanning is not supported on this device. Use manual entry.");
      startingRef.current = false;
      return;
    }

    // Check DOM element exists using ref
    if (!readerRef.current) {
      setBarcodeError("Scanner element not ready. Please try again.");
      startingRef.current = false;
      return;
    }

    try {
      // Request camera permission first - try environment camera, fallback to any camera
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: { ideal: "environment" } } 
        });
      } catch {
        // Fallback to any available camera
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
      }
      // Stop the test stream immediately
      stream.getTracks().forEach(track => track.stop());
    } catch (err: any) {
      console.error("Camera permission check failed:", err);
      startingRef.current = false;
      if (err?.name === "NotAllowedError") {
        setBarcodeError("Camera permission denied. Enable camera access in browser settings or use manual entry.");
      } else if (err?.name === "NotFoundError") {
        setBarcodeError("No camera found on this device. Use manual entry.");
      } else if (err?.name === "NotReadableError") {
        setBarcodeError("Camera is in use by another app. Close other apps and try again.");
      } else if (err?.name === "OverconstrainedError") {
        setBarcodeError("Camera does not meet requirements. Use manual entry.");
      } else {
        setBarcodeError("Could not access camera. Use manual entry.");
      }
      return;
    }

    try {
      startCountRef.current += 1;
      setIsScanning(true);
      
      // Configure scanner with barcode formats (EAN, UPC, CODE_128)
      const html5QrCode = new Html5Qrcode("reader", {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_128,
        ],
        verbose: false,
      });
      scannerRef.current = html5QrCode;

      const scanConfig = { fps: 10, qrbox: { width: 250, height: 150 } };
      const onSuccess = (decodedText: string) => {
        // Prevent multiple decodes
        if (didDecodeRef.current) return;
        didDecodeRef.current = true;
        
        setBarcode(decodedText);
        stopScan();
        handleBarcodeLookupWithCode(decodedText);
      };
      const onError = () => {}; // silent on failure to find barcode

      // Try rear camera first, fallback to any camera
      try {
        await html5QrCode.start({ facingMode: "environment" }, scanConfig, onSuccess, onError);
        
        // Check if cancelled during start - if so, immediately stop and clean up
        if (cancelledRef.current) {
          try { await html5QrCode.stop(); } catch {}
          try { html5QrCode.clear(); } catch {}
          scannerRef.current = null;
          startingRef.current = false;
          setIsScanning(false);
          return;
        }
        isRunningRef.current = true;
      } catch (cameraErr: any) {
        console.log("Rear camera failed, trying any camera:", cameraErr?.message);
        // Clear state before retry (safe stop)
        try { await html5QrCode.stop(); } catch {}
        try { html5QrCode.clear(); } catch {}
        
        // Check if cancelled during start attempt
        if (cancelledRef.current) {
          scannerRef.current = null;
          startingRef.current = false;
          setIsScanning(false);
          return;
        }
        
        // Fallback: try any available camera (front camera or first available)
        const fallbackQrCode = new Html5Qrcode("reader", {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.EAN_8,
            Html5QrcodeSupportedFormats.UPC_A,
            Html5QrcodeSupportedFormats.UPC_E,
            Html5QrcodeSupportedFormats.CODE_128,
          ],
          verbose: false,
        });
        scannerRef.current = fallbackQrCode;
        // Use front camera as fallback
        await fallbackQrCode.start({ facingMode: "user" }, scanConfig, onSuccess, onError);
        
        // Check if cancelled during fallback start
        if (cancelledRef.current) {
          try { await fallbackQrCode.stop(); } catch {}
          try { fallbackQrCode.clear(); } catch {}
          scannerRef.current = null;
          startingRef.current = false;
          setIsScanning(false);
          return;
        }
        isRunningRef.current = true;
      }
      
      startingRef.current = false;
    } catch (err: any) {
      console.error("Scanner start failed:", err?.message || err);
      startingRef.current = false;
      isRunningRef.current = false;
      setIsScanning(false);
      scannerRef.current = null;
      
      const errorMsg = err?.message || String(err);
      gatherDebugInfo(errorMsg);
      
      if (err?.name === "NotAllowedError" || errorMsg.includes("Permission")) {
        setBarcodeError("Camera permission denied. Enable camera access or use manual entry.");
      } else if (err?.name === "NotFoundError" || errorMsg.includes("not found")) {
        setBarcodeError("No camera found. Use manual entry.");
      } else if (err?.name === "NotReadableError" || errorMsg.includes("in use")) {
        setBarcodeError("Camera is busy. Close other apps and try again.");
      } else if (errorMsg.includes("No MultiFormat Readers")) {
        setBarcodeError("Scanner configuration error. Use manual entry.");
      } else {
        setBarcodeError(`Camera error: ${errorMsg}. Use manual entry.`);
      }
    }
  };

  const stopScan = async () => {
    // Mark as cancelled so any pending start knows to stop immediately
    cancelledRef.current = true;
    
    // If currently starting, just let the start handle cleanup
    if (startingRef.current) {
      setIsScanning(false);
      return;
    }
    
    // Guard: don't stop if not running or already stopping
    if (!isRunningRef.current || stoppingRef.current) {
      setIsScanning(false);
      return;
    }
    
    stoppingRef.current = true;
    const s = scannerRef.current;
    
    if (s) {
      try {
        await s.stop();
      } catch (err: any) {
        // Ignore "scanner is not running" error - this is expected in some cases
        const errMsg = String(err);
        if (!errMsg.includes("scanner is not running") && !errMsg.includes("not running or paused")) {
          console.error("Scanner stop error:", err);
        }
      }
      try {
        s.clear();
      } catch {}
    }
    
    scannerRef.current = null;
    isRunningRef.current = false;
    stoppingRef.current = false;
    setIsScanning(false);
  };

  const [showBarcodeCreateForm, setShowBarcodeCreateForm] = useState(false);
  const [barcodeCreateData, setBarcodeCreateData] = useState({
    name: "", brand: "", kcal: "0", protein: "0", carbs: "0", fat: "0", fibre: "0", servingSizeG: "",
  });
  const [isCreatingBarcodeFood, setIsCreatingBarcodeFood] = useState(false);

  const handleBarcodeLookupWithCode = async (codeToUse: string) => {
    if (!codeToUse) return;
    setIsLookingUp(true);
    setBarcodeError("");
    setBarcodeResult(null);
    setShowBarcodeCreateForm(false);
    try {
      const res = await fetch(`/api/food/barcode/${codeToUse}`, { credentials: "include", cache: "no-store" });
      const data = await res.json();
      console.log("[Barcode] Raw API response:", data);

      if (!data.found && data.canCreate) {
        setBarcodeError("This barcode isn't in our database yet.");
        setShowBarcodeCreateForm(true);
        setBarcodeCreateData({ name: "", brand: "", kcal: "0", protein: "0", carbs: "0", fat: "0", fibre: "0", servingSizeG: "" });
        return;
      }

      if (!data.found) {
        setBarcodeError("Not found — use Custom entry or Whole Foods.");
        return;
      }

      if (data.source === "custom" && data.custom) {
        const transformed = {
          name: data.custom.name,
          image_url: null,
          calories_kcal_100g: data.custom.macros_per_100g?.kcal ?? 0,
          protein_g_100g: data.custom.macros_per_100g?.protein ?? 0,
          carbs_g_100g: data.custom.macros_per_100g?.carbs ?? 0,
          fat_g_100g: data.custom.macros_per_100g?.fat ?? 0,
          fibre_g_100g: data.custom.macros_per_100g?.fibre ?? 0,
          barcode: data.barcode,
          source: "custom",
          mapping: null,
          suggestions: null,
        };
        setBarcodeResult(transformed);
        setGrams(data.custom.servingSizeG ? String(data.custom.servingSizeG) : "100");
        return;
      }

      const transformed = data.off ? {
        name: data.off.name,
        image_url: data.off.image_url,
        calories_kcal_100g: data.off.macros_per_100g?.kcal ?? 0,
        protein_g_100g: data.off.macros_per_100g?.protein ?? 0,
        carbs_g_100g: data.off.macros_per_100g?.carbs ?? 0,
        fat_g_100g: data.off.macros_per_100g?.fat ?? 0,
        fibre_g_100g: data.off.macros_per_100g?.fibre ?? 0,
        barcode: data.barcode,
        mapping: data.mapping,
        suggestions: data.suggestions,
      } : data;
      
      console.log("[Barcode] Nutrition per 100g object:", {
        kcal: transformed.calories_kcal_100g,
        protein: transformed.protein_g_100g,
        carbs: transformed.carbs_g_100g,
        fat: transformed.fat_g_100g,
        fibre: transformed.fibre_g_100g,
      });
      
      setBarcodeResult(transformed);
      setGrams("100");
      
      // Reset mapping state, then apply existing mapping if any
      setSelectedMappingIngredient(null);
      setMappingSearchTerm("");
      setSkipMicros(false);
      
      // If there's an existing mapping, pre-select it
      if (data.mapping?.ingredientIndex !== undefined) {
        const ingredientRes = await fetch("/api/ingredients", { credentials: "include", cache: "no-store" });
        if (ingredientRes.ok) {
          const allIngredients = await ingredientRes.json();
          const mapped = allIngredients[data.mapping.ingredientIndex];
          if (mapped) {
            setSelectedMappingIngredient({ ...mapped, index: data.mapping.ingredientIndex });
          }
        }
      } else if (data.suggestions?.best?.confidence === "high" && data.suggestions.best.ingredientIndex !== undefined) {
        const ingredientRes = await fetch("/api/ingredients", { credentials: "include", cache: "no-store" });
        if (ingredientRes.ok) {
          const allIngredients = await ingredientRes.json();
          const autoMapped = allIngredients[data.suggestions.best.ingredientIndex];
          if (autoMapped) {
            setSelectedMappingIngredient({ ...autoMapped, index: data.suggestions.best.ingredientIndex });
          }
        }
      }
    } catch (err) {
      setBarcodeError("Error looking up barcode. Please try again.");
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleBarcodeLookup = () => handleBarcodeLookupWithCode(barcode);

  const handleBarcodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !barcodeResult) return;

    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;

    // Build entry payload with mapping fields if ingredient is selected
    const entryPayload: any = {
      userId: user.id,
      date,
      name: barcodeResult.name,
      grams: parseInt(grams) || 100,
      calories: calculateMacro(barcodeResult.calories_kcal_100g),
      protein: calculateMacro(barcodeResult.protein_g_100g),
      carbs: calculateMacro(barcodeResult.carbs_g_100g),
      fat: calculateMacro(barcodeResult.fat_g_100g),
      fibre: calculateMacro(barcodeResult.fibre_g_100g || 0),
      meal: selectedMeal,
      snackIndex: snackIdx,
      // OFF-specific fields
      sourceType: "off",
      offBarcode: barcodeResult.barcode || barcode,
      macroSource: "off",
    };
    
    // Include mapping if selected
    if (selectedMappingIngredient && !skipMicros) {
      entryPayload.ingredientIndex = selectedMappingIngredient.index;
      entryPayload.ingredientName = selectedMappingIngredient.name;
      entryPayload.microSource = "ingredient";
    } else {
      entryPayload.microSource = "none";
    }
    
    console.log("[Add to Log] Request body:", entryPayload);
    console.log("[Add to Log] Name included:", entryPayload.name ? "YES" : "NO - MISSING!");
    console.log("[Add to Log] Mapping:", selectedMappingIngredient?.name || "none");

    createEntry(entryPayload, {
      onSuccess: () => {
        showJustAdded(entryPayload.name);
        setBarcode("");
        setBarcodeResult(null);
        setGrams("100");
        setSelectedMappingIngredient(null);
        setMappingSearchTerm("");
        setSkipMicros(false);
      }
    });
  };
  
  // Save ingredient mapping for a barcode
  const saveIngredientMapping = async (ingredient: any, ingredientIndex: number) => {
    if (!barcodeResult?.barcode && !barcode) return;
    
    setIsSavingMapping(true);
    try {
      const code = barcodeResult?.barcode || barcode;
      const res = await fetch(`/api/food/barcode/${code}/map`, {
        credentials: "include",
        cache: "no-store",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ingredientIndex }),
      });
      
      if (res.ok) {
        setSelectedMappingIngredient({ ...ingredient, index: ingredientIndex });
        setMappingSearchTerm("");
        setSkipMicros(false);
      }
    } catch (err) {
      console.error("Failed to save mapping:", err);
    } finally {
      setIsSavingMapping(false);
    }
  };
  
  // Create a custom food (My Foods database)
  const handleCreateCustomFood = async () => {
    if (!newFoodData.name || !newFoodData.kcalPer100g) return;
    
    setIsCreatingFood(true);
    try {
      const payload = {
        name: newFoodData.name.trim(),
        brand: newFoodData.brand.trim() || undefined,
        barcode: newFoodData.barcode.trim() || undefined,
        kcalPer100g: parseInt(newFoodData.kcalPer100g) || 0,
        proteinPer100g: parseFloat(newFoodData.proteinPer100g) || 0,
        carbsPer100g: parseFloat(newFoodData.carbsPer100g) || 0,
        fatPer100g: parseFloat(newFoodData.fatPer100g) || 0,
        fibrePer100g: parseFloat(newFoodData.fibrePer100g) || 0,
      };
      
      const res = await fetch("/api/foods/custom", {
        credentials: "include",
        cache: "no-store",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      
      if (res.ok) {
        const savedFood = await res.json();
        // Reset form and close dialog
        setNewFoodData({
          name: "",
          brand: "",
          barcode: "",
          kcalPer100g: "",
          proteinPer100g: "",
          carbsPer100g: "",
          fatPer100g: "",
          fibrePer100g: "",
        });
        setShowCreateFoodDialog(false);
        setBarcodeError("");
        
        // Auto-populate barcode result to log the food immediately
        setBarcodeResult({
          name: savedFood.name,
          barcode: savedFood.barcode,
          calories_kcal_100g: savedFood.kcalPer100g,
          protein_g_100g: savedFood.proteinPer100g || 0,
          carbs_g_100g: savedFood.carbsPer100g || 0,
          fat_g_100g: savedFood.fatPer100g || 0,
          fibre_g_100g: savedFood.fibrePer100g || 0,
          image_url: null,
        });
      } else {
        const err = await res.json();
        console.error("Failed to create food:", err);
      }
    } catch (err) {
      console.error("Failed to create custom food:", err);
    } finally {
      setIsCreatingFood(false);
    }
  };

  const getNormalizedGrams = () => {
    const g = parseFloat(grams);
    if (isNaN(g)) return 0;
    if (!selectedIngredient?.supportsCookedToggle || !selectedIngredient?.canonicalBasis || !selectedIngredient?.cookedYieldFactor) return g;
    if (selectedIngredient.canonicalBasis === "raw" && enteredBasis === "cooked") {
      return g / selectedIngredient.cookedYieldFactor;
    }
    if (selectedIngredient.canonicalBasis === "cooked" && enteredBasis === "raw") {
      return g * selectedIngredient.cookedYieldFactor;
    }
    return g;
  };

  const calculateMacro = (per100: number) => {
    const val = (per100 * getNormalizedGrams()) / 100;
    return isNaN(val) ? 0 : Math.round(val);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;

    if (selectedIngredient) {
      const ingredientIdx = ingredients.findIndex((i: any) => i.name === selectedIngredient.name);
      const showToggle = selectedIngredient.supportsCookedToggle && selectedIngredient.cookedYieldFactor;
      const normGrams = Math.round(getNormalizedGrams());
      createEntry({
        userId: user.id,
        date,
        name: selectedIngredient.name,
        grams: parseInt(grams) || 100,
        calories: calculateMacro(selectedIngredient.calories_per_100g),
        protein: calculateMacro(selectedIngredient.protein_g_per_100g),
        carbs: calculateMacro(selectedIngredient.carbs_g_per_100g),
        fat: calculateMacro(selectedIngredient.fat_g_per_100g),
        fibre: calculateMacro(selectedIngredient.fibre_g_per_100g || 0),
        meal: selectedMeal,
        snackIndex: snackIdx,
        sourceType: "ingredient",
        ingredientIndex: ingredientIdx >= 0 ? ingredientIdx : null,
        macroSource: "ingredient",
        microSource: ingredientIdx >= 0 ? "ingredient" : "none",
        enteredBasis: showToggle ? enteredBasis : null,
        normalizedGrams: showToggle ? normGrams : null,
        yieldFactorUsed: showToggle ? selectedIngredient.cookedYieldFactor : null,
      }, {
        onSuccess: () => {
          showJustAdded(selectedIngredient.name);
          setSearchTerm("");
          setSelectedIngredient(null);
          setGrams("100");
          setEnteredBasis("cooked");
          setUnitMode("grams");
          setUnitCount(1);
          setUnitSize("medium");
        }
      });
    } else if (searchTerm) {
      createEntry({
        userId: user.id,
        date,
        name: searchTerm,
        grams: parseInt(grams) || 100,
        calories: parseInt(customMacros.calories) || 0,
        protein: parseInt(customMacros.protein) || 0,
        carbs: parseInt(customMacros.carbs) || 0,
        fat: parseInt(customMacros.fat) || 0,
        fibre: parseInt(customMacros.fibre) || 0,
        meal: selectedMeal,
        snackIndex: snackIdx,
      }, {
        onSuccess: () => {
          showJustAdded(searchTerm);
          setSearchTerm("");
          setCustomMacros({ calories: "", protein: "", carbs: "", fat: "", fibre: "" });
          setGrams("100");
        }
      });
    }
  };

  const { data: ingredients = [] } = useQuery({
    queryKey: ["/api/ingredients"],
    queryFn: async () => {
      const res = await fetch("/api/ingredients", { credentials: "include", cache: "no-store" });
      if (!res.ok) throw new Error("Failed to fetch ingredients");
      return res.json();
    }
  });

  const filteredIngredients = searchTerm.length > 1
    ? (() => {
        const lc = searchTerm.toLowerCase();
        return (ingredients as any[])
          .filter((i) => i.name.toLowerCase().includes(lc))
          .map((i) => {
            const name = i.name.toLowerCase();
            let score = 0;
            if (name === lc) score = 3;
            else if (name.startsWith(lc)) score = 2;
            else score = 1;
            return { i, score };
          })
          .sort((a, b) => b.score - a.score || (b.i.commonScore ?? 0) - (a.i.commonScore ?? 0))
          .map((x) => x.i);
      })()
    : [];

  const handleSelect = (ingredient: any) => {
    setSelectedIngredient(ingredient);
    setSearchTerm(ingredient.name);
    if (ingredient.supportsCookedToggle) {
      setEnteredBasis("cooked");
    }
    const unit = getCoreFoodUnit(ingredient.name);
    if (unit) {
      const defaultSize: UnitSize = unit.defaultSize ?? "medium";
      const defaultCount = unit.defaultCount;
      setUnitMode("count");
      setUnitCount(defaultCount);
      setUnitSize(defaultSize);
      setGrams(String(computeUnitGrams(unit, defaultCount, defaultSize)));
    } else {
      setUnitMode("grams");
      setUnitCount(1);
      setUnitSize("medium");
      setGrams("100");
    }
  };

  const quickAmounts = ["50", "100", "150", "200"];

  return (
    <>
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={isPrimary ? "default" : "outline"} data-testid="button-add-food">
          <Utensils className="mr-2 h-4 w-4" />
          Add Food
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] flex flex-col max-h-[90vh] p-0 overflow-visible">
        <DialogHeader className="p-6 pb-0">
          <div className="flex items-center justify-between">
            <DialogTitle className="font-display">Add Food</DialogTitle>
            <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground" onClick={() => setOpen(false)} data-testid="button-done-adding">
              Done
            </Button>
          </div>
          <DialogDescription className="sr-only">Log a food item by searching ingredients, scanning a barcode, or entering custom macros.</DialogDescription>
          {justAdded && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-1.5 text-xs text-emerald-500 font-medium mt-1"
              data-testid="text-just-added"
            >
              <Check className="h-3 w-3" />
              <span>{justAdded} added</span>
            </motion.div>
          )}
        </DialogHeader>
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="px-6 pt-4 pb-2 space-y-3 shrink-0 border-b">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Add to meal</Label>
              <div className="flex gap-2">
                <Select value={selectedMeal} onValueChange={(v) => {
                  setSelectedMeal(v as MealType);
                  if (v !== "snack") setSelectedSnackIndex(null);
                }}>
                  <SelectTrigger className="w-[140px]" data-testid="select-meal">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast"><div className="flex items-center gap-2"><Coffee className="h-3.5 w-3.5" /> Breakfast</div></SelectItem>
                    <SelectItem value="lunch"><div className="flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Lunch</div></SelectItem>
                    <SelectItem value="dinner"><div className="flex items-center gap-2"><Moon className="h-3.5 w-3.5" /> Dinner</div></SelectItem>
                    <SelectItem value="snack"><div className="flex items-center gap-2"><Cookie className="h-3.5 w-3.5" /> Snack</div></SelectItem>
                  </SelectContent>
                </Select>
                {selectedMeal === "snack" && (
                  <Select 
                    value={selectedSnackIndex !== null ? selectedSnackIndex.toString() : "new"}
                    onValueChange={(v) => setSelectedSnackIndex(v === "new" ? null : parseInt(v))}
                  >
                    <SelectTrigger className="w-[120px]" data-testid="select-snack-index">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New Snack #{nextSnackIndex}</SelectItem>
                      {uniqueSnackIndices.map(idx => (
                        <SelectItem key={idx} value={idx.toString()}>Snack #{idx}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
          </div>
          <Tabs defaultValue="whole" className="w-full flex-1 flex flex-col overflow-hidden">
            <div className="px-6 pt-2 shrink-0">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="search" data-testid="tab-search">Search</TabsTrigger>
                <TabsTrigger value="whole">Whole Food</TabsTrigger>
                <TabsTrigger value="barcode">Barcode</TabsTrigger>
                <TabsTrigger value="custom">Custom</TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-y-auto px-6">
              <TabsContent value="search" className="space-y-4 py-4 mt-0">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search foods (e.g. chicken breast, rice, protein bar)"
                    className="pl-10"
                    value={offSearchQuery}
                    onChange={(e) => handleOffSearch(e.target.value)}
                    data-testid="input-off-search"
                  />
                </div>

                {selectedOffFood ? (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-4"
                  >
                    <div className="flex gap-3 items-start">
                      {selectedOffFood.image ? (
                        <div className="h-14 w-14 rounded-md overflow-hidden border bg-muted shrink-0">
                          <img src={selectedOffFood.image} alt={selectedOffFood.name} className="h-full w-full object-cover" />
                        </div>
                      ) : (
                        <div className="h-14 w-14 rounded-md border bg-muted shrink-0 flex items-center justify-center">
                          <UtensilsCrossed className="h-5 w-5 text-muted-foreground" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm truncate">{selectedOffFood.name}</p>
                        {selectedOffFood.brand && (
                          <p className="text-xs text-muted-foreground truncate">{selectedOffFood.brand}</p>
                        )}
                        <button
                          type="button"
                          className="text-[10px] text-primary underline mt-0.5"
                          onClick={() => { setSelectedOffFood(null); setOffSearchQuery(""); setOffMappingIngredient(null); setOffSuggestions(null); setOffSkipMicros(false); }}
                          data-testid="button-off-change"
                        >
                          Change selection
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="off-grams" className="text-xs">Amount (grams)</Label>
                      <Input
                        id="off-grams"
                        type="number"
                        value={offGrams}
                        onChange={(e) => setOffGrams(e.target.value)}
                        className="h-8 text-sm"
                        data-testid="input-off-grams"
                      />
                      <div className="flex gap-1 justify-center pt-1">
                        {["50", "100", "150", "200"].map(amt => (
                          <Button
                            key={amt}
                            type="button"
                            variant="outline"
                            size="sm"
                            className="px-2 h-7 text-[10px]"
                            onClick={() => setOffGrams(amt)}
                            data-testid={`button-off-grams-${amt}`}
                          >
                            {amt}g
                          </Button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-secondary/30 rounded-lg space-y-2" data-testid="section-off-nutrition">
                      <div className="flex justify-between items-center border-b border-border pb-2">
                        <span className="text-sm font-medium text-muted-foreground">Nutrition per {offGrams}g</span>
                        <span className="text-lg font-bold text-primary" data-testid="text-off-kcal">{calculateOffMacro(selectedOffFood.calories)} kcal</span>
                      </div>
                      <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                        <div>
                          <div className="text-[10px] text-muted-foreground font-bold">Prot</div>
                          <div className="font-mono text-sm" data-testid="text-off-protein">{calculateOffMacro(selectedOffFood.protein)}g</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground font-bold">Carb</div>
                          <div className="font-mono text-sm" data-testid="text-off-carbs">{calculateOffMacro(selectedOffFood.carbs)}g</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground font-bold">Fat</div>
                          <div className="font-mono text-sm" data-testid="text-off-fat">{calculateOffMacro(selectedOffFood.fat)}g</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground font-bold text-emerald-500">Fib</div>
                          <div className="font-mono text-sm text-emerald-600" data-testid="text-off-fibre">{calculateOffMacro(selectedOffFood.fibre || 0)}g</div>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-muted/30 rounded-lg space-y-2 border" data-testid="section-off-micro-mapping">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-muted-foreground">Micros Source (for AMQS)</span>
                        {offMappingIngredient && !offSkipMicros && (
                          <button
                            type="button"
                            className="text-[10px] text-primary underline"
                            onClick={() => {
                              setOffMappingIngredient(null);
                              setOffMappingSearch("");
                            }}
                            data-testid="button-off-change-mapping"
                          >
                            Change
                          </button>
                        )}
                      </div>

                      {offMappingIngredient && !offSkipMicros ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-sm text-emerald-600">
                            <Check className="h-3.5 w-3.5" />
                            <span>Mapped to: <strong>{offMappingIngredient.name}</strong></span>
                          </div>
                          {offSuggestions?.best?.confidence === "high" && (
                            <span className="text-[10px] text-muted-foreground">Mapped automatically</span>
                          )}
                        </div>
                      ) : offSkipMicros ? (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground italic">Skipped (macros only)</span>
                          <button
                            type="button"
                            className="text-[10px] text-primary underline"
                            onClick={() => setOffSkipMicros(false)}
                          >
                            Enable micros
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {offSuggestions?.best && (
                            <div className="space-y-1">
                              {offSuggestions.best.confidence === "medium" && (
                                <span className="text-[10px] text-amber-500">Suggested match — tap to confirm or change</span>
                              )}
                              {offSuggestions.best.confidence === "low" && (
                                <span className="text-[10px] text-muted-foreground">No reliable match — please choose</span>
                              )}
                            </div>
                          )}
                          {!offSuggestions?.best && (
                            <span className="text-[10px] text-muted-foreground">No match found — search or skip</span>
                          )}

                          {offSuggestions?.top && offSuggestions.top.length > 0 && (
                            <div className="space-y-1">
                              <span className="text-[10px] text-muted-foreground">Suggested matches:</span>
                              <div className="flex flex-wrap gap-1">
                                {offSuggestions.top.slice(0, 3).map((s: any, idx: number) => (
                                  <div key={idx} className="flex flex-col items-start">
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      className={`h-6 text-[10px] px-2 ${s.confidence === "high" ? "border-emerald-500/50" : s.confidence === "medium" ? "border-amber-500/50" : ""}`}
                                      onClick={() => saveOffMapping(ingredients[s.ingredientIndex], s.ingredientIndex)}
                                      data-testid={`button-off-suggestion-${idx}`}
                                    >
                                      {s.ingredientName}
                                    </Button>
                                    {s.reasons && s.reasons.length > 0 && (s.confidence === "medium" || s.confidence === "low") && (
                                      <span className="text-[9px] text-muted-foreground mt-0.5 pl-1">
                                        {s.reasons.slice(0, 2).join("; ")}
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="relative">
                            <Input
                              placeholder="Search ingredients..."
                              value={offMappingSearch}
                              onChange={(e) => setOffMappingSearch(e.target.value)}
                              className="h-7 text-xs"
                              data-testid="input-off-mapping-search"
                            />
                            {offMappingSearch.length > 1 && (
                              <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-[150px] overflow-auto">
                                {ingredients
                                  .map((ing: any, idx: number) => ({ ...ing, index: idx }))
                                  .filter((ing: any) => ing.name.toLowerCase().includes(offMappingSearch.toLowerCase()))
                                  .slice(0, 10)
                                  .map((ing: any) => (
                                    <button
                                      key={ing.index}
                                      type="button"
                                      className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent transition-colors border-b last:border-0"
                                      onClick={() => saveOffMapping(ing, ing.index)}
                                    >
                                      {ing.name}
                                    </button>
                                  ))}
                                {ingredients.filter((ing: any) => ing.name.toLowerCase().includes(offMappingSearch.toLowerCase())).length === 0 && (
                                  <div className="px-3 py-2 text-xs text-muted-foreground">No matches found</div>
                                )}
                              </div>
                            )}
                          </div>

                          <button
                            type="button"
                            className="text-[10px] text-muted-foreground underline"
                            onClick={() => setOffSkipMicros(true)}
                            data-testid="button-off-skip-micros"
                          >
                            Skip micros (track macros only)
                          </button>
                        </div>
                      )}
                    </div>

                    <Button onClick={handleOffFoodSubmit} disabled={isPending} className="w-full" data-testid="button-off-add-to-log">
                      {isPending ? "Adding..." : "Add to Log"}
                    </Button>
                  </motion.div>
                ) : (
                  <div className="space-y-1">
                    {isSearching && (
                      <div className="flex items-center justify-center py-6">
                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                        <span className="ml-2 text-sm text-muted-foreground">Searching...</span>
                      </div>
                    )}

                    {!isSearching && offSearchQuery.length >= 2 && offSearchResults.length === 0 && (
                      <div className="text-center py-6">
                        <p className="text-sm text-muted-foreground">No results found</p>
                        <p className="text-xs text-muted-foreground mt-1">Try a different search term or use Barcode/Custom tabs</p>
                      </div>
                    )}

                    {!isSearching && offSearchResults.length > 0 && (
                      <div className="space-y-1" data-testid="list-off-results">
                        {offSearchResults.map((food, idx) => (
                          <button
                            key={`${food.barcode || idx}-${idx}`}
                            type="button"
                            className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-accent transition-colors text-left border-b last:border-0"
                            onClick={() => handleSelectOffFood(food)}
                            data-testid={`button-off-result-${idx}`}
                          >
                            {food.image ? (
                              <div className="h-10 w-10 rounded overflow-hidden border bg-muted shrink-0">
                                <img src={food.image} alt="" className="h-full w-full object-cover" loading="lazy" />
                              </div>
                            ) : (
                              <div className="h-10 w-10 rounded border bg-muted shrink-0 flex items-center justify-center">
                                <UtensilsCrossed className="h-4 w-4 text-muted-foreground" />
                              </div>
                            )}
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium truncate">{food.name}</p>
                              {food.brand && <p className="text-[10px] text-muted-foreground truncate">{food.brand}</p>}
                            </div>
                            <div className="text-right shrink-0">
                              <div className="text-sm font-mono font-medium">{food.calories}<span className="text-[10px] text-muted-foreground ml-0.5">kcal</span></div>
                              <div className="text-[10px] text-muted-foreground">P{food.protein} C{food.carbs} F{food.fat}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {offSearchQuery.length < 2 && !isSearching && (
                      <div className="text-center py-6 space-y-2">
                        <Search className="h-8 w-8 text-muted-foreground/30 mx-auto" />
                        <p className="text-xs text-muted-foreground">Search the Open Food Facts database</p>
                        <p className="text-[10px] text-muted-foreground">Type at least 2 characters to search</p>
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="whole" className="space-y-6 py-4 mt-0">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <Label htmlFor="search">Search Ingredient</Label>
                <div className="relative mt-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="search" 
                    placeholder="Start typing (e.g. Chicken)..."
                    className="pl-10"
                    value={searchTerm} 
                    onChange={e => {
                      setSearchTerm(e.target.value);
                      if (selectedIngredient && e.target.value !== selectedIngredient.name) {
                        setSelectedIngredient(null);
                      }
                    }}
                  />
                </div>
                {filteredIngredients.length > 0 && !selectedIngredient && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-[200px] overflow-auto">
                    {filteredIngredients.map((i: any) => (
                      <button
                        key={i.name}
                        type="button"
                        className="w-full text-left px-4 py-2 text-sm hover:bg-accent transition-colors border-b last:border-0"
                        onClick={() => handleSelect(i)}
                      >
                        {i.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {selectedIngredient && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-4"
                >
                  {/* Count/Size mode for supported core foods */}
                  {(() => {
                    const unit = selectedIngredient ? getCoreFoodUnit(selectedIngredient.name) : null;
                    return unit ? (
                      <div className="space-y-3">
                        {/* Mode toggle */}
                        <div className="flex items-center justify-between">
                          <Label className="text-sm">Amount</Label>
                          <div className="flex items-center rounded-md border overflow-hidden" data-testid="toggle-unit-mode">
                            <button
                              type="button"
                              className={`px-3 py-1 text-xs font-medium transition-colors ${unitMode === "count" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                              onClick={() => setUnitMode("count")}
                              data-testid="button-mode-count"
                            >
                              Count
                            </button>
                            <button
                              type="button"
                              className={`px-3 py-1 text-xs font-medium transition-colors ${unitMode === "grams" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                              onClick={() => setUnitMode("grams")}
                              data-testid="button-mode-grams"
                            >
                              Grams
                            </button>
                          </div>
                        </div>

                        {unitMode === "count" ? (
                          <div className="space-y-3">
                            {/* Size selector */}
                            {unit.supportsSize && (
                              <div>
                                <Label className="text-xs text-muted-foreground mb-1.5 block">Size</Label>
                                <div className="flex gap-2" data-testid="group-unit-size">
                                  {(["small", "medium", "large"] as UnitSize[]).map((s) => (
                                    <button
                                      key={s}
                                      type="button"
                                      data-testid={`button-size-${s}`}
                                      className={`flex-1 py-1.5 rounded-md border text-xs font-medium capitalize transition-colors ${
                                        unitSize === s
                                          ? "border-primary bg-primary/10 text-foreground"
                                          : "border-border/40 text-muted-foreground hover:bg-secondary/30"
                                      }`}
                                      onClick={() => {
                                        setUnitSize(s);
                                        setGrams(String(computeUnitGrams(unit, unitCount, s)));
                                      }}
                                    >
                                      {s.charAt(0).toUpperCase() + s.slice(1)}
                                      {unit.gramsBySize && (
                                        <span className="block text-[10px] font-normal text-muted-foreground">
                                          {unit.gramsBySize[s]}g
                                        </span>
                                      )}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Count stepper */}
                            <div>
                              <Label className="text-xs text-muted-foreground mb-1.5 block">
                                {unit.unitLabel.charAt(0).toUpperCase() + unit.unitLabel.slice(1)}s
                              </Label>
                              <div className="flex items-center gap-3" data-testid="group-unit-count">
                                <button
                                  type="button"
                                  data-testid="button-count-minus"
                                  className="h-9 w-9 rounded-md border border-border/60 flex items-center justify-center text-lg font-bold text-muted-foreground hover:bg-secondary/30 transition-colors disabled:opacity-30"
                                  disabled={unitCount <= 1}
                                  onClick={() => {
                                    const next = Math.max(1, unitCount - 1);
                                    setUnitCount(next);
                                    setGrams(String(computeUnitGrams(unit, next, unitSize)));
                                  }}
                                >
                                  −
                                </button>
                                <span className="text-2xl font-extrabold font-mono w-8 text-center" data-testid="text-unit-count">{unitCount}</span>
                                <button
                                  type="button"
                                  data-testid="button-count-plus"
                                  className="h-9 w-9 rounded-md border border-border/60 flex items-center justify-center text-lg font-bold text-muted-foreground hover:bg-secondary/30 transition-colors disabled:opacity-30"
                                  disabled={unitCount >= 20}
                                  onClick={() => {
                                    const next = Math.min(20, unitCount + 1);
                                    setUnitCount(next);
                                    setGrams(String(computeUnitGrams(unit, next, unitSize)));
                                  }}
                                >
                                  +
                                </button>
                                <span className="text-xs text-muted-foreground">≈ {grams}g total</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          /* Grams fallback */
                          <div className="space-y-2">
                            <div className="flex gap-2">
                              <Input
                                id="grams"
                                type="number"
                                value={grams}
                                onChange={e => setGrams(e.target.value)}
                                className="flex-1"
                                data-testid="input-grams"
                              />
                              <div className="flex gap-1">
                                {quickAmounts.map(amount => (
                                  <Button
                                    key={amount}
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    className="px-2 h-9 text-xs"
                                    onClick={() => setGrams(amount)}
                                  >
                                    {amount}g
                                  </Button>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      /* Standard grams input for non-unit foods */
                      <div className="space-y-2">
                        <div className="flex items-center justify-between flex-wrap gap-1">
                          <Label htmlFor="grams">Amount (grams){selectedIngredient?.supportsCookedToggle ? ` \u2014 ${enteredBasis === "cooked" ? "Cooked" : "Raw"}` : ""}</Label>
                          {selectedIngredient?.supportsCookedToggle && (
                            <div className="flex items-center rounded-md border overflow-visible" data-testid="toggle-basis">
                              <button
                                type="button"
                                className={`px-3 py-1 text-xs font-medium transition-colors ${enteredBasis === "raw" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                                onClick={() => setEnteredBasis("raw")}
                                data-testid="button-basis-raw"
                              >
                                Raw
                              </button>
                              <button
                                type="button"
                                className={`px-3 py-1 text-xs font-medium transition-colors ${enteredBasis === "cooked" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                                onClick={() => setEnteredBasis("cooked")}
                                data-testid="button-basis-cooked"
                              >
                                Cooked
                              </button>
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Input
                            id="grams"
                            type="number"
                            value={grams}
                            onChange={e => setGrams(e.target.value)}
                            className="flex-1"
                            data-testid="input-grams"
                          />
                          <div className="flex gap-1">
                            {quickAmounts.map(amount => (
                              <Button
                                key={amount}
                                type="button"
                                variant="outline"
                                size="sm"
                                className="px-2 h-9 text-xs"
                                onClick={() => setGrams(amount)}
                              >
                                {amount}g
                              </Button>
                            ))}
                          </div>
                        </div>
                        {selectedIngredient?.supportsCookedToggle && enteredBasis !== selectedIngredient.canonicalBasis && (
                          <p className="text-[10px] text-muted-foreground">
                            Nutrition calculated from {Math.round(getNormalizedGrams())}g {selectedIngredient.canonicalBasis} equivalent (yield factor: {selectedIngredient.cookedYieldFactor})
                          </p>
                        )}
                      </div>
                    );
                  })()}

                  <div className="p-4 bg-secondary/30 rounded-lg space-y-2">
                    <div className="flex justify-between items-center border-b border-border pb-2">
                      <span className="text-sm font-medium">Estimated Nutrition</span>
                      <span className="text-lg font-bold text-primary">{calculateMacro(selectedIngredient.calories_per_100g)} kcal</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Prot</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.protein_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Carb</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.carbs_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Fat</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.fat_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold text-emerald-500">Fib</div>
                        <div className="font-mono text-sm text-emerald-600">{calculateMacro(selectedIngredient.fibre_g_per_100g || 0)}g</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

                  <div className="pt-2 pb-6 flex justify-end">
                    <Button type="submit" disabled={isPending || !selectedIngredient} className="w-full sm:w-auto">
                      {isPending ? "Logging..." : "Add Food"}
                    </Button>
                  </div>
                </form>

                {!selectedIngredient && !searchTerm && (
                  <div className="space-y-3 pt-2 pb-6">
                    <div>
                      <h4 className="text-sm font-semibold text-foreground">Core Foods</h4>
                      <p className="text-xs text-muted-foreground">Typical values for common meals. Tap to log, edit serving if needed.</p>
                    </div>
                    <div className="space-y-1">
                      {CORE_FOODS.map((cf) => (
                        <button
                          key={cf.name}
                          type="button"
                          data-testid={`button-core-food-${cf.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                          className="w-full text-left px-3 py-2.5 rounded-md border bg-secondary/30 hover-elevate transition-colors flex items-center justify-between gap-2"
                          onClick={() => {
                            if (!user) return;
                            createEntry({
                              userId: user.id,
                              date,
                              name: cf.name,
                              grams: cf.serving,
                              calories: cf.calories,
                              protein: cf.protein,
                              carbs: cf.carbs,
                              fat: cf.fat,
                              fibre: cf.fibre,
                              meal: selectedMeal,
                              snackIndex: selectedMeal === "snack" ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex) : null,
                              sourceType: "manual",
                              macroSource: "manual",
                              microSource: "none",
                            }, {
                              onSuccess: () => showJustAdded(cf.name),
                            });
                          }}
                        >
                          <div className="min-w-0">
                            <span className="text-sm font-medium truncate block">{cf.name}</span>
                            <span className="text-xs text-muted-foreground">{cf.serving}g serving</span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-sm font-mono font-medium">{cf.calories}</span>
                            <span className="text-xs text-muted-foreground ml-1">kcal</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="barcode" className="space-y-4 py-4 mt-0">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="barcode">Barcode</Label>
                <div className="flex gap-2">
                  <Input 
                    id="barcode" 
                    placeholder="Enter barcode manually" 
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    data-testid="input-barcode"
                  />
                  <Button 
                    variant="default" 
                    onClick={handleBarcodeLookup} 
                    disabled={isLookingUp || !barcode}
                    data-testid="button-barcode-lookup"
                  >
                    {isLookingUp ? "..." : "Lookup"}
                  </Button>
                </div>
                {barcodeError && (
                  <div className="mt-1 space-y-1">
                    <p className="text-xs text-destructive" data-testid="text-barcode-error">
                      {barcodeError}
                    </p>
                    {showBarcodeCreateForm ? (
                      <div className="space-y-3 p-3 rounded-md border bg-muted/30" data-testid="form-barcode-create">
                        <p className="text-xs text-muted-foreground">Add this food to the PRFMR database so it shows up next time.</p>
                        <div className="space-y-2">
                          <Input
                            placeholder="Food name (required)"
                            value={barcodeCreateData.name}
                            onChange={e => setBarcodeCreateData(prev => ({ ...prev, name: e.target.value }))}
                            data-testid="input-barcode-food-name"
                          />
                          <Input
                            placeholder="Brand (optional)"
                            value={barcodeCreateData.brand}
                            onChange={e => setBarcodeCreateData(prev => ({ ...prev, brand: e.target.value }))}
                            data-testid="input-barcode-food-brand"
                          />
                          <p className="text-xs font-medium text-muted-foreground">Nutrition per 100g</p>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <Label className="text-xs">kcal</Label>
                              <Input
                                type="number" min="0"
                                value={barcodeCreateData.kcal}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, kcal: e.target.value }))}
                                data-testid="input-barcode-food-kcal"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Protein (g)</Label>
                              <Input
                                type="number" min="0"
                                value={barcodeCreateData.protein}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, protein: e.target.value }))}
                                data-testid="input-barcode-food-protein"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Carbs (g)</Label>
                              <Input
                                type="number" min="0"
                                value={barcodeCreateData.carbs}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, carbs: e.target.value }))}
                                data-testid="input-barcode-food-carbs"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Fat (g)</Label>
                              <Input
                                type="number" min="0"
                                value={barcodeCreateData.fat}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, fat: e.target.value }))}
                                data-testid="input-barcode-food-fat"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Fibre (g)</Label>
                              <Input
                                type="number" min="0"
                                value={barcodeCreateData.fibre}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, fibre: e.target.value }))}
                                data-testid="input-barcode-food-fibre"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Serving (g)</Label>
                              <Input
                                type="number" min="1"
                                placeholder="optional"
                                value={barcodeCreateData.servingSizeG}
                                onChange={e => setBarcodeCreateData(prev => ({ ...prev, servingSizeG: e.target.value }))}
                                data-testid="input-barcode-food-serving"
                              />
                            </div>
                          </div>
                        </div>
                        <Button
                          type="button"
                          className="w-full"
                          disabled={!barcodeCreateData.name.trim() || isCreatingBarcodeFood}
                          onClick={async () => {
                            setIsCreatingBarcodeFood(true);
                            try {
                              const codeToUse = barcode;
                              const res = await fetch(`/api/food/barcode/${codeToUse}/create`, {
                                credentials: "include",
                                cache: "no-store",
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                  name: barcodeCreateData.name.trim(),
                                  brand: barcodeCreateData.brand.trim() || undefined,
                                  kcal: Number(barcodeCreateData.kcal) || 0,
                                  protein: Number(barcodeCreateData.protein) || 0,
                                  carbs: Number(barcodeCreateData.carbs) || 0,
                                  fat: Number(barcodeCreateData.fat) || 0,
                                  fibre: Number(barcodeCreateData.fibre) || 0,
                                  servingSizeG: barcodeCreateData.servingSizeG ? Number(barcodeCreateData.servingSizeG) : undefined,
                                }),
                              });
                              if (!res.ok) {
                                const err = await res.json();
                                setBarcodeError(err.error || "Failed to save");
                                return;
                              }
                              setShowBarcodeCreateForm(false);
                              setBarcodeError("");
                              queryClient.invalidateQueries({ queryKey: ["/api/foods/custom"] });
                              handleBarcodeLookupWithCode(codeToUse);
                            } catch {
                              setBarcodeError("Network error saving food.");
                            } finally {
                              setIsCreatingBarcodeFood(false);
                            }
                          }}
                          data-testid="button-save-to-prfmr"
                        >
                          {isCreatingBarcodeFood ? "Saving..." : "Save to PRFMR database"}
                        </Button>
                      </div>
                    ) : (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => {
                          setNewFoodData(prev => ({
                            ...prev,
                            barcode: barcode || "",
                          }));
                          setShowCreateFoodDialog(true);
                        }}
                        data-testid="button-add-to-my-foods"
                      >
                        <Plus className="h-3 w-3 mr-1" />
                        Add to My Foods
                      </Button>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-3">
                {scannerUnavailableReason ? (
                  <div className="p-3 rounded-lg bg-muted/50 border border-muted">
                    <p className="text-xs text-muted-foreground text-center">
                      {scannerUnavailableReason}
                    </p>
                    <p className="text-xs text-muted-foreground text-center mt-1">
                      Enter the barcode manually above.
                    </p>
                  </div>
                ) : isScanning ? (
                  <Button 
                    variant="destructive" 
                    className="w-full min-h-10" 
                    onClick={() => stopScan()}
                    data-testid="button-stop-scan"
                  >
                    Stop Scan
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    className="w-full min-h-10" 
                    onClick={startScan}
                    data-testid="button-start-scan"
                  >
                    Scan Barcode
                  </Button>
                )}
                <div 
                  id="reader" 
                  ref={readerRef}
                  className={isScanning ? "block w-full overflow-hidden rounded-lg border bg-black min-h-[200px]" : "hidden"} 
                />
                {isScanning && (
                  <p className="text-[10px] text-center text-muted-foreground animate-pulse">
                    Position barcode within the frame
                  </p>
                )}
                
                <button
                  type="button"
                  onClick={() => {
                    setShowScannerDebug(!showScannerDebug);
                    gatherDebugInfo(debugInfo?.lastError || "");
                  }}
                  className="text-[10px] text-muted-foreground underline hover:text-foreground mt-2"
                  data-testid="button-scanner-debug"
                >
                  {showScannerDebug ? "Hide" : "Show"} Scanner Debug
                </button>
                
                {showScannerDebug && debugInfo && (
                  <div className="p-3 rounded-lg bg-muted/30 border text-[10px] font-mono space-y-1 mt-2">
                    <p>Secure: {debugInfo.secureContext ? "Yes" : "No"}</p>
                    <p>Origin: {debugInfo.origin}</p>
                    <p>MediaDevices: {debugInfo.hasMediaDevices ? "Yes" : "No"}</p>
                    <p>Cameras: {debugInfo.cameraCount}</p>
                    <p>Start calls: {debugInfo.startCount}</p>
                    {debugInfo.lastError && (
                      <p className="text-destructive break-all">Error: {debugInfo.lastError}</p>
                    )}
                    <p className="text-muted-foreground break-all">UA: {debugInfo.userAgent}</p>
                  </div>
                )}
              </div>

              {barcodeResult && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-4 pt-2 border-t"
                >
                  <div className="flex gap-4 items-start">
                    {barcodeResult.image_url && (
                      <div className="h-16 w-16 rounded-md overflow-hidden border bg-muted shrink-0">
                        <img 
                          src={barcodeResult.image_url} 
                          alt={barcodeResult.name} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    <div className="space-y-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{barcodeResult.name}</p>
                      <Label htmlFor="barcode-grams" className="text-xs">Amount (grams)</Label>
                      <div className="flex gap-2">
                        <Input 
                          id="barcode-grams" 
                          type="number" 
                          value={grams} 
                          onChange={e => setGrams(e.target.value)}
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-1 justify-center">
                    {quickAmounts.map(amount => (
                      <Button 
                        key={amount}
                        type="button"
                        variant="outline"
                        size="sm"
                        className="px-2 h-7 text-[10px]"
                        onClick={() => setGrams(amount)}
                      >
                        {amount}g
                      </Button>
                    ))}
                  </div>

                  <div className="p-4 bg-secondary/30 rounded-lg space-y-2" data-testid="section-barcode-nutrition">
                    <div className="flex justify-between items-center border-b border-border pb-2">
                      <span className="text-sm font-medium text-muted-foreground">Nutrition per {grams}g</span>
                      <span className="text-lg font-bold text-primary" data-testid="text-barcode-kcal">{calculateMacro(barcodeResult.calories_kcal_100g)} kcal</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Prot</div>
                        <div className="font-mono text-sm" data-testid="text-barcode-protein">{calculateMacro(barcodeResult.protein_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Carb</div>
                        <div className="font-mono text-sm" data-testid="text-barcode-carbs">{calculateMacro(barcodeResult.carbs_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold">Fat</div>
                        <div className="font-mono text-sm" data-testid="text-barcode-fat">{calculateMacro(barcodeResult.fat_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold text-emerald-500">Fib</div>
                        <div className="font-mono text-sm text-emerald-600" data-testid="text-barcode-fibre">{calculateMacro(barcodeResult.fibre_g_100g || 0)}g</div>
                      </div>
                    </div>
                  </div>

                  {/* Ingredient Mapping for Micronutrients */}
                  <div className="p-3 bg-muted/30 rounded-lg space-y-2 border" data-testid="section-micro-mapping">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-muted-foreground">Micros Source (for AMQS)</span>
                      {selectedMappingIngredient && !skipMicros && (
                        <button
                          type="button"
                          className="text-[10px] text-primary underline"
                          onClick={() => {
                            setSelectedMappingIngredient(null);
                            setMappingSearchTerm("");
                          }}
                          data-testid="button-change-mapping"
                        >
                          Change
                        </button>
                      )}
                    </div>
                    
                    {selectedMappingIngredient && !skipMicros ? (
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-emerald-600">
                          <Check className="h-3.5 w-3.5" />
                          <span>Mapped to: <strong>{selectedMappingIngredient.name}</strong></span>
                        </div>
                        {barcodeResult.suggestions?.best?.confidence === "high" && !barcodeResult.mapping && (
                          <span className="text-[10px] text-muted-foreground" data-testid="text-mapping-hint">Mapped automatically</span>
                        )}
                      </div>
                    ) : skipMicros ? (
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground italic">Skipped (macros only)</span>
                        <button
                          type="button"
                          className="text-[10px] text-primary underline"
                          onClick={() => setSkipMicros(false)}
                        >
                          Enable micros
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {barcodeResult.suggestions?.best && (
                          <div className="space-y-1">
                            {barcodeResult.suggestions.best.confidence === "medium" && (
                              <span className="text-[10px] text-amber-500" data-testid="text-confidence-hint">
                                Suggested match — tap to confirm or change
                              </span>
                            )}
                            {barcodeResult.suggestions.best.confidence === "low" && (
                              <span className="text-[10px] text-muted-foreground" data-testid="text-confidence-hint">
                                No reliable match — please choose
                              </span>
                            )}
                          </div>
                        )}
                        {!barcodeResult.suggestions?.best && (
                          <span className="text-[10px] text-muted-foreground" data-testid="text-confidence-hint">
                            No match found — search or skip
                          </span>
                        )}

                        {barcodeResult.suggestions?.top && barcodeResult.suggestions.top.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[10px] text-muted-foreground">Suggested matches:</span>
                            <div className="flex flex-wrap gap-1">
                              {barcodeResult.suggestions.top.slice(0, 3).map((s: any, idx: number) => (
                                <div key={idx} className="flex flex-col items-start">
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    className={`h-6 text-[10px] px-2 ${s.confidence === "high" ? "border-emerald-500/50" : s.confidence === "medium" ? "border-amber-500/50" : ""}`}
                                    disabled={isSavingMapping}
                                    onClick={() => saveIngredientMapping(ingredients[s.ingredientIndex], s.ingredientIndex)}
                                    data-testid={`button-suggestion-${idx}`}
                                  >
                                    {s.ingredientName}
                                  </Button>
                                  {s.reasons && s.reasons.length > 0 && (s.confidence === "medium" || s.confidence === "low") && (
                                    <span className="text-[9px] text-muted-foreground mt-0.5 pl-1" data-testid={`text-suggestion-reason-${idx}`}>
                                      {s.reasons.slice(0, 2).join("; ")}
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* Search dropdown */}
                        <div className="relative">
                          <Input
                            placeholder="Search ingredients..."
                            value={mappingSearchTerm}
                            onChange={(e) => setMappingSearchTerm(e.target.value)}
                            className="h-7 text-xs"
                            data-testid="input-mapping-search"
                          />
                          {mappingSearchTerm.length > 1 && (
                            <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-[150px] overflow-auto">
                              {ingredients
                                .map((ing: any, idx: number) => ({ ...ing, index: idx }))
                                .filter((ing: any) => ing.name.toLowerCase().includes(mappingSearchTerm.toLowerCase()))
                                .slice(0, 10)
                                .map((ing: any) => (
                                  <button
                                    key={ing.index}
                                    type="button"
                                    className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent transition-colors border-b last:border-0"
                                    onClick={() => saveIngredientMapping(ing, ing.index)}
                                    disabled={isSavingMapping}
                                  >
                                    {ing.name}
                                  </button>
                                ))}
                              {ingredients.filter((ing: any) => ing.name.toLowerCase().includes(mappingSearchTerm.toLowerCase())).length === 0 && (
                                <div className="px-3 py-2 text-xs text-muted-foreground">No matches found</div>
                              )}
                            </div>
                          )}
                        </div>
                        
                        {/* Skip option */}
                        <button
                          type="button"
                          className="text-[10px] text-muted-foreground underline"
                          onClick={() => setSkipMicros(true)}
                          data-testid="button-skip-micros"
                        >
                          Skip micros (track macros only)
                        </button>
                      </div>
                    )}
                  </div>

                  <Button onClick={handleBarcodeSubmit} disabled={isPending || isSavingMapping} className="w-full" data-testid="button-add-to-log">
                    {isPending ? "Adding..." : "Add to Log"}
                  </Button>
                </motion.div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-6 py-4">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="custom-name">Food Name</Label>
                <Input 
                  id="custom-name" 
                  placeholder="Enter food name" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="p-4 bg-accent/5 border border-dashed rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="custom-grams" className="text-xs">Weight (g)</Label>
                    <Input 
                      id="custom-grams" 
                      type="number" 
                      value={grams} 
                      onChange={e => setGrams(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-calories" className="text-xs">Calories (kcal)</Label>
                    <Input 
                      id="custom-calories" 
                      type="number" 
                      value={customMacros.calories} 
                      onChange={e => setCustomMacros({...customMacros, calories: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-protein" className="text-xs">Protein (g)</Label>
                    <Input 
                      id="custom-protein" 
                      type="number" 
                      value={customMacros.protein} 
                      onChange={e => setCustomMacros({...customMacros, protein: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-carbs" className="text-xs">Carbs (g)</Label>
                    <Input 
                      id="custom-carbs" 
                      type="number" 
                      value={customMacros.carbs} 
                      onChange={e => setCustomMacros({...customMacros, carbs: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-fat" className="text-xs">Fat (g)</Label>
                    <Input 
                      id="custom-fat" 
                      type="number" 
                      value={customMacros.fat} 
                      onChange={e => setCustomMacros({...customMacros, fat: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-fibre" className="text-xs">Fibre (g)</Label>
                    <Input 
                      id="custom-fibre" 
                      type="number" 
                      value={customMacros.fibre} 
                      onChange={e => setCustomMacros({...customMacros, fibre: e.target.value})}
                    />
                  </div>
                </div>
              </div>

                  <div className="pt-2 pb-6 flex justify-end">
                    <Button type="submit" disabled={isPending || !searchTerm} className="w-full sm:w-auto">
                      {isPending ? "Logging..." : "Add Food"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
    
    {/* Create Custom Food Dialog */}
    <Dialog open={showCreateFoodDialog} onOpenChange={setShowCreateFoodDialog}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add to My Foods
          </DialogTitle>
          <DialogDescription>
            Save this food to your personal database for quick logging later.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="food-name">Food Name *</Label>
            <Input
              id="food-name"
              placeholder="e.g., Homemade Granola"
              value={newFoodData.name}
              onChange={e => setNewFoodData(prev => ({ ...prev, name: e.target.value }))}
              data-testid="input-food-name"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="food-brand">Brand (optional)</Label>
              <Input
                id="food-brand"
                placeholder="e.g., Homemade"
                value={newFoodData.brand}
                onChange={e => setNewFoodData(prev => ({ ...prev, brand: e.target.value }))}
                data-testid="input-food-brand"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="food-barcode">Barcode (optional)</Label>
              <Input
                id="food-barcode"
                placeholder="12345678"
                value={newFoodData.barcode}
                onChange={e => setNewFoodData(prev => ({ ...prev, barcode: e.target.value }))}
                data-testid="input-food-barcode"
              />
            </div>
          </div>
          
          <div className="pt-2 border-t">
            <p className="text-sm font-medium mb-3">Nutrition per 100g</p>
            <div className="grid grid-cols-5 gap-2">
              <div className="space-y-1">
                <Label htmlFor="food-kcal" className="text-xs">Calories *</Label>
                <Input
                  id="food-kcal"
                  type="number"
                  placeholder="0"
                  value={newFoodData.kcalPer100g}
                  onChange={e => setNewFoodData(prev => ({ ...prev, kcalPer100g: e.target.value }))}
                  className="h-9 text-sm"
                  data-testid="input-food-kcal"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="food-protein" className="text-xs">Protein</Label>
                <Input
                  id="food-protein"
                  type="number"
                  step="0.1"
                  placeholder="0"
                  value={newFoodData.proteinPer100g}
                  onChange={e => setNewFoodData(prev => ({ ...prev, proteinPer100g: e.target.value }))}
                  className="h-9 text-sm"
                  data-testid="input-food-protein"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="food-carbs" className="text-xs">Carbs</Label>
                <Input
                  id="food-carbs"
                  type="number"
                  step="0.1"
                  placeholder="0"
                  value={newFoodData.carbsPer100g}
                  onChange={e => setNewFoodData(prev => ({ ...prev, carbsPer100g: e.target.value }))}
                  className="h-9 text-sm"
                  data-testid="input-food-carbs"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="food-fat" className="text-xs">Fat</Label>
                <Input
                  id="food-fat"
                  type="number"
                  step="0.1"
                  placeholder="0"
                  value={newFoodData.fatPer100g}
                  onChange={e => setNewFoodData(prev => ({ ...prev, fatPer100g: e.target.value }))}
                  className="h-9 text-sm"
                  data-testid="input-food-fat"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="food-fibre" className="text-xs">Fibre</Label>
                <Input
                  id="food-fibre"
                  type="number"
                  step="0.1"
                  placeholder="0"
                  value={newFoodData.fibrePer100g}
                  onChange={e => setNewFoodData(prev => ({ ...prev, fibrePer100g: e.target.value }))}
                  className="h-9 text-sm"
                  data-testid="input-food-fibre"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowCreateFoodDialog(false)}
            data-testid="button-cancel-create-food"
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleCreateCustomFood}
            disabled={isCreatingFood || !newFoodData.name || !newFoodData.kcalPer100g}
            data-testid="button-save-food"
          >
            {isCreatingFood ? "Saving..." : "Save & Log"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
    </>
  );
}

function EditFoodDialog({ entry, existingEntries = [] }: { entry: any; existingEntries?: any[] }) {
  const [open, setOpen] = useState(false);
  const { mutate: updateEntry, isPending } = useUpdateFoodEntry();
  const [grams, setGrams] = useState(entry.grams.toString());
  const [calories, setCalories] = useState(entry.calories.toString());
  const [protein, setProtein] = useState(entry.protein.toString());
  const [carbs, setCarbs] = useState(entry.carbs.toString());
  const [fat, setFat] = useState(entry.fat.toString());
  const [fibre, setFibre] = useState((entry.fibre || 0).toString());
  const [selectedMeal, setSelectedMeal] = useState<MealType>(entry.meal || "lunch");
  const [selectedSnackIndex, setSelectedSnackIndex] = useState<number | null>(entry.snackIndex ?? null);

  // Count mode state (for foods with unit config)
  const unitConfig = getCoreFoodUnit(entry.name);
  const [editUnitMode, setEditUnitMode] = useState<"count" | "grams">(unitConfig ? "count" : "grams");
  const [editUnitCount, setEditUnitCount] = useState(unitConfig?.defaultCount ?? 1);
  const [editUnitSize, setEditUnitSize] = useState<UnitSize>(unitConfig?.defaultSize ?? "medium");

  // Store per-100g base values for auto-recalculation
  const basePer100g = useRef({
    calories: entry.grams > 0 ? entry.calories / entry.grams * 100 : entry.calories,
    protein: entry.grams > 0 ? entry.protein / entry.grams * 100 : entry.protein,
    carbs: entry.grams > 0 ? entry.carbs / entry.grams * 100 : entry.carbs,
    fat: entry.grams > 0 ? entry.fat / entry.grams * 100 : entry.fat,
    fibre: entry.grams > 0 ? (entry.fibre || 0) / entry.grams * 100 : (entry.fibre || 0),
  });

  // Calculate snack options
  const existingSnackIndices = existingEntries
    .filter(e => e.meal === "snack" && e.snackIndex !== null && e.id !== entry.id)
    .map(e => e.snackIndex as number);
  const maxSnackIndex = existingSnackIndices.length > 0 ? Math.max(...existingSnackIndices) : 0;
  const nextSnackIndex = Math.max(maxSnackIndex + 1, (entry.snackIndex ?? 0) + 1);
  const uniqueSnackIndices = Array.from(new Set([...existingSnackIndices, entry.snackIndex].filter(x => x !== null) as number[])).sort((a, b) => a - b);

  // Sync state when dialog opens or entry changes
  useEffect(() => {
    if (open) {
      setGrams(entry.grams.toString());
      setCalories(entry.calories.toString());
      setProtein(entry.protein.toString());
      setCarbs(entry.carbs.toString());
      setFat(entry.fat.toString());
      setFibre((entry.fibre || 0).toString());
      setSelectedMeal(entry.meal || "lunch");
      setSelectedSnackIndex(entry.snackIndex ?? null);
      const uc = getCoreFoodUnit(entry.name);
      setEditUnitMode(uc ? "count" : "grams");
      setEditUnitCount(uc?.defaultCount ?? 1);
      setEditUnitSize(uc?.defaultSize ?? "medium");
      // Recalculate base per-100g when dialog opens
      basePer100g.current = {
        calories: entry.grams > 0 ? entry.calories / entry.grams * 100 : entry.calories,
        protein: entry.grams > 0 ? entry.protein / entry.grams * 100 : entry.protein,
        carbs: entry.grams > 0 ? entry.carbs / entry.grams * 100 : entry.carbs,
        fat: entry.grams > 0 ? entry.fat / entry.grams * 100 : entry.fat,
        fibre: entry.grams > 0 ? (entry.fibre || 0) / entry.grams * 100 : (entry.fibre || 0),
      };
      console.log("[food][edit] Dialog opened for entry:", entry.id, entry.name, "basePer100g:", basePer100g.current);
    }
  }, [open, entry]);

  // Handle grams change - recalculate macros automatically
  const handleGramsChange = (newGramsValue: string) => {
    setGrams(newGramsValue);
    const newGrams = parseFloat(newGramsValue) || 0;
    if (newGrams > 0) {
      const base = basePer100g.current;
      const newCalories = Math.round(base.calories * newGrams / 100);
      const newProtein = Math.round(base.protein * newGrams / 100);
      const newCarbs = Math.round(base.carbs * newGrams / 100);
      const newFat = Math.round(base.fat * newGrams / 100);
      const newFibre = Math.round(base.fibre * newGrams / 100);
      console.log("[food][edit] Grams changed to", newGrams, "-> recalculated:", { newCalories, newProtein, newCarbs, newFat, newFibre });
      setCalories(newCalories.toString());
      setProtein(newProtein.toString());
      setCarbs(newCarbs.toString());
      setFat(newFat.toString());
      setFibre(newFibre.toString());
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;
    
    const payload = {
      id: entry.id,
      grams: parseInt(grams) || 100,
      calories: parseInt(calories) || 0,
      protein: parseInt(protein) || 0,
      carbs: parseInt(carbs) || 0,
      fat: parseInt(fat) || 0,
      fibre: parseInt(fibre) || 0,
      meal: selectedMeal,
      snackIndex: snackIdx,
    };
    console.log("[food][edit] Before mutation - payload:", payload);
    
    updateEntry(payload, {
      onSuccess: () => {
        console.log("[food][edit] After mutation success - entry updated");
        setOpen(false);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          size="icon" 
          variant="ghost" 
          className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
          data-testid={`button-edit-food-${entry.id}`}
        >
          <Pencil className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-display">Edit: {entry.name}</DialogTitle>
          <DialogDescription className="sr-only">Edit the macro values for this food entry.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Meal</Label>
            <div className="flex gap-2">
              <Select value={selectedMeal} onValueChange={(v) => {
                setSelectedMeal(v as MealType);
                if (v !== "snack") setSelectedSnackIndex(null);
              }}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast"><div className="flex items-center gap-2"><Coffee className="h-3.5 w-3.5" /> Breakfast</div></SelectItem>
                  <SelectItem value="lunch"><div className="flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Lunch</div></SelectItem>
                  <SelectItem value="dinner"><div className="flex items-center gap-2"><Moon className="h-3.5 w-3.5" /> Dinner</div></SelectItem>
                  <SelectItem value="snack"><div className="flex items-center gap-2"><Cookie className="h-3.5 w-3.5" /> Snack</div></SelectItem>
                </SelectContent>
              </Select>
              {selectedMeal === "snack" && (
                <Select 
                  value={selectedSnackIndex !== null ? selectedSnackIndex.toString() : "new"}
                  onValueChange={(v) => setSelectedSnackIndex(v === "new" ? null : parseInt(v))}
                >
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New Snack #{nextSnackIndex}</SelectItem>
                    {uniqueSnackIndices.map(idx => (
                      <SelectItem key={idx} value={idx.toString()}>Snack #{idx}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
          {/* Count mode for supported foods */}
          {unitConfig && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Amount</Label>
                <div className="flex items-center rounded-md border overflow-hidden" data-testid="toggle-edit-unit-mode">
                  <button type="button" onClick={() => setEditUnitMode("count")}
                    className={`px-3 py-1 text-xs font-medium transition-colors ${editUnitMode === "count" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                    data-testid="button-edit-mode-count">Count</button>
                  <button type="button" onClick={() => setEditUnitMode("grams")}
                    className={`px-3 py-1 text-xs font-medium transition-colors ${editUnitMode === "grams" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                    data-testid="button-edit-mode-grams">Grams</button>
                </div>
              </div>
              {editUnitMode === "count" && (
                <div className="space-y-3">
                  {unitConfig.supportsSize && (
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">Size</Label>
                      <div className="flex gap-2" data-testid="group-edit-unit-size">
                        {(["small", "medium", "large"] as UnitSize[]).map((s) => (
                          <button key={s} type="button" data-testid={`button-edit-size-${s}`}
                            className={`flex-1 py-1.5 rounded-md border text-xs font-medium capitalize transition-colors ${editUnitSize === s ? "border-primary bg-primary/10 text-foreground" : "border-border/40 text-muted-foreground hover:bg-secondary/30"}`}
                            onClick={() => {
                              setEditUnitSize(s);
                              const g = String(computeUnitGrams(unitConfig, editUnitCount, s));
                              handleGramsChange(g);
                            }}>
                            {s.charAt(0).toUpperCase() + s.slice(1)}
                            {unitConfig.gramsBySize && <span className="block text-[10px] font-normal text-muted-foreground">{unitConfig.gramsBySize[s]}g</span>}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <Label className="text-xs text-muted-foreground mb-1.5 block">
                      {unitConfig.unitLabel.charAt(0).toUpperCase() + unitConfig.unitLabel.slice(1)}s
                    </Label>
                    <div className="flex items-center gap-3" data-testid="group-edit-unit-count">
                      <button type="button" data-testid="button-edit-count-minus"
                        className="h-9 w-9 rounded-md border border-border/60 flex items-center justify-center text-lg font-bold text-muted-foreground hover:bg-secondary/30 transition-colors disabled:opacity-30"
                        disabled={editUnitCount <= 1}
                        onClick={() => {
                          const next = Math.max(1, editUnitCount - 1);
                          setEditUnitCount(next);
                          handleGramsChange(String(computeUnitGrams(unitConfig, next, editUnitSize)));
                        }}>−</button>
                      <span className="text-2xl font-extrabold font-mono w-8 text-center" data-testid="text-edit-unit-count">{editUnitCount}</span>
                      <button type="button" data-testid="button-edit-count-plus"
                        className="h-9 w-9 rounded-md border border-border/60 flex items-center justify-center text-lg font-bold text-muted-foreground hover:bg-secondary/30 transition-colors disabled:opacity-30"
                        disabled={editUnitCount >= 20}
                        onClick={() => {
                          const next = Math.min(20, editUnitCount + 1);
                          setEditUnitCount(next);
                          handleGramsChange(String(computeUnitGrams(unitConfig, next, editUnitSize)));
                        }}>+</button>
                      <span className="text-xs text-muted-foreground">≈ {grams}g total</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-grams">Grams</Label>
              <Input id="edit-grams" type="number" value={grams} onChange={(e) => handleGramsChange(e.target.value)} data-testid="input-edit-grams"
                className={unitConfig && editUnitMode === "count" ? "opacity-50" : ""} readOnly={unitConfig !== null && editUnitMode === "count"} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-calories">Calories</Label>
              <Input id="edit-calories" type="number" value={calories} onChange={(e) => setCalories(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-protein">Protein (g)</Label>
              <Input id="edit-protein" type="number" value={protein} onChange={(e) => setProtein(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-carbs">Carbs (g)</Label>
              <Input id="edit-carbs" type="number" value={carbs} onChange={(e) => setCarbs(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-fat">Fat (g)</Label>
              <Input id="edit-fat" type="number" value={fat} onChange={(e) => setFat(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-fibre">Fibre (g)</Label>
              <Input id="edit-fibre" type="number" value={fibre} onChange={(e) => setFibre(e.target.value)} />
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={isPending} data-testid="button-save-edit-food">
            {isPending ? "Saving..." : "Save Changes"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function CopyFoodDialog({ entry }: { entry: any }) {
  const [open, setOpen] = useState(false);
  const [toDate, setToDate] = useState(entry.date || "");
  const [toMeal, setToMeal] = useState<MealType>(entry.meal || "lunch");
  const { mutate: createEntry, isPending } = useCreateFoodEntry();
  const { toast } = useToast();

  const handleCopy = () => {
    if (!toDate) return;
    createEntry({
      userId: entry.userId,
      name: entry.name,
      date: toDate,
      grams: entry.grams,
      calories: entry.calories,
      protein: entry.protein,
      carbs: entry.carbs,
      fat: entry.fat,
      fibre: entry.fibre ?? 0,
      meal: toMeal,
      snackIndex: toMeal === "snack" ? 1 : null,
      sourceType: entry.sourceType || "manual",
      offBarcode: entry.offBarcode ?? null,
      ingredientIndex: entry.ingredientIndex ?? null,
      macroSource: entry.macroSource || "ingredient",
      microSource: entry.microSource || "none",
      enteredBasis: entry.enteredBasis ?? null,
      normalizedGrams: entry.normalizedGrams ?? null,
      yieldFactorUsed: entry.yieldFactorUsed ?? null,
    }, {
      onSuccess: () => {
        setOpen(false);
        toast({ title: "Copied", description: `${entry.name} copied to ${toDate}.` });
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => {
      setOpen(o);
      if (o) { setToDate(entry.date || ""); setToMeal(entry.meal || "lunch"); }
    }}>
      <DialogTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
          data-testid={`button-copy-food-${entry.id}`}
        >
          <Copy className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[360px]">
        <DialogHeader>
          <DialogTitle className="font-display">Copy item</DialogTitle>
          <DialogDescription>{entry.name} — choose a target date and meal.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <Label htmlFor="copy-food-date">Date</Label>
            <Input id="copy-food-date" type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} data-testid="input-copy-food-date" />
          </div>
          <div className="space-y-1.5">
            <Label>Meal</Label>
            <Select value={toMeal} onValueChange={(v) => setToMeal(v as MealType)}>
              <SelectTrigger data-testid="select-copy-food-meal">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="breakfast"><div className="flex items-center gap-2"><Coffee className="h-3.5 w-3.5" /> Breakfast</div></SelectItem>
                <SelectItem value="lunch"><div className="flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Lunch</div></SelectItem>
                <SelectItem value="dinner"><div className="flex items-center gap-2"><Moon className="h-3.5 w-3.5" /> Dinner</div></SelectItem>
                <SelectItem value="snack"><div className="flex items-center gap-2"><Cookie className="h-3.5 w-3.5" /> Snack</div></SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleCopy} disabled={!toDate || isPending} className="w-full" data-testid="button-confirm-copy-food">
            {isPending ? "Copying..." : "Copy item"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function DeleteFoodButton({ id }: { id: number }) {
  const { mutate: deleteEntry, isPending } = useDeleteFoodEntry();
  return (
    <Button 
      size="icon" 
      variant="ghost" 
      disabled={isPending}
      className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
      onClick={() => deleteEntry(id)}
      data-testid={`button-delete-food-${id}`}
    >
      <Trash2 className="h-4 w-4" />
    </Button>
  );
}

function LogEntryDialog({ existingLog, date }: { existingLog?: any, date: string }) {
  const [open, setOpen] = useState(false);
  const { mutate: createLog, isPending: creating } = useCreateLog();
  const { mutate: updateLog, isPending: updating } = useUpdateLog();
  const { data: user } = useUser();

  const [formData, setFormData] = useState({
    weight: "",
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    fibre: "",
  });

  // Pre-fill
  useEffect(() => {
    if (existingLog) {
      setFormData({
        weight: existingLog.weight?.toString() || "",
        calories: existingLog.calories?.toString() || "",
        protein: existingLog.protein?.toString() || "",
        carbs: existingLog.carbs?.toString() || "",
        fat: existingLog.fat?.toString() || "",
        fibre: existingLog.fibre?.toString() || "",
      });
    } else if (user?.currentWeight) {
        setFormData(prev => ({...prev, weight: user.currentWeight?.toString() || "" }));
    }
  }, [existingLog, user, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      userId: user!.id,
      date,
      weight: formData.weight ? parseFloat(formData.weight) : undefined,
      calories: formData.calories ? parseInt(formData.calories) : 0,
      protein: formData.protein ? parseInt(formData.protein) : 0,
      carbs: formData.carbs ? parseInt(formData.carbs) : 0,
      fat: formData.fat ? parseInt(formData.fat) : 0,
      fibre: formData.fibre ? parseInt(formData.fibre) : 0,
    };

    if (existingLog) {
      updateLog({ id: existingLog.id, ...payload }, { onSuccess: () => setOpen(false) });
    } else {
      createLog(payload, { onSuccess: () => setOpen(false) });
    }
  };

  const isPending = creating || updating;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="lg" data-testid="button-update-summary">
          <Pencil className="mr-2 h-4 w-4" />
          Update Summary
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-display">{existingLog ? "Edit Summary" : "Log Summary"} ({format(parseISO(date), "MMM d")})</DialogTitle>
          <DialogDescription className="sr-only">Log or edit your daily macro totals.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <p className="text-xs text-muted-foreground mb-4">
            Note: Manually entering values here will override the calculated totals from your logged food items.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="calories">Total Calories (kcal)</Label>
              <Input 
                id="calories" 
                type="number" 
                value={formData.calories} 
                onChange={e => setFormData({...formData, calories: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input 
                id="weight" 
                type="number" 
                step="0.1"
                value={formData.weight} 
                onChange={e => setFormData({...formData, weight: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Macros & Fibre</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="protein" className="text-xs">Protein (g)</Label>
                <Input 
                  id="protein" 
                  type="number" 
                  value={formData.protein} 
                  onChange={e => setFormData({...formData, protein: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="carbs" className="text-xs">Carbs (g)</Label>
                <Input 
                  id="carbs" 
                  type="number" 
                  value={formData.carbs} 
                  onChange={e => setFormData({...formData, carbs: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="fat" className="text-xs">Fat (g)</Label>
                <Input 
                  id="fat" 
                  type="number" 
                  value={formData.fat} 
                  onChange={e => setFormData({...formData, fat: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="fibre" className="text-xs">Fibre (g)</Label>
                <Input 
                  id="fibre" 
                  type="number" 
                  value={formData.fibre} 
                  onChange={e => setFormData({...formData, fibre: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Summary"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DashboardSkeleton() {
  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          <Skeleton className="md:col-span-2 h-[300px] rounded-xl" />
          <Skeleton className="h-[300px] rounded-xl" />
        </div>
      </div>
    </Layout>
  );
}
