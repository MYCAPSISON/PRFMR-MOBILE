import { useState } from "react";
import { format, subDays } from "date-fns";
import { Layout } from "@/components/layout";
import { AMQSCard } from "@/components/AMQSCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { useLocation } from "wouter";
import { parseISO, addDays } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

interface AMQSTrendResult {
  layer1: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
  layer2: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
}

function formatTrendLine(layer: AMQSTrendResult["layer1"] | undefined): string {
  if (!layer) return "";
  const { delta, trend, prevWeekAvg } = layer;
  if (prevWeekAvg === 0) return "still building";
  if (trend === "improving") return `↑ +${delta} vs last week`;
  if (trend === "slightly_down") return `↓ ${delta} vs last week`;
  return "→ steady vs last week";
}

function trendLineColor(layer: AMQSTrendResult["layer1"] | undefined): string {
  if (!layer || layer.prevWeekAvg === 0) return "text-muted-foreground/50";
  if (layer.trend === "improving") return "text-emerald-500";
  if (layer.trend === "slightly_down") return "text-amber-400";
  return "text-muted-foreground/50";
}

export default function MicronutrientsPage() {
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));

  const goToPreviousDay = () => setSelectedDate(format(subDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToNextDay = () => setSelectedDate(format(addDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToToday = () => setSelectedDate(format(new Date(), "yyyy-MM-dd"));
  const isToday = selectedDate === format(new Date(), "yyyy-MM-dd");

  const { data: trend } = useQuery<AMQSTrendResult | null>({
    queryKey: ["/api/me/amqs/trend", selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/amqs/trend/${selectedDate}`, { credentials: "include", cache: "no-store" });
      if (!res.ok) return null;
      return res.json();
    },
  });

  const chartData = trend
    ? trend.layer1.dailyScores.map((d, i) => ({
        date: d.date.slice(5),
        l1: d.score,
        l2: trend.layer2.dailyScores[i]?.score ?? 0,
      }))
    : [];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Micronutrient Score</h1>
            <p className="text-sm text-muted-foreground">Your daily and weekly AMQS analysis</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setLocation("/dashboard")} data-testid="button-back-dashboard">
            ← Dashboard
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={goToPreviousDay} data-testid="button-micros-prev-day">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-[160px] font-medium"
              data-testid="input-micros-date"
            />
          </div>
          <Button variant="outline" size="icon" onClick={goToNextDay} data-testid="button-micros-next-day">
            <ChevronRight className="h-4 w-4" />
          </Button>
          {!isToday && (
            <Button variant="ghost" size="sm" onClick={goToToday} data-testid="button-micros-today">
              Today
            </Button>
          )}
        </div>

        <AMQSCard
          date={selectedDate}
          onLogFirstMeal={() => setLocation("/dashboard?openAddFood=1")}
        />

        {/* 7-day trend section */}
        {trend && chartData.length > 1 && (
          <div className="bg-card rounded-xl p-5 space-y-4" data-testid="section-micros-trend">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">7-Day Trend</h3>
                <p className="text-[11px] text-muted-foreground/60">Basic vs Performance this week</p>
              </div>
              <div className="text-right space-y-0.5">
                <p className={`text-xs font-medium ${trendLineColor(trend.layer1)}`} data-testid="text-micros-l1-trend">
                  Basic {formatTrendLine(trend.layer1)}
                </p>
                <p className={`text-xs font-medium ${trendLineColor(trend.layer2)}`} data-testid="text-micros-l2-trend">
                  Perf {formatTrendLine(trend.layer2)}
                </p>
              </div>
            </div>

            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="microL1Fill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.2} />
                      <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="microL2Fill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.12} />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area
                    type="monotone"
                    dataKey="l1"
                    name="Layer 1"
                    stroke="hsl(var(--primary))"
                    fill="url(#microL1Fill)"
                    strokeWidth={2}
                    dot={false}
                    strokeOpacity={0.7}
                  />
                  <Area
                    type="monotone"
                    dataKey="l2"
                    name="Layer 2"
                    stroke="#3b82f6"
                    fill="url(#microL2Fill)"
                    strokeWidth={1.5}
                    dot={false}
                    strokeOpacity={0.5}
                  />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))", opacity: 0.5 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis domain={[0, 100]} hide />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 11 }}
                    labelStyle={{ color: "hsl(var(--muted-foreground))", marginBottom: 4 }}
                    formatter={(value: number, name: string) => [`${value}`, name]}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-secondary/15 space-y-0.5">
                <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">General avg</p>
                <p className="text-lg font-bold font-mono" data-testid="text-micros-l1-avg">{trend.layer1.currentWeekAvg}</p>
                <p className="text-[10px] text-muted-foreground/50">Baseline adequacy</p>
              </div>
              <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/10 space-y-0.5">
                <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Performance avg</p>
                <p className="text-lg font-bold font-mono text-muted-foreground/70" data-testid="text-micros-l2-avg">{trend.layer2.currentWeekAvg}</p>
                <p className="text-[10px] text-muted-foreground/50">Athlete optimisation</p>
              </div>
            </div>
          </div>
        )}

        <div className="text-center space-y-1 pb-4">
          <p className="text-[10px] text-muted-foreground/50 italic">
            AMQS combines food and supplement micronutrient data. Estimates only — not medical advice.
          </p>
          <p className="text-[10px] text-muted-foreground/40">
            Basic = baseline adequacy targets · Performance = athlete optimisation targets
          </p>
        </div>
      </div>
    </Layout>
  );
}
