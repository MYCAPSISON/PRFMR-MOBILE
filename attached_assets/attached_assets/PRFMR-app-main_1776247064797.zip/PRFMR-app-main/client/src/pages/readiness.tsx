import { useState } from "react";
import { format } from "date-fns";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Layout } from "@/components/layout";
import { SessionReadiness } from "@/components/SessionReadiness";
import { FuelAvailability } from "@/components/FuelAvailability";
import { Button } from "@/components/ui/button";

export default function ReadinessPage() {
  const [selectedDate] = useState(() => format(new Date(), "yyyy-MM-dd"));
  const [, navigate] = useLocation();

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0"
            onClick={() => navigate("/dashboard")}
            data-testid="button-back-dashboard"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Session Readiness</h1>
            <p className="text-muted-foreground">
              Your readiness and fuel status for {format(new Date(selectedDate + "T12:00:00"), "EEEE, MMMM d")}
            </p>
          </div>
        </div>

        <SessionReadiness date={selectedDate} />
        <FuelAvailability date={selectedDate} />

        <p className="text-xs text-muted-foreground/50 italic text-center pb-4">
          Scores are estimates based on logged food, sleep, and training data — not medical advice.
        </p>
      </div>
    </Layout>
  );
}
