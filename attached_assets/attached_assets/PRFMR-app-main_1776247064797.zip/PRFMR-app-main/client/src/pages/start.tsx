import { useState } from "react";
import { motion } from "framer-motion";
import { Activity, ArrowRight, Check, Mail, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { SOURCE_ALLOWLIST } from "@shared/schema";
import { SiGoogle } from "react-icons/si";

const SOURCE_LABELS: Record<string, string> = {
  ig: "Instagram",
  tiktok: "TikTok",
  reddit: "Reddit",
  discord: "Discord",
  gym: "Gym",
  uni: "University",
  friend: "Friend",
  google: "Google",
  facebook: "Facebook",
  sideproject: "Side Project",
  other: "Other",
  unknown: "Prefer not to say",
};

const STORAGE_KEY = "prfmr_source";

function getInitialSource(): { value: string; locked: boolean } {
  if (typeof window === "undefined") return { value: "", locked: false };
  try {
    const params = new URLSearchParams(window.location.search);
    const urlSrc = params.get("src")?.toLowerCase().trim() || "";
    if (urlSrc && (SOURCE_ALLOWLIST as readonly string[]).includes(urlSrc)) {
      localStorage.setItem(STORAGE_KEY, urlSrc);
      return { value: urlSrc, locked: true };
    }
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && (SOURCE_ALLOWLIST as readonly string[]).includes(stored)) {
      return { value: stored, locked: false };
    }
  } catch {}
  return { value: "", locked: false };
}

export default function StartPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [isPending, setIsPending] = useState(false);
  const [error, setError] = useState("");
  const [showHints, setShowHints] = useState(false);

  const [initialSource] = useState(getInitialSource);
  const [source, setSource] = useState(initialSource.value);
  const [sourceLocked, setSourceLocked] = useState(initialSource.locked);

  const handleSourceChange = (val: string) => {
    setSource(val);
    localStorage.setItem(STORAGE_KEY, val);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setError("");
    setIsPending(true);

    try {
      const res = await fetch("/api/invites/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, source: source || "unknown" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Something went wrong.");
        return;
      }
      setSubmitted(true);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setIsPending(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-8 bg-background relative">
        <div className="w-full max-w-sm space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Activity className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              PRFMR
            </h1>
            <p className="mt-3 text-muted-foreground">
              A nutrition and training tracker built for serious athletes. We're currently invite-only.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="space-y-4"
          >
            <Button
              type="button"
              variant="outline"
              data-testid="button-google-signup"
              className="w-full h-12 text-base gap-3"
              onClick={() => { window.location.href = "/auth/google"; }}
            >
              <SiGoogle className="h-4 w-4" />
              Continue with Google
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">or request an invite</span>
              </div>
            </div>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-3 p-4 rounded-md bg-primary/10 border border-primary/20">
                <Check className="h-5 w-5 text-primary flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-foreground" data-testid="text-request-success">
                    Invite sent — check your email.
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    If it doesn't arrive within 1–2 minutes, please check your Spam or Junk folder.
                  </p>
                </div>
              </div>

              <div className="rounded-md border border-border bg-muted/30 p-4 space-y-3">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-4 w-4 flex-shrink-0" />
                  <p className="text-xs">
                    Our emails come from <strong className="text-foreground">team@prfmr.link</strong>
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowHints(!showHints)}
                  className="flex items-center gap-1 text-xs text-primary hover:underline"
                  data-testid="button-toggle-email-hints"
                >
                  {showHints ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                  {showHints ? "Hide" : "Can't find it? Tips by provider"}
                </button>

                {showHints && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-2 text-xs text-muted-foreground"
                    data-testid="section-email-hints"
                  >
                    <div className="pl-3 border-l-2 border-border space-y-1">
                      <p><strong className="text-foreground">iCloud Mail</strong></p>
                      <p>Check Junk and "All Mail". If missing, add team@prfmr.link to your contacts.</p>
                    </div>
                    <div className="pl-3 border-l-2 border-border space-y-1">
                      <p><strong className="text-foreground">Outlook / Hotmail</strong></p>
                      <p>Check Junk Email. Click "Not junk" and "Always trust team@prfmr.link".</p>
                    </div>
                    <div className="pl-3 border-l-2 border-border space-y-1">
                      <p><strong className="text-foreground">Gmail</strong></p>
                      <p>Check Promotions or Spam. Move it to Primary and mark as "Not spam".</p>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.form
              onSubmit={handleSubmit}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="space-y-4"
            >
              {error && (
                <div className="text-sm text-destructive bg-destructive/10 rounded-md p-3" data-testid="text-request-error">
                  {error}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <Input
                  id="email"
                  data-testid="input-request-email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12"
                  required
                  autoComplete="email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="source">How did you hear about us?</Label>
                <Select
                  value={source}
                  onValueChange={handleSourceChange}
                  disabled={sourceLocked}
                >
                  <SelectTrigger className="h-12" data-testid="select-source">
                    <SelectValue placeholder="Select an option (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {SOURCE_ALLOWLIST.filter(s => s !== "unknown").map((s) => (
                      <SelectItem key={s} value={s} data-testid={`select-source-${s}`}>
                        {SOURCE_LABELS[s] || s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {sourceLocked && (
                  <p className="text-xs text-muted-foreground">Auto-detected from your link</p>
                )}
              </div>
              <Button
                type="submit"
                data-testid="button-request-invite"
                disabled={isPending || !email.trim()}
                className="w-full h-12 text-base group"
              >
                {isPending ? "Submitting..." : "Request an Invite"}
                {!isPending && (
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                )}
              </Button>
            </motion.form>
          )}

          <p className="text-sm text-center text-muted-foreground pt-4">
            Already have an account?{" "}
            <Link href="/" className="text-primary hover:underline" data-testid="link-login">
              Sign in
            </Link>
          </p>
        </div>
      </div>

      <div className="hidden lg:block relative bg-muted overflow-hidden">
        <div className="absolute inset-0 bg-zinc-900">
          <img
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
            alt="Training aesthetics"
            className="w-full h-full object-cover opacity-50 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-12">
            <p className="text-white font-display text-2xl max-w-md font-medium tracking-tight">
              Track nutrition. Build strength. Transform your health.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
