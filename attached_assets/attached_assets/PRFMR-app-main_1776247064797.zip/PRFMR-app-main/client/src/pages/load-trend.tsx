import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import { Layout } from "@/components/layout";
import { useUser } from "@/hooks/use-user";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";
import { ArrowLeft, AlertTriangle, TrendingUp, BarChart2, Info } from "lucide-react";

interface LoadHistoryEntry {
  date: string;
  totalLoad: number;
  classification: "light" | "moderate" | "hard" | "very_hard";
  relativeLoad: number | null;
  sessionCount: number;
}

interface LoadHistoryResponse {
  history: LoadHistoryEntry[];
  baselineLoad: number | null;
  baselineDaysUsed: number | null;
  acuteLoad: number;
  acuteDaily: number;
  acwr: number | null;
  date: string;
}

const classificationColors: Record<string, string> = {
  light: "#22c55e",
  moderate: "#eab308",
  hard: "#f97316",
  very_hard: "#ef4444",
};

const classificationBg: Record<string, string> = {
  light: "bg-green-500/20 text-green-400",
  moderate: "bg-yellow-500/20 text-yellow-400",
  hard: "bg-orange-500/20 text-orange-400",
  very_hard: "bg-red-500/20 text-red-400",
};

function acwrStatusLabel(acwr: number | null): { label: string; color: string } {
  if (acwr === null) return { label: "No baseline yet", color: "text-muted-foreground" };
  if (acwr < 0.8) return { label: "Under-trained (< 0.8)", color: "text-blue-400" };
  if (acwr <= 1.3) return { label: "Optimal zone (0.8–1.3)", color: "text-green-400" };
  if (acwr <= 1.5) return { label: "Elevated risk (1.3–1.5)", color: "text-yellow-400" };
  return { label: "High risk spike (> 1.5)", color: "text-red-400" };
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload as LoadHistoryEntry;
  return (
    <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-xs space-y-1.5 min-w-[160px]">
      <p className="font-semibold">{format(new Date(label + "T00:00:00"), "EEE d MMM")}</p>
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">Load</span>
        <span className="font-medium">{d.totalLoad}</span>
      </div>
      {d.relativeLoad !== null && (
        <div className="flex justify-between gap-4">
          <span className="text-muted-foreground">Relative</span>
          <span className="font-medium">{d.relativeLoad.toFixed(2)}×</span>
        </div>
      )}
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">Class</span>
        <span
          className="font-medium capitalize"
          style={{ color: classificationColors[d.classification] }}
        >
          {d.classification.replace("_", " ")}
        </span>
      </div>
      {d.sessionCount > 0 && (
        <div className="flex justify-between gap-4">
          <span className="text-muted-foreground">Sessions</span>
          <span className="font-medium">{d.sessionCount}</span>
        </div>
      )}
    </div>
  );
}

export default function LoadTrendPage() {
  const { data: user } = useUser();
  const [, navigate] = useLocation();
  const today = format(new Date(), "yyyy-MM-dd");

  const { data, isLoading } = useQuery<LoadHistoryResponse>({
    queryKey: ["/api/me/training/load-history", today],
    queryFn: async () => {
      const res = await fetch(`/api/me/training/load-history/${today}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!user,
  });

  const chartData = data?.history ?? [];

  const maxLoad = Math.max(...chartData.map((d) => d.totalLoad), 1);
  const hasRelative = chartData.some((d) => d.relativeLoad !== null);

  const acwrStatus = acwrStatusLabel(data?.acwr ?? null);

  const trainingDays = chartData.filter((d) => d.sessionCount > 0).length;
  const highStressDays = chartData.filter(
    (d) => d.relativeLoad !== null ? d.relativeLoad > 1.2 : d.totalLoad >= 600
  ).length;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4 pb-24">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="gap-1 px-2" onClick={() => navigate("/training")}>
            <ArrowLeft className="h-4 w-4" />
            Training
          </Button>
          <div className="flex-1">
            <h1 className="text-base font-semibold">Load Trend</h1>
            <p className="text-xs text-muted-foreground">28-day acute &amp; chronic workload</p>
          </div>
          <BarChart2 className="h-5 w-5 text-muted-foreground" />
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="border-border/50">
            <CardContent className="p-3 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">ACWR</p>
              <p className="text-xl font-bold">
                {data?.acwr !== null && data?.acwr !== undefined ? data.acwr.toFixed(2) : "—"}
              </p>
              <p className={`text-[10px] font-medium ${acwrStatus.color}`}>{acwrStatus.label}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-3 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Baseline</p>
              <p className="text-xl font-bold">
                {data?.baselineLoad !== null && data?.baselineLoad !== undefined
                  ? Math.round(data.baselineLoad)
                  : "—"}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {data?.baselineDaysUsed ? `${data.baselineDaysUsed}-day avg` : "< 7 days data"}
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-3 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Acute (7d)</p>
              <p className="text-xl font-bold">{data?.acuteLoad ?? "—"}</p>
              <p className="text-[10px] text-muted-foreground">
                {data?.acuteDaily !== undefined ? `${data.acuteDaily.toFixed(0)}/day avg` : ""}
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-3 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">High-stress</p>
              <p className="text-xl font-bold">{isLoading ? "—" : highStressDays}</p>
              <p className="text-[10px] text-muted-foreground">
                of {trainingDays} training days
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Absolute load chart */}
        <Card className="border-border/50">
          <CardHeader className="px-4 pt-4 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Absolute Load
            </CardTitle>
            <p className="text-xs text-muted-foreground">RPE × minutes per day (last 28 days)</p>
          </CardHeader>
          <CardContent className="px-2 pb-4">
            {isLoading ? (
              <div className="h-48 flex items-center justify-center">
                <p className="text-xs text-muted-foreground">Loading…</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <ComposedChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(d) => format(new Date(d + "T00:00:00"), "d MMM")}
                    tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }}
                    interval={6}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  {/* Reference lines for thresholds */}
                  <ReferenceLine y={300} stroke="#22c55e" strokeDasharray="3 3" strokeOpacity={0.5} />
                  <ReferenceLine y={600} stroke="#f97316" strokeDasharray="3 3" strokeOpacity={0.5} />
                  <ReferenceLine y={900} stroke="#ef4444" strokeDasharray="3 3" strokeOpacity={0.5} />
                  {data?.baselineLoad ? (
                    <ReferenceLine
                      y={data.baselineLoad}
                      stroke="hsl(var(--primary))"
                      strokeDasharray="5 3"
                      strokeWidth={1.5}
                      label={{ value: "baseline", position: "insideTopLeft", fontSize: 9, fill: "hsl(var(--primary))" }}
                    />
                  ) : null}
                  <Bar
                    dataKey="totalLoad"
                    name="Load"
                    fill="hsl(var(--primary))"
                    opacity={0.75}
                    radius={[2, 2, 0, 0]}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            )}
            <div className="flex gap-3 mt-2 px-2 flex-wrap">
              {[
                { label: "Light (< 300)", color: "#22c55e" },
                { label: "Moderate (< 600)", color: "#eab308" },
                { label: "Hard (< 900)", color: "#f97316" },
                { label: "Very Hard (≥ 900)", color: "#ef4444" },
              ].map((t) => (
                <div key={t.label} className="flex items-center gap-1">
                  <div
                    className="h-0.5 w-4 rounded"
                    style={{ background: t.color, opacity: 0.6, borderTop: `1px dashed ${t.color}` }}
                  />
                  <span className="text-[9px] text-muted-foreground">{t.label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Relative load chart */}
        {hasRelative && (
          <Card className="border-border/50">
            <CardHeader className="px-4 pt-4 pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BarChart2 className="h-4 w-4 text-primary" />
                Relative Load
              </CardTitle>
              <p className="text-xs text-muted-foreground">
                Today's load ÷ {data?.baselineDaysUsed ?? "28"}-day baseline average
              </p>
            </CardHeader>
            <CardContent className="px-2 pb-4">
              <ResponsiveContainer width="100%" height={200}>
                <ComposedChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(d) => format(new Date(d + "T00:00:00"), "d MMM")}
                    tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }}
                    interval={6}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `${v}×`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  {/* High-stress threshold lines */}
                  <ReferenceLine y={1} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" strokeOpacity={0.4} />
                  <ReferenceLine
                    y={1.2}
                    stroke="#eab308"
                    strokeDasharray="4 3"
                    strokeOpacity={0.7}
                    label={{ value: "high stress", position: "insideTopLeft", fontSize: 9, fill: "#eab308" }}
                  />
                  <ReferenceLine
                    y={1.4}
                    stroke="#ef4444"
                    strokeDasharray="4 3"
                    strokeOpacity={0.7}
                    label={{ value: "very high", position: "insideTopLeft", fontSize: 9, fill: "#ef4444" }}
                  />
                  <Bar
                    dataKey="relativeLoad"
                    name="Relative load"
                    fill="hsl(var(--primary))"
                    opacity={0.7}
                    radius={[2, 2, 0, 0]}
                  />
                </ComposedChart>
              </ResponsiveContainer>
              <p className="text-[9px] text-muted-foreground px-2 mt-2">
                1.0 = exactly at baseline · &gt;1.2 high stress · &gt;1.4 very high stress
              </p>
            </CardContent>
          </Card>
        )}

        {/* ACWR education card */}
        <Card className="border-border/50 bg-secondary/10">
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-primary shrink-0" />
              <p className="text-xs font-semibold">About ACWR</p>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              The Acute:Chronic Workload Ratio (ACWR) compares your 7-day average load to your baseline.
              Research suggests the "sweet spot" is <span className="text-foreground font-medium">0.8–1.3</span> — below this suggests detraining, above 1.5 indicates injury risk elevation.
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Baseline window: 28 days → 14 days → 7 days as your history builds.
            </p>
            <p className="text-[10px] text-muted-foreground/60 leading-relaxed border-t border-border/30 pt-2">
              Based on: Gabbett, T.J. (2016). The training-injury prevention paradox: should athletes be training smarter and harder?{" "}
              <em>British Journal of Sports Medicine, 50</em>(5), 273–280.
            </p>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground/50 italic text-center pb-2">
          Daily stress rating is personalised to your baseline. ACWR tracks your weekly load trend.
        </p>
      </div>
    </Layout>
  );
}
