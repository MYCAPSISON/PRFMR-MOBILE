import { useState, useMemo, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { format, addDays, subDays, parseISO } from "date-fns";
import { Layout } from "@/components/layout";
import { useUser } from "@/hooks/use-user";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  Pencil,
  Flame,
  Clock,
  Dumbbell,
  Activity,
  AlertTriangle,
  Check,
  ChevronsUpDown,
  BedDouble,
  BarChart2,
  Calendar,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { TrainingLoadWarningModal, type TrainingLoadAnalysis } from "@/components/TrainingLoadWarningModal";
import { TrainingBlockModal } from "@/components/TrainingBlockModal";
import type {
  WorkoutSession,
  WorkoutExercise,
  WorkoutSet,
  SessionActivity,
  ExerciseCatalogItem,
  ActivityCatalogItem,
} from "@shared/schema";

type TimeOfDay = "morning" | "afternoon" | "evening";
type Intensity = "light" | "moderate" | "vigorous";

interface WorkoutExerciseWithSets extends WorkoutExercise {
  sets: WorkoutSet[];
}

interface WorkoutSessionWithDetails extends WorkoutSession {
  exercises: WorkoutExerciseWithSets[];
  activities: SessionActivity[];
}

// Module-level pending warning — survives Training component unmount/remount
// (cleared on acknowledge; persists when user navigates away and back)
let _pendingLoadWarning: { analysis: TrainingLoadAnalysis; date: string } | null = null;

export default function Training() {
  const { data: user } = useUser();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedDate, setSelectedDate] = useState(
    format(new Date(), "yyyy-MM-dd")
  );
  const [openSections, setOpenSections] = useState<Record<TimeOfDay, boolean>>({
    morning: true,
    afternoon: true,
    evening: true,
  });
  const [addExerciseDialog, setAddExerciseDialog] = useState<{
    open: boolean;
    sessionId: number;
  } | null>(null);
  const [addActivityDialog, setAddActivityDialog] = useState<{
    open: boolean;
    sessionId: number;
  } | null>(null);
  const [editActivityDialog, setEditActivityDialog] = useState<{
    open: boolean;
    activity: any;
  } | null>(null);
  const [addSetDialog, setAddSetDialog] = useState<{
    open: boolean;
    exerciseId: number;
    sessionId: number;
  } | null>(null);

  const [blockModalOpen, setBlockModalOpen] = useState(false);

  const [loadWarningModal, setLoadWarningModal] = useState<{
    open: boolean;
    analysis: TrainingLoadAnalysis | null;
  }>(() => {
    // On mount: re-open any pending warning for today's date
    const today = format(new Date(), "yyyy-MM-dd");
    if (_pendingLoadWarning && _pendingLoadWarning.date === today) {
      return { open: true, analysis: _pendingLoadWarning.analysis };
    }
    return { open: false, analysis: null };
  });

  const checkAndShowLoadWarning = useCallback(async (date: string) => {
    try {
      const res = await fetch(`/api/me/training-load/${date}`, { credentials: "include" });
      if (!res.ok) return;
      const data = await res.json();
      if (data.warnings && data.warnings.length > 0) {
        _pendingLoadWarning = { analysis: data as TrainingLoadAnalysis, date };
        setLoadWarningModal({ open: true, analysis: data as TrainingLoadAnalysis });
      }
    } catch {
      // non-critical, ignore
    }
  }, []);

  const { data: sessions = [], isLoading } = useQuery<
    WorkoutSessionWithDetails[]
  >({
    queryKey: ["/api/workouts/sessions", selectedDate, selectedDate],
    queryFn: async () => {
      const res = await fetch(
        `/api/workouts/sessions?start=${selectedDate}&end=${selectedDate}`,
        { credentials: "include", cache: "no-store" }
      );
      if (!res.ok) throw new Error("Failed to fetch sessions");
      return res.json();
    },
    enabled: !!user,
  });

  const { data: exerciseCatalog = [] } = useQuery<ExerciseCatalogItem[]>({
    queryKey: ["/api/exercises"],
    enabled: !!user,
  });

  const { data: activityCatalog = [] } = useQuery<ActivityCatalogItem[]>({
    queryKey: ["/api/activities"],
    enabled: !!user,
  });

  const { data: activeBlock } = useQuery<{
    id: number; name: string; startDate: string; weekCount: number;
    days: { dayOfWeek: number; plannedLoad: string; activities?: any[] }[];
  } | null>({
    queryKey: ["/api/training-blocks/active"],
    enabled: !!user,
  });

  // Derive planned load for the selected date from the active block
  const plannedLoadForDate = (() => {
    if (!activeBlock) return null;
    const start = new Date(activeBlock.startDate);
    const end = new Date(activeBlock.startDate);
    end.setDate(end.getDate() + activeBlock.weekCount * 7 - 1);
    const d = new Date(selectedDate);
    if (d < start || d > end) return null;
    const dow = (d.getDay() + 6) % 7; // 0=Mon…6=Sun
    const dayDef = activeBlock.days.find(x => x.dayOfWeek === dow);
    if (!dayDef) return null;
    // Prefer derived load from activities if present
    const acts: any[] = dayDef.activities ?? [];
    if (acts.length === 0) return dayDef.plannedLoad ?? null;
    const au = acts.reduce((s: number, a: any) => s + (a.rpe ? a.rpe * a.durationMinutes : a.durationMinutes * 3), 0);
    if (au === 0) return "rest";
    if (au < 300) return "light";
    if (au < 600) return "moderate";
    if (au < 900) return "hard";
    return "very_hard";
  })();

  const { data: trainingLoadData } = useQuery<{
    warnings: string[];
    backToBackHardDays: boolean;
    highLoadCluster: boolean;
    threeDayStreak: boolean;
    totalLoad: number;
    classification: "light" | "moderate" | "hard" | "very_hard";
    effectiveClassification: "light" | "moderate" | "hard" | "very_hard";
    overrideClassification: string | null;
    acuteLoad: number;
    acwr: number | null;
    highStress: boolean;
    veryHighStress: boolean;
  }>({
    queryKey: ["/api/me/training-load", selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/training-load/${selectedDate}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!user,
    staleTime: 0,
  });

  const { data: restDayData } = useQuery<{ isRestDay: boolean }>({
    queryKey: ["/api/me/training/summary", selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/me/training/summary/${selectedDate}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!user,
  });

  const isRestDay = restDayData?.isRestDay ?? false;

  const { data: weightCutPlan } = useQuery<{ daysUntil: number; fightDate: string } | null>({
    queryKey: ["/api/me/weight-cut"],
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
  });

  const restDayMutation = useMutation({
    mutationFn: async (markRest: boolean) => {
      if (markRest) {
        return apiRequest("POST", `/api/me/rest-day/${selectedDate}`, {});
      } else {
        return apiRequest("DELETE", `/api/me/rest-day/${selectedDate}`);
      }
    },
    onSuccess: (_, markRest) => {
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/morning-status", selectedDate], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      toast({ title: markRest ? "Rest day marked" : "Rest day removed" });
    },
  });

  const sessionsByTimeOfDay = useMemo(() => {
    const grouped: Record<TimeOfDay, WorkoutSessionWithDetails | null> = {
      morning: null,
      afternoon: null,
      evening: null,
    };
    sessions.forEach((session) => {
      grouped[session.timeOfDay as TimeOfDay] = session;
    });
    return grouped;
  }, [sessions]);

  const totalCalories = useMemo(() => {
    return sessions.reduce((sum, s) => sum + (s.estimatedKcal || 0), 0);
  }, [sessions]);

  const dayLoad = useMemo(() => {
    if (sessions.length === 0) return null;
    const allActivities = sessions.flatMap(s => s.activities || []);
    const hasActivities = allActivities.length > 0;

    // Prefer classification from the API (which respects user override and correct thresholds)
    const apiClassification = trainingLoadData?.effectiveClassification ?? trainingLoadData?.classification;
    const apiTotalLoad = trainingLoadData?.totalLoad;
    const isOverridden = !!trainingLoadData?.overrideClassification;

    let classKey: string;
    let totalLoad: number;

    if (apiClassification) {
      classKey = apiClassification;
      totalLoad = apiTotalLoad ?? 0;
    } else {
      // Fallback: compute from sessions using correct thresholds
      let computed = 0;
      for (const act of allActivities) {
        if (act.rpe) {
          computed += Math.round((act.rpe as number) * (act.durationMinutes ?? 0));
        } else {
          computed += act.estimatedKcal ?? 0;
        }
      }
      totalLoad = computed;
      if (computed < 300) classKey = "light";
      else if (computed < 600) classKey = "moderate";
      else if (computed < 900) classKey = "hard";
      else classKey = "very_hard";
    }

    const classLabels: Record<string, string> = {
      light: "Light", moderate: "Moderate", hard: "Hard", very_hard: "Very Hard",
    };
    const badgeClasses: Record<string, string> = {
      light: "bg-blue-500/15 text-blue-400 border-blue-500/30",
      moderate: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
      hard: "bg-orange-500/15 text-orange-400 border-orange-500/30",
      very_hard: "bg-red-500/15 text-red-400 border-red-500/30",
    };

    const classification = classLabels[classKey] ?? classKey;
    const badgeClass = badgeClasses[classKey] ?? "";
    const provisional = !hasActivities;
    return { classification, badgeClass, totalLoad, provisional, isOverridden };
  }, [sessions, trainingLoadData]);

  const createSessionMutation = useMutation({
    mutationFn: async (data: {
      timeOfDay: TimeOfDay;
      title?: string;
      intensity?: Intensity;
      durationMinutes?: number;
    }) => {
      return apiRequest("POST", "/api/workouts/sessions", {
        date: selectedDate,
        ...data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      toast({ title: "Session created" });
    },
  });

  const deleteSessionMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/workouts/sessions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      toast({ title: "Session deleted" });
    },
  });

  const addExerciseMutation = useMutation({
    mutationFn: async (data: {
      sessionId: number;
      exerciseCatalogId?: number;
      name: string;
    }) => {
      return apiRequest(
        "POST",
        `/api/workouts/sessions/${data.sessionId}/exercises`,
        {
          exerciseCatalogId: data.exerciseCatalogId,
          name: data.name,
        }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      setAddExerciseDialog(null);
      toast({ title: "Exercise added" });
    },
  });

  const deleteExerciseMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/workouts/exercises/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
    },
  });

  const addSetMutation = useMutation({
    mutationFn: async (data: {
      exerciseId: number;
      reps: number;
      weightKg?: number;
      rpe?: number;
      restSeconds?: number;
    }) => {
      return apiRequest(
        "POST",
        `/api/workouts/exercises/${data.exerciseId}/sets`,
        {
          reps: data.reps,
          weightKg: data.weightKg,
          rpe: data.rpe,
          restSeconds: data.restSeconds,
        }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training-load", selectedDate] });
      setAddSetDialog(null);
      toast({ title: "Set added" });
      checkAndShowLoadWarning(selectedDate);
    },
  });

  const deleteSetMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/workouts/sets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
    },
  });

  const addActivityMutation = useMutation({
    mutationFn: async (data: {
      sessionId: number;
      activityCatalogId?: number;
      name: string;
      durationMinutes: number;
      intensity: Intensity;
      metValue: number;
      activityType?: string;
      sessionRpe?: number;
      bodyRegion?: string;
      rpe?: number;
    }) => {
      return apiRequest(
        "POST",
        `/api/workouts/sessions/${data.sessionId}/activities`,
        {
          activityCatalogId: data.activityCatalogId,
          name: data.name,
          durationMinutes: data.durationMinutes,
          intensity: data.intensity,
          metValue: data.metValue,
          activityType: data.activityType || "cardio",
          sessionRpe: data.sessionRpe,
          bodyRegion: data.bodyRegion,
          rpe: data.rpe,
        }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training-load", selectedDate] });
      setAddActivityDialog(null);
      toast({ title: "Activity added" });
      checkAndShowLoadWarning(selectedDate);
    },
  });

  const deleteActivityMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/workouts/activities/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training-load", selectedDate] });
    },
  });

  const updateActivityMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      name: string;
      durationMinutes: number;
      intensity: string;
      metValue: number;
      activityType: string;
      activityCatalogId?: number;
      sessionRpe?: number;
      bodyRegion?: string;
      rpe?: number;
    }) => {
      const { id, ...body } = data;
      return apiRequest("PATCH", `/api/workouts/activities/${id}`, body);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/sessions"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/training/summary"], exact: false });
      queryClient.removeQueries({ queryKey: ["/api/me/targets/effective"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/training-load", selectedDate] });
      setEditActivityDialog(null);
      toast({ title: "Activity updated" });
      checkAndShowLoadWarning(selectedDate);
    },
  });

  const goToPreviousDay = () => {
    setSelectedDate(format(subDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  };

  const goToNextDay = () => {
    setSelectedDate(format(addDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  };

  const timeOfDayLabels: Record<TimeOfDay, string> = {
    morning: "Morning",
    afternoon: "Afternoon",
    evening: "Evening",
  };

  const timeOfDayIcons: Record<TimeOfDay, string> = {
    morning: "06:00 - 12:00",
    afternoon: "12:00 - 18:00",
    evening: "18:00 - 24:00",
  };

  if (!user) {
    return (
      <Layout>
        <div className="text-center py-12">
          <p>Please log in to access training.</p>
        </div>
      </Layout>
    );
  }

  return (
    <>
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl font-display font-bold">Training Log</h1>
            <p className="text-muted-foreground">
              Track your workouts and activities
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {weightCutPlan && typeof weightCutPlan.daysUntil === "number" && weightCutPlan.daysUntil >= 0 && (
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-400 text-xs font-semibold"
                data-testid="chip-days-to-fight"
              >
                <span>🥊</span>
                <span>{weightCutPlan.daysUntil} day{weightCutPlan.daysUntil !== 1 ? "s" : ""} to fight night</span>
              </div>
            )}
            {activeBlock && (
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs font-medium"
                data-testid="chip-active-block"
              >
                <Calendar className="h-3 w-3" />
                <span>{activeBlock.name}</span>
              </div>
            )}
            <Button
              variant="outline"
              size="sm"
              data-testid="button-plan-block"
              onClick={() => setBlockModalOpen(true)}
              className="h-8 text-xs border-primary/30 text-primary hover:bg-primary/10"
            >
              <Calendar className="h-3.5 w-3.5 mr-1" />
              {activeBlock ? "Edit Block" : "Plan Block"}
            </Button>
          </div>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={goToPreviousDay}
                data-testid="button-previous-day"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex-1 text-center">
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-auto mx-auto text-center"
                  data-testid="input-date"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  {format(parseISO(selectedDate), "EEEE, MMMM d, yyyy")}
                </p>
                {plannedLoadForDate && plannedLoadForDate !== "rest" && (
                  <div className="mt-1.5 flex justify-center">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${
                      plannedLoadForDate === "very_hard" ? "bg-red-500/15 border-red-500/30 text-red-400" :
                      plannedLoadForDate === "hard"      ? "bg-orange-500/15 border-orange-500/30 text-orange-400" :
                      plannedLoadForDate === "moderate"  ? "bg-yellow-500/15 border-yellow-500/30 text-yellow-400" :
                                                           "bg-green-500/15 border-green-500/30 text-green-400"
                    }`} data-testid="chip-planned-load">
                      <Calendar className="h-2.5 w-2.5" />
                      Planned: {plannedLoadForDate.replace("_", " ")}
                    </span>
                  </div>
                )}
                {plannedLoadForDate === "rest" && (
                  <div className="mt-1.5 flex justify-center">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border bg-muted/30 border-border/30 text-muted-foreground" data-testid="chip-planned-rest">
                      <Calendar className="h-2.5 w-2.5" />
                      Planned: rest day
                    </span>
                  </div>
                )}
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={goToNextDay}
                data-testid="button-next-day"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {sessions.length === 0 && (
          <div className="flex justify-end">
            <button
              onClick={() => restDayMutation.mutate(!isRestDay)}
              disabled={restDayMutation.isPending}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                isRestDay
                  ? "bg-green-500/15 border-green-500/30 text-green-400 hover:bg-green-500/25"
                  : "border-border/50 text-muted-foreground hover:bg-secondary/40"
              }`}
              data-testid="button-toggle-rest-day"
            >
              <BedDouble className="h-3.5 w-3.5" />
              {isRestDay ? "Rest day ✓ (tap to undo)" : "Mark as rest day"}
            </button>
          </div>
        )}

        <Card className="bg-accent/10 border-accent/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flame className="h-5 w-5 text-accent" />
                <span className="font-medium">Estimated Calories Burned</span>
              </div>
              <div className="flex items-center gap-2">
                {dayLoad && (
                  <Badge
                    variant="outline"
                    className={`text-xs border ${dayLoad.badgeClass}`}
                    data-testid="badge-day-classification"
                    title={
                      dayLoad.isOverridden
                        ? "Your perceived classification override"
                        : dayLoad.provisional
                        ? "Classification provisional — add activities for a more accurate assessment"
                        : undefined
                    }
                  >
                    {dayLoad.classification}{dayLoad.isOverridden ? " ✎" : dayLoad.provisional ? " (est.)" : ""}
                  </Badge>
                )}
                <span className="text-xl font-bold text-accent">
                  ~{totalCalories} kcal
                </span>
              </div>
            </div>
            {trainingLoadData?.warnings && trainingLoadData.warnings.length > 0 && (
              <div className="mt-2 space-y-0.5">
                {trainingLoadData.warnings.map((w, i) => (
                  <p key={i} className="text-xs text-orange-400/70 flex items-start gap-1" data-testid={`text-load-warning-${i}`}>
                    <AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0" />
                    {w}
                  </p>
                ))}
              </div>
            )}
            <div className="mt-3 flex items-center justify-between">
              <p className="text-[10px] text-muted-foreground/50 italic">
                Classification is personalised to your baseline.
              </p>
              <button
                onClick={() => navigate("/load-trend")}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-view-load-trend"
              >
                <BarChart2 className="h-3.5 w-3.5" />
                28-day trend
              </button>
            </div>

            {!user?.currentWeight && (
              <p className="text-xs text-muted-foreground mt-2">
                Set your weight in profile for cardio activity estimates.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {(["morning", "afternoon", "evening"] as TimeOfDay[]).map(
            (timeOfDay) => {
              const session = sessionsByTimeOfDay[timeOfDay];
              const isOpen = openSections[timeOfDay];

              return (
                <Collapsible
                  key={timeOfDay}
                  open={isOpen}
                  onOpenChange={(open) =>
                    setOpenSections((prev) => ({ ...prev, [timeOfDay]: open }))
                  }
                >
                  <Card>
                    <CardHeader className="p-4">
                      <CollapsibleTrigger asChild>
                        <div className="flex items-center justify-between cursor-pointer">
                          <div className="flex items-center gap-3">
                            <ChevronDown
                              className={cn(
                                "h-5 w-5 transition-transform",
                                !isOpen && "-rotate-90"
                              )}
                            />
                            <div>
                              <CardTitle className="text-lg">
                                {timeOfDayLabels[timeOfDay]}
                              </CardTitle>
                              <p className="text-xs text-muted-foreground">
                                {timeOfDayIcons[timeOfDay]}
                              </p>
                            </div>
                          </div>
                          {session && (
                            <Badge variant="secondary">
                              <Flame className="h-3 w-3 mr-1" />~
                              {session.estimatedKcal || 0} kcal
                            </Badge>
                          )}
                        </div>
                      </CollapsibleTrigger>
                    </CardHeader>
                    <CollapsibleContent>
                      <CardContent className="p-4 pt-0">
                        {!session ? (
                          <button
                            className="w-full text-left py-3 px-1 text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer flex items-center gap-2"
                            onClick={() =>
                              createSessionMutation.mutate({ timeOfDay })
                            }
                            disabled={createSessionMutation.isPending}
                            data-testid={`button-create-session-${timeOfDay}`}
                          >
                            <Plus className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
                            <span>No {timeOfDayLabels[timeOfDay].toLowerCase()} session yet — tap to log</span>
                          </button>
                        ) : (
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="flex items-center gap-2">
                                  {session.title && (
                                    <p className="font-medium">{session.title}</p>
                                  )}
                                  {session.isPlanned && (
                                    <Badge
                                      data-testid={`badge-planned-${session.id}`}
                                      variant="outline"
                                      className="text-[10px] px-1.5 py-0 border-primary/40 text-primary/80 bg-primary/8"
                                    >
                                      Planned
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  {session.intensity && (
                                    <Badge variant="outline" className="text-xs">
                                      {session.intensity}
                                    </Badge>
                                  )}
                                  {session.durationMinutes && (
                                    <span className="flex items-center gap-1">
                                      <Clock className="h-3 w-3" />
                                      {session.durationMinutes} min
                                    </span>
                                  )}
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() =>
                                  deleteSessionMutation.mutate(session.id)
                                }
                                data-testid={`button-delete-session-${session.id}`}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>

                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h4 className="text-sm font-medium flex items-center gap-2">
                                  <Dumbbell className="h-4 w-4" />
                                  Exercises
                                </h4>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setAddExerciseDialog({
                                      open: true,
                                      sessionId: session.id,
                                    })
                                  }
                                  data-testid={`button-add-exercise-${session.id}`}
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Add Exercise
                                </Button>
                              </div>

                              {session.exercises.length === 0 ? (
                                <p className="text-sm text-muted-foreground text-center py-2">
                                  No exercises yet
                                </p>
                              ) : (
                                <div className="space-y-3">
                                  {session.exercises.map((exercise) => (
                                    <div
                                      key={exercise.id}
                                      className="border rounded-lg p-3"
                                    >
                                      <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                          <span className="font-medium">
                                            {exercise.name}
                                          </span>
                                          {exercise.estimatedKcal && exercise.estimatedKcal > 0 && (
                                            <Badge variant="outline" className="text-xs">
                                              ~{exercise.estimatedKcal} kcal
                                            </Badge>
                                          )}
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() =>
                                              setAddSetDialog({
                                                open: true,
                                                exerciseId: exercise.id,
                                                sessionId: session.id,
                                              })
                                            }
                                            data-testid={`button-add-set-${exercise.id}`}
                                          >
                                            <Plus className="h-3 w-3 mr-1" />
                                            Set
                                          </Button>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() =>
                                              deleteExerciseMutation.mutate(
                                                exercise.id
                                              )
                                            }
                                          >
                                            <Trash2 className="h-3 w-3 text-destructive" />
                                          </Button>
                                        </div>
                                      </div>

                                      {exercise.sets.length > 0 && (
                                        <div className="space-y-1">
                                          <div className="grid grid-cols-5 gap-2 text-xs text-muted-foreground px-2">
                                            <span>Set</span>
                                            <span>Reps</span>
                                            <span>Weight</span>
                                            <span>RPE</span>
                                            <span></span>
                                          </div>
                                          {exercise.sets.map((set) => (
                                            <div
                                              key={set.id}
                                              className="grid grid-cols-5 gap-2 text-sm bg-muted/50 rounded px-2 py-1"
                                            >
                                              <span>{set.setIndex}</span>
                                              <span>{set.reps}</span>
                                              <span>
                                                {set.weightKg
                                                  ? `${set.weightKg}kg`
                                                  : "-"}
                                              </span>
                                              <span>{set.rpe || "-"}</span>
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-6 w-6"
                                                onClick={() =>
                                                  deleteSetMutation.mutate(
                                                    set.id
                                                  )
                                                }
                                              >
                                                <Trash2 className="h-3 w-3 text-destructive" />
                                              </Button>
                                            </div>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h4 className="text-sm font-medium flex items-center gap-2">
                                  <Activity className="h-4 w-4" />
                                  Activities
                                </h4>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setAddActivityDialog({
                                      open: true,
                                      sessionId: session.id,
                                    })
                                  }
                                  data-testid={`button-add-activity-${session.id}`}
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Add Activity
                                </Button>
                              </div>

                              {session.activities.length === 0 ? (
                                <p className="text-sm text-muted-foreground text-center py-2">
                                  No activities yet
                                </p>
                              ) : (
                                <div className="space-y-2">
                                  {session.activities.map((activity) => (
                                    <div
                                      key={activity.id}
                                      className="flex items-center justify-between border rounded-lg p-3"
                                    >
                                      <div>
                                        <span className="font-medium flex items-center gap-1.5">
                                          {(activity as any).activityType === "lifting" && <Dumbbell className="h-3.5 w-3.5 text-muted-foreground" />}
                                          {activity.name}
                                        </span>
                                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                          <span>
                                            {activity.durationMinutes} min
                                          </span>
                                          {(activity as any).activityType === "lifting" ? (
                                            <>
                                              <Badge variant="secondary" className="text-xs">
                                                RPE {(activity as any).sessionRpe}
                                              </Badge>
                                              <Badge variant="outline" className="text-xs">
                                                {(activity as any).bodyRegion}
                                              </Badge>
                                              {activity.estimatedKcal > 0 && (
                                                <span className="text-accent">
                                                  ~{activity.estimatedKcal} kcal
                                                </span>
                                              )}
                                              {(activity as any).trainingLoadScore && (
                                                <span className="text-primary/70 text-xs">
                                                  Load {Math.round((activity as any).trainingLoadScore)}
                                                </span>
                                              )}
                                            </>
                                          ) : (
                                            <>
                                              <Badge
                                                variant="outline"
                                                className="text-xs"
                                              >
                                                {activity.intensity}
                                              </Badge>
                                              {(activity as any).rpe && (
                                                <Badge variant="secondary" className="text-xs">
                                                  RPE {(activity as any).rpe}
                                                </Badge>
                                              )}
                                              <span className="text-accent">
                                                ~{activity.estimatedKcal} kcal
                                              </span>
                                            </>
                                          )}
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          data-testid={`button-edit-activity-${activity.id}`}
                                          onClick={() =>
                                            setEditActivityDialog({ open: true, activity })
                                          }
                                        >
                                          <Pencil className="h-4 w-4 text-muted-foreground" />
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          onClick={() =>
                                            deleteActivityMutation.mutate(
                                              activity.id
                                            )
                                          }
                                        >
                                          <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              );
            }
          )}
        </div>

        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <div className="space-y-1">
                <p className="font-medium">Disclaimer</p>
                <p>
                  Calorie estimates are approximate and based on MET values.
                  Actual energy expenditure varies significantly based on
                  individual factors including age, fitness level, body
                  composition, and technique. This is for personal tracking
                  only, not medical advice.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {addExerciseDialog && (
        <AddExerciseDialog
          open={addExerciseDialog.open}
          sessionId={addExerciseDialog.sessionId}
          exerciseCatalog={exerciseCatalog}
          onClose={() => setAddExerciseDialog(null)}
          onSubmit={(data) => addExerciseMutation.mutate(data)}
          isPending={addExerciseMutation.isPending}
        />
      )}

      {addSetDialog && (
        <AddSetDialog
          open={addSetDialog.open}
          exerciseId={addSetDialog.exerciseId}
          onClose={() => setAddSetDialog(null)}
          onSubmit={(data) => addSetMutation.mutate(data)}
          isPending={addSetMutation.isPending}
        />
      )}

      {addActivityDialog && (
        <AddActivityDialog
          open={addActivityDialog.open}
          sessionId={addActivityDialog.sessionId}
          activityCatalog={activityCatalog}
          onClose={() => setAddActivityDialog(null)}
          onSubmit={(data) => addActivityMutation.mutate(data)}
          isPending={addActivityMutation.isPending}
        />
      )}

      {editActivityDialog && (
        <EditActivityDialog
          open={editActivityDialog.open}
          activity={editActivityDialog.activity}
          activityCatalog={activityCatalog}
          onClose={() => setEditActivityDialog(null)}
          onSubmit={(data) => updateActivityMutation.mutate(data)}
          isPending={updateActivityMutation.isPending}
        />
      )}
    </Layout>

    <TrainingLoadWarningModal
      open={loadWarningModal.open}
      analysis={loadWarningModal.analysis}
      onClose={() => {
        _pendingLoadWarning = null;
        setLoadWarningModal({ open: false, analysis: null });
      }}
    />

    <TrainingBlockModal
      open={blockModalOpen}
      onClose={() => setBlockModalOpen(false)}
      initialBlock={activeBlock ?? null}
    />
  </>
  );
}

function AddExerciseDialog({
  open,
  sessionId,
  exerciseCatalog,
  onClose,
  onSubmit,
  isPending,
}: {
  open: boolean;
  sessionId: number;
  exerciseCatalog: ExerciseCatalogItem[];
  onClose: () => void;
  onSubmit: (data: {
    sessionId: number;
    exerciseCatalogId?: number;
    name: string;
  }) => void;
  isPending: boolean;
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedExercise, setSelectedExercise] =
    useState<ExerciseCatalogItem | null>(null);
  const [customName, setCustomName] = useState("");

  const handleSubmit = () => {
    if (selectedExercise) {
      onSubmit({
        sessionId,
        exerciseCatalogId: selectedExercise.id,
        name: selectedExercise.name,
      });
    } else if (customName.trim()) {
      onSubmit({
        sessionId,
        name: customName.trim(),
      });
    }
    setSelectedExercise(null);
    setCustomName("");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Add Exercise</DialogTitle>
          <DialogDescription>
            Search for an exercise or enter a custom name
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Select Exercise</Label>
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between"
                  data-testid="button-exercise-search"
                >
                  {selectedExercise
                    ? selectedExercise.name
                    : "Search exercises..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent 
                  className="w-full p-0"
                  onWheelCapture={(e) => e.stopPropagation()}
                  onTouchMove={(e) => e.stopPropagation()}
                >
                <Command>
                  <CommandInput placeholder="Search exercises..." />
                  <CommandList className="max-h-[320px] overflow-y-auto overscroll-contain touch-pan-y pointer-events-auto">
                    <CommandEmpty>No exercise found.</CommandEmpty>
                    <CommandGroup>
                      {exerciseCatalog.map((exercise) => (
                        <CommandItem
                          key={exercise.id}
                          value={exercise.name}
                          onSelect={() => {
                            setSelectedExercise(exercise);
                            setCustomName("");
                            setSearchOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedExercise?.id === exercise.id
                                ? "opacity-100"
                                : "opacity-0"
                            )}
                          />
                          <div>
                            <span>{exercise.name}</span>
                            <span className="text-xs text-muted-foreground ml-2">
                              {exercise.primaryMuscle}
                            </span>
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>
          <div className="text-center text-sm text-muted-foreground">or</div>
          <div>
            <Label htmlFor="customName">Custom Exercise Name</Label>
            <Input
              id="customName"
              placeholder="e.g., Cable Kickback"
              value={customName}
              onChange={(e) => {
                setCustomName(e.target.value);
                setSelectedExercise(null);
              }}
              data-testid="input-custom-exercise"
            />
          </div>
          <Button
            onClick={handleSubmit}
            disabled={isPending || (!selectedExercise && !customName.trim())}
            className="w-full"
            data-testid="button-submit-exercise"
          >
            Add Exercise
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AddSetDialog({
  open,
  exerciseId,
  onClose,
  onSubmit,
  isPending,
}: {
  open: boolean;
  exerciseId: number;
  onClose: () => void;
  onSubmit: (data: {
    exerciseId: number;
    reps: number;
    weightKg?: number;
    rpe?: number;
    restSeconds?: number;
  }) => void;
  isPending: boolean;
}) {
  const [reps, setReps] = useState("");
  const [weightKg, setWeightKg] = useState("");
  const [rpe, setRpe] = useState("");
  const [restSeconds, setRestSeconds] = useState("");

  const handleSubmit = () => {
    if (!reps) return;
    onSubmit({
      exerciseId,
      reps: parseInt(reps),
      weightKg: weightKg ? parseFloat(weightKg) : undefined,
      rpe: rpe ? parseFloat(rpe) : undefined,
      restSeconds: restSeconds ? parseInt(restSeconds) : undefined,
    });
    setReps("");
    setWeightKg("");
    setRpe("");
    setRestSeconds("");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Add Set</DialogTitle>
          <DialogDescription>Log a set for this exercise</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="reps">Reps *</Label>
              <Input
                id="reps"
                type="number"
                placeholder="e.g., 10"
                value={reps}
                onChange={(e) => setReps(e.target.value)}
                data-testid="input-reps"
              />
            </div>
            <div>
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input
                id="weight"
                type="number"
                step="0.5"
                placeholder="e.g., 60"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                data-testid="input-weight"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="rpe">RPE (1-10)</Label>
              <Input
                id="rpe"
                type="number"
                step="0.5"
                min="1"
                max="10"
                placeholder="e.g., 8"
                value={rpe}
                onChange={(e) => setRpe(e.target.value)}
                data-testid="input-rpe"
              />
            </div>
            <div>
              <Label htmlFor="rest">Rest (seconds)</Label>
              <Input
                id="rest"
                type="number"
                placeholder="e.g., 90"
                value={restSeconds}
                onChange={(e) => setRestSeconds(e.target.value)}
                data-testid="input-rest"
              />
            </div>
          </div>
          <Button
            onClick={handleSubmit}
            disabled={isPending || !reps}
            className="w-full"
            data-testid="button-submit-set"
          >
            Add Set
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const ACTIVITY_SEARCH_ALIASES: Record<string, string[]> = {
  "Strength Training": ["strength", "weights", "lifting", "weightlifting", "resistance"],
  "Weight Lifting": ["weights", "lifting", "weightlifting", "strength", "resistance"],
};

function EditActivityDialog({
  open,
  activity,
  activityCatalog,
  onClose,
  onSubmit,
  isPending,
}: {
  open: boolean;
  activity: any;
  activityCatalog: ActivityCatalogItem[];
  onClose: () => void;
  onSubmit: (data: {
    id: number;
    name: string;
    durationMinutes: number;
    intensity: string;
    metValue: number;
    activityType: string;
    activityCatalogId?: number;
    sessionRpe?: number;
    bodyRegion?: string;
    rpe?: number;
  }) => void;
  isPending: boolean;
}) {
  // Pre-select the catalog item if one is linked
  const initialCatalogItem = activity.activityCatalogId
    ? activityCatalog.find((a) => a.id === activity.activityCatalogId) ?? null
    : null;

  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<ActivityCatalogItem | null>(initialCatalogItem);
  // For custom-name activities, strip any prefixes added at creation time
  const strippedName = (activity.name as string)
    .replace(/^\[Lifting\] /, "")
    .replace(/^\[Manual\] /, "");
  const [customName, setCustomName] = useState(activity.activityCatalogId ? "" : strippedName);
  const [durationMinutes, setDurationMinutes] = useState(String(activity.durationMinutes ?? ""));
  const [intensity, setIntensity] = useState<Intensity>((activity.intensity || "moderate") as Intensity);
  const [customMet, setCustomMet] = useState(String(activity.metValue ?? "5.0"));
  const [sessionRpe, setSessionRpe] = useState(String(activity.sessionRpe ?? "7"));
  const [bodyRegion, setBodyRegion] = useState<"upper" | "lower" | "full">(
    (activity.bodyRegion || "full") as "upper" | "lower" | "full"
  );
  // universal RPE (pre-fill from stored value if available)
  const [rpe, setRpe] = useState(activity.rpe != null ? String(activity.rpe) : "");

  // A catalog item is "lifting" when its metValue sentinel is 0.
  // For existing lifting rows without a matched catalog item, fall back on activityType.
  const isLiftingActivity = selectedActivity
    ? selectedActivity.metValue === 0
    : activity.activityType === "lifting";

  const handleSubmit = () => {
    if (!durationMinutes) return;
    const duration = parseInt(durationMinutes);
    const rpeVal = rpe ? parseFloat(rpe) : undefined;

    if (selectedActivity) {
      if (isLiftingActivity) {
        const srpe = parseFloat(sessionRpe) || 7;
        onSubmit({
          id: activity.id,
          activityCatalogId: selectedActivity.id,
          name: `[Lifting] ${selectedActivity.name}`,
          durationMinutes: duration,
          intensity: "moderate",
          metValue: 0,
          activityType: "lifting",
          sessionRpe: srpe,
          bodyRegion,
          rpe: srpe,
        });
      } else {
        onSubmit({
          id: activity.id,
          activityCatalogId: selectedActivity.id,
          name: selectedActivity.name,
          durationMinutes: duration,
          intensity: selectedActivity.intensity,
          metValue: selectedActivity.metValue,
          activityType: "cardio",
          rpe: rpeVal,
        });
      }
    } else {
      // Custom / free-text activity (no catalog match)
      const name = customName.trim() || strippedName;
      if (isLiftingActivity) {
        const srpe = parseFloat(sessionRpe) || 7;
        onSubmit({
          id: activity.id,
          name: `[Lifting] ${name}`,
          durationMinutes: duration,
          intensity: "moderate",
          metValue: 0,
          activityType: "lifting",
          sessionRpe: srpe,
          bodyRegion,
          rpe: srpe,
        });
      } else {
        onSubmit({
          id: activity.id,
          name,
          durationMinutes: duration,
          intensity,
          metValue: parseFloat(customMet) || 5.0,
          activityType: "cardio",
          rpe: rpeVal,
        });
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Edit Activity</DialogTitle>
          <DialogDescription>
            Update activity details and recalculate calories
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          {/* Catalog selector */}
          <div>
            <Label>Activity</Label>
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between"
                  data-testid="button-edit-activity-search"
                >
                  {selectedActivity
                    ? selectedActivity.metValue === 0
                      ? selectedActivity.name
                      : `${selectedActivity.name} (MET ${selectedActivity.metValue})`
                    : customName || strippedName || "Search activities..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent
                className="w-full p-0"
                onWheelCapture={(e) => e.stopPropagation()}
                onTouchMove={(e) => e.stopPropagation()}
              >
                <Command>
                  <CommandInput placeholder="Search activities..." />
                  <CommandList className="max-h-[320px] overflow-y-auto overscroll-contain touch-pan-y pointer-events-auto">
                    <CommandEmpty>No activity found.</CommandEmpty>
                    <CommandGroup>
                      {activityCatalog.map((cat) => (
                        <CommandItem
                          key={cat.id}
                          value={cat.name}
                          keywords={[cat.name, ...(ACTIVITY_SEARCH_ALIASES[cat.name] ?? [])]}
                          onSelect={() => {
                            setSelectedActivity(cat);
                            setCustomName("");
                            setSearchOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedActivity?.id === cat.id ? "opacity-100" : "opacity-0"
                            )}
                          />
                          <div className="flex items-center gap-2">
                            {cat.metValue === 0 && <Dumbbell className="h-3.5 w-3.5 text-muted-foreground" />}
                            <span>{cat.name}</span>
                            {cat.metValue > 0 && (
                              <Badge variant="outline" className="text-xs">MET {cat.metValue}</Badge>
                            )}
                            {cat.metValue === 0 && (
                              <Badge variant="secondary" className="text-xs">Lifting</Badge>
                            )}
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Lifting-specific fields */}
          {isLiftingActivity && (
            <div className="space-y-3 p-3 rounded-lg bg-secondary/30 border border-border/30">
              <p className="text-xs font-medium text-muted-foreground">Session RPE method — training load = duration × RPE × region multiplier</p>
              <div>
                <Label htmlFor="edit-session-rpe">Session RPE (1–10)</Label>
                <Input
                  id="edit-session-rpe"
                  type="number"
                  min="1"
                  max="10"
                  step="0.5"
                  value={sessionRpe}
                  onChange={(e) => setSessionRpe(e.target.value)}
                  data-testid="input-edit-session-rpe"
                />
                <p className="text-[10px] text-muted-foreground mt-1">1 = very easy, 10 = maximal</p>
              </div>
              <div>
                <Label>Body Region</Label>
                <Select value={bodyRegion} onValueChange={(v) => setBodyRegion(v as "upper" | "lower" | "full")}>
                  <SelectTrigger data-testid="select-edit-body-region">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upper">Upper Body (×1.0)</SelectItem>
                    <SelectItem value="lower">Lower Body (×1.25)</SelectItem>
                    <SelectItem value="full">Full Body (×1.1)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Cardio custom-activity fields (only when no catalog item selected) */}
          {!isLiftingActivity && !selectedActivity && (
            <div className="space-y-3">
              <div>
                <Label htmlFor="edit-custom-name">Activity Name</Label>
                <Input
                  id="edit-custom-name"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  data-testid="input-edit-custom-activity"
                />
              </div>
              <div>
                <Label>Intensity</Label>
                <Select value={intensity} onValueChange={(v) => setIntensity(v as Intensity)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="vigorous">Vigorous</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-met">MET Value</Label>
                <Input
                  id="edit-met"
                  type="number"
                  step="0.1"
                  value={customMet}
                  onChange={(e) => setCustomMet(e.target.value)}
                  data-testid="input-edit-met"
                />
                <p className="text-xs text-muted-foreground mt-1">Default: 5.0 (moderate activity)</p>
              </div>
            </div>
          )}

          {/* Duration — always visible */}
          <div>
            <Label htmlFor="edit-activity-duration">Duration (minutes)</Label>
            <Input
              id="edit-activity-duration"
              type="number"
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(e.target.value)}
              data-testid="input-edit-activity-duration"
            />
          </div>

          {/* Universal RPE — shown for all non-lifting activities */}
          {!isLiftingActivity && (
            <div>
              <Label htmlFor="edit-activity-rpe">Effort (RPE) — optional</Label>
              <Input
                id="edit-activity-rpe"
                type="number"
                min="1"
                max="10"
                step="0.5"
                placeholder="1–10"
                value={rpe}
                onChange={(e) => setRpe(e.target.value)}
                data-testid="input-edit-activity-rpe"
              />
              <p className="text-[10px] text-muted-foreground mt-1">1 = very easy · 10 = max effort</p>
            </div>
          )}

          <Button
            onClick={handleSubmit}
            disabled={
              isPending ||
              !durationMinutes ||
              (isLiftingActivity && (!sessionRpe || parseFloat(sessionRpe) < 1 || parseFloat(sessionRpe) > 10))
            }
            className="w-full"
            data-testid="button-save-activity-changes"
          >
            {isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AddActivityDialog({
  open,
  sessionId,
  activityCatalog,
  onClose,
  onSubmit,
  isPending,
}: {
  open: boolean;
  sessionId: number;
  activityCatalog: ActivityCatalogItem[];
  onClose: () => void;
  onSubmit: (data: {
    sessionId: number;
    activityCatalogId?: number;
    name: string;
    durationMinutes: number;
    intensity: Intensity;
    metValue: number;
    activityType?: string;
    sessionRpe?: number;
    bodyRegion?: string;
    rpe?: number;
  }) => void;
  isPending: boolean;
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] =
    useState<ActivityCatalogItem | null>(null);
  const [customName, setCustomName] = useState("");
  const [durationMinutes, setDurationMinutes] = useState("");
  const [intensity, setIntensity] = useState<Intensity>("moderate");
  const [customMet, setCustomMet] = useState("5.0");
  const [sessionRpe, setSessionRpe] = useState("7");
  const [bodyRegion, setBodyRegion] = useState<"upper" | "lower" | "full">("full");
  const [rpe, setRpe] = useState("");

  const isLiftingActivity = selectedActivity ? selectedActivity.metValue === 0 : false;

  const handleSubmit = () => {
    if (!durationMinutes) return;
    const duration = parseInt(durationMinutes);
    const rpeVal = rpe ? parseFloat(rpe) : undefined;

    if (selectedActivity) {
      if (isLiftingActivity) {
        const srpe = parseFloat(sessionRpe) || 7;
        onSubmit({
          sessionId,
          activityCatalogId: selectedActivity.id,
          name: selectedActivity.name,
          durationMinutes: duration,
          intensity: "moderate",
          metValue: 0,
          activityType: "lifting",
          sessionRpe: srpe,
          bodyRegion,
          rpe: srpe, // mirror sessionRpe as the universal effort field
        });
      } else {
        onSubmit({
          sessionId,
          activityCatalogId: selectedActivity.id,
          name: selectedActivity.name,
          durationMinutes: duration,
          intensity: selectedActivity.intensity as Intensity,
          metValue: selectedActivity.metValue,
          rpe: rpeVal,
        });
      }
    } else if (customName.trim()) {
      onSubmit({
        sessionId,
        name: customName.trim(),
        durationMinutes: duration,
        intensity,
        metValue: parseFloat(customMet) || 5.0,
        rpe: rpeVal,
      });
    }
    setSelectedActivity(null);
    setCustomName("");
    setDurationMinutes("");
    setIntensity("moderate");
    setCustomMet("5.0");
    setSessionRpe("7");
    setBodyRegion("full");
    setRpe("");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-display">Add Activity</DialogTitle>
          <DialogDescription>
            Add a cardio, sports, or strength activity
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Select Activity</Label>
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between"
                  data-testid="button-activity-search"
                >
                  {selectedActivity
                    ? selectedActivity.metValue === 0
                      ? `${selectedActivity.name}`
                      : `${selectedActivity.name} (MET ${selectedActivity.metValue})`
                    : "Search activities..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent 
                  className="w-full p-0" 
                  onWheelCapture={(e) => e.stopPropagation()}
                  onTouchMove={(e) => e.stopPropagation()}
                >
                <Command>
                  <CommandInput placeholder="Search activities..." />
                  <CommandList className="max-h-[320px] overflow-y-auto overscroll-contain touch-pan-y pointer-events-auto">
                    <CommandEmpty>No activity found.</CommandEmpty>
                    <CommandGroup>
                      {activityCatalog.map((activity) => (
                        <CommandItem
                          key={activity.id}
                          value={activity.name}
                          keywords={[activity.name, ...(ACTIVITY_SEARCH_ALIASES[activity.name] ?? [])]}
                          onSelect={() => {
                            setSelectedActivity(activity);
                            setCustomName("");
                            setSearchOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedActivity?.id === activity.id
                                ? "opacity-100"
                                : "opacity-0"
                            )}
                          />
                          <div className="flex items-center gap-2">
                            {activity.metValue === 0 && <Dumbbell className="h-3.5 w-3.5 text-muted-foreground" />}
                            <span>{activity.name}</span>
                            {activity.metValue > 0 && (
                              <Badge
                                variant="outline"
                                className="text-xs"
                              >
                                MET {activity.metValue}
                              </Badge>
                            )}
                            {activity.metValue === 0 && (
                              <Badge
                                variant="secondary"
                                className="text-xs"
                              >
                                Lifting
                              </Badge>
                            )}
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {isLiftingActivity && (
            <div className="space-y-3 p-3 rounded-lg bg-secondary/30 border border-border/30">
              <p className="text-xs font-medium text-muted-foreground">Session RPE method — training load = duration × RPE × region multiplier</p>
              <div>
                <Label htmlFor="sessionRpe">Session RPE (1–10) *</Label>
                <Input
                  id="sessionRpe"
                  type="number"
                  min="1"
                  max="10"
                  step="0.5"
                  placeholder="e.g., 7"
                  value={sessionRpe}
                  onChange={(e) => setSessionRpe(e.target.value)}
                  data-testid="input-session-rpe"
                />
                <p className="text-[10px] text-muted-foreground mt-1">How hard was the session overall? 1 = very easy, 10 = maximal</p>
              </div>
              <div>
                <Label>Body Region</Label>
                <Select value={bodyRegion} onValueChange={(v) => setBodyRegion(v as "upper" | "lower" | "full")}>
                  <SelectTrigger data-testid="select-body-region">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upper">Upper Body (×1.0)</SelectItem>
                    <SelectItem value="lower">Lower Body (×1.25)</SelectItem>
                    <SelectItem value="full">Full Body (×1.1)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {!isLiftingActivity && (
            <>
              <div className="text-center text-sm text-muted-foreground">or</div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="customActivityName">Custom Activity Name</Label>
                  <Input
                    id="customActivityName"
                    placeholder="e.g., Swimming"
                    value={customName}
                    onChange={(e) => {
                      setCustomName(e.target.value);
                      setSelectedActivity(null);
                    }}
                    data-testid="input-custom-activity"
                  />
                </div>
                {customName && (
                  <>
                    <div>
                      <Label>Intensity</Label>
                      <Select
                        value={intensity}
                        onValueChange={(v) => setIntensity(v as Intensity)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="light">Light</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="vigorous">Vigorous</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="customMet">MET Value</Label>
                      <Input
                        id="customMet"
                        type="number"
                        step="0.1"
                        value={customMet}
                        onChange={(e) => setCustomMet(e.target.value)}
                        data-testid="input-met"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Default: 5.0 (moderate activity)
                      </p>
                    </div>
                  </>
                )}
              </div>
            </>
          )}

          <div>
            <Label htmlFor="activityDuration">Duration (minutes) *</Label>
            <Input
              id="activityDuration"
              type="number"
              placeholder="e.g., 60"
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(e.target.value)}
              data-testid="input-activity-duration"
            />
          </div>

          {!isLiftingActivity && (
            <div>
              <Label htmlFor="add-activity-rpe">Effort (RPE) — optional</Label>
              <Input
                id="add-activity-rpe"
                type="number"
                min="1"
                max="10"
                step="0.5"
                placeholder="1–10"
                value={rpe}
                onChange={(e) => setRpe(e.target.value)}
                data-testid="input-add-activity-rpe"
              />
              <p className="text-[10px] text-muted-foreground mt-1">1 = very easy · 10 = max effort</p>
            </div>
          )}

          <Button
            onClick={handleSubmit}
            disabled={
              isPending ||
              !durationMinutes ||
              (!selectedActivity && !customName.trim()) ||
              (isLiftingActivity && (!sessionRpe || parseFloat(sessionRpe) < 1 || parseFloat(sessionRpe) > 10))
            }
            className="w-full"
            data-testid="button-submit-activity"
          >
            {isLiftingActivity ? "Add Lifting Session" : "Add Activity"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
