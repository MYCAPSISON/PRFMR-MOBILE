import { useState, useEffect, useRef } from "react";
import { useOnboard, useUser } from "@/hooks/use-user";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronRight, ChevronLeft, Check, Utensils, Zap } from "lucide-react";
import type { OnboardingData } from "@shared/schema";
import { useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { USER_ME_QUERY_KEY } from "@/hooks/use-user";

const SPLASH_SEEN_KEY = "prfmr_splash_seen";
const STEPS = ["Basics", "Body Metrics", "Lifestyle", "Goal"];
const DEV = import.meta.env.DEV;

export default function OnboardingPage() {
  const { data: profileUser } = useUser();
  const isRecalculate = useRef(
    typeof window !== "undefined" && new URLSearchParams(window.location.search).has("recalculate")
  ).current;

  const splashAlreadySeen = useRef(
    typeof window !== "undefined" && !!localStorage.getItem(SPLASH_SEEN_KEY)
  ).current;

  // -1 = splash screen (first-time only); 0..3 = form steps; 4 = success
  const initialStep = isRecalculate || splashAlreadySeen ? 0 : -1;
  const [step, setStep] = useState(initialStep);

  const [formData, setFormData] = useState<Partial<OnboardingData>>({
    experienceLevel: "beginner",
    activityLevel: "moderate",
    goal: "fat_loss",
  });
  const [seeded, setSeeded] = useState(false);

  useEffect(() => {
    if (isRecalculate && profileUser && !seeded) {
      if (DEV) console.log("[onboarding] recalc started — seeding form from profile");
      setFormData({
        age: profileUser.age ?? undefined,
        gender: profileUser.gender ?? undefined,
        height: profileUser.height ?? undefined,
        currentWeight: profileUser.currentWeight ?? undefined,
        activityLevel: profileUser.activityLevel ?? "moderate",
        goal: profileUser.goal ?? "fat_loss",
        experienceLevel: profileUser.experienceLevel ?? "beginner",
      });
      setSeeded(true);
    }
  }, [isRecalculate, profileUser, seeded]);

  const { mutate, isPending } = useOnboard();
  const [, setLocation] = useLocation();

  const handleNext = async () => {
    if (step === -1) {
      localStorage.setItem(SPLASH_SEEN_KEY, "1");
      setStep(0);
      return;
    }
    if (step < STEPS.length - 1) {
      setStep(s => s + 1);
    } else if (step === STEPS.length) {
      if (DEV) console.log("[onboarding] success screen -> navigating to /dashboard (replace)");
      setLocation("/dashboard", { replace: true });
    } else {
      if (DEV) console.log("[onboarding] final submit, mode:", isRecalculate ? "recalculate" : "first-time");
      mutate(formData as OnboardingData, {
        onSuccess: async () => {
          if (isRecalculate) {
            if (DEV) console.log("[onboarding] recalc complete -> navigating to /dashboard (replace)");
            queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
            setLocation("/dashboard", { replace: true });
          } else {
            if (DEV) console.log("[onboarding] first-time complete -> showing success screen");
            await queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
            await queryClient.refetchQueries({ queryKey: USER_ME_QUERY_KEY });
            setStep(STEPS.length);
          }
        },
      });
    }
  };

  const handleBack = () => {
    setStep(s => Math.max(0, s - 1));
  };

  const updateField = (key: keyof OnboardingData, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const isSplash = step === -1;
  const isSuccess = step === STEPS.length;

  const progressPct = isSplash ? 0 : isSuccess ? 100 : ((step + 1) / STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {!isSplash && (
          <div className="mb-8">
            <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
              <span>{isSuccess ? "Setup Complete" : `Step ${step + 1} of ${STEPS.length}`}</span>
              <span>{isSuccess ? "Success" : STEPS[step]}</span>
            </div>
            <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${progressPct}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        )}

        <Card className="border-none shadow-xl shadow-black/5">
          <CardContent className="p-6 sm:p-8 relative overflow-visible">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 min-h-[300px] overflow-visible"
              >
                {/* Splash screen — shown once to new users */}
                {step === -1 && (
                  <div className="flex flex-col items-center justify-center text-center py-8 space-y-6">
                    <div className="h-20 w-20 bg-primary/10 rounded-full flex items-center justify-center">
                      <Zap className="h-10 w-10 text-primary" />
                    </div>
                    <div className="space-y-3">
                      <h2 className="text-3xl font-display font-bold">Welcome to PRFMR</h2>
                      <p className="text-muted-foreground text-base max-w-sm mx-auto">
                        Precision nutrition for athletes who take performance seriously.
                      </p>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-1.5 text-left w-full max-w-xs mx-auto">
                      <div className="flex items-center gap-2"><Check className="h-4 w-4 text-primary flex-shrink-0" /><span>Personalised macro targets</span></div>
                      <div className="flex items-center gap-2"><Check className="h-4 w-4 text-primary flex-shrink-0" /><span>Training calorie credits</span></div>
                      <div className="flex items-center gap-2"><Check className="h-4 w-4 text-primary flex-shrink-0" /><span>Micronutrient quality scoring</span></div>
                      <div className="flex items-center gap-2"><Check className="h-4 w-4 text-primary flex-shrink-0" /><span>Fight camp weight management</span></div>
                    </div>
                    <p className="text-[11px] text-muted-foreground/60 max-w-sm leading-relaxed">
                      Setup takes about 2 minutes. We'll personalise your targets right away.
                    </p>
                  </div>
                )}

                {step === 0 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">
                        {isRecalculate ? "Update Your Details" : "Tell us about yourself"}
                      </h2>
                      <p className="text-muted-foreground">
                        {isRecalculate ? "Review and update your information." : "Let's start with some simple details."}
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Age</Label>
                        <Input
                          type="number"
                          placeholder="Years"
                          value={formData.age || ""}
                          onChange={(e) => updateField("age", parseInt(e.target.value) || 0)}
                          data-testid="input-age"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Gender</Label>
                        <RadioGroup
                          value={formData.gender ?? undefined}
                          onValueChange={(v) => updateField("gender", v)}
                          className="grid grid-cols-2 gap-4"
                        >
                          <div>
                            <RadioGroupItem value="male" id="male" className="peer sr-only" />
                            <Label
                              htmlFor="male"
                              className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary peer-data-[state=checked]:text-primary-foreground cursor-pointer transition-all"
                              data-testid="radio-male"
                            >
                              Male
                            </Label>
                          </div>
                          <div>
                            <RadioGroupItem value="female" id="female" className="peer sr-only" />
                            <Label
                              htmlFor="female"
                              className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary peer-data-[state=checked]:text-primary-foreground cursor-pointer transition-all"
                              data-testid="radio-female"
                            >
                              Female
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </div>
                )}

                {step === 1 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Body Metrics</h2>
                      <p className="text-muted-foreground">This helps us calculate your baseline.</p>
                    </div>

                    <div className="grid gap-6">
                      <div className="space-y-2">
                        <Label>Height (cm)</Label>
                        <Input
                          type="number"
                          placeholder="e.g. 175"
                          value={formData.height || ""}
                          onChange={(e) => updateField("height", parseInt(e.target.value) || 0)}
                          data-testid="input-height"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Current Weight (kg)</Label>
                        <Input
                          type="number"
                          step="0.1"
                          placeholder="e.g. 70.5"
                          value={formData.currentWeight || ""}
                          onChange={(e) => updateField("currentWeight", parseFloat(e.target.value) || 0)}
                          data-testid="input-weight"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Lifestyle</h2>
                      <p className="text-muted-foreground">Be honest - this affects your calorie needs.</p>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Activity Level</Label>
                        <Select
                          value={formData.activityLevel ?? undefined}
                          onValueChange={(v) => updateField("activityLevel", v)}
                        >
                          <SelectTrigger className="h-12" data-testid="select-activity">
                            <SelectValue placeholder="Select activity level" />
                          </SelectTrigger>
                          <SelectContent position="popper" side="bottom" align="start" sideOffset={6} className="z-[9999]">
                            <SelectItem value="sedentary">Sedentary — desk job, little to no exercise</SelectItem>
                            <SelectItem value="light">Light — 1-2 sessions per week, mostly walking</SelectItem>
                            <SelectItem value="moderate">Moderate — 3-4 structured sessions per week</SelectItem>
                            <SelectItem value="active">Active — 5-6 sessions per week, consistent training</SelectItem>
                            <SelectItem value="very_active">Very Active — daily training or physical job + training</SelectItem>
                          </SelectContent>
                          <p className="text-xs text-muted-foreground mt-1">
                            Pick the level that best describes a typical week. Training sessions logged separately add calories on top.
                          </p>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Experience Level</Label>
                        <Select
                          value={formData.experienceLevel ?? undefined}
                          onValueChange={(v) => updateField("experienceLevel", v)}
                        >
                          <SelectTrigger className="h-12" data-testid="select-experience">
                            <SelectValue placeholder="Select experience" />
                          </SelectTrigger>
                          <SelectContent position="popper" side="bottom" align="start" sideOffset={6} className="z-[9999]">
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="rounded-lg border border-orange-500/40 bg-orange-500/10 px-4 py-3 flex items-start gap-2.5">
                        <Zap className="h-4 w-4 text-orange-400 mt-0.5 flex-shrink-0" />
                        <p className="text-xs text-orange-300 leading-relaxed">
                          Training sessions you log in the Training tab add real calorie credits on top of your TDEE — so your targets adjust automatically on hard days.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Primary Goal</h2>
                      <p className="text-muted-foreground">What are you aiming for?</p>
                    </div>

                    <RadioGroup
                      value={formData.goal ?? undefined}
                      onValueChange={(v) => updateField("goal", v)}
                      className="space-y-3"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="fat_loss" id="fat_loss" className="peer sr-only" />
                        <Label
                          htmlFor="fat_loss"
                          className="flex flex-1 items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary cursor-pointer transition-all"
                          data-testid="radio-fat-loss"
                        >
                          <div>
                            <div className="font-semibold">Make Weight</div>
                            <div className="text-xs text-muted-foreground">Conservative calorie deficit for sustainable results</div>
                          </div>
                          <Check className="h-4 w-4 opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="maintenance" id="maintenance" className="peer sr-only" />
                        <Label
                          htmlFor="maintenance"
                          className="flex flex-1 items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary cursor-pointer transition-all"
                          data-testid="radio-maintenance"
                        >
                          <div>
                            <div className="font-semibold">Maintenance</div>
                            <div className="text-xs text-muted-foreground">Eat at TDEE to maintain current weight</div>
                          </div>
                          <Check className="h-4 w-4 opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="weight_gain" id="weight_gain" className="peer sr-only" />
                        <Label
                          htmlFor="weight_gain"
                          className="flex flex-1 items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary cursor-pointer transition-all"
                          data-testid="radio-weight-gain"
                        >
                          <div>
                            <div className="font-semibold">Weight Gain</div>
                            <div className="text-xs text-muted-foreground">Modest surplus (~300 kcal) for lean muscle gain</div>
                          </div>
                          <Check className="h-4 w-4 opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                    </RadioGroup>

                    <p className="text-xs text-muted-foreground mt-4">
                      All modes use research-based targets. Training calories are added back at goal-specific rates (50-100%).
                    </p>
                  </div>
                )}

                {step === 4 && (
                  <div className="space-y-6 flex flex-col items-center justify-center text-center py-8">
                    <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                      <Check className="h-8 w-8 text-primary" />
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Your targets are set.</h2>
                      <p className="text-muted-foreground">Log your first meal to unlock your micro gaps.</p>
                    </div>

                    {formData.goal === "fat_loss" && (
                      <button
                        onClick={() => setLocation("/weight-cut", { replace: true })}
                        className="w-full rounded-lg border border-orange-500/40 bg-orange-500/10 px-4 py-3 text-left flex items-start gap-3 hover:bg-orange-500/15 transition-colors"
                        data-testid="button-setup-fight-camp"
                      >
                        <span className="text-xl">🥊</span>
                        <div>
                          <p className="text-sm font-semibold text-orange-400">Set up Fight Camp</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Have a fight date? Set your target weight and we'll build your cut plan.
                          </p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-orange-400/60 ml-auto mt-0.5 flex-shrink-0" />
                      </button>
                    )}

                    <p className="text-[11px] text-muted-foreground max-w-sm mt-4 leading-relaxed">
                      This app provides educational estimates only and does not offer medical, nutritional, or training advice. Intended for healthy individuals without medical conditions.
                    </p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-between mt-8 pt-4 border-t">
              {!isSuccess ? (
                <>
                  {isSplash ? (
                    <div />
                  ) : (
                    <Button
                      variant="ghost"
                      onClick={handleBack}
                      disabled={step === 0}
                      className="text-muted-foreground"
                      data-testid="button-back"
                    >
                      <ChevronLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                  )}
                  <Button onClick={handleNext} disabled={isPending} data-testid="button-next">
                    {isSplash
                      ? "Get Started"
                      : step === STEPS.length - 1
                        ? (isPending ? "Calculating..." : isRecalculate ? "Update Goals" : "Complete Setup")
                        : "Next Step"}
                    {!isSplash && step !== STEPS.length - 1 && <ChevronRight className="ml-2 h-4 w-4" />}
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => setLocation("/dashboard?openAddFood=true", { replace: true })}
                  className="w-full"
                  data-testid="button-log-first-meal-onboarding"
                >
                  <Utensils className="mr-2 h-4 w-4" />
                  Log first meal
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
