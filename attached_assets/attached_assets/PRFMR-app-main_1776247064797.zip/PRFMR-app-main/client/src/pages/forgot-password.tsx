import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Activity, Mail, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const { mutate, isPending } = useMutation({
    mutationFn: async (email: string) => {
      return apiRequest("POST", "/api/auth/forgot-password", { email });
    },
    onSuccess: () => {
      setSubmitted(true);
    },
    onError: () => {
      setSubmitted(true);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    mutate(email);
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-8 bg-background relative">
        <div className="w-full max-w-sm space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Activity className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              Reset password
            </h1>
            <p className="mt-3 text-muted-foreground">
              {submitted 
                ? "Check your email for reset instructions."
                : "Enter your email and we'll send you a reset link."}
            </p>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="space-y-6"
            >
              <div className="flex items-center gap-3 p-4 rounded-lg bg-muted">
                <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                <p className="text-sm text-foreground">
                  If that email is registered, you will receive a password reset link. Check your inbox and spam folder.
                </p>
              </div>
              <Link href="/">
                <Button
                  variant="outline"
                  className="w-full h-12 text-base"
                  data-testid="button-back-to-login"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Sign In
                </Button>
              </Link>
            </motion.div>
          ) : (
            <motion.form
              onSubmit={handleSubmit}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    data-testid="input-email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="h-12 pl-10"
                    required
                    autoComplete="email"
                  />
                </div>
              </div>
              <Button
                type="submit"
                data-testid="button-send-reset"
                disabled={isPending || !email}
                className="w-full h-12 text-base"
              >
                {isPending ? "Sending..." : "Send Reset Link"}
              </Button>
              <Link href="/">
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full h-12 text-base"
                  data-testid="link-back-to-login"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Sign In
                </Button>
              </Link>
            </motion.form>
          )}
        </div>
      </div>

      <div className="hidden lg:block relative bg-muted overflow-hidden">
        <div className="absolute inset-0 bg-zinc-900">
          <img 
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop"
            alt="Gym aesthetics"
            className="w-full h-full object-cover opacity-50 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-12">
            <p className="text-white font-display text-2xl max-w-md font-medium tracking-tight">
              Fuel performance. Recover better. Stay consistent.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
