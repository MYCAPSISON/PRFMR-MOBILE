import { useState } from "react";
import { useRegister } from "@/hooks/use-auth";
import { useUsernameValidation } from "@/hooks/use-username-validation";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Activity, Eye, EyeOff, Check, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function PasswordRequirement({ met, text }: { met: boolean; text: string }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      {met ? (
        <Check className="h-3 w-3 text-green-500" />
      ) : (
        <X className="h-3 w-3 text-muted-foreground" />
      )}
      <span className={met ? "text-green-500" : "text-muted-foreground"}>{text}</span>
    </div>
  );
}

function UsernameStatusIndicator({ status, error }: { status: string; error: string | null }) {
  if (status === "idle") return null;

  if (status === "checking") {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground" data-testid="text-username-checking">
        <Loader2 className="h-3 w-3 animate-spin" />
        <span>Checking availability...</span>
      </div>
    );
  }

  if (status === "available") {
    return (
      <div className="flex items-center gap-2 text-xs text-green-500" data-testid="text-username-available">
        <Check className="h-3 w-3" />
        <span>Username available</span>
      </div>
    );
  }

  if (status === "taken" || status === "invalid") {
    return (
      <div className="flex items-center gap-2 text-xs text-destructive" data-testid="text-username-error">
        <X className="h-3 w-3" />
        <span>{error}</span>
      </div>
    );
  }

  return null;
}

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");
  const { mutate, isPending } = useRegister();
  const [, setLocation] = useLocation();
  const username = useUsernameValidation();

  const hasMinLength = password.length >= 8;
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const passwordsMatch = password === confirmPassword && confirmPassword.length > 0;
  const isValidPassword = hasMinLength && hasLetter && hasNumber && passwordsMatch;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !username.isValid || !isValidPassword) return;
    setServerError("");
    
    mutate({ email, username: username.value, password }, {
      onSuccess: () => setLocation("/onboarding"),
      onError: (err: any) => {
        const msg = err?.message || "Registration failed";
        if (msg.toLowerCase().includes("username")) {
          username.reset(username.displayValue);
        }
        setServerError(msg);
      },
    });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-8 bg-background relative">
        <div className="w-full max-w-sm space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Activity className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              Create your account
            </h1>
            <p className="mt-3 text-muted-foreground">
              Start your fitness journey with personalized tracking.
            </p>
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            {serverError && (
              <div className="text-sm text-destructive bg-destructive/10 rounded-md p-3" data-testid="text-server-error">
                {serverError}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                data-testid="input-email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12"
                required
                autoComplete="email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                data-testid="input-username"
                type="text"
                placeholder="Choose a username"
                value={username.displayValue}
                onChange={(e) => username.onChange(e.target.value)}
                className="h-12"
                required
                autoComplete="username"
              />
              <UsernameStatusIndicator status={username.status} error={username.error} />
              {username.status === "idle" && !username.displayValue && (
                <p className="text-xs text-muted-foreground" data-testid="text-username-hint">
                  Choose a unique username. Letters, numbers, ".", "_" only.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  data-testid="input-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Create a password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 pr-10"
                  required
                  autoComplete="new-password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  data-testid="button-toggle-password"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <div className="space-y-1 pt-2">
                <PasswordRequirement met={hasMinLength} text="At least 8 characters" />
                <PasswordRequirement met={hasLetter} text="Contains a letter" />
                <PasswordRequirement met={hasNumber} text="Contains a number" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                data-testid="input-confirm-password"
                type={showPassword ? "text" : "password"}
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-12"
                required
                autoComplete="new-password"
              />
              {confirmPassword && (
                <PasswordRequirement met={passwordsMatch} text="Passwords match" />
              )}
            </div>
            <Button
              type="submit"
              data-testid="button-register"
              disabled={isPending || !email || !username.isValid || !isValidPassword}
              className="w-full h-12 text-base group"
            >
              {isPending ? "Creating account..." : "Create Account"}
              {!isPending && (
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              )}
            </Button>
            <p className="text-sm text-center text-muted-foreground pt-4">
              Already have an account?{" "}
              <Link href="/" className="text-primary hover:underline" data-testid="link-login">
                Sign in
              </Link>
            </p>
          </motion.form>
        </div>
      </div>

      <div className="hidden lg:block relative bg-muted overflow-hidden">
        <div className="absolute inset-0 bg-zinc-900">
           <img 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
            alt="Training aesthetics"
            className="w-full h-full object-cover opacity-50 mix-blend-overlay"
           />
           <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-12">
             <p className="text-white font-display text-2xl max-w-md font-medium tracking-tight">
               Track nutrition. Build strength. Transform your health.
             </p>
           </div>
        </div>
      </div>
    </div>
  );
}
