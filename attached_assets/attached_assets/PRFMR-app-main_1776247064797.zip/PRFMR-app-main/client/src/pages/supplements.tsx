import { useState, useMemo } from "react";
import { useUser } from "@/hooks/use-user";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Plus, Pencil, Trash2, Pill, Info } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Supplement, SupplementCatalogItem } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

const FORM_OPTIONS = ["pill", "capsule", "powder", "liquid", "tablet", "softgel", "gummy", "other"];
const DOSE_UNITS = ["mcg", "mg", "g", "IU", "ml", "serving", "CFU"];

export default function Supplements() {
  const { data: user, isLoading: userLoading } = useUser();
  const { toast } = useToast();
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editingSupplement, setEditingSupplement] = useState<Supplement | null>(null);

  const { data: supplements = [], isLoading: supplementsLoading } = useQuery<Supplement[]>({
    queryKey: ["/api/me/supplements"],
    enabled: !!user,
    queryFn: async () => {
      const res = await fetch("/api/me/supplements", { credentials: "include", cache: "no-store" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: catalog = [], isError: catalogError, error: catalogFetchError } = useQuery<SupplementCatalogItem[]>({
    queryKey: ["/api/supplement-catalog"],
    queryFn: async () => {
      console.log("[supplements][catalog] Fetching catalog...");
      const res = await fetch("/api/supplement-catalog", { credentials: "include", cache: "no-store" });
      if (!res.ok) {
        const errorText = await res.text().catch(() => "Unknown error");
        console.error("[supplements][catalog] Fetch failed:", res.status, errorText);
        throw new Error(`Failed to fetch catalog: ${res.status}`);
      }
      const data = await res.json();
      console.log("[supplements][catalog] Loaded", data.length, "supplements");
      return data;
    },
    retry: 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; brand?: string; form?: string; notes?: string; catalogId?: number; doseAmount?: number; doseUnit?: string }) => {
      return apiRequest("POST", "/api/supplements", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/supplements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/stacks/scheduled"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"], exact: false });
      setAddOpen(false);
      toast({ title: "Supplement added" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; name?: string; brand?: string; form?: string; notes?: string; catalogId?: number | null; doseAmount?: number | null; doseUnit?: string | null }) => {
      return apiRequest("PATCH", `/api/supplements/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/supplements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/stacks/scheduled"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"], exact: false });
      setEditOpen(false);
      setEditingSupplement(null);
      toast({ title: "Supplement updated" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/supplements/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/supplements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/stacks/scheduled"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score"], exact: false });
      queryClient.invalidateQueries({ queryKey: ["/api/me/amqs/score-range"], exact: false });
      toast({ title: "Supplement deleted" });
    },
  });

  if (userLoading) {
    return (
      <Layout>
        <Skeleton className="h-[200px] w-full rounded-xl" />
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between pb-4 border-b">
          <div>
            <h1 className="text-2xl font-display font-bold">My Supplements</h1>
            <p className="text-muted-foreground">Track your personal supplement inventory</p>
          </div>
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-supplement">
                <Plus className="mr-2 h-4 w-4" /> Add Supplement
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="font-display">Add New Supplement</DialogTitle>
              </DialogHeader>
              <AddSupplementForm 
                catalog={catalog}
                onSubmit={(data) => createMutation.mutate(data)}
                isPending={createMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>

        {catalogError && (
          <Card className="border-destructive/50 bg-destructive/5">
            <CardContent className="flex items-start gap-3 pt-4">
              <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-destructive">Catalog Load Error</p>
                <p className="text-muted-foreground">
                  Failed to load the supplement catalog. You can still add custom supplements.
                  {catalogFetchError instanceof Error && (
                    <span className="block text-xs mt-1">Error: {catalogFetchError.message}</span>
                  )}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="rounded-lg border border-border/40 bg-secondary/20 px-4 py-3 space-y-2" data-testid="supplements-explainer">
          <p className="text-xs font-semibold text-foreground">How Supplements work</p>
          <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
            <li>Add a supplement once (name, dose).</li>
            <li>Set an optional daily reminder time for each supplement.</li>
            <li>Scheduled supplements appear on the Dashboard — tick off as you take them.</li>
          </ol>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your Supplements</CardTitle>
            <CardDescription>
              {supplements.length === 0 
                ? "No supplements added yet. Add your first supplement to get started."
                : `${supplements.length} supplement${supplements.length === 1 ? '' : 's'} in your inventory`
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {supplementsLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            ) : supplements.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
                <Pill className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No supplements yet</p>
                <p className="text-sm">Click "Add Supplement" to get started</p>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence>
                  {supplements.map((supp) => (
                    <motion.div
                      key={supp.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="flex items-center justify-between p-4 rounded-lg border bg-secondary/30 group"
                      data-testid={`supplement-item-${supp.id}`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium">{supp.name}</p>
                          {supp.doseAmount && supp.doseUnit && (
                            <Badge variant="outline" className="text-[10px]">{supp.doseAmount} {supp.doseUnit}</Badge>
                          )}
                          {supp.form && (
                            <Badge variant="secondary" className="text-[10px] capitalize">{supp.form}</Badge>
                          )}
                          {supp.catalogId && (
                            <Badge variant="default" className="text-[10px]">AMQS tracked</Badge>
                          )}
                        </div>
                        {supp.catalogId && (
                          <p className="text-xs text-muted-foreground/60 mt-0.5">Contributing to your AMQS score</p>
                        )}
                        {supp.reminderEnabled && supp.reminderTime && (
                          <p className="text-xs text-primary/70 mt-0.5">⏰ Daily reminder at {supp.reminderTime}</p>
                        )}
                        <div className="text-sm text-muted-foreground mt-1">
                          {supp.brand && <span>{supp.brand}</span>}
                          {supp.notes && <span className="block text-xs mt-1 italic">{supp.notes}</span>}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => {
                            setEditingSupplement(supp);
                            setEditOpen(true);
                          }}
                          data-testid={`button-edit-supplement-${supp.id}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                          onClick={() => deleteMutation.mutate(supp.id)}
                          data-testid={`button-delete-supplement-${supp.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={editOpen} onOpenChange={(open) => {
          setEditOpen(open);
          if (!open) setEditingSupplement(null);
        }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">Edit Supplement</DialogTitle>
            </DialogHeader>
            {editingSupplement && (
              <EditSupplementForm
                supplement={editingSupplement}
                catalog={catalog}
                onSubmit={(data) => updateMutation.mutate({ id: editingSupplement.id, ...data })}
                isPending={updateMutation.isPending}
              />
            )}
          </DialogContent>
        </Dialog>

        <p className="text-xs text-muted-foreground/50 italic text-center pb-4">
          For tracking purposes only — not medical advice. Consult a healthcare professional before starting any supplement regimen.
        </p>
      </div>
    </Layout>
  );
}

function AddSupplementForm({ 
  catalog,
  onSubmit, 
  isPending 
}: { 
  catalog: SupplementCatalogItem[];
  onSubmit: (data: { name: string; brand?: string; form?: string; notes?: string; catalogId?: number; doseAmount?: number; doseUnit?: string; reminderEnabled?: boolean; reminderTime?: string }) => void;
  isPending: boolean;
}) {
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [form, setForm] = useState("");
  const [notes, setNotes] = useState("");
  const [catalogId, setCatalogId] = useState<number | null>(null);
  const [doseAmount, setDoseAmount] = useState("");
  const [doseUnit, setDoseUnit] = useState("");
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState("08:00");

  const selectedCatalogItem = useMemo(() => 
    catalog.find(c => c.id === catalogId), 
    [catalog, catalogId]
  );

  const handleCatalogSelect = (value: string) => {
    if (value === "custom") {
      setCatalogId(null);
      setDoseUnit("");
      return;
    }
    const id = parseInt(value);
    const item = catalog.find(c => c.id === id);
    if (item) {
      setCatalogId(id);
      setName(item.name);
      setDoseUnit(item.defaultUnit);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({
      name: name.trim(),
      brand: brand.trim() || undefined,
      form: form || undefined,
      notes: notes.trim() || undefined,
      catalogId: catalogId || undefined,
      doseAmount: doseAmount ? parseFloat(doseAmount) : undefined,
      doseUnit: doseUnit || undefined,
      reminderEnabled,
      reminderTime: reminderEnabled ? reminderTime : undefined,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Select from Catalog (optional)</Label>
        <Select value={catalogId?.toString() || "custom"} onValueChange={handleCatalogSelect}>
          <SelectTrigger data-testid="select-catalog">
            <SelectValue placeholder="Choose from catalog or add custom" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="custom">Custom Supplement</SelectItem>
            {catalog.map((item) => (
              <SelectItem key={item.id} value={item.id.toString()}>{item.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedCatalogItem && (
          <div className="flex items-start gap-2 text-xs text-muted-foreground bg-secondary/50 p-2 rounded">
            <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
            <span>{selectedCatalogItem.notes || "This supplement's micronutrients will be tracked for AMQS."}</span>
          </div>
        )}
      </div>
      <div className="space-y-2">
        <Label htmlFor="name">Supplement Name *</Label>
        <Input 
          id="name" 
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          placeholder="e.g., Vitamin D3"
          required
          data-testid="input-supplement-name"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="doseAmount">Dose Amount</Label>
          <Input 
            id="doseAmount" 
            type="number"
            step="any"
            value={doseAmount} 
            onChange={(e) => setDoseAmount(e.target.value)} 
            placeholder="e.g., 25"
            data-testid="input-dose-amount"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="doseUnit">Dose Unit</Label>
          <Select value={doseUnit} onValueChange={setDoseUnit}>
            <SelectTrigger data-testid="select-dose-unit">
              <SelectValue placeholder="Unit" />
            </SelectTrigger>
            <SelectContent>
              {DOSE_UNITS.map((unit) => (
                <SelectItem key={unit} value={unit}>{unit}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="brand">Brand (optional)</Label>
        <Input 
          id="brand" 
          value={brand} 
          onChange={(e) => setBrand(e.target.value)} 
          placeholder="e.g., Nature Made"
          data-testid="input-supplement-brand"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="form">Form (optional)</Label>
        <Select value={form} onValueChange={setForm}>
          <SelectTrigger data-testid="select-supplement-form">
            <SelectValue placeholder="Select form" />
          </SelectTrigger>
          <SelectContent>
            {FORM_OPTIONS.map((opt) => (
              <SelectItem key={opt} value={opt} className="capitalize">{opt}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="notes">Notes (optional)</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Any personal notes..."
          className="resize-none"
          data-testid="input-supplement-notes"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>Daily Reminder</Label>
          <button
            type="button"
            role="switch"
            aria-checked={reminderEnabled}
            onClick={() => setReminderEnabled(!reminderEnabled)}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${reminderEnabled ? "bg-primary" : "bg-secondary"}`}
            data-testid="toggle-reminder-enabled"
          >
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${reminderEnabled ? "translate-x-4" : "translate-x-1"}`} />
          </button>
        </div>
        {reminderEnabled && (
          <Input
            type="time"
            value={reminderTime}
            onChange={(e) => setReminderTime(e.target.value)}
            className="w-auto"
            data-testid="input-reminder-time"
          />
        )}
      </div>

      <DialogFooter>
        <Button type="submit" disabled={isPending || !name.trim()} data-testid="button-save-supplement">
          {isPending ? "Adding..." : "Add Supplement"}
        </Button>
      </DialogFooter>
    </form>
  );
}

function EditSupplementForm({
  supplement,
  catalog,
  onSubmit,
  isPending,
}: {
  supplement: Supplement;
  catalog: SupplementCatalogItem[];
  onSubmit: (data: { name?: string; brand?: string; form?: string; notes?: string; catalogId?: number | null; doseAmount?: number | null; doseUnit?: string | null; reminderEnabled?: boolean; reminderTime?: string | null }) => void;
  isPending: boolean;
}) {
  const [name, setName] = useState(supplement.name);
  const [brand, setBrand] = useState(supplement.brand || "");
  const [form, setForm] = useState(supplement.form || "");
  const [notes, setNotes] = useState(supplement.notes || "");
  const [catalogId, setCatalogId] = useState<number | null>(supplement.catalogId || null);
  const [doseAmount, setDoseAmount] = useState(supplement.doseAmount?.toString() || "");
  const [doseUnit, setDoseUnit] = useState(supplement.doseUnit || "");
  const [reminderEnabled, setReminderEnabled] = useState(supplement.reminderEnabled ?? false);
  const [reminderTime, setReminderTime] = useState(supplement.reminderTime || "08:00");

  const selectedCatalogItem = useMemo(() => 
    catalog.find(c => c.id === catalogId), 
    [catalog, catalogId]
  );

  const handleCatalogSelect = (value: string) => {
    if (value === "custom") {
      setCatalogId(null);
      return;
    }
    const id = parseInt(value);
    const item = catalog.find(c => c.id === id);
    if (item) {
      setCatalogId(id);
      setName(item.name);
      if (!doseUnit) setDoseUnit(item.defaultUnit);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({
      name: name.trim(),
      brand: brand.trim() || undefined,
      form: form || undefined,
      notes: notes.trim() || undefined,
      catalogId: catalogId || null,
      doseAmount: doseAmount ? parseFloat(doseAmount) : null,
      doseUnit: doseUnit || null,
      reminderEnabled,
      reminderTime: reminderEnabled ? reminderTime : null,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Select from Catalog (optional)</Label>
        <Select value={catalogId?.toString() || "custom"} onValueChange={handleCatalogSelect}>
          <SelectTrigger>
            <SelectValue placeholder="Choose from catalog or add custom" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="custom">Custom Supplement</SelectItem>
            {catalog.map((item) => (
              <SelectItem key={item.id} value={item.id.toString()}>{item.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedCatalogItem && (
          <div className="flex items-start gap-2 text-xs text-muted-foreground bg-secondary/50 p-2 rounded">
            <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
            <span>{selectedCatalogItem.notes || "This supplement's micronutrients will be tracked for AMQS."}</span>
          </div>
        )}
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-name">Supplement Name *</Label>
        <Input id="edit-name" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="edit-doseAmount">Dose Amount</Label>
          <Input 
            id="edit-doseAmount" 
            type="number"
            step="any"
            value={doseAmount} 
            onChange={(e) => setDoseAmount(e.target.value)} 
            placeholder="e.g., 25"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="edit-doseUnit">Dose Unit</Label>
          <Select value={doseUnit} onValueChange={setDoseUnit}>
            <SelectTrigger>
              <SelectValue placeholder="Unit" />
            </SelectTrigger>
            <SelectContent>
              {DOSE_UNITS.map((unit) => (
                <SelectItem key={unit} value={unit}>{unit}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-brand">Brand (optional)</Label>
        <Input id="edit-brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-form">Form (optional)</Label>
        <Select value={form} onValueChange={setForm}>
          <SelectTrigger>
            <SelectValue placeholder="Select form" />
          </SelectTrigger>
          <SelectContent>
            {FORM_OPTIONS.map((opt) => (
              <SelectItem key={opt} value={opt} className="capitalize">{opt}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="edit-notes">Notes (optional)</Label>
        <Textarea id="edit-notes" value={notes} onChange={(e) => setNotes(e.target.value)} className="resize-none" />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>Daily Reminder</Label>
          <button
            type="button"
            role="switch"
            aria-checked={reminderEnabled}
            onClick={() => setReminderEnabled(!reminderEnabled)}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${reminderEnabled ? "bg-primary" : "bg-secondary"}`}
            data-testid="toggle-edit-reminder-enabled"
          >
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${reminderEnabled ? "translate-x-4" : "translate-x-1"}`} />
          </button>
        </div>
        {reminderEnabled && (
          <Input
            type="time"
            value={reminderTime}
            onChange={(e) => setReminderTime(e.target.value)}
            className="w-auto"
            data-testid="input-edit-reminder-time"
          />
        )}
      </div>

      <DialogFooter>
        <Button type="submit" disabled={isPending || !name.trim()}>
          {isPending ? "Saving..." : "Save Changes"}
        </Button>
      </DialogFooter>
    </form>
  );
}
