import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@/hooks/use-user";
import { useLogs } from "@/hooks/use-logs";
import { usePushNotifications } from "@/hooks/use-push-notifications";
import { useUsernameValidation } from "@/hooks/use-username-validation";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Settings, UserCircle, Bell, BellOff, CheckCircle, XCircle, Smartphone, Share, Pencil, Camera, Loader2, Check, X as XIcon, Swords } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { WeightUpdateDialog } from "@/components/weight-update-dialog";
import { format } from "date-fns";
import { queryClient } from "@/lib/queryClient";
import { USER_ME_QUERY_KEY } from "@/hooks/use-user";
import { ObjectUploader } from "@/components/ObjectUploader";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { data: user, isLoading } = useUser();
  const { data: logs } = useLogs();
  const [, setLocation] = useLocation();
  const push = usePushNotifications();
  const today = format(new Date(), "yyyy-MM-dd");

  const { data: weightCutPlan } = useQuery<{ daysUntil: number; targetWeight: number; fightDate: string } | null>({
    queryKey: ["/api/me/weight-cut"],
    enabled: !!user,
    staleTime: 60_000,
  });
  const fightCampActive = weightCutPlan && weightCutPlan.daysUntil > 0;

  const [isEditingUsername, setIsEditingUsername] = useState(false);
  const [isSavingUsername, setIsSavingUsername] = useState(false);
  const [serverUsernameError, setServerUsernameError] = useState("");
  const usernameField = useUsernameValidation({ currentUsername: user?.username });
  const { toast } = useToast();

  const [isEditingBodyFat, setIsEditingBodyFat] = useState(false);
  const [bodyFatInput, setBodyFatInput] = useState("");
  const [isSavingBodyFat, setIsSavingBodyFat] = useState(false);

  const saveBodyFat = async () => {
    const pct = parseFloat(bodyFatInput);
    if (isNaN(pct) || pct < 3 || pct > 55) {
      toast({ title: "Enter a value between 3 and 55", variant: "destructive" });
      return;
    }
    setIsSavingBodyFat(true);
    try {
      const res = await fetch("/api/me/body-composition", {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bodyFatPct: pct / 100 }),
      });
      if (res.ok) {
        await queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
        setIsEditingBodyFat(false);
        toast({ title: "Body fat % updated" });
      } else {
        toast({ title: "Failed to save", variant: "destructive" });
      }
    } finally {
      setIsSavingBodyFat(false);
    }
  };

  
  // Photo upload state - track pending path per file
  const [pendingPhotoPath, setPendingPhotoPath] = useState<string | null>(null);
  
  const handlePhotoUpload = async (objectPath: string) => {
    if (!user || !objectPath) return;
    
    try {
      const res = await fetch(`/api/me/profile-photo`, {
        credentials: "include",
        cache: "no-store",
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photoUrl: objectPath }),
      });
      
      if (res.ok) {
        await queryClient.invalidateQueries({ queryKey: USER_ME_QUERY_KEY });
      }
    } catch (err) {
      console.error("Failed to update profile photo:", err);
    } finally {
      setPendingPhotoPath(null);
    }
  };
  
  const getUploadParameters = async (file: { name: string; size?: number | null; type?: string }) => {
    const res = await fetch("/api/uploads/request-url", {
      credentials: "include",
      cache: "no-store",
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: file.name,
        size: file.size,
        contentType: file.type,
      }),
    });
    
    if (!res.ok) {
      throw new Error("Failed to get upload URL");
    }
    
    const data = await res.json();
    setPendingPhotoPath(data.objectPath);
    
    return {
      method: "PUT" as const,
      url: data.uploadURL,
      headers: { "Content-Type": file.type || "application/octet-stream" },
    };
  };
  
  const handleUsernameChange = async () => {
    if (!user || !usernameField.isValid) return;
    
    setServerUsernameError("");
    setIsSavingUsername(true);
    
    try {
      const res = await fetch("/api/me/username", {
        credentials: "include",
        cache: "no-store",
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: usernameField.value }),
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        setServerUsernameError(data.error || "Failed to change username");
        return;
      }
      
      queryClient.setQueryData(["/api/auth/me"], null);
      queryClient.clear();
      localStorage.setItem("fitness_app_username", data.newUsername || usernameField.value);
      
      toast({
        title: "Username updated",
        description: "Please sign in again with your new username.",
      });
      
      const newName = data.newUsername || usernameField.value;
      setLocation(`/login?username=${encodeURIComponent(newName)}`);
    } catch (err) {
      setServerUsernameError("Network error. Please try again.");
    } finally {
      setIsSavingUsername(false);
    }
  };
  const todaysLog = logs?.find((l: any) => l.date === today);

  if (isLoading) {
    return (
      <Layout>
        <Skeleton className="h-[200px] w-full rounded-xl" />
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4 pb-4 border-b">
            <div className="relative">
              <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center overflow-hidden">
                {user.profilePhotoUrl ? (
                  <img 
                    src={user.profilePhotoUrl} 
                    alt="Profile" 
                    className="h-full w-full object-cover"
                    data-testid="img-profile-photo"
                  />
                ) : (
                  <UserCircle className="h-12 w-12 text-muted-foreground" />
                )}
              </div>
              <ObjectUploader
                maxNumberOfFiles={1}
                maxFileSize={5242880}
                onGetUploadParameters={getUploadParameters}
                onComplete={(result) => {
                  if (result.successful?.length && pendingPhotoPath) {
                    handlePhotoUpload(pendingPhotoPath);
                  }
                }}
                buttonClassName="absolute bottom-0 right-0 rounded-full"
              >
                <Camera className="h-3.5 w-3.5" />
              </ObjectUploader>
            </div>
            <div className="space-y-1 flex-1">
                {isEditingUsername ? (
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        value={usernameField.displayValue}
                        onChange={e => usernameField.onChange(e.target.value)}
                        placeholder="New username"
                        className="h-9"
                        data-testid="input-new-username"
                      />
                      <Button
                        size="sm"
                        onClick={handleUsernameChange}
                        disabled={isSavingUsername || !usernameField.isValid}
                        data-testid="button-save-username"
                      >
                        {isSavingUsername ? "..." : "Save"}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setIsEditingUsername(false);
                          usernameField.reset();
                          setServerUsernameError("");
                        }}
                        data-testid="button-cancel-username"
                      >
                        Cancel
                      </Button>
                    </div>
                    {usernameField.status === "checking" && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Loader2 className="h-3 w-3 animate-spin" />
                        <span>Checking availability...</span>
                      </div>
                    )}
                    {usernameField.status === "available" && (
                      <div className="flex items-center gap-2 text-xs text-green-500" data-testid="text-username-available">
                        <Check className="h-3 w-3" />
                        <span>Username available</span>
                      </div>
                    )}
                    {(usernameField.status === "taken" || usernameField.status === "invalid") && usernameField.error && (
                      <div className="flex items-center gap-2 text-xs text-destructive" data-testid="text-username-error">
                        <XIcon className="h-3 w-3" />
                        <span>{usernameField.error}</span>
                      </div>
                    )}
                    {serverUsernameError && (
                      <p className="text-xs text-destructive" data-testid="text-username-server-error">
                        {serverUsernameError}
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-display font-bold">{user.username}</h1>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        usernameField.reset(user.username);
                        setIsEditingUsername(true);
                      }}
                      data-testid="button-edit-username"
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                  </div>
                )}
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-muted-foreground capitalize">{user.experienceLevel} • {user.goal?.replace('_', ' ')}</p>
                  {fightCampActive && (
                    <Badge
                      data-testid="badge-fight-camp-active"
                      className="text-[11px] flex items-center gap-1 bg-orange-500/15 text-orange-400 border-orange-500/30"
                    >
                      <Swords className="h-3 w-3" />
                      Fight Camp
                    </Badge>
                  )}
                </div>
            </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <div className="space-y-1.5">
              <CardTitle>Current Metrics</CardTitle>
              <CardDescription>Based on your latest update</CardDescription>
            </div>
            <WeightUpdateDialog 
              date={today} 
              userId={user.id} 
              existingLog={todaysLog}
            />
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
             <div className="space-y-1">
                <Label className="text-muted-foreground">Height</Label>
                <div className="text-lg font-medium">{user.height} cm</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Weight</Label>
                <div className="text-lg font-medium">{user.currentWeight} kg</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Age</Label>
                <div className="text-lg font-medium">{user.age}</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Activity</Label>
                <div className="text-lg font-medium capitalize">{user.activityLevel?.replace('_', ' ')}</div>
             </div>
             <div className="space-y-1 col-span-2">
                <Label className="text-muted-foreground text-xs">Body Fat % <span className="text-muted-foreground/60">(used for EA scoring)</span></Label>
                {isEditingBodyFat ? (
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={3}
                      max={55}
                      step={0.5}
                      className="w-24 h-8 text-sm"
                      value={bodyFatInput}
                      onChange={e => setBodyFatInput(e.target.value)}
                      placeholder="e.g. 15"
                      data-testid="input-body-fat-pct"
                    />
                    <span className="text-sm text-muted-foreground">%</span>
                    <Button size="sm" variant="ghost" className="h-7 px-2" onClick={saveBodyFat} disabled={isSavingBodyFat} data-testid="button-save-body-fat">
                      {isSavingBodyFat ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5 text-green-400" />}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => setIsEditingBodyFat(false)} data-testid="button-cancel-body-fat">
                      <XIcon className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <div className="text-lg font-medium">
                      {(user as any).bodyFatPct != null ? `${Math.round((user as any).bodyFatPct * 100)}%` : <span className="text-muted-foreground text-sm">Not set (default 15%)</span>}
                    </div>
                    <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => { setBodyFatInput((user as any).bodyFatPct != null ? String(Math.round((user as any).bodyFatPct * 100)) : ""); setIsEditingBodyFat(true); }} data-testid="button-edit-body-fat">
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )}
             </div>
          </CardContent>
        </Card>

         <Card>
          <CardHeader>
            <CardTitle>Nutrition Targets</CardTitle>
            <CardDescription>Calculated daily goals</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-4">
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetCalories}</div>
                <div className="text-xs text-muted-foreground">Calories</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetProtein}g</div>
                <div className="text-xs text-muted-foreground">Protein</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetCarbs}g</div>
                <div className="text-xs text-muted-foreground">Carbs</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetFat}g</div>
                <div className="text-xs text-muted-foreground">Fat</div>
             </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Push Notifications
            </CardTitle>
            <CardDescription>
              Receive reminders for supplements and workouts on your device
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {push.notificationStatus === "server_disabled" ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <XCircle className="h-4 w-4" />
                <span className="text-sm">Push notifications are not configured on the server</span>
              </div>
            ) : push.notificationStatus === "ios_safari" ? (
              <div className="space-y-3">
                <div className="flex items-start gap-2 p-3 bg-secondary/50 rounded-lg">
                  <Smartphone className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Install PRFMR to enable notifications</p>
                    <p className="text-xs text-muted-foreground">
                      iOS requires the app to be installed on your home screen. Follow these steps:
                    </p>
                    <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                      <li className="flex items-center gap-1">
                        Tap the <Share className="h-3 w-3 inline" /> Share button in Safari
                      </li>
                      <li>Scroll down and tap "Add to Home Screen"</li>
                      <li>Open PRFMR from your home screen</li>
                      <li>Return here to enable notifications</li>
                    </ol>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Requires iOS 16.4 or later.
                </p>
              </div>
            ) : push.notificationStatus === "unsupported_browser" ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <XCircle className="h-4 w-4" />
                <span className="text-sm">Push notifications are not supported in this browser</span>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {push.isSubscribed ? (
                      <>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Notifications enabled</span>
                      </>
                    ) : (
                      <>
                        <BellOff className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">Notifications disabled</span>
                      </>
                    )}
                  </div>
                  {push.isSubscribed ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={push.unsubscribe}
                      disabled={push.isLoading}
                      data-testid="button-disable-notifications"
                    >
                      Disable
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      onClick={push.subscribe}
                      disabled={push.isLoading}
                      data-testid="button-enable-notifications"
                    >
                      Enable Notifications
                    </Button>
                  )}
                </div>
                {push.isSubscribed && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={push.sendTestNotification}
                    data-testid="button-test-notification"
                  >
                    Send Test Notification
                  </Button>
                )}
                {push.permission === "denied" && (
                  <p className="text-sm text-destructive">
                    Notifications are blocked. Please enable them in your browser settings.
                  </p>
                )}
                {push.isIOSDevice && push.isInstalledPWA && (
                  <p className="text-xs text-muted-foreground">
                    Running as installed app on iOS.
                  </p>
                )}
              </>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end pt-4">
             <Button variant="outline" onClick={() => setLocation("/onboarding?recalculate")}>
                <Settings className="mr-2 h-4 w-4" /> Recalculate Goals
             </Button>
        </div>
      </div>
    </Layout>
  );
}
