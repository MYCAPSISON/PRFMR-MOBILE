import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { MessageSquare, Loader2, CheckCircle, ImagePlus, X, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

const feedbackFormSchema = z.object({
  category: z.enum(["bug", "feature", "question", "other"]),
  message: z.string().min(10, "Message must be at least 10 characters"),
  includeDiagnostics: z.boolean().default(true),
});

type FeedbackFormValues = z.infer<typeof feedbackFormSchema>;

interface ScreenshotFile {
  file: File;
  preview: string;
}

const MAX_SCREENSHOTS = 3;
const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/webp"];

export default function FeedbackPage() {
  const [, setLocation] = useLocation();
  const [submitted, setSubmitted] = useState(false);
  const [screenshots, setScreenshots] = useState<ScreenshotFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: versionInfo } = useQuery<{ version: string; environment: string }>({
    queryKey: ["/api/meta"],
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const form = useForm<FeedbackFormValues>({
    resolver: zodResolver(feedbackFormSchema),
    defaultValues: {
      category: "bug",
      message: "",
      includeDiagnostics: true,
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newFiles: ScreenshotFile[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!ALLOWED_TYPES.includes(file.type)) {
        toast({ title: "Invalid file type", description: `${file.name}: Only PNG, JPEG, and WebP are allowed.`, variant: "destructive" });
        continue;
      }
      if (file.size > MAX_FILE_SIZE) {
        toast({ title: "File too large", description: `${file.name}: Maximum size is 5MB.`, variant: "destructive" });
        continue;
      }
      if (screenshots.length + newFiles.length >= MAX_SCREENSHOTS) {
        toast({ title: "Maximum reached", description: `You can attach up to ${MAX_SCREENSHOTS} screenshots.`, variant: "destructive" });
        break;
      }
      newFiles.push({ file, preview: URL.createObjectURL(file) });
    }

    setScreenshots((prev) => [...prev, ...newFiles]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeScreenshot = (index: number) => {
    setScreenshots((prev) => {
      const removed = prev[index];
      URL.revokeObjectURL(removed.preview);
      return prev.filter((_, i) => i !== index);
    });
  };

  const submitMutation = useMutation({
    mutationFn: async (values: FeedbackFormValues) => {
      const uploadedAttachments: Array<{ url: string; filename: string; mimeType: string; size: number }> = [];

      for (const ss of screenshots) {
        const urlRes = await apiRequest("POST", "/api/feedback/upload-url", {
          name: ss.file.name,
          size: ss.file.size,
          contentType: ss.file.type,
        });
        const { uploadURL, objectPath } = await urlRes.json();

        await fetch(uploadURL, {
          method: "PUT",
          body: ss.file,
          headers: { "Content-Type": ss.file.type },
        });

        uploadedAttachments.push({
          url: objectPath,
          filename: ss.file.name,
          mimeType: ss.file.type,
          size: ss.file.size,
        });
      }

      const payload: Record<string, unknown> = {
        category: values.category,
        message: values.message,
        route: "/feedback",
        attachments: uploadedAttachments,
      };

      if (values.includeDiagnostics) {
        payload.userAgent = navigator.userAgent;
        payload.viewport = `${window.innerWidth}x${window.innerHeight}`;
        payload.appVersion = versionInfo?.version || undefined;
      }

      const res = await apiRequest("POST", "/api/feedback", payload);
      return res.json();
    },
    onSuccess: () => {
      setSubmitted(true);
      queryClient.invalidateQueries({ queryKey: ["/api/feedback/mine"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit",
        description: error.message.includes("429") ? "Too many submissions. Try again later." : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: FeedbackFormValues) => {
    submitMutation.mutate(values);
  };

  if (submitted) {
    return (
      <Layout>
        <div className="max-w-lg mx-auto p-4 pt-8 space-y-6">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 py-12">
              <CheckCircle className="h-12 w-12 text-green-500" data-testid="icon-feedback-success" />
              <h2 className="text-lg font-semibold" data-testid="text-feedback-success">Thanks for your feedback!</h2>
              <p className="text-sm text-muted-foreground text-center">
                Your submission helps us improve PRFMR for everyone.
              </p>
              <Button
                variant="outline"
                onClick={() => setLocation("/dashboard")}
                data-testid="button-back-dashboard"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-lg mx-auto p-4 pt-8 space-y-6">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-back-dashboard-top"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Send Feedback
            </h1>
            <p className="text-sm text-muted-foreground">Help us improve PRFMR</p>
          </div>
        </div>

        <Card>
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-feedback-category">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="bug">Bug Report</SelectItem>
                          <SelectItem value="feature">Feature Request</SelectItem>
                          <SelectItem value="question">Question</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Tell us what's on your mind... (min 10 characters)"
                          rows={5}
                          data-testid="textarea-feedback-message"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-2">
                  <Label>Screenshots (optional)</Label>
                  <p className="text-xs text-muted-foreground">
                    Up to {MAX_SCREENSHOTS} images, max 5MB each (PNG, JPEG, WebP)
                  </p>

                  {screenshots.length > 0 && (
                    <div className="flex gap-2 flex-wrap">
                      {screenshots.map((ss, idx) => (
                        <div key={idx} className="relative group" data-testid={`screenshot-preview-${idx}`}>
                          <img
                            src={ss.preview}
                            alt={ss.file.name}
                            className="h-20 w-20 rounded-md object-cover border"
                          />
                          <Button
                            type="button"
                            variant="secondary"
                            size="icon"
                            className="absolute -top-2 -right-2 h-5 w-5 rounded-full"
                            onClick={() => removeScreenshot(idx)}
                            data-testid={`button-remove-screenshot-${idx}`}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                          <span className="text-[10px] text-muted-foreground block truncate max-w-[80px] mt-1">{ss.file.name}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {screenshots.length < MAX_SCREENSHOTS && (
                    <>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        multiple
                        className="hidden"
                        onChange={handleFileSelect}
                        data-testid="input-screenshot-file"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                        data-testid="button-add-screenshot"
                      >
                        <ImagePlus className="mr-2 h-4 w-4" />
                        Add Screenshot
                      </Button>
                    </>
                  )}
                </div>

                <FormField
                  control={form.control}
                  name="includeDiagnostics"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-feedback-diagnostics"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <Label className="text-sm font-normal">
                          Include diagnostic info
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Browser, viewport size, and app version
                        </p>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/dashboard")}
                    data-testid="button-cancel-feedback"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitMutation.isPending}
                    data-testid="button-submit-feedback"
                  >
                    {submitMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      "Submit"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {versionInfo?.version && (
          <p className="text-xs text-muted-foreground text-center" data-testid="text-feedback-version">
            v{versionInfo.version}
          </p>
        )}
      </div>
    </Layout>
  );
}
