import { useState } from "react";
import { useLogin } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Activity, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SiGoogle } from "react-icons/si";

export default function LoginPage() {
  const prefillUsername = typeof window !== "undefined" 
    ? new URLSearchParams(window.location.search).get("username") || ""
    : "";
  const googleError = typeof window !== "undefined"
    ? new URLSearchParams(window.location.search).get("error") === "google_auth_failed"
    : false;
  const [identifier, setIdentifier] = useState(prefillUsername);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { mutate, isPending } = useLogin();
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim() || !password.trim()) return;
    
    mutate({ identifier, password });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-8 bg-background relative">
        <div className="w-full max-w-sm space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Activity className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              Welcome back
            </h1>
            <p className="mt-3 text-muted-foreground">
              Sign in to continue tracking your nutrition and training.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            {googleError && (
              <div className="text-sm text-destructive bg-destructive/10 rounded-md p-3" data-testid="text-google-error">
                Google sign-in failed. Please try again or use email login.
              </div>
            )}

            <Button
              type="button"
              variant="outline"
              data-testid="button-google-login"
              className="w-full h-12 text-base gap-3"
              onClick={() => { window.location.href = "/auth/google"; }}
            >
              <SiGoogle className="h-4 w-4" />
              Continue with Google
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">or</span>
              </div>
            </div>
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="identifier">Email or Username</Label>
              <Input
                id="identifier"
                data-testid="input-identifier"
                type="text"
                placeholder="you@example.com or username"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="h-12"
                required
                autoComplete="username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  data-testid="input-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 pr-10"
                  required
                  autoComplete="current-password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  data-testid="button-toggle-password"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <Button
              type="submit"
              data-testid="button-login"
              disabled={isPending || !identifier || !password}
              className="w-full h-12 text-base group"
            >
              {isPending ? "Signing in..." : "Sign In"}
              {!isPending && (
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              )}
            </Button>
            <div className="text-center pt-2">
              <Link href="/forgot-password" className="text-sm text-muted-foreground hover:text-primary hover:underline" data-testid="link-forgot-password">
                Forgot password?
              </Link>
            </div>
            <p className="text-sm text-center text-muted-foreground pt-2">
              Don't have an account?{" "}
              <Link href="/start" className="text-primary hover:underline" data-testid="link-register">
                Request an invite
              </Link>
            </p>
          </motion.form>
        </div>
      </div>

      <div className="hidden lg:block relative bg-muted overflow-hidden">
        <div className="absolute inset-0 bg-zinc-900">
           <img 
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop"
            alt="Gym aesthetics"
            className="w-full h-full object-cover opacity-50 mix-blend-overlay"
           />
           <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-12">
             <p className="text-white font-display text-2xl max-w-md font-medium tracking-tight">
               Fuel performance. Recover better. Stay consistent.
             </p>
           </div>
        </div>
      </div>
    </div>
  );
}
