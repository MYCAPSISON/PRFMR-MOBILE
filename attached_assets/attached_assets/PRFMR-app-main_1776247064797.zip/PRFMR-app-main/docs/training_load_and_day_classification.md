# Training Load & Day Classification

## Overview

PRFMR derives a **training load** value for each session activity, sums those values across all sessions for a day, and classifies the day into one of four tiers: **Light / Moderate / Hard / Very Hard**.

This classification is used to:
- Display a visual day-load badge on the Training Log page.
- Feed a derived `yesterdayTrainingDemand` signal into the Session Readiness and Fuel Availability calculations, replacing the need to ask the athlete "did you train yesterday?" in the provisional check-in.
- Drive the carb target used in the readiness carb sufficiency score (today's classification → carb g/kg target).
- Generate non-blocking coaching warnings when training demand accumulates across consecutive days.

---

## 1. Session Load

**Source:** `server/lib/training-load.ts` → `computeSessionLoad(activity)`

| Condition | Formula |
|---|---|
| `rpe` present | `round(rpe × durationMinutes)` |
| `rpe` absent (old rows) | `estimatedKcal` used as proxy fallback |

**Why the fallback works:** For most activities, `estimatedKcal ≈ RPE × minutes` in magnitude. For example, a 45-minute run at moderate effort produces ~270 RPE-minutes (6 × 45) and a similar kcal estimate (~250–300 kcal). This makes the two approaches broadly comparable, meaning classification thresholds hold across both modes.

Lifting activities that predate the universal RPE field still carry `estimatedKcal` computed from the MET/RPE/body-region formula, so their load is represented without any data migration.

---

## 2. Daily Load

**Source:** `server/lib/training-load.ts` → `computeDailyLoad(activities, sessionCount)`

All activities for all sessions logged on a given date are collected and their session loads summed:

```
totalDailyLoad = Σ computeSessionLoad(activity) for all activities that day
```

The function also tracks:
- `sessionCount` – number of distinct workout sessions
- `totalDurationMinutes` – sum of all activity durations
- `totalKcal` – sum of all `estimatedKcal` values

---

## 3. Day Classification Thresholds

| Tier | Total Load Range | Badge colour | Typical example |
|---|---|---|---|
| **Light** | < 200 | Blue | 30-min easy run (RPE 4 × 30 = 120) |
| **Moderate** | 200–499 | Yellow | 45-min pads session (RPE 6 × 45 = 270) |
| **Hard** | 500–899 | Orange | 90-min sparring + 30-min run (RPE 7×90 + RPE 6×30 = 810) |
| **Very Hard** | ≥ 900 | Red | Two-a-day camp: morning conditioning + PM sparring |

These thresholds are calibrated to the RPE × duration scale. When activities use the kcal fallback, the same thresholds apply because kcal magnitudes overlap the RPE-minutes range.

---

## 4. Provisional Classification

A classification is marked **provisional** when:
- Sessions exist on the day but **no activities** have been added to any session yet.

When provisional, the badge shows "(est.)" suffix, e.g. "Moderate (est.)".

A zero-session day is classified as **Light** and is **not** marked provisional — no training is a complete picture of that day.

---

## 5. Body-Region Multipliers (lifting only)

Two separate multiplier tables exist — one for the training load score, one for the calorie estimate.

| Region | Load multiplier | Kcal multiplier |
|---|---|---|
| Upper | 1.0 × | 1.0 × |
| Full body | 1.1 × | 1.15 × |
| Lower | 1.25 × | 1.1 × |

**Load score formula:** `round(durationMinutes × sessionRpe × loadMultiplier)`

---

## 6. Lifting Calorie Estimate (RPE → MET)

**Source:** `server/lib/training-load.ts` → `estimateLiftingCalories()`

| RPE range | MET used |
|---|---|
| 1–3 | 3.5 |
| 4–5 | 4.5 |
| 6–7 | 5.0 |
| 8–9 | 6.0 |
| 10 | 6.5 |

**Formula:** `MET × bodyweightKg × (durationMinutes / 60) × bodyRegionKcalMultiplier`

---

## 7. Acute Load, Chronic Load & Load Ratio

**Source:** `server/lib/training-load.ts` → `computeLoadWarnings()`

These are coaching-context signals only. They are not injury-prediction tools.

| Field | Definition |
|---|---|
| `acuteLoad` | Sum of daily training loads over the last 7 days (today + 6 prior) |
| `chronicLoad` | Average daily training load over the last 28 days (today + 27 prior) |
| `loadRatio` | `(acuteLoad / 7) / chronicLoad` — normalised acute:chronic ratio (ACWR) |
| `loadStatus` | Derived from loadRatio (see table below) |

**loadStatus thresholds:**

| loadRatio | Status |
|---|---|
| < 0.8 | `"low"` — training significantly below recent baseline |
| 0.8 – 1.5 | `"stable"` — load in line with recent training history |
| > 1.5 | `"spike"` — acute load substantially exceeds recent baseline |
| `chronicLoad = 0` | `null` — insufficient history to compute |

---

## 8. Stacked Hard Day Detection

**Source:** `server/lib/training-load.ts` → `computeLoadWarnings(todayLoad, priorDays)`

"Hard" and "Very Hard" are treated as **high-load days** for stacking detection.

| Flag | Condition |
|---|---|
| `backToBackHardDays` | Today is high-load AND yesterday is high-load |
| `highLoadCluster` | Today is high-load AND at least 2 of [today, yesterday, 2-days-ago] are high-load |
| `threeDayStreak` | Today, yesterday, and 2-days-ago are all high-load |

These flags are independent — `threeDayStreak` implies both `backToBackHardDays` and `highLoadCluster`.

---

## 9. Warning Messages

**Source:** `server/lib/training-load.ts` → `computeLoadWarnings()`

Warnings are **informational coaching signals only**. They do not block any user action.

| Trigger | Warning text |
|---|---|
| `threeDayStreak` | "Three consecutive high-load days — consider recovery support" |
| `backToBackHardDays` (no streak) | "Back-to-back hard training days — recovery demand is elevated" |
| `highLoadCluster` (no streak) | "Training load is clustering across multiple days" |
| Today is `very_hard` | "Very high training demand today" |
| `loadStatus === "spike"` | "Training spike relative to recent baseline" |

Multiple warnings can fire in the same response. The streak warning takes priority — if `threeDayStreak` is true, the back-to-back warning is suppressed.

---

## 10. Yesterday Training Demand

**How it works (server-side):**

Both `GET /api/me/readiness/:date` and `GET /api/me/fuel/:date` now:
1. Fetch yesterday's sessions.
2. Fetch all activities for each session.
3. Call `computeDailyLoad(activities, sessionCount)` to get the classification.
4. Return `yesterdayTrainingDemand` (the classification string) and `yesterdayDailyLoad` (the full object) in the API response.

When a provisional check-in exists AND actual training data is available, the system **prefers the derived demand** over the self-report:

```
derivedTrainedYesterday = (yesterdayTrainingDemand !== null) → true
derivedIntensity        = classificationToPlannedIntensity(yesterdayTrainingDemand)
                          (maps very_hard → hard for the 3-tier intensity scale)
```

**Provisional check-in UI:**

When `hasYesterdayTraining = true` (sessions exist yesterday), the "Did you train yesterday?" question is already hidden in the ProvisionalCheckIn card. The derived demand also feeds the readiness penalty automatically via the API.

---

## 11. Backward Compatibility

Old activity rows without an `rpe` value are fully supported. `computeSessionLoad` falls back to `estimatedKcal`. The threshold scale was chosen so that typical kcal values produce the same classification as their RPE-minutes equivalent, ensuring day-to-day consistency as users add RPE to newer sessions.

No existing training data, calorie estimates, or session load scores are modified by this feature.

---

## 12. Carb Target by Day Classification (readiness scoring)

**Source:** `server/lib/readiness.ts` → `calculateCarbSufficiency()`

Today's training classification drives the carb target used when scoring yesterday's carb intake. Score is proportional: `clamp((carbsYesterdayG / (target × bodyweightKg)) × 25, 0, 25)`.

| Classification | Carb target |
|---|---|
| Light | 3 g/kg |
| Moderate | 5 g/kg |
| Hard | 6 g/kg |
| Very Hard | 7 g/kg |

---

## 13. Carb Suggestion Text (inline, from readiness scoring)

Generated inside `calculateCarbSufficiency()` and surfaced as the suggested fix when carbs is the primary limiter:

| Carb % of target | Classification | Message |
|---|---|---|
| < 50% | Very Hard | "High training demand — prioritise carbs before and after sessions" |
| < 50% | Hard or Moderate | "Increase carbs to support training — e.g. oats, rice, fruit, bread" |
| < 50% | Light | "You're under-fuelling slightly — consider adding carbs if training later" |
| 50–80% | Hard or Very Hard | "Carbs could be higher for this level of training demand" |
| ≥ 80% | Any | *(no suggestion generated)* |

---

## 14. Readiness Card — Session Label

**Source:** `server/lib/readiness.ts` → `calculateSessionReadiness()`

Total score = sleep (max 30) + EA (max 30) + carbs (max 25) + AMQS (max 15) = 100 points.

| Condition | Label |
|---|---|
| Any required data missing | **Provisional** |
| Total ≥ 85 | **High** |
| Total 70–84 | **Moderate** |
| Total 55–69 | **Low** |
| Total < 55 | **Poor** |

Missing data that triggers Provisional: sleep log, yesterday's food, yesterday's training.

---

## 15. Readiness Card — Primary Limiter & Suggested Fix

The component with the **lowest score as a % of its maximum** is the primary limiter. Provisional mode overrides all of this.

**Provisional:**
> Limiter: *"Incomplete data"*
> Fix: `"Log [missing items] for a complete readiness score"`

**Sleep is limiter:**

| Condition | Limiter | Fix |
|---|---|---|
| Sleep logged but poor | "Poor sleep last night" | "Prioritize 7–8h sleep tonight" |
| Sleep not logged | "Sleep not logged" | "Log last night's sleep for a complete score" |

**Energy Availability is limiter:**

| Condition | Limiter | Fix |
|---|---|---|
| Bodyweight is set | "Low energy availability" | "Aim for 35+ kcal/kg FFM net intake (currently X kcal/kg)" |
| No bodyweight on record | "Bodyweight not set" | "Set your bodyweight in profile for accurate scoring" |

**Carbs is limiter:**
> Limiter: *"Low carbohydrate availability"*
> Fix: uses the carb suggestion from §13 if one exists; otherwise calculates the exact gram gap and shows `"+Xg carbs — e.g. bagel + jam, banana + oats, or rice + honey"`; if no food was logged: `"Log yesterday's food for a complete carb score"`

**AMQS is limiter:**
> Limiter: *"Low micronutrient coverage"*
> Fix: *"Add nutrient-dense foods (leafy greens, fruit, nuts)"*

---

## 16. Readiness Card — Cross-Signal (amber line)

**Source:** `server/lib/readiness.ts` → end of `calculateSessionReadiness()`

Only shown when the score is non-provisional and bodyweight is available. EA is "low" when score ≤ 12/30; carbs "low" when score ≤ 12/25.

| EA score | Carb score | Cross-signal |
|---|---|---|
| ≤ 12 | ≤ 12 | "Under-fuelled — both energy and carb availability are low" |
| > 12 | ≤ 12 | "Performance may suffer — energy is adequate but carbs are low for training" |
| ≤ 12 | > 12 | "Energy deficit despite adequate carbs — check overall calorie intake" |
| > 12 | > 12 | *(no cross-signal)* |

---

## 17. Readiness Card — Stacking Context Line (orange line)

Appears below the cross-signal when stacking flags are present and the score is non-provisional.

| Condition | Text |
|---|---|
| `threeDayStreak` | "Three consecutive high-load days — consider recovery support" |
| `highLoadCluster` (no streak) | "Training load is clustering across consecutive days" |
| `backToBackHardDays` (no cluster) | "Back-to-back hard training days — recovery demand is elevated" |

---

## 18. Fuel Card — Status & Glycogen Risk

**Source:** `server/lib/fuel-availability.ts`

Note: the Fuel card uses a simpler EA model (total bodyweight, not FFM) — it is separate from the readiness EA component.

**Fuel status** (`EA = (caloriesYesterday − exerciseKcal) / bodyweightKg`):

| EA | Status |
|---|---|
| ≥ 40 | High |
| 30–39 | Adequate |
| < 30 | Low |

**Glycogen risk** (yesterday's carbs/kg vs today's planned intensity):

| Intensity | High risk | Moderate risk | Low risk |
|---|---|---|---|
| Hard | < 4 g/kg | 4–6 g/kg | > 6 g/kg |
| Moderate | < 3.5 g/kg | 3.5–5 g/kg | > 5 g/kg |
| Light / rest | < 2 g/kg | 2–3.5 g/kg | > 3.5 g/kg |

**Fuel card constraint + suggested fix (evaluated in priority order):**

| Trigger | Constraint | Suggested Fix |
|---|---|---|
| Glycogen High + hard session | "hard session planned, carbs too low yesterday" | "+Xg carbs before training — e.g., bagel + jam, banana + oats, or rice + honey" |
| Glycogen High + other intensity | "training planned, carbs too low yesterday" | "+Xg carbs before training — e.g., toast + jam, banana + oats, or yogurt + cereal" |
| Fuel Low (EA < 30) | "Overall energy intake was low yesterday" | "A carb-rich meal or snack before training — e.g., oats, rice bowl, or pasta" |
| Glycogen Moderate | "Carb stores may be slightly depleted" | "+40–60g carbs pre-session — e.g., banana + oats, toast + jam, or yogurt + cereal" |
| All clear | "Fuel stores look adequate" | "Fuel looks good — stay hydrated and maintain your normal eating" |

The `+Xg` deficit is clamped to 40–120g regardless of the raw calculation.

---

## 19. Fuel Card — Load Warning Line

**Source:** `server/routes.ts` → `GET /api/me/fuel/:date`

An additional warning line appears in the fuel card when training is stacking alongside low fuel support:

| Trigger | Warning |
|---|---|
| Stacking flags + glycogen High or Moderate | "Training demand is stacking while fuel support is low" |
| Today is hard/very_hard + glycogen High (no stacking) | "High training demand with low carbohydrate support" |

Only shown when the card is non-provisional.

---

## 20. Where Warnings Appear

| Location | Data source | What is shown |
|---|---|---|
| Training page — under the day badge | `GET /api/me/training-load/:date` | `warnings[]` list (stacking + spike messages) |
| Readiness card — below cross-signal | `GET /api/me/readiness/:date` | Single stacking context line |
| Fuel card — above the suggested fix | `GET /api/me/fuel/:date` | Single fuel load warning line |

All warnings are small text, informational only, and do not block any user action.

---

## 21. API Reference

### `GET /api/me/training-load/:date`

Returns daily load for the specified date plus full warning context. Fetches last 28 days for acute/chronic calculation.

```json
{
  "date": "2026-03-17",
  "totalLoad": 480,
  "classification": "moderate",
  "provisional": false,
  "sessionCount": 1,
  "totalDurationMinutes": 60,
  "totalKcal": 410,
  "warnings": [],
  "backToBackHardDays": false,
  "highLoadCluster": false,
  "threeDayStreak": false,
  "acuteLoad": 1200,
  "chronicLoad": 180,
  "loadRatio": 0.95,
  "loadStatus": "stable"
}
```

### `GET /api/me/readiness/:date`

Returns the full readiness result including:
- `total`, `label`, `primaryLimiter`, `suggestedFix`, `crossSignal`
- `components[]` — each with `name`, `score`, `maxPoints`, `detail`
- `yesterdayTrainingDemand`: `"light" | "moderate" | "hard" | "very_hard" | null`
- `yesterdayDailyLoad`: full `DailyLoadResult` or null
- `todayClassification`: classification used for carb target scoring
- `loadWarnings`: `string[]` — stacking warnings (subset, 3-day window only)
- `backToBackHardDays`, `highLoadCluster`, `threeDayStreak`: boolean stacking flags

### `GET /api/me/fuel/:date`

Returns:
- `fuelStatus`: `"High" | "Adequate" | "Low"`
- `glycogenRisk`: `"Low" | "Moderate" | "High"`
- `constraint`, `suggestedFix`
- `eaValue`, `carbsPerKg`
- `yesterdayTrainingDemand`, `yesterdayDailyLoad`
- `fuelLoadWarning`: `string | null` — load-aware warning for fuel card
- `backToBackHardDays`, `highLoadCluster`, `threeDayStreak`: boolean stacking flags
