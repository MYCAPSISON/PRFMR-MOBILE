# Provisional Readiness & Fuel Status

## What is Provisional Mode?

When a user hasn't logged yesterday's food or yesterday's training session, PRFMR switches the Session Readiness and Fuel Status cards into **provisional mode**. Instead of calculating nothing, the app uses answers from a 3-question Quick Check-in to produce useful screening-level estimates.

Provisional mode is a **self-report fallback** — not a replacement for objective data.

---

## When Does Provisional Mode Activate?

Provisional mode is active when **either** of these is missing for yesterday's date:

| Missing | Provisional? |
|---|---|
| Yesterday's food log | Yes |
| Yesterday's training session | Yes |
| Yesterday's bodyweight log only | **No** — bodyweight is resolved separately |

Bodyweight alone does not trigger provisional mode. The app resolves bodyweight using a fallback chain: today's log → most recent within 7 days → profile weight.

---

## What the Quick Check-in Asks

Three questions, each with three options:

1. **How do you feel today?** — Fresh / Okay / Tired
2. **Did you fuel well yesterday?** — Yes / Somewhat / Not really
3. **Planned session intensity** — Light / Moderate / Hard

These map to concepts from subjective wellness monitoring used in athlete readiness research (Hooper et al. 1995; Saw et al. 2016). Self-reported fatigue, perceived fueling, and session demand are accepted screening inputs when objective data is unavailable.

---

## Provisional Session Readiness

### How the score is calculated

Each answer contributes points to a 0–100 estimate:

| Input | Fresh | Okay | Tired |
|---|---|---|---|
| Wellness | 40 | 28 | 16 |

| Input | Yes | Somewhat | No |
|---|---|---|---|
| Perceived fueling | 40 | 25 | 10 |

| Input | Light | Moderate | Hard |
|---|---|---|---|
| Session demand | 20 | 15 | 10 |

Hard sessions score lower because they impose greater demands on available resources — the same wellness and fueling state carries more risk under a heavy training load.

### Labels

| Score | Label |
|---|---|
| ≥ 80 | Good |
| ≥ 65 | Moderate |
| ≥ 50 | Caution |
| < 50 | Low |

These labels (Good / Moderate / Caution / Low) are deliberately **different** from the full-data labels (High / Moderate / Low / Poor / Provisional) to make it clear the user is in a provisional state.

### Score display

Provisional scores are shown with a `~` prefix (e.g. `~68 — Moderate`) to communicate that this is an **estimate**, not a measurement.

### What provisional readiness does NOT claim

- It does not measure sleep quality, sleep duration, or HRV.
- It does not calculate energy availability (EA) or energy balance.
- It does not consider actual carbohydrate or protein intake.
- It is not a substitute for objective athlete monitoring.

---

## Provisional Fuel Status

### Why "Fuel Availability Risk" — not "Glycogen Risk"

**Glycogen risk** is only reported when real carbohydrate intake data (grams of carbohydrate per kg bodyweight) is available from food logs. Without that data, it is not scientifically defensible to classify glycogen status.

In provisional mode, the app uses **fuel availability risk** instead — a broader, self-report-appropriate term meaning: *given how this athlete perceives their fueling and what they plan to do, how elevated is the risk of insufficient fuel availability?*

### How fuel availability risk is determined

| Perceived fueling | Planned intensity | Fuel Status | Fuel Risk |
|---|---|---|---|
| Yes | Any | Adequate | Low |
| Somewhat | Hard | Low | Elevated |
| Somewhat | Light / Moderate | Adequate | Elevated |
| No | Hard | Low | Elevated |
| No | Light / Moderate | Low | Elevated |

Note: **"Adequate" is the maximum fuel status from self-report.** The full-data model can return "High" when carb intake data supports it — but provisional mode cannot make that claim from perception alone.

### What provisional fuel status does NOT claim

- It does not measure glycogen stores or carbohydrate availability.
- It does not calculate grams of carbs per kg bodyweight.
- It does not use energy availability (EA) calculations.
- "Elevated fuel risk" means the athlete's self-report suggests a risk — not that depletion is confirmed.

---

## How Provisional Differs from the Full-Data Model

| Feature | Full Data | Provisional |
|---|---|---|
| Readiness inputs | Sleep, EA, carb/kg, AMQS | Self-reported wellness, fueling, intensity |
| Fuel inputs | Actual carb intake, EA, training calories | Perceived fueling, planned intensity |
| Glycogen risk | Yes — from real carb data | No — replaced by "Fuel Availability Risk" |
| Score precision | Objective 0–100 | Estimated — shown with `~` prefix |
| Labels | High / Moderate / Low / Poor | Good / Moderate / Caution / Low |
| Fuel status max | High | Adequate |
| Disclaimer | Performance guidance estimate | Self-report estimate, not objective data |

---

## Why Self-Report Is an Acceptable Fallback

In athlete monitoring research, subjective wellness questionnaires (SWQ) are widely validated as cost-effective, practical tools for daily readiness screening. Studies consistently show that subjective fatigue, mood, sleep quality, and perceived exertion correlate meaningfully with objective performance indicators.

PRFMR uses provisional mode as a **screening layer** — useful for new users who haven't built a logging habit yet, or for days when data entry was missed. It provides directional guidance (e.g. "consider a lighter session") without making biomarker-level claims.

**The provisional check-in is not medical advice and should not substitute for consistent nutrition and training logging.**

---

## Files

| File | Purpose |
|---|---|
| `server/lib/provisional-readiness.ts` | All provisional calculation logic |
| `server/lib/readiness.ts` | Full-data readiness + provisional trigger |
| `server/lib/fuel-availability.ts` | Full-data fuel + provisional trigger |
| `server/routes.ts` | API routes for `/api/me/readiness` and `/api/me/fuel` |
| `client/src/components/ProvisionalCheckIn.tsx` | Quick Check-in card UI |
| `client/src/components/SessionReadiness.tsx` | Session Readiness card |
| `client/src/components/FuelAvailability.tsx` | Fuel Status card |
