# Full-Data Readiness & Fuel Availability — Technical Reference

> This document covers the **full-data** (non-provisional) pathways for Session Readiness and Fuel Availability.
> For the provisional pathway, see `docs/provisional_readiness_and_fuel.md`.

---

## Overview

When all required data is present — today's sleep log, yesterday's food log, and a resolved bodyweight — the app computes two independent scores:

1. **Session Readiness Score** — composite 0–100, labeled High / Moderate / Low / Poor
2. **Fuel Availability Status** — categorical: High / Adequate / Low, plus Glycogen Risk (Low / Moderate / High)

These replace provisional estimates the moment the user submits the morning check-in or logs the required data.

---

## 1. Session Readiness Score

**Calculated in:** `server/lib/readiness.ts`

### Inputs

| Input | Source | Notes |
|-------|--------|-------|
| `sleepHours` | `sleep_logs.hours` (today) | Required; 0 triggers provisional |
| `sleepQuality` | `sleep_logs.quality` (today, 1–5) | Optional; defaults to 3 if absent |
| `energyAvailability` | Yesterday's kcal intake vs. BMR | "High" / "Adequate" / "Low" |
| `carbsSufficiency` | Yesterday's carbs vs. body-weight target | Percentage of recommended |
| `amqsScore` | Today's AMQS daily score (0–100) | Optional; 0 if not yet logged |
| `bodyweightKg` | Resolved weight (today → 7d recent → profile) | Used in carbs sufficiency target |

### Component Scoring

#### Sleep Component (max 30 pts)

```
sleepPts = clamp(((sleepHours - 5) / 3) * 20, 0, 20)
qualityPts = ((sleepQuality - 1) / 4) * 10
total = sleepPts + qualityPts
```

- 8h + quality 5 → 30 pts
- 7h + quality 4 → ~23 pts
- 5h + quality 1 → 0 pts
- <5h of sleep → 0 pts sleep contribution

#### Energy Availability Component (max 30 pts)

```
if energyAvailability === "High":   30 pts
if energyAvailability === "Adequate": 20 pts
if energyAvailability === "Low":    8 pts
```

Energy availability is classified by comparing yesterday's caloric intake to estimated BMR (Mifflin-St Jeor).

- **High:** intake ≥ 1.1× BMR
- **Adequate:** intake ≥ 0.85× BMR
- **Low:** intake < 0.85× BMR

#### Carb Sufficiency Component (max 25 pts)

```
carbTarget = bodyweightKg * 3  (g/day, general athlete baseline)
pct = carbsYesterdayG / carbTarget * 100
carbPts = clamp((pct / 100) * 25, 0, 25)
```

- Full carb target met → 25 pts
- 50% of target → 12.5 pts
- 0g carbs → 0 pts

**Suggestion trigger:** If carb pts < 12.5 (below 50% of target), a food suggestion is shown:
> "+Xg carbs before training — e.g., banana + oats, bagel + jam, or rice + honey"

#### AMQS Component (max 15 pts)

```
amqsPts = (amqsScore / 100) * 15
```

- AMQS 100 → 15 pts
- AMQS 60 → 9 pts
- AMQS 0 or not logged → 0 pts

### Total Score and Labels

```
score = sleepPts + energyPts + carbPts + amqsPts
```

| Score | Label |
|-------|-------|
| 75–100 | High |
| 50–74 | Moderate |
| 25–49 | Low |
| 0–24 | Poor |

### Details Breakdown

The readiness card exposes each component's contribution:
- Sleep score (X/30)
- Energy availability (X/30)
- Carb sufficiency (X/25)
- Micronutrient score (X/15)

Each component links to a human-readable status for quick scanning.

---

## 2. Fuel Availability

**Calculated in:** `server/lib/fuel-availability.ts`

### Inputs

| Input | Source | Notes |
|-------|--------|-------|
| `carbsYesterdayG` | Yesterday's food log | Sum of all food entry carbs |
| `caloriesYesterdayKcal` | Yesterday's food log | Sum of all food entry calories |
| `bodyweightKg` | Resolved weight (today → 7d recent → profile) | Used for glycogen targets |
| `exerciseKcalYesterday` | Yesterday's training summary | Optional; from training log |
| `plannedIntensity` | User's provisional check-in (planned session) | "hard", "moderate", "easy", "rest"; optional |

### Fuel Status Classification

Fuel status describes overall energy availability yesterday:

```
netCalories = caloriesYesterdayKcal - exerciseKcalYesterday
bmrEstimate = bodyweightKg * 24 * 0.9  (simplified)

if netCalories >= bmrEstimate * 1.05: "High"
if netCalories >= bmrEstimate * 0.80: "Adequate"
else: "Low"
```

### Glycogen Risk Classification

Glycogen risk describes specifically whether carbohydrate stores are depleted:

```
carbTarget:
  hard session: bodyweightKg * 6 g/day
  moderate:     bodyweightKg * 4 g/day
  easy/rest:    bodyweightKg * 3 g/day

pctOfTarget = carbsYesterdayG / carbTarget * 100

if pctOfTarget < 50:  "High" risk
if pctOfTarget < 80:  "Moderate" risk
else:                 "Low" risk
```

### Suggested Fix (user-facing guidance)

| Condition | Suggestion |
|-----------|-----------|
| Glycogen High risk + hard session planned | `+Xg carbs before training — e.g., bagel + jam, banana + oats, or rice + honey` |
| Glycogen High risk + other session | `+Xg carbs before training — e.g., toast + jam, banana + oats, or yogurt + cereal` |
| Fuel status Low | `A carb-rich meal or snack before training — e.g., oats, rice bowl, or pasta` |
| Glycogen Moderate risk | `+40–60g carbs pre-session — e.g., banana + oats, toast + jam, or yogurt + cereal` |
| Adequate | `Fuel looks good — stay hydrated and maintain your normal eating` |

### Gram estimate for High-risk suggestions

```
deficit = carbTarget - carbsYesterdayG
clampedDeficit = clamp(deficit, 40, 120) g
```

---

## 3. Bodyweight Resolution

Both calculations use a **resolved bodyweight** rather than only the profile-stored value:

```
1. Today's logged weight (weight_logs table, today's date)
2. Average of last 7 days of weight logs (if no today entry)
3. Profile currentWeight field (fallback)
```

This ensures calculations remain stable even if the user hasn't weighed in today.

---

## 4. Provisional State Triggers

A result is shown as **Provisional** instead of full-data when:
- No sleep log for today, OR
- No food entries for yesterday

When provisional, `SessionReadiness` shows `~score` prefix and a "Provisional" badge.
`FuelAvailability` shows a "Provisional" badge next to the status.

The provisional pathway uses the 3-question check-in to estimate these values. See `docs/provisional_readiness_and_fuel.md`.

---

## 5. Data Flow

```
User logs sleep (today)
  └→ sleep_logs table
       └→ readiness.ts reads sleepHours, sleepQuality

User logs food (yesterday)
  └→ food_entries table
       └→ readiness.ts reads energyAvailability, carbsSufficiency
       └→ fuel-availability.ts reads carbsYesterdayG, caloriesYesterdayKcal

User logs weight (today or recent)
  └→ weight_logs table
       └→ both calculations resolve bodyweightKg

User logs training (yesterday)
  └→ training_sessions + training_activities tables
       └→ fuel-availability.ts reads exerciseKcalYesterday

API: GET /api/me/readiness/:date
API: GET /api/me/fuel-availability/:date
  └→ Dashboard fetches both, passes date prop to components
       └→ SessionReadiness.tsx renders score breakdown
       └→ FuelAvailability.tsx renders status + glycogen risk
```

---

## 6. Design Principles

- **Calm language:** No "danger", "behind", "failing", "missed target"
- **Transparency:** Every score exposes its component breakdown in the details view
- **Conservative suggestions:** All food suggestions are practical, whole-food examples
- **Provisional fallback:** Always show something useful, even with incomplete data
- **Educational framing:** All outputs include a disclaimer that these are estimates, not medical advice
