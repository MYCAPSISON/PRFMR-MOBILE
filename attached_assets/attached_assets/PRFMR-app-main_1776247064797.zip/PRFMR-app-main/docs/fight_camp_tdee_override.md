# Fight Camp TDEE Override

## Background: Normal (Non-Fight-Camp) Users

For all users not in a Fight Camp, calorie targets are calculated using the standard approach:

1. **BMR** via Mifflin-St Jeor equation
2. **TDEE** = BMR × activity multiplier (1.2–1.9 depending on lifestyle)
3. **Target calories** = TDEE ± goal adjustment (−500 fat loss, 0 maintenance, +300 weight gain)
4. **Training credit** applied client-side: the dashboard adds back a portion of logged training calories
   - Fat loss: 50% credit
   - Maintenance: 75% credit
   - Weight gain: 100% credit

This system is unchanged for non-Fight-Camp users.

---

## Problem: Double-Counting in Fight Camp Mode

The standard activity-multiplier TDEE already bakes in an assumed volume of training. For example, a user set to `active` gets TDEE = BMR × 1.725, implicitly accounting for roughly 5 sessions per week.

In Fight Camp mode, actual logged training sessions are also available. Adding training calories on top of a TDEE that already includes them leads to double-counting — the user's target is inflated, deficit too small, and fat loss stalls.

---

## Solution: NEAT-Only Baseline + Actual Training

When a Fight Camp plan is active (daysUntil > 0), the TDEE calculation is replaced entirely:

```
baselineTdee   = BMR × 1.4
                  └─ covers NEAT, daily steps, incidental movement only
                     (no structured training assumed)

trainingKcalToday = sum of estimatedKcal for today's logged workout sessions

fightCampTdee  = baselineTdee + trainingKcalToday

targetCalories = max(1200, fightCampTdee − dailyDeficit)
```

The multiplier **1.4** is chosen as a conservative NEAT-only floor — equivalent to a lightly active daily life without structured exercise.

---

## Deficit Logic

The deficit applied is the same as the existing weight-cut planner:

```
dailyDeficit = clamp(300, 900, cut.suggestedDeficitKcal)
```

`suggestedDeficitKcal` is derived from the recommended weekly fat loss rate (capped at 1% BW/week) × 7700 ÷ 7.

---

## Training Calorie Credits: Bypassed in Fight Camp Mode

**Approach chosen: bypass.**

Because `trainingKcalToday` is already included in `fightCampTdee` server-side, the API returns `trainingCalorieCreditPct: 0`. The client's `computeAdjustedTargets()` therefore adds zero training credits — preventing double-counting.

For reference, non-Fight-Camp credit percentages remain:
- `fat_loss`: 0.50
- `maintenance`: 0.75
- `weight_gain`: 1.00

---

## Goal Logic After TDEE

Goals are not configurable in Fight Camp — the planner always operates in fat loss mode. Protein and fat targets are set independently of calories:

```
targetProtein = 2.2 g/kg BW   (muscle preservation in deficit)
targetFat     = 0.7 g/kg BW   (hormonal support)
targetCarbs   = (targetCalories − protein×4 − fat×9) / 4
```

---

## Provisional Targets

If no training sessions are logged for today, `trainingKcalToday = 0` and the API returns `provisional: true` with `modeNote: "Target is provisional until training is logged for today."`.

Once sessions are logged (cardio activities or lifting with RPE-based estimation), the `targets/effective` query is invalidated and the client receives an updated `targetCalories` that includes actual burn.

---

## Cache Invalidation

Any mutation that modifies a workout session's `estimatedKcal` triggers invalidation of `/api/me/targets/effective`. This covers:

- Training session create / delete (training.tsx, AILogDialog.tsx)
- Add / delete exercise (training.tsx)
- Add / delete set (training.tsx)
- Add / update / delete activity (training.tsx)
- Manual calorie burn log (dashboard.tsx)
- Recurring schedule creation (use-logs.ts)

---

## Files Changed

| File | Change |
|------|--------|
| `server/routes.ts` | `calculateTargets()` now returns `bmr`; fight camp block in `/api/me/targets/effective` replaced with NEAT-baseline + actual-training logic |
| `client/src/hooks/use-logs.ts` | Invalidates `targets/effective` after training mutations |
| `client/src/components/AILogDialog.tsx` | Already invalidated `targets/effective` (confirmed present) |
| `client/src/pages/dashboard.tsx` | Invalidates `targets/effective` on manual burn |
| `client/src/pages/training.tsx` | Invalidates `targets/effective` on all 8 session/exercise/activity mutations |
| `docs/fight_camp_tdee_override.md` | This file |
