# Weight-Cut Planner — Model Reference

## Overview

The weight-cut planner (`server/lib/weight-cut.ts`) calculates fat-loss pacing and fight-week targets for athletes preparing for a competition weigh-in. It separates the planning into two distinct flows based on weigh-in timing.

This is a **planning model only**. It does not provide dehydration guidance, acute water-cut protocols, or any other weight-manipulation advice beyond long-term fat-loss pacing.

---

## Key Concepts

| Term | Definition |
|---|---|
| **targetWeight** | The competition weigh-in limit the athlete must meet |
| **pre-final-cut target** | The bodyweight the athlete should reach *before* the final-week reduction window. This is the fat-loss endpoint. |
| **tempCut** | Planning allowance for temporary weight reduction in the final window (water, glycogen, food volume, etc.) |
| **fatLossRequired** | Fat loss that must occur *before* the final-cut window: `max(0, currentWeight − preFinalCutTarget)` |
| **required pace** | Weekly fat-loss rate needed to reach the pre-final-cut target in the available time |
| **recommended pace** | Required pace capped at 1% bodyweight/week — used for deficit and weekly targets |

---

## Two-Flow Model

### A. DAY-BEFORE Weigh-In

The athlete weighs in the day before competition. This allows a larger final-week reduction window.

**Fat loss phase runs until T-7 days.**

#### Step-by-step

1. **Pre-final-cut target at T-7 days**

   - Auto: `predictedWeekMinus1Weight = targetWeight / (1 − 0.06)` *(~6% reduction allowance)*
   - Manual: `predictedWeekMinus1Weight = targetWeight + manualTempReductionKg` *(capped at 10% of that weight)*

2. **Fat loss required**

   ```
   fatLossRequired = max(0, currentWeight − predictedWeekMinus1Weight)
   ```

3. **Time available for fat loss**

   ```
   weeksForFatLoss = max(0.5, (daysUntil − 7) / 7)
   ```

4. **Required weekly rate** *(based on what must be done, not what's recommended)*

   ```
   requiredWeeklyRate = fatLossRequired / weeksForFatLoss
   requiredWeeklyRatePct = requiredWeeklyRate / currentWeight × 100
   ```

5. **Recommended weekly rate** *(capped at 1% BW/wk — used for deficit and weekly targets)*

   ```
   recommendedWeeklyRate = min(requiredWeeklyRate, currentWeight × 0.01)
   ```

6. **Temporary reduction**

   ```
   tempCut = min(predictedWeekMinus1Weight − targetWeight, totalToLose − fatLossRequired)
   ```

   Displayed only within the **final 10 days**.

7. **dayMinus4Target** — not applicable; returns `null` for day_before.

---

### B. SAME-DAY Weigh-In

The athlete weighs in the same morning as competition. The reduction window is much tighter, so fat loss must continue until T-4 days with a minimal allowance for temporary reduction.

**Fat loss phase runs until T-4 days.**

#### Step-by-step

1. **Pre-final-cut target at T-4 days**

   - Auto: `predictedDayMinus4Weight = targetWeight / (1 − 0.01)` *(~1% reduction allowance)*
   - Manual: `predictedDayMinus4Weight = targetWeight + manualTempReductionKg` *(capped at 2% of that weight)*

2. **Fat loss required**

   ```
   fatLossRequired = max(0, currentWeight − predictedDayMinus4Weight)
   ```

3. **Time available for fat loss**

   ```
   weeksForFatLoss = max(0.5, (daysUntil − 4) / 7)
   ```

4. **Required weekly rate**

   ```
   requiredWeeklyRate = fatLossRequired / weeksForFatLoss
   requiredWeeklyRatePct = requiredWeeklyRate / currentWeight × 100
   ```

5. **Recommended weekly rate** *(capped at 1% BW/wk)*

   ```
   recommendedWeeklyRate = min(requiredWeeklyRate, currentWeight × 0.01)
   ```

6. **Temporary reduction**

   ```
   tempCut = min(predictedDayMinus4Weight − targetWeight, totalToLose − fatLossRequired)
   ```

   Displayed only within the **final 5 days**.

7. **dayMinus4Target** — `predictedDayMinus4Weight` (rounded to 1dp). This is the scale weight the athlete should be at or below four days before the fight.

---

## Status Logic

Status is derived from the **required** weekly rate, not the recommended (capped) rate. This ensures the status reflects how aggressive the timeline actually is — even if the recommended deficit is softened by the 1% cap.

| requiredWeeklyRatePct | status | statusLabel |
|---|---|---|
| ≤ 0.5% | `on_track` | Steady pace |
| ≤ 1.0% | `on_track` | On track |
| ≤ 1.5% | `aggressive` | Quite aggressive — consider extending timeline |
| ≤ 2.0% | `very_aggressive` | Very aggressive — adjust target or date |
| > 2.0% | `unrealistic` | Timeline too tight — adjust target or date |

Special cases: `complete` (already at/below target), `past_date` (fight date passed).

---

## Weekly Targets

Weekly targets are trajectories toward the **pre-final-cut target weight** (not the final fight weight, which includes temporary reduction on top). They use the **recommended** weekly rate so the targets remain achievable even when the required rate exceeds 1% BW/wk.

- **day_before**: targets run toward `predictedWeekMinus1Weight`
- **same_day**: targets run toward `predictedDayMinus4Weight`

If `recommendedWeeklyRate = 0` (athlete already at or below the pre-final-cut target), no targets are generated.

---

## Suggested Deficit

```
suggestedDeficitKcal = round(recommendedWeeklyRate × 7700 / 7)
```

Uses the **recommended** (capped) rate, so the deficit remains within a sustainable range regardless of how tight the timeline is.

---

## Return Object

| Field | Description |
|---|---|
| `currentWeight` | Input current bodyweight (kg) |
| `targetWeight` | Input competition weight limit (kg) |
| `fightDate` | ISO date of the competition |
| `daysUntil` | Days remaining |
| `weeksUntil` | `daysUntil / 7` |
| `totalToLose` | `currentWeight − targetWeight` |
| `fatLossRequired` | Fat loss needed before final-cut window |
| `tempCut` | Planning allowance for final-window reduction |
| `tempCutDisplayed` | `tempCut` when inside display window, else `0` |
| `requiredWeeklyRate` | Weekly rate needed to hit fat-loss target (kg/wk) |
| `requiredWeeklyRatePct` | As % of currentWeight |
| `recommendedWeeklyRate` | `requiredWeeklyRate` capped at 1% BW/wk |
| `recommendedWeeklyRatePct` | As % of currentWeight |
| `weeklyRate` | Same as `recommendedWeeklyRate` (backward compat) |
| `weeklyRatePct` | Same as `recommendedWeeklyRatePct` (backward compat) |
| `predictedWeekMinus1Weight` | T-7 bodyweight target (day_before only, null for same_day) |
| `predictedDayMinus4Weight` | T-4 bodyweight target (same_day only, null for day_before) |
| `dayMinus4Target` | `predictedDayMinus4Weight` rounded (same_day), null for day_before |
| `status` | `on_track` / `aggressive` / `very_aggressive` / `unrealistic` / `complete` / `past_date` |
| `statusLabel` | Human-readable status |
| `weeklyTargets` | Array of `{ week, targetWeight }` toward pre-final-cut target |
| `suggestedDeficitKcal` | Daily caloric deficit from recommended pace |
| `manualTempReductionKg` | Manual temp reduction override if set, else null |

---

## Why the Two Flows Differ

Same-day athletes must already be very close to fight weight by morning. There's no full week of recovery time between weigh-in and competition. Therefore:

- **Fat loss runs longer** (until T-4, not T-7)
- **Temp reduction allowance is much smaller** (1% vs 6%)
- **tempCutDisplayed window is tighter** (final 5 days vs 10 days)
- **dayMinus4Target** is the meaningful pre-competition check-in weight

Day-before athletes have a full day between weigh-in and competition to rehydrate, so a larger temporary reduction is a viable planning allowance. The fat-loss phase ends a week out (T-7) and the final window covers the last week.
