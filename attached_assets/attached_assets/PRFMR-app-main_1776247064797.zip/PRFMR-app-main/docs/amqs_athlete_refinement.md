# AMQS Athlete Refinement — Developer Documentation

## Overview

The Athlete Micronutrient Quality Score (AMQS) uses a two-layer scoring model to help users understand and improve their micronutrient intake.

- **Layer 1 (Adequacy Score)** — baseline coverage against UK/DRI-style reference nutrient intakes. This is the primary score shown to users.
- **Layer 2 (Athlete Optimisation Score)** — stricter targets informed by sports nutrition research. Shown alongside Layer 1 to encourage further improvement.

---

## 1. Layer 1 — Baseline Adequacy

Layer 1 reflects whether daily intake meets established population reference values (UK Reference Nutrient Intakes or US Dietary Reference Intakes, depending on nutrient). These are conservative, population-wide adequacy targets.

**Formula:**

```
adequacy_i = min(intake_i / target_i, 1.0)
score = (Σ weight_i × adequacy_i) / (Σ weight_i) × 100
```

The adequacy ratio is **capped at 1.0** — over-consuming one nutrient does not compensate for gaps elsewhere.

---

## 2. Layer 2 — Athlete Optimisation

Layer 2 uses the same formula and weights as Layer 1, but applies stricter targets where sports nutrition evidence supports higher intake. It is calculated separately and displayed alongside Layer 1.

> **Important:** Do NOT call these "athlete RDAs". The correct phrasing is: _"Athlete optimisation targets informed by sports nutrition literature and dietary reference intakes."_

---

## 3. Complete Nutrient List, Targets, and Weights

| Nutrient | Key | Unit | Weight | Layer 1 (M/F) | Layer 2 | Source rationale |
|---|---|---|---|---|---|---|
| Iron | `iron_mg` | mg | 2.0 (2.5 F) | 8.7 / 14.8 | 8.7 / 14.8 | UK RNI; individualized — not raised for athletes automatically |
| Calcium | `calcium_mg` | mg | 2.0 | 700 | 1000 | L2: US RDA; bone health for high-impact athletes |
| Vitamin D | `vitamin_d_ug` | µg | 2.0 | 10 | 25 (≈1000 IU) | L2: Holick 2011; indoor/winter athletes commonly insufficient |
| Magnesium | `magnesium_mg` | mg | 1.5 | 300 / 270 | 400 | L2: Volpe 2015; sweat losses in training |
| Zinc | `zinc_mg` | mg | 1.5 | 9.5 / 7.0 | 12 | L2: Lukaski; immune turnover & sweat losses |
| Iodine | `iodine_ug` | µg | 1.0 | 140 | 150 | L2: US RDA |
| Selenium | `selenium_ug` | µg | 1.0 | 75 / 60 | 55 | L2: US RDA (unified for both sexes) |
| Folate | `folate_ug` | µg | 1.0 | 200 | 400 | L2: US RDA; DNA synthesis with high cell turnover |
| Vitamin B12 | `vitamin_b12_ug` | µg | 1.0 (2.0 vegan) | 1.5 | 2.4 | L2: US RDA |
| Vitamin C | `vitamin_c_mg` | mg | 1.0 | 40 | 120 | L2: Peake; oxidative stress from exercise |
| Vitamin A | `vitamin_a_ug` | µg | 1.0 | 700 / 600 | 900 / 700 | L2: US RDA |
| Potassium | `potassium_mg` | mg | 1.0 | 3500 | 4000 | L2: NAS 2019; electrolyte for athletic performance |
| Vitamin B1 | `vitamin_b1_mg` | mg | 0.75 | 1.2 / 1.1 | 1.4 | L2: ACSM; carbohydrate energy metabolism |
| Vitamin B2 | `vitamin_b2_mg` | mg | 0.75 | 1.3 / 1.1 | 1.5 | L2: Burke & Deakin; mitochondrial enzyme function |
| Vitamin B3 | `vitamin_b3_mg` | mg | 0.75 | 16 / 14 | 18 | L2: NAD production for oxidative metabolism |
| Vitamin B6 | `vitamin_b6_mg` | mg | 0.75 | 1.3 | 1.6 | L2: Protein metabolism higher with high-protein diet |
| Omega-3 | `omega3_g` | g | 1.0 | 1.6 / 1.1 | 2.0 | L2: IOC; recovery, inflammation, muscle protein synthesis |

**Total tracked nutrients: 17**

---

## 4. Weight Philosophy

- **High priority (2.0–2.5):** Iron, Calcium, Vitamin D, Zinc, Magnesium — athlete-critical; deficiency common.
- **Moderate priority (0.75–1.0):** Supporting nutrients, B vitamins, Omega-3.
- **Dynamic adjustments:** Female iron weight raised to 2.5. Vegan B12 raised to 2.0.

Do not add new nutrients with weight > 1.0 unless they are clearly athlete-critical. New nutrients should not dominate the score.

---

## 5. Tier Thresholds

| Tier | Layer 1 Score | Note |
|---|---|---|
| Elite | 95–100 | Requires critical nutrients ≥70% of Layer 1 target |
| Optimal | 85–94 | |
| Good | 70–84 | |
| Fair | 50–69 | |
| Basic | < 50 | |

### Critical nutrient floor
If any of `iron_mg`, `calcium_mg`, `vitamin_d_ug`, or `magnesium_mg` is below **70%** of its Layer 1 target, the tier is capped at **Optimal** even if the raw score is 95+.

This prevents a score from being Elite when a fundamental athletic nutrient is clearly insufficient.

---

## 6. Layer 1 Completion Toast

When `allMet = true` (all Layer 1 nutrients ≥ 100% of target), a toast fires:

> "Baseline adequacy covered. All key micronutrient targets met today. Now optimise for athlete targets."

The toast fires **once per day** using a localStorage key `amqs-l1-complete-{date}`. It will not repeat on the same calendar day.

---

## 7. ingredients.json Extension

The file at `data/ingredients.json` was extended with five new fields per core food entry:

```json
{
  "vitamin_b1_mg_per_100g": 0.07,
  "vitamin_b2_mg_per_100g": 0.48,
  "vitamin_b3_mg_per_100g": 0.07,
  "vitamin_b6_mg_per_100g": 0.12,
  "omega3_g_per_100g": 0.1
}
```

**Updated entries (37 foods):** Eggs, Oats, Milk (Whole/Semi/Skimmed), Greek Yogurt, Yogurt (Low-Fat), Bread (White/Wholemeal), White/Brown/Basmati Rice, Potatoes, Sweet Potato, Banana, Spinach, Chicken Breast/Thigh, Salmon (Fresh/Smoked/Canned), Tuna (Canned in Water/Oil), Beef Mince (5%/15%), Beef Steaks, Liver, Lentils, Baked Beans, Almonds, Sunflower Seeds, Pumpkin Seeds, Walnuts, Chia Seeds, Flaxseeds, Cheddar Cheese, Cottage Cheese, Avocado, Broccoli, Peas, Edamame, Sardines, Mackerel, Trout.

**Not updated (168 entries):** Processed/composite foods, beverages, condiments, sauces, and foods where B vitamin or Omega-3 data is sparse or unreliable in the standard databases. These foods do not have fake values — absence means the field is simply absent.

All values sourced from USDA FoodData Central and McCance & Widdowson Composition of Foods. No values were invented or estimated.

---

## 8. How to Update Targets

To update Layer 1 or Layer 2 targets, edit `server/lib/amqs.ts`:

```typescript
const NUTRIENTS: NutrientDef[] = [
  {
    key: "calcium_mg",
    // ...
    getTarget: () => 700,     // Layer 1 — baseline
    getL2Target: () => 1000,  // Layer 2 — athlete optimisation
  },
  // ...
];
```

`getL2Target` is optional. If not provided, the nutrient's Layer 1 target is used for Layer 2 as well.

---

## 9. How to Update Weights

Weights are defined on each `NutrientDef` object:

```typescript
{ key: "iron_mg", weight: 2.0, ... }
```

Dynamic weight overrides are applied inside `computeAMQSScore()`:
```typescript
if (n.key === "vitamin_b12_ug" && profile.diet === "vegan") weight = 2.0;
if (n.key === "iron_mg" && profile.sex === "female") weight = 2.5;
```

---

## 10. How to Add a New Nutrient

1. **Add a field to `data/ingredients.json`** for relevant foods: `new_nutrient_unit_per_100g`
2. **Add the key to `MICRO_KEYS` in `server/lib/micros.ts`** so it gets aggregated from food entries.
3. **Add a `NutrientDef` entry to `NUTRIENTS` in `server/lib/amqs.ts`** with Layer 1 and (optionally) Layer 2 targets, a weight, and `getMicronutrientValue()` key.
4. **Document the source** in this file and in the `getL2Target` comment.

---

## 11. Confidence and Tier Logic

**Confidence** is based on what percentage of logged items (foods + supplements) have micronutrient data:
- High: ≥75% of logged items matched
- Medium: 40–74% matched  
- Low: <40% matched or no data

**Tier** is applied to both Layer 1 and Layer 2 scores independently, with the critical nutrient floor applied to both.

---

## 12. Supplements

Supplement micronutrients come from `supplement_catalog.microsPerUnit` (JSONB). Only marked-as-taken supplements are included. The keys in `microsPerUnit` must match the `MICRO_KEYS` identifiers (e.g. `vitamin_d_ug`, `iron_mg`).

New nutrients added in this refinement (B1, B2, B3, B6, Omega-3) can be tracked via supplements if the catalog entries are updated with corresponding `microsPerUnit` keys.

---

## 13. UI Reference Link

The "How this is scored" link is a `<button>` in the AMQS card footer (`data-testid="button-amqs-how-scored"`). It opens a dialog (`data-testid="dialog-how-scored"`) that explains:
- The two-layer model
- Score calculation formula
- Tier thresholds
- Tracked nutrients
- Key references

The same link appears inside the detail modal (`data-testid="button-modal-how-scored"`).

---

## Primary Source Citations

- Thomas DT, Erdman KA, Burke LM. *Nutrition and Athletic Performance.* J Acad Nutr Diet, 2016.
- Maughan RJ et al. *IOC Consensus Statement: Dietary Supplements and the High-Performance Athlete.* Br J Sports Med, 2018.
- Institute of Medicine. *Dietary Reference Intakes.* National Academies Press.
- Burke LM & Deakin V. *Clinical Sports Nutrition.* 5th ed.
- Holick MF et al. *Vitamin D Deficiency: An Important, Common, and Easily Treated Condition.* JCEM, 2011. doi:10.1210/jc.2011-0385
- Owens DJ et al. *Vitamin D and the athlete.* Sports Medicine, 2018. doi:10.1007/s40279-018-0933-7
- Volpe SL. *Magnesium and the Athlete.* Curr Sports Med Rep, 2015. doi:10.1249/JSR.0b013e3181d4f59d
- Lukaski HC. *Magnesium, zinc, and chromium nutrition and athletic performance.* Can J Appl Physiol.
- Peake JM et al. *Antioxidants, exercise and inflammation.* J Sports Med.
- National Academies of Sciences. *Dietary Reference Intakes for Potassium,* 2019.
