# Fight Camp Calorie & Macro Model (v2)

_Server file: `server/routes.ts` — `GET /api/me/targets/effective`_

---

## Order of Operations

1. **Planned calories** — baseline calorie target before constraints  
   `tdeeNoExercise = BMR × 1.4`  
   `plannedCalories = tdeeNoExercise + exerciseKcal − plannedDeficitKcal`

2. **EA floor (hard constraint)** — energy availability must never fall below 30 kcal/kg FFM  
   `ffmKg = bodyweight × (1 − bodyFatPct)`  (defaults to 15% BF if not set)  
   `eaFloor = 30 × ffmKg`  
   `minCaloriesFromEA = exerciseKcal + eaFloor`

3. **Final calorie target**  
   `targetCalories = max(plannedCalories, minCaloriesFromEA)`  
   `constraintSource = "ea_floor"` when EA floor overrides; `"planned_deficit"` otherwise

4. **Macro split by day type** — protein and fat fixed per kg bodyweight; carbs fill remaining calories

   | Day type    | Protein (g/kg) | Fat (g/kg) | Carbs    |
   |-------------|---------------|------------|----------|
   | `hard`      | 1.8           | 0.7        | residual |
   | `very_hard` | 1.8           | 0.5        | residual |
   | `moderate`  | 2.0           | 0.9        | residual |
   | `light`     | 2.0           | 0.9        | residual |
   | `rest`      | 2.0           | 1.0        | residual |

   `carbCals = max(0, targetCalories − protein×4 − fat×9)`  
   `targetCarbs = round(carbCals / 4)`

5. **Flags returned in response**

   | Flag                     | Condition                                                      |
   |--------------------------|----------------------------------------------------------------|
   | `isLowEA`                | `constraintSource === "ea_floor"` (EA floor overrode planned) |
   | `isLowCarb`              | `carbG < 3 × bodyweight` AND not a rest day                   |
   | `isBelowPerformanceCarb` | Soft carb warning per day type (see below)                    |
   | `eaValue`                | `(targetCalories − exerciseKcal) / ffmKg` in kcal/kg FFM     |

6. **Soft carb performance thresholds** (non-rest days only)

   | Day type    | Threshold | Warning message                                                                                                                         |
   |-------------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------|
   | `hard`      | < 4 g/kg  | "You may benefit from increasing carbohydrate intake for performance. Typical recommendations are ~5 g/kg for this level of training."  |
   | `very_hard` | < 5 g/kg  | "Carbohydrate intake may be low for a very high training load. Increasing toward ~5–7 g/kg may support performance."                   |
   | `moderate`  | < 3 g/kg  | "Carbohydrate intake is at the lower end. ~3–5 g/kg is typically recommended for moderate training."                                   |
   | `light`     | < 3 g/kg  | "Carbohydrate intake is below minimum recommended levels (~3 g/kg) for athletes (IOC/ISSN guidelines)…"                               |

## API Response Fields

```json
{
  "mode": "fight_camp",
  "modeLabel": "Fight Camp Fat Loss",
  "modeNote": "Calories adjusted for today's logged training.",
  "targetCalories": 2100,
  "targetProtein": 130,
  "targetCarbs": 210,
  "targetFat": 50,
  "tdee": 2500,
  "baselineTdee": 2000,
  "trainingKcalToday": 500,
  "dailyDeficit": 400,
  "plannedCalories": 2100,
  "minCaloriesFromEA": 1944,
  "constraintOverrideKcal": 0,
  "constraintSource": "planned_deficit",
  "dayType": "hard",
  "eaValue": 30.0,
  "isLowEA": false,
  "isLowCarb": false,
  "isBelowPerformanceCarb": true,
  "performanceCarbWarning": "You may benefit from increasing carbohydrate intake...",
  "trainingCalorieCreditPct": 0,
  "provisional": false,
  "weeklyRate": 0.5,
  "weeklyRatePct": 0.69,
  "daysUntil": 100
}
```

## Key Principles

- **Training is baked into `targetCalories`** — client must NOT add training calories again (`trainingCalorieCreditPct = 0`).
- **EA floor is the only hard calorie constraint** — carb floor is advisory (flags only, no forced calorie override).
- **Rest day** = no sessions logged (`todaySessions.length === 0`). Rest days: protein 2.0 g/kg, fat 1.0 g/kg, no carb floor warning.
- **`provisional = true`** when it's a rest day (no training logged); calories will change once sessions are added.
- **References:** IOC RED-S consensus (EA < 30 kcal/kg FFM), IOC/ISSN carbohydrate guidelines.

## Client Responsibilities

When `isLowEA === true`:
- Show a modal: "Energy availability too low" with the IOC RED-S message.
- Offer "Adjust target" (accept the EA-floored calories) or "Keep plan".

When `isLowCarb === true`:
- Show a hard floor warning: carbs < 3 g/kg on a training day.
- Offer user the choice to adjust.

When `isBelowPerformanceCarb === true` (and `isLowCarb === false`):
- Show `performanceCarbWarning` as a soft advisory toast or inline note.
- No user action required.
