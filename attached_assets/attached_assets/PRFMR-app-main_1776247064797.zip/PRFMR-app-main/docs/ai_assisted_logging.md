# AI-Assisted Logging (Quick Log)

## Overview

Quick Log is a natural-language logging feature that lets athletes describe what they've done in plain English. It parses the text into a structured intent, shows a confirmation UI, and only saves to the database after the user explicitly confirms.

**Key principle: the parser never writes to the database. Everything goes through the confirmation step.**

## Entry Point

The "Quick Log" button appears in the dashboard header action bar, next to "Add Food". It opens `AILogDialog`.

`data-testid="button-ai-log"`

---

## Supported Intents

### 1. `log_food`

**Triggers:** Phrases containing meal keywords or food trigger words.

**Examples:**
- `"2 eggs and 2 slices of toast for breakfast"`
- `"Had chicken and rice for lunch"`
- `"Banana and yogurt as a snack"`

**Behaviour:**
1. Parser extracts meal type and individual food items with counts/grams.
2. Dialog matches each item against `ingredients.json` by fuzzy name matching.
3. Macros are calculated at the matched ingredient's per-100g values × detected grams.
4. Unmatched items are shown but deselected by default.
5. User can edit grams inline before confirming.
6. On confirm: `POST /api/food` for each included item with `sourceType: "ingredient"`.

---

### 2. `log_weight`

**Triggers:** "weight", "weigh", "morning weight", or a bare number (40–250).

**Examples:**
- `"Morning weight 71.8"`
- `"Weighed 71.2 kg"`
- `"71.8"` (bare bodyweight)

**Behaviour:**
1. Parser extracts the numeric weight. If in lbs, converts to kg.
2. Dialog shows the value and allows editing.
3. On confirm: `POST /api/weights` with `{ date, weight }`.
4. Invalidates: weights range, weight-cut, targets/effective, morning-status.

---

### 3. `log_training_session`

**Triggers:** Activity keywords (pads, muay thai, running, cycling, bjj, etc.) + optional duration/time.

**Examples:**
- `"Pads for 60 min at 7pm"`
- `"Running 30 minutes this morning"`
- `"BJJ 1 hour"`

**Behaviour:**
1. Parser extracts activity name, duration (defaults 60 min if missing), and time of day.
2. Dialog allows editing all three fields inline.
3. On confirm:
   - `POST /api/workouts/sessions` → creates session with title + timeOfDay.
   - `GET /api/activities?query=...` → looks up best-matching activity in catalog.
   - `POST /api/workouts/sessions/:id/activities` → attaches activity with duration + metValue.
4. Invalidates: workouts/sessions, training/summary, targets/effective.

---

### 4. `log_supplements`

**Triggers:** Known supplement keywords (creatine, vitamin D, magnesium, zinc, fish oil, etc.) + take/took/had phrases.

**Examples:**
- `"Creatine and Vitamin D taken"`
- `"Took magnesium and zinc"`
- `"Had fish oil"`

**Behaviour:**
1. Parser extracts supplement names from the keyword bank.
2. Dialog matches each raw name against the user's saved supplements (`GET /api/me/supplements`).
3. Unmatched supplements are flagged and excluded by default.
4. On confirm: `POST /api/supplement-intakes` for each matched supplement.
5. Invalidates: supplement-intakes for selected date.

**Note:** Supplements must already be added in the Supplements section before they can be matched here.

---

### 5. `create_recurring_training_schedule`

**Triggers:** "every [day of week]" phrases.

**Examples:**
- `"Every Tuesday pads at 7pm for 60 min"`
- `"Every Thursday morning BJJ 90 min and afternoon bag work 30 min in fight camp"`

**V1 Behaviour (simplified):**
1. Parser extracts the day of week and sessions.
2. Dialog shows a confirmation card with a clear note that V1 only creates the **next** occurrence of that day.
3. On confirm: creates training sessions for the next matching date.
4. Full recurring schedule management is available in the Training Log section.

---

## Confidence Levels

| Level  | Meaning |
|--------|---------|
| `high` | Multiple strong signals detected (meal keyword + food names, or weight trigger + number) |
| `medium` | One strong signal or ambiguous detection — review carefully before confirming |
| `low` | Parser uncertain — shown in the unknown/clarification state |

---

## Parser Architecture (`client/src/lib/aiLogParser.ts`)

The parser is purely rule-based and runs entirely on the client:

1. **Normalise** input (lowercase, trim)
2. **Score** each intent using keyword banks and pattern matching
3. **Pick** the highest-scoring intent (minimum score of 2 required)
4. **Sub-parse** to extract entities for that intent
5. **Return** a typed `ParseResult` with `requiresConfirmation: true`

No API calls are made during parsing.

---

## Dialog Architecture (`client/src/components/AILogDialog.tsx`)

### Dialog States

| State | Description |
|-------|-------------|
| `input` | Textarea + Review button + optional mic |
| `review` | Confirmation card for the parsed intent |
| `saving` | Mutation pending |
| `done` | Success screen with "Log another" option |

### Key `data-testid` attributes

| Element | testid |
|---------|--------|
| Text input | `ai-log-input` |
| Parse/Review button | `ai-parse-button` |
| Mic toggle | `ai-mic-button` |
| Food confirm button | `ai-confirm-food` |
| Weight confirm button | `ai-confirm-weight` |
| Training confirm button | `ai-confirm-training` |
| Supplements confirm button | `ai-confirm-supplements` |
| Recurring confirm button | `ai-confirm-recurring` |
| Edit/back button | `ai-edit-back` |
| Per-food grams input | `ai-food-grams-{index}` |
| Per-food toggle | `ai-food-toggle-{index}` |
| Supplement toggle | `ai-supp-toggle-{index}` |
| Log another button | `ai-log-another` |
| Dashboard entry button | `button-ai-log` |

---

## Adding New Activity Keywords

Edit `TRAINING_ACTIVITY_KEYWORDS` in `client/src/lib/aiLogParser.ts`.

## Adding New Supplement Keywords

Edit `SUPPLEMENT_KEYWORDS` in `client/src/lib/aiLogParser.ts`.

## Adding Core Food Unit Support

Follow the guide in `docs/core_food_units.md` and add to `client/src/lib/coreFoodUnits.ts`.

---

## Future V2 Ideas

- True recurring schedule creation (write to a recurring_sessions table)
- Ambiguity resolution prompts ("Did you mean Chicken Breast or Chicken Thigh?")
- Multi-intent parsing in a single input ("2 eggs for breakfast and morning weight 71.8")
- Confidence-based auto-confirm for high-confidence intents
- Meal photo parsing via API
