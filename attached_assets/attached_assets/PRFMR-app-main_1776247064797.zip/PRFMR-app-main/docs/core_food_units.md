# Core Food Units

Allows logging common whole foods by count and size instead of raw grams.

## Where mappings live

`client/src/lib/coreFoodUnits.ts`

Each entry is keyed by the **exact food name** as it appears in `data/ingredients.json`.

## How count + size converts to grams

```
// supportsSize = true
totalGrams = gramsBySize[selectedSize] × count

// supportsSize = false (uniform size)
totalGrams = gramsPerUnit × count
```

`computeUnitGrams(unit, count, size)` does this calculation and returns an integer.

The result is stored in the existing `grams` state variable in `FoodEntryDialog`,
so it flows directly into `calculateMacro(per100)` → `(per100 × grams) / 100`.
No changes to the backend or nutrition pipeline are needed.

## Foods currently supported

| Food | Sizes | Default |
|------|-------|---------|
| Eggs (Whole) | small 38g / medium 44g / large 50g | 2 × medium |
| Banana | small 100g / medium 118g / large 136g | 1 × medium |
| Apple | small 100g / medium 138g / large 182g | 1 × medium |
| Orange | small 100g / medium 131g / large 160g | 1 × medium |
| Kiwi | 90g each (no size) | 1 |
| Dates (Dried) | 8g each (no size) | 3 |
| Bread (White Sliced) | 30g per slice | 2 slices |
| Bread (Wholemeal) | 35g per slice | 2 slices |
| Bread (Sourdough) | 35g per slice | 1 slice |
| Pitta Bread | 70g each | 1 |
| Bagel (Plain) | 105g each | 1 |
| Tortilla Wrap (Wheat) | 45g each | 1 |
| Rice Cakes | 9g each | 3 |

## Adding a new food

1. Find the exact name in `data/ingredients.json`
2. Add an entry to `CORE_FOOD_UNITS` in `client/src/lib/coreFoodUnits.ts`:

```ts
"Food Name": {
  supportsCount: true,
  supportsSize: true,           // false if no size variation
  defaultCount: 1,
  defaultSize: "medium",        // omit if supportsSize: false
  gramsBySize: { small: X, medium: Y, large: Z },   // if supportsSize
  gramsPerUnit: X,              // if not supportsSize
  unitLabel: "singular noun",   // e.g. "egg", "slice", "wrap"
},
```

3. That's it — the UI automatically shows the Count/Grams toggle when this food is selected.
