# Performance Features — Sleep, Readiness, Fuel, Weight Cut

## Sleep Logging

Users log sleep hours and optional quality (1–5) each morning via the Morning Check-In card on the dashboard.

- **API**: `PUT /api/me/sleep/:date` (hoursSlept, sleepQuality?)
- **Storage**: `sleep_logs` table, unique per user+date, upsert behavior
- **UI**: `client/src/components/MorningCheckIn.tsx`

## Session Readiness Score (0–100)

Composite score from four components, computed server-side.

| Component           | Max Points | File                       |
|---------------------|-----------|----------------------------|
| Sleep               | 30        | `server/lib/readiness.ts`  |
| Energy Availability | 30        | `server/lib/readiness.ts`  |
| Carb Sufficiency    | 25        | `server/lib/readiness.ts`  |
| AMQS                | 15        | `server/lib/readiness.ts`  |

### Sleep Score (/30)
- 8+ hours → 30
- 7–8 hours → 26
- 6–7 hours → 20
- 5–6 hours → 14
- <5 hours → 8
- Quality adjustment: ≥4 stars → +2, ≤2 stars → -2

### Energy Availability (/30)
EA = (calories_yesterday − exercise_kcal_yesterday) / bodyweight_kg
- EA ≥ 40 → 30
- EA ≥ 35 → 26
- EA ≥ 30 → 20
- EA ≥ 25 → 12
- EA < 25 → 6

### Carb Sufficiency (/25)
carbsPerKg = carbs_yesterday_g / bodyweight_kg

Target ranges by planned intensity:
- Rest/Light: 3–4 g/kg
- Moderate: 4–6 g/kg
- Hard: 6–8 g/kg

Scoring: in range → 25, ≥75% of low end → 20, ≥50% → 12, below → 6

### AMQS (/15)
- AMQS ≥ 85 → 15
- AMQS ≥ 75 → 12
- AMQS ≥ 60 → 9
- AMQS < 60 → 5

### Labels
- ≥ 85 → High
- ≥ 70 → Moderate
- ≥ 55 → Low
- < 55 → Poor
- Missing data → **Provisional** (score shown but marked as estimate)

### Provisional State
When any of the following data is missing, the score is labelled "Provisional" with a blue badge and a specific CTA listing the missing inputs:
- Sleep not logged
- Yesterday's food not logged
- Bodyweight not available (today, recent 7 days, or profile)

### Bodyweight Resolution (all performance routes)
Order: today's weight log → last 7 days → profile `currentWeight` → null.
Response includes `bodyweightSource` ("today"|"recent"|"profile"|null) and `bodyweightKg`.

### API
`GET /api/me/readiness/:date`
Returns additional fields: `provisional`, `missingData[]`, `bodyweightSource`, `bodyweightKg`

## Fuel Availability / Glycogen Risk

### Fuel Status
Based on Energy Availability (same formula as readiness):
- EA ≥ 40 → High
- EA ≥ 30 → Adequate
- EA < 30 → Low

### Glycogen Risk
Based on carbs/kg and planned intensity:

| Intensity | High Risk | Moderate Risk | Low Risk |
|-----------|----------|---------------|----------|
| Hard      | < 4 g/kg | 4–6 g/kg      | > 6 g/kg |
| Moderate  | < 3.5    | 3.5–5         | > 5      |
| Light     | < 2      | 2–3.5         | > 3.5    |

### Provisional State
Shows "Provisional" badge when yesterday's food is not logged and bodyweight is unavailable. CTA message guides user to log the missing data.

### API
`GET /api/me/fuel/:date`
Returns additional fields: `provisional`, `hasYesterdayFood`, `bodyweightSource`, `bodyweightKg`

### File
`server/lib/fuel-availability.ts`

## Weight Cut Planner

Fat-loss-only planning tool for athletes with a target date.

### Inputs
- Current weight (kg)
- Target weight (kg)
- Fight/target date

### Calculations
- Weekly rate = total_to_lose / weeks_until
- Weekly rate % = weekly_rate / current_weight × 100
- Suggested deficit = weekly_rate × 7700 / 7 (kcal/day)

### Status Labels (calm language)
| Weekly Rate % | Status Key       | Label                                      |
|--------------|------------------|--------------------------------------------|
| ≤ 0.5%       | on_track         | Steady pace                                |
| ≤ 1.0%       | on_track         | On track                                   |
| ≤ 1.5%       | aggressive       | Faster than ideal — keep an eye on energy  |
| ≤ 2.0%       | very_aggressive  | Quite fast — consider extending timeline   |
| > 2.0%       | unrealistic      | Timeline too tight — adjust target or date |

### Features
- **Edit**: Pencil icon opens the same dialog pre-filled with current values (reuses POST which upserts)
- **Bodyweight**: Uses `resolveBodyweight` helper for live weight data

### API
- `GET /api/me/weight-cut` — returns `bodyweightSource` field
- `POST /api/me/weight-cut` — upserts (deletes existing then creates)
- `PUT /api/me/weight-cut`
- `DELETE /api/me/weight-cut`

### Files
- Calculation: `server/lib/weight-cut.ts`
- Storage: `server/storage.ts`, `server/database-storage.ts`
- Schema: `shared/schema.ts` (`weight_cut_plans` table)
- UI: `client/src/components/WeightCutPlanner.tsx`

## Morning Check-In

Dashboard card that prompts users to complete their morning routine:
1. Log sleep (hours + optional quality)
2. Log morning weight
3. Create training session

Disappears when all items are completed for the day.

### API
`GET /api/me/morning-status/:date`

### File
`client/src/components/MorningCheckIn.tsx`

## Changing Thresholds

All threshold values are in the calculation modules:
- Sleep scoring: `server/lib/readiness.ts` → `calculateSleepScore()`
- EA thresholds: `server/lib/readiness.ts` → `calculateEnergyAvailability()`
- Carb targets: `server/lib/readiness.ts` → `getCarbTargetRange()`
- AMQS thresholds: `server/lib/readiness.ts` → `calculateAmqsSufficiency()`
- Fuel status: `server/lib/fuel-availability.ts` → `calculateFuelStatus()`
- Glycogen risk: `server/lib/fuel-availability.ts` → `calculateGlycogenRisk()`
- Weight cut status: `server/lib/weight-cut.ts` → status label thresholds
