# PRFMR Developer Guide

## 1. Project Overview

### What is PRFMR?

PRFMR is a mobile-first web application for athletes, fighters, and active individuals who want to manage their nutrition with precision. It goes beyond simple calorie counting by tracking **micronutrients** (vitamins and minerals), calculating an **Athlete Micronutrient Quality Score (AMQS)**, and logging training sessions.

### Who is it for?

- Athletes and fighters who need to optimise recovery and performance
- Active individuals managing fat loss, maintenance, or weight gain goals
- Anyone who wants data-driven insight into their nutritional quality, not just calories

### Main Features

| Feature | Description |
|---|---|
| **Food Logging** | Log meals manually, from a curated list, via barcode scanner, or by searching Open Food Facts |
| **Macro Tracking** | Track calories, protein, carbs, fat, and fibre against personalised daily targets |
| **AMQS Score** | A 0–100 score measuring how well you're covering 12 key micronutrients |
| **Nutrient Gap Analysis** | Identifies your top 3 nutrient gaps and suggests foods to close them |
| **Training Log** | Log workouts (exercises, sets, reps, weight, RPE), cardio, and manual calorie burns |
| **Supplement Tracker** | Track supplements, build stacks, set reminders, and see how they contribute to your AMQS |
| **Saved Meals** | Save and reuse meal templates for quick logging |
| **Weight Tracking** | Log body weight over time with trend visualisation |
| **Playbook** | Educational content on nutrition principles (with disclaimers) |

---

## 2. Project Structure

```
prfmr/
├── client/                  # React frontend (Vite + TypeScript)
│   └── src/
│       ├── pages/           # Route-level views
│       ├── components/      # Reusable UI components
│       │   └── ui/          # shadcn/ui primitives (Button, Card, Dialog, etc.)
│       ├── hooks/           # Custom React hooks
│       └── lib/             # Frontend utilities (API client, helpers)
├── server/                  # Express backend (TypeScript, ESM)
│   ├── lib/                 # Business logic modules
│   ├── routes.ts            # Main API routes
│   ├── auth.ts              # Passport.js setup
│   ├── auth-routes.ts       # Login, register, OAuth endpoints
│   ├── feedback-routes.ts   # Feedback submission endpoints
│   ├── invite-routes.ts     # Invite-only signup system
│   ├── storage.ts           # IStorage interface (data access contract)
│   ├── database-storage.ts  # PostgreSQL implementation of IStorage
│   ├── db.ts                # Drizzle ORM database connection
│   └── index.ts             # Server entry point
├── shared/                  # Code shared between frontend and backend
│   ├── schema.ts            # Database schema + Zod validation types
│   ├── routes.ts            # Shared API route constants
│   ├── utils.ts             # Shared utility functions
│   └── username-validation.ts
├── data/
│   └── ingredients.json     # Reference database of foods with micronutrient profiles
├── script/                  # Maintenance scripts (seeding, migrations)
├── drizzle.config.ts        # Database migration configuration
├── vite.config.ts           # Frontend build configuration
└── package.json
```

### Key Files Explained

#### Frontend (`client/src/`)

| File | Purpose |
|---|---|
| `pages/dashboard.tsx` | Main dashboard — AMQS card, macro summary, food log, training card, supplements |
| `pages/onboarding.tsx` | 4-step onboarding flow that calculates personalised macro targets |
| `pages/training.tsx` | Full training log — exercises, cardio, session history |
| `pages/supplements.tsx` | Supplement catalog browser and personal supplement management |
| `pages/stacks.tsx` | Supplement stack builder with scheduling and reminders |
| `pages/start.tsx` | Landing/signup page with invite code entry and source attribution |
| `hooks/use-auth.ts` | Authentication state management (session, user data) |
| `hooks/use-logs.ts` | Food entry CRUD, AMQS-aware toast notifications, cache invalidation |
| `hooks/use-reminder-engine.ts` | Push notification scheduling for supplement reminders |
| `components/layout.tsx` | App shell — top bar, bottom nav (mobile), sidebar (desktop) |

#### Backend (`server/`)

| File | Purpose |
|---|---|
| `lib/amqs.ts` | AMQS score calculation — weights, targets, adequacy formula |
| `lib/micros.ts` | Micronutrient aggregation from food entries and supplements |
| `lib/energy.ts` | Calorie burn estimation using MET-based formulas |
| `lib/offMatch.ts` | Algorithm to match Open Food Facts products to local ingredient database |
| `lib/email.ts` | Email sending via Resend (verification, invite codes, feedback) |
| `lib/push-notifications.ts` | Web Push notification service (VAPID authentication) |
| `storage.ts` | `IStorage` interface — defines all data access methods |
| `database-storage.ts` | Implements `IStorage` using Drizzle ORM + PostgreSQL |
| `routes.ts` | API endpoints for food search, AMQS, training, supplements, etc. |
| `auth.ts` | Passport.js strategies (local + Google OAuth) |

#### Shared (`shared/`)

| File | Purpose |
|---|---|
| `schema.ts` | Single source of truth: database tables, Zod schemas, insert/select types, source allowlist |
| `utils.ts` | `Ingredient` type definition, `getMicronutrientValue()` helper |

#### Data (`data/`)

| File | Purpose |
|---|---|
| `ingredients.json` | ~200+ foods with full micronutrient profiles per 100g (iron, calcium, vitamin D, etc.) |

### How Frontend, Backend, and Database Interact

```
┌─────────────┐    HTTP/JSON     ┌─────────────┐    Drizzle ORM    ┌────────────┐
│   React     │ ──────────────── │   Express   │ ──────────────── │ PostgreSQL │
│  Frontend   │  TanStack Query  │   Backend   │   IStorage       │  Database  │
│  (Vite)     │                  │  (Node.js)  │                  │            │
└─────────────┘                  └─────────────┘                  └────────────┘
       │                                │
       │ imports from                   │ reads
       ▼                                ▼
  shared/schema.ts              data/ingredients.json
  shared/utils.ts
```

1. **Frontend** makes API calls using TanStack React Query (default fetcher configured in `lib/queryClient.ts`)
2. **Backend** validates requests with Zod schemas from `shared/schema.ts`, then calls `IStorage` methods
3. **Database** is accessed only through `DatabaseStorage` (implements `IStorage`), using Drizzle ORM
4. **Shared types** ensure the frontend and backend always agree on data shapes

---

## 3. How the App Works (Step by Step)

### User Flow: Signup → Logging Food → Seeing Insights

#### Step 1: Signup (Invite-Only)
1. User visits `/start` with an optional source param (e.g., `?src=ig`)
2. Enters an **invite code** to gain access (beta user cap enforced)
3. Creates account with email/password or continues with Google OAuth
4. Source attribution is tracked across `invite_requests`, `users`, and `users_auth` tables

#### Step 2: Onboarding
1. User answers 4 questions: age, sex, weight, activity level, and goal
2. Backend calculates personalised targets using **Mifflin-St Jeor BMR** → **TDEE** → goal-adjusted macros
3. Targets are stored in the user profile

#### Step 3: Logging Food
1. User taps "Add Food" on the dashboard (or the mobile FAB button)
2. Chooses from: **Quick-add** (curated meals), **Search** (Open Food Facts), **Barcode** scan, or **Manual** entry
3. Each entry is saved with: name, grams, calories, protein, carbs, fat, fibre, meal type, and source metadata
4. For entries matched to `ingredients.json`, micronutrient data is automatically attached

#### Step 4: Micronutrient Aggregation
1. `server/lib/micros.ts` runs `getDailyMicros()` which:
   - Sums micronutrients from all food entries for the day (matching against `ingredients.json`)
   - Decomposes composite meals (e.g., "porridge" → oats + milk) into individual ingredients
   - Sums micronutrient contributions from taken supplements
   - Returns combined totals with a food/supplement breakdown

#### Step 5: AMQS Scoring
1. `server/lib/amqs.ts` runs `computeAMQSScore()` which:
   - Gets micronutrient totals from Step 4
   - Compares each nutrient intake against sex/age-adjusted daily targets
   - Calculates a weighted average of nutrient adequacies (0–100)
   - Identifies the top 3 nutrient gaps and suggests foods to close them
   - Assigns a tier: Basic / Fair / Good / Optimal / Elite

#### Step 6: Dashboard Display
1. **AMQS Card** shows the daily score, tier, 7-day trend sparkline, and top gaps with progress bars
2. **Macro cards** show calories, protein, carbs, fat progress against targets
3. **Training card** shows today's sessions and calories burned
4. **Supplement card** shows today's scheduled supplements and intake status
5. Clicking the AMQS score opens a details modal with "What moved it today" and quick win suggestions

---

## 4. Nutrient Score System (AMQS)

See **[NUTRIENT_SCORING.md](./NUTRIENT_SCORING.md)** for the complete technical breakdown including:
- The scoring formula and how it works
- All 12 tracked nutrients ranked by weight
- Why certain nutrients matter more for athletes
- How to modify weights, targets, and add new nutrients
- A worked example calculation

---

## 5. Data Sources

### Where Nutrient Data Comes From

| Source | What it provides | File/Module |
|---|---|---|
| `data/ingredients.json` | Micronutrient profiles for ~200+ foods (per 100g) | Loaded by `server/lib/micros.ts` |
| Open Food Facts API | Macros and product info for branded/packaged foods | Queried by `server/routes.ts` (`/api/foods/search`) |
| Supplement Catalog | Micronutrient content per supplement unit | Stored in `supplement_catalog` table |
| User Manual Entry | User-entered macros for custom foods | Stored in `food_entries` table |

### How Foods are Stored

**Food entries** (`food_entries` table) store:
- Basic macros: calories, protein, carbs, fat, fibre
- Source metadata: `sourceType` (manual / off / ingredient), `offBarcode`, `ingredientIndex`
- Micro tracking: `microSource` (none / ingredient), `ingredientIndex` (link to `ingredients.json`)
- Cooking adjustments: `enteredBasis` (raw/cooked), `normalizedGrams`, `yieldFactorUsed`

**Micronutrient lookup** happens at query time, not storage time. When AMQS is calculated, the system looks up each food entry's micronutrient values from `ingredients.json` using the stored `ingredientIndex` or name match.

### How `ingredients.json` is Structured

Each entry contains:
```json
{
  "name": "Spinach",
  "calories_per_100g": 23,
  "protein_g_per_100g": 2.9,
  "carbs_g_per_100g": 3.6,
  "fat_g_per_100g": 0.4,
  "fibre_g_per_100g": 2.2,
  "iron_mg_per_100g": 2.7,
  "calcium_mg_per_100g": 99,
  "magnesium_mg_per_100g": 79,
  "zinc_mg_per_100g": 0.5,
  "potassium_mg_per_100g": 558,
  "vitamin_c_mg_per_100g": 28,
  "vitamin_a_ug_per_100g": 469,
  "vitamin_b12_ug_per_100g": 0,
  "folate_ug_per_100g": 194,
  "iodine_ug_per_100g": null,
  "selenium_ug_per_100g": 1,
  "vitamin_d_ug_per_100g": 0,
  "supportsCookedToggle": true,
  "canonicalBasis": "raw",
  "cookedYieldFactor": 0.85,
  "commonScore": 0.9
}
```

The `commonScore` (0–1) indicates how commonly consumed a food is and influences AMQS food suggestions.

---

## 6. Managing the App as a Beginner Developer

### Running the App Locally

The app runs on Replit. The workflow `Start application` executes:

```bash
npm run dev
```

This starts both the Express backend and Vite frontend dev server on the same port. Changes to source files trigger automatic hot-reload.

### Deploying

Use Replit's built-in deployment. The app publishes to a `.replit.app` domain with automatic TLS and health checks.

### Updating Nutrient Logic

#### To change AMQS nutrient weights or targets:
1. Open `server/lib/amqs.ts`
2. Find the `NUTRIENTS` array (line ~25)
3. Modify the `weight` value or `getTarget` function for any nutrient
4. Save — the server auto-restarts

#### To add a new tracked nutrient:
1. Add it to the `NUTRIENTS` array in `server/lib/amqs.ts`
2. Add the corresponding `_per_100g` field to entries in `data/ingredients.json`
3. Add the key to `MICRO_KEYS` in `server/lib/micros.ts`
4. Update the `Ingredient` type in `shared/utils.ts` if needed

#### To add a new food to the ingredient database:
1. Open `data/ingredients.json`
2. Add a new object following the existing format (all values per 100g)
3. Include a `commonScore` (0–1) — higher means it's more commonly eaten
4. Save — the ingredient cache refreshes on next server restart

#### To add a new composite meal decomposition:
1. Open `server/lib/micros.ts`
2. Add an entry to the `COMPOSITE_FOODS` object
3. Each component's `ingredient` name must match an entry in `ingredients.json` (case-insensitive)
4. Run the app — `validateCompositeIngredients()` warns about any unmatched names at startup

### Adding Features Safely

1. **Schema first**: Define new tables or columns in `shared/schema.ts` (with insert schemas and types)
2. **Storage interface**: Add new methods to `IStorage` in `server/storage.ts`
3. **Implementation**: Implement the methods in `server/database-storage.ts`
4. **Routes**: Add thin API routes in `server/routes.ts` (validate with Zod, delegate to storage)
5. **Frontend**: Add pages in `client/src/pages/`, use TanStack Query for data fetching
6. **Push schema**: Run `npm run db:push` to sync the database

---

## 7. Key Functions Explained

### Backend

| Function | File | What it does |
|---|---|---|
| `computeAMQSScore()` | `server/lib/amqs.ts` | Takes a user ID and date, calculates the 0–100 AMQS score by comparing nutrient intake vs targets |
| `computeWeeklyAMQS()` | `server/lib/amqs.ts` | Runs `computeAMQSScore()` for each day in a date range and averages the scores |
| `getDailyMicros()` | `server/lib/micros.ts` | Aggregates all micronutrient intake (food + supplements) for a given day |
| `getFoodMicrosForDate()` | `server/lib/micros.ts` | Looks up each food entry in `ingredients.json` and calculates nutrient contributions based on grams eaten |
| `getSupplementMicrosForDate()` | `server/lib/micros.ts` | Sums micronutrient contributions from all supplements marked as "taken" that day |
| `isCompositeFoodEntry()` | `server/lib/micros.ts` | Checks if a food name maps to a composite meal (e.g., "porridge") that needs decomposition |
| `kcalFromMET()` | `server/lib/energy.ts` | Estimates calories burned using: `(MET x 3.5 x weight_kg / 200) x minutes` |
| `getStrengthMET()` | `server/lib/energy.ts` | Returns the MET value for a strength training intensity (light=3.5, moderate=5.0, vigorous=6.0) |
| `normalizeSource()` | `shared/schema.ts` | Validates and normalises a traffic source string against the `SOURCE_ALLOWLIST` |

### Frontend

| Function/Hook | File | What it does |
|---|---|---|
| `useAuth()` | `hooks/use-auth.ts` | Provides the current user session, login/logout functions, and auth state |
| `useCreateFoodEntry()` | `hooks/use-logs.ts` | Mutation hook for logging a food entry — posts to API, invalidates caches, shows AMQS-aware toast |
| `scrollToAmqsCard()` | `hooks/use-logs.ts` | Smoothly scrolls the dashboard to the AMQS card and triggers a pulse animation |
| `AMQSCard` | `pages/dashboard.tsx` | Dashboard component showing AMQS score, tier, sparkline, gaps, and clickable details modal |

---

## Quick Reference

| Topic | Where to look |
|---|---|
| Database schema | `shared/schema.ts` |
| All API routes | `server/routes.ts`, `server/auth-routes.ts`, `server/feedback-routes.ts` |
| AMQS scoring formula | `server/lib/amqs.ts` (line ~25 for weights, line ~258 for final score) |
| Micronutrient data | `data/ingredients.json` |
| Micro aggregation | `server/lib/micros.ts` |
| Composite meal decomposition | `server/lib/micros.ts` (`COMPOSITE_FOODS` map) |
| Calorie calculations | `server/lib/energy.ts` |
| Environment secrets | `.env` / Replit Secrets panel |
| Source attribution | `shared/schema.ts` (`SOURCE_ALLOWLIST`) |
