# PRFMR - Athlete Nutrition & Training Tracker

## Overview
PRFMR is a mobile-first web application designed to empower active individuals with sustainable nutrition management. It offers tools for calorie and macro tracking, weight trend visualization, and nutrition education to support fat loss, maintenance, and weight gain goals. The project provides personalized macro targets, training calorie credits, daily food logging (with barcode scanner and micronutrient mapping), progress charts, an educational "Playbook," a supplement tracker with micronutrient integration, and a comprehensive training log. The core vision is to enable data-driven health and fitness decisions.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework:** React 18 with TypeScript, using Vite.
- **Routing:** Wouter.
- **State Management:** TanStack React Query.
- **Styling:** Tailwind CSS with shadcn/ui.
- **Animations:** Framer Motion.
- **Charts:** Recharts.
- **Design Principles:** Dark theme, conservative framing, transparent calculations, clear educational disclaimers, and a mobile-first approach.
- **Key UI Elements:** Intelligent button hierarchy, persistent "Add Food" dialog, supplement/stack explainers, smart toast notifications, and guided onboarding.

### Backend
- **Runtime:** Node.js with Express, written in TypeScript (ESM modules).
- **API Design:** RESTful endpoints with shared schema/route definitions for type safety.
- **Core Logic:** Server-side processing for critical calculations (BMR, TDEE, macro adjustments).

### Data Storage
- **ORM:** Drizzle ORM configured for PostgreSQL.
- **Schema:** Comprehensive schema for user profiles, logs (weight, macros, food), supplement tracking, training sessions, and authentication.

### Authentication System
- **Mechanism:** Secure session-based authentication using Passport.js with local strategy (Argon2 hashing) and Google OAuth 2.0.
- **Features:** Email/username login, password requirements, email verification (via Resend), API endpoint protection, and an invite-only signup system with beta user cap.

### Core Features
- **Saved Meals:** Users can save and reuse meal templates.
- **Supplement Tracker:** Track supplements and stacks, define dosages, set reminders, and integrate micronutrient data.
- **Raw vs. Cooked Weight Handling:** Automatic conversion for accurate macro/micro calculations.
- **AMQS (Athlete Micronutrient Quality Score):** Server-side aggregation of micronutrients, daily/weekly scores, identification of nutrient gaps, and food suggestions. Uses a two-layer model (baseline adequacy and athlete optimization) with 17 tracked nutrients and detailed scoring thresholds.
- **Training Log:** Records workouts, exercises (reps, weight, RPE), cardio, estimates calories burned, and dynamically adjusts nutrition targets. Includes manual calorie burn logging and detailed lifting activity tracking.
- **Calculation Engine:** Implements Mifflin-St Jeor BMR, TDEE, and goal-specific adjustments for calories, protein, fat, and dynamic carbohydrate adjustments.
- **Fight Camp Target Override:** A priority system for nutrition targets (Fight Camp Active > Profile Goal > Maintenance) with specific macro models for different training intensities and warnings for low energy/carb availability.
- **Sleep Logging:** Daily sleep hours and quality tracking via Morning Check-In.
- **Rest Day Logging:** Users can mark any day as a rest day, which adjusts nutrition targets accordingly.
- **Provisional Check-In:** Self-report card for missing data to drive provisional readiness and fuel estimates.
- **Session Readiness Score:** Composite score (0–100) based on sleep, energy availability, carb sufficiency, and AMQS.
- **Fuel Availability & Glycogen Risk:** Status based on yesterday's intake, exercise, and planned training.
- **WeightCutHero:** Dashboard hero card for fight camp, displaying countdown, weight goals, fat loss breakdown, and consistency tracking. Includes `same_day` vs. `day_before` weigh-in timing options.
- **Morning Check-In:** Dashboard card prompting sleep log, morning weight, and training session creation, with inline weight logging.
- **Push Notifications:** Web Push API for notifications.
- **Profile Photo Upload:** Secure uploads using Replit Object Storage.
- **Food Search:** Integration with Open Food Facts for searching food items, macros, and micronutrients.
- **Core Foods Quick-Add:** Pre-curated common mixed meals for instant logging with micronutrient decomposition.
- **Meal Totals:** Compact totals row for each meal section.
- **Copy Food Item:** Feature to copy food entries to other dates/meals.
- **Count-mode in Edit dialog:** For specific whole foods, allows logging by count and size rather than raw grams.
- **Macro Warnings:** Visual warnings for exceeding macro targets.
- **Beta Feedback:** Dedicated feedback system with optional diagnostics and screenshot attachments.
- **Quick Log (AI-Assisted Logging V1):** Natural-language logging from the dashboard for food, weight, training, and supplements.
- **Training Block Planner:** Multi-step modal on the training page to schedule weekly training patterns across a configurable number of weeks. Computes projected ACWR via `/api/training-blocks/preview`, forces acknowledgment if overtraining risk (ACWR > 1.5) is detected, then persists via `training_blocks` + `training_block_days` tables. Active block name shown as a header chip; planned load for the selected date shown in the date card.

## External Dependencies

### UI Component Library
- shadcn/ui (built on Radix UI)

### Key NPM Packages
- @tanstack/react-query
- drizzle-orm / drizzle-zod
- zod
- recharts
- framer-motion
- date-fns
- wouter
- web-push
- uppy

### Database
- PostgreSQL (primary data storage)
- connect-pg-simple (session storage)

### APIs
- Open Food Facts (food nutrition data, barcode scanning)
- Resend (email services for verification, invites)

### App Versioning
- `GET /api/meta` provides app version and environment details.