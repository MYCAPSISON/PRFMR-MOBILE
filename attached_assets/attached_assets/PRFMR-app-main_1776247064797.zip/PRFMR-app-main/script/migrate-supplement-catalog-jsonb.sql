-- Migration: Convert supplement_catalog.micros_per_unit from TEXT to JSONB
-- This migration safely handles existing data

-- Step 1: Drop NOT NULL temporarily
ALTER TABLE supplement_catalog
ALTER COLUMN micros_per_unit DROP NOT NULL;

-- Step 2: Convert empty/invalid values to empty JSON object
UPDATE supplement_catalog
SET micros_per_unit = '{}'
WHERE micros_per_unit IS NULL 
   OR micros_per_unit = '' 
   OR micros_per_unit !~ '^[\s]*\{.*\}[\s]*$';

-- Step 3: Convert column type to JSONB
ALTER TABLE supplement_catalog
ALTER COLUMN micros_per_unit TYPE jsonb
USING micros_per_unit::jsonb;

-- Step 4: Set default and NOT NULL constraint
ALTER TABLE supplement_catalog
ALTER COLUMN micros_per_unit SET DEFAULT '{}'::jsonb;

ALTER TABLE supplement_catalog
ALTER COLUMN micros_per_unit SET NOT NULL;

-- Verify the migration
SELECT id, name, micros_per_unit, pg_typeof(micros_per_unit) as column_type
FROM supplement_catalog
LIMIT 5;
