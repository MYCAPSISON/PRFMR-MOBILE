import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { supplementCatalog, exerciseCatalog, activityCatalog } from "../shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is not set");
}

const client = postgres(process.env.DATABASE_URL);
const db = drizzle(client);

const SUPPLEMENT_CATALOG_DATA = [
  { name: "Vitamin D3", defaultUnit: "mcg", microsPerUnit: { vitamin_d_ug: 1 }, notes: "1 mcg = 40 IU" },
  { name: "Vitamin D3 (IU)", defaultUnit: "IU", microsPerUnit: { vitamin_d_ug: 0.025 }, notes: "1 IU = 0.025 mcg" },
  { name: "Magnesium Glycinate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: null },
  { name: "Magnesium Citrate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: null },
  { name: "Magnesium Oxide", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 0.6 }, notes: "60% elemental magnesium" },
  { name: "Zinc Picolinate", defaultUnit: "mg", microsPerUnit: { zinc_mg: 1 }, notes: null },
  { name: "Zinc Gluconate", defaultUnit: "mg", microsPerUnit: { zinc_mg: 1 }, notes: null },
  { name: "Iron Bisglycinate", defaultUnit: "mg", microsPerUnit: { iron_mg: 1 }, notes: "Gentle form, well absorbed" },
  { name: "Iron Sulfate", defaultUnit: "mg", microsPerUnit: { iron_mg: 0.2 }, notes: "20% elemental iron" },
  { name: "Calcium Carbonate", defaultUnit: "mg", microsPerUnit: { calcium_mg: 0.4 }, notes: "40% elemental calcium" },
  { name: "Calcium Citrate", defaultUnit: "mg", microsPerUnit: { calcium_mg: 0.21 }, notes: "21% elemental calcium" },
  { name: "Vitamin B12 (Methylcobalamin)", defaultUnit: "mcg", microsPerUnit: { vitamin_b12_ug: 1 }, notes: "Active form" },
  { name: "Vitamin B12 (Cyanocobalamin)", defaultUnit: "mcg", microsPerUnit: { vitamin_b12_ug: 1 }, notes: "Synthetic form" },
  { name: "Folate (Methylfolate)", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Active form" },
  { name: "Folic Acid", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Synthetic form" },
  { name: "Vitamin C", defaultUnit: "mg", microsPerUnit: { vitamin_c_mg: 1 }, notes: null },
  { name: "Vitamin A (Retinol)", defaultUnit: "mcg", microsPerUnit: { vitamin_a_ug: 1 }, notes: "RAE (Retinol Activity Equivalents)" },
  { name: "Vitamin A (Beta-Carotene)", defaultUnit: "mcg", microsPerUnit: { vitamin_a_ug: 0.083 }, notes: "12:1 conversion ratio" },
  { name: "Selenium (Selenomethionine)", defaultUnit: "mcg", microsPerUnit: { selenium_ug: 1 }, notes: "Organic form" },
  { name: "Selenium (Sodium Selenite)", defaultUnit: "mcg", microsPerUnit: { selenium_ug: 1 }, notes: "Inorganic form" },
  { name: "Iodine (Potassium Iodide)", defaultUnit: "mcg", microsPerUnit: { iodine_ug: 1 }, notes: null },
  { name: "Potassium Citrate", defaultUnit: "mg", microsPerUnit: { potassium_mg: 0.38 }, notes: "38% elemental potassium" },
  { name: "Potassium Chloride", defaultUnit: "mg", microsPerUnit: { potassium_mg: 0.52 }, notes: "52% elemental potassium" },
  { name: "Omega-3 Fish Oil", defaultUnit: "mg", microsPerUnit: {}, notes: "EPA/DHA - no micronutrient tracking" },
  { name: "Creatine Monohydrate", defaultUnit: "g", microsPerUnit: {}, notes: "No micronutrient tracking" },
  { name: "Protein Powder", defaultUnit: "g", microsPerUnit: {}, notes: "Track macros separately" },
  { name: "Multivitamin (Generic)", defaultUnit: "tablet", microsPerUnit: { vitamin_d_ug: 25, vitamin_b12_ug: 6, vitamin_c_mg: 90, iron_mg: 8, zinc_mg: 8, magnesium_mg: 50 }, notes: "Approximate values" },
  { name: "Prenatal Vitamin", defaultUnit: "tablet", microsPerUnit: { vitamin_d_ug: 25, folate_ug: 800, iron_mg: 27, vitamin_b12_ug: 8, iodine_ug: 150 }, notes: "Approximate values" },
  { name: "Athletic Multivitamin", defaultUnit: "tablet", microsPerUnit: { vitamin_d_ug: 50, vitamin_b12_ug: 100, magnesium_mg: 100, zinc_mg: 15, iron_mg: 10 }, notes: "Higher doses for athletes" },
];

const EXERCISE_CATALOG_DATA = [
  { name: "Barbell Bench Press", category: "push", equipment: "barbell" },
  { name: "Dumbbell Bench Press", category: "push", equipment: "dumbbell" },
  { name: "Incline Barbell Press", category: "push", equipment: "barbell" },
  { name: "Incline Dumbbell Press", category: "push", equipment: "dumbbell" },
  { name: "Overhead Press", category: "push", equipment: "barbell" },
  { name: "Dumbbell Shoulder Press", category: "push", equipment: "dumbbell" },
  { name: "Push-ups", category: "push", equipment: "bodyweight" },
  { name: "Dips", category: "push", equipment: "bodyweight" },
  { name: "Tricep Pushdowns", category: "push", equipment: "cable" },
  { name: "Skull Crushers", category: "push", equipment: "barbell" },
  { name: "Lateral Raises", category: "push", equipment: "dumbbell" },
  { name: "Front Raises", category: "push", equipment: "dumbbell" },
  { name: "Cable Flyes", category: "push", equipment: "cable" },
  { name: "Barbell Rows", category: "pull", equipment: "barbell" },
  { name: "Dumbbell Rows", category: "pull", equipment: "dumbbell" },
  { name: "Pull-ups", category: "pull", equipment: "bodyweight" },
  { name: "Chin-ups", category: "pull", equipment: "bodyweight" },
  { name: "Lat Pulldowns", category: "pull", equipment: "cable" },
  { name: "Seated Cable Rows", category: "pull", equipment: "cable" },
  { name: "Face Pulls", category: "pull", equipment: "cable" },
  { name: "Bicep Curls", category: "pull", equipment: "dumbbell" },
  { name: "Barbell Curls", category: "pull", equipment: "barbell" },
  { name: "Hammer Curls", category: "pull", equipment: "dumbbell" },
  { name: "Reverse Flyes", category: "pull", equipment: "dumbbell" },
  { name: "Deadlifts", category: "pull", equipment: "barbell" },
  { name: "Barbell Squats", category: "legs", equipment: "barbell" },
  { name: "Front Squats", category: "legs", equipment: "barbell" },
  { name: "Goblet Squats", category: "legs", equipment: "dumbbell" },
  { name: "Leg Press", category: "legs", equipment: "machine" },
  { name: "Romanian Deadlifts", category: "legs", equipment: "barbell" },
  { name: "Bulgarian Split Squats", category: "legs", equipment: "dumbbell" },
  { name: "Lunges", category: "legs", equipment: "dumbbell" },
  { name: "Leg Curls", category: "legs", equipment: "machine" },
  { name: "Leg Extensions", category: "legs", equipment: "machine" },
  { name: "Calf Raises", category: "legs", equipment: "machine" },
  { name: "Hip Thrusts", category: "legs", equipment: "barbell" },
  { name: "Hack Squats", category: "legs", equipment: "machine" },
  { name: "Good Mornings", category: "legs", equipment: "barbell" },
  { name: "Planks", category: "core", equipment: "bodyweight" },
  { name: "Crunches", category: "core", equipment: "bodyweight" },
  { name: "Leg Raises", category: "core", equipment: "bodyweight" },
  { name: "Russian Twists", category: "core", equipment: "bodyweight" },
  { name: "Ab Wheel Rollouts", category: "core", equipment: "bodyweight" },
  { name: "Cable Crunches", category: "core", equipment: "cable" },
  { name: "Hanging Leg Raises", category: "core", equipment: "bodyweight" },
  { name: "Woodchops", category: "core", equipment: "cable" },
  { name: "Burpees", category: "full_body", equipment: "bodyweight" },
  { name: "Kettlebell Swings", category: "full_body", equipment: "kettlebell" },
  { name: "Clean and Jerk", category: "full_body", equipment: "barbell" },
  { name: "Snatches", category: "full_body", equipment: "barbell" },
  { name: "Thrusters", category: "full_body", equipment: "barbell" },
  { name: "Turkish Get-ups", category: "full_body", equipment: "kettlebell" },
  { name: "Battle Ropes", category: "full_body", equipment: "other" },
  { name: "Box Jumps", category: "full_body", equipment: "bodyweight" },
];

const ACTIVITY_CATALOG_DATA = [
  { name: "Running (Easy)", category: "running", metValue: 7.0, notes: "6-7 min/km pace" },
  { name: "Running (Moderate)", category: "running", metValue: 9.8, notes: "5-6 min/km pace" },
  { name: "Running (Fast)", category: "running", metValue: 12.3, notes: "<5 min/km pace" },
  { name: "Sprinting", category: "running", metValue: 15.0, notes: "All-out effort" },
  { name: "Trail Running", category: "running", metValue: 9.0, notes: null },
  { name: "Cycling (Easy)", category: "cycling", metValue: 4.0, notes: "<16 km/h" },
  { name: "Cycling (Moderate)", category: "cycling", metValue: 6.8, notes: "16-22 km/h" },
  { name: "Cycling (Vigorous)", category: "cycling", metValue: 10.0, notes: ">22 km/h" },
  { name: "Mountain Biking", category: "cycling", metValue: 8.5, notes: null },
  { name: "Stationary Bike (Easy)", category: "gym_cardio", metValue: 5.5, notes: "Light resistance" },
  { name: "Stationary Bike (Moderate)", category: "gym_cardio", metValue: 7.0, notes: "Moderate resistance" },
  { name: "Stationary Bike (Vigorous)", category: "gym_cardio", metValue: 10.0, notes: "High resistance" },
  { name: "Rowing Machine", category: "gym_cardio", metValue: 7.0, notes: "Moderate effort" },
  { name: "Elliptical", category: "gym_cardio", metValue: 5.0, notes: "Moderate effort" },
  { name: "Stair Climber", category: "gym_cardio", metValue: 9.0, notes: null },
  { name: "Swimming (Easy)", category: "swimming", metValue: 5.8, notes: "Leisurely pace" },
  { name: "Swimming (Laps)", category: "swimming", metValue: 8.0, notes: "Moderate pace" },
  { name: "Swimming (Vigorous)", category: "swimming", metValue: 10.0, notes: "Fast pace" },
  { name: "Walking", category: "outdoor", metValue: 3.5, notes: "Moderate pace" },
  { name: "Hiking", category: "outdoor", metValue: 6.0, notes: "Varied terrain" },
  { name: "Hiking (Steep)", category: "outdoor", metValue: 8.0, notes: "Steep incline" },
  { name: "Jump Rope", category: "gym_cardio", metValue: 11.0, notes: "Moderate pace" },
  { name: "Boxing (Bag Work)", category: "combat", metValue: 5.5, notes: null },
  { name: "Boxing (Sparring)", category: "combat", metValue: 9.0, notes: null },
  { name: "Martial Arts", category: "combat", metValue: 10.0, notes: "General" },
  { name: "Wrestling", category: "combat", metValue: 9.0, notes: null },
  { name: "Basketball", category: "team_sports", metValue: 6.5, notes: "Game" },
  { name: "Soccer", category: "team_sports", metValue: 7.0, notes: "Game" },
  { name: "Tennis (Singles)", category: "team_sports", metValue: 8.0, notes: null },
  { name: "Tennis (Doubles)", category: "team_sports", metValue: 5.0, notes: null },
  { name: "Volleyball", category: "team_sports", metValue: 4.0, notes: null },
  { name: "Hockey", category: "team_sports", metValue: 8.0, notes: null },
  { name: "Golf (Walking)", category: "outdoor", metValue: 4.3, notes: "Carrying clubs" },
  { name: "Skiing (Downhill)", category: "outdoor", metValue: 6.0, notes: null },
  { name: "Cross-Country Skiing", category: "outdoor", metValue: 9.0, notes: null },
  { name: "Snowboarding", category: "outdoor", metValue: 5.3, notes: null },
  { name: "Rock Climbing", category: "outdoor", metValue: 8.0, notes: null },
  { name: "Kayaking", category: "outdoor", metValue: 5.0, notes: "Recreational" },
  { name: "Yoga", category: "flexibility", metValue: 2.5, notes: "Hatha yoga" },
  { name: "Power Yoga", category: "flexibility", metValue: 4.0, notes: "Vinyasa/Ashtanga" },
  { name: "Pilates", category: "flexibility", metValue: 3.0, notes: null },
  { name: "Stretching", category: "flexibility", metValue: 2.3, notes: null },
];

async function seedDatabase() {
  console.log("Starting database seed...");
  
  try {
    // Seed supplement catalog
    console.log("Seeding supplement catalog...");
    for (const item of SUPPLEMENT_CATALOG_DATA) {
      try {
        await db.insert(supplementCatalog).values(item).onConflictDoNothing();
      } catch (e) {
        console.log(`  Skipping duplicate: ${item.name}`);
      }
    }
    console.log(`  Inserted ${SUPPLEMENT_CATALOG_DATA.length} supplement catalog items`);
    
    // Seed exercise catalog
    console.log("Seeding exercise catalog...");
    for (const item of EXERCISE_CATALOG_DATA) {
      try {
        await db.insert(exerciseCatalog).values(item).onConflictDoNothing();
      } catch (e) {
        console.log(`  Skipping duplicate: ${item.name}`);
      }
    }
    console.log(`  Inserted ${EXERCISE_CATALOG_DATA.length} exercise catalog items`);
    
    // Seed activity catalog
    console.log("Seeding activity catalog...");
    for (const item of ACTIVITY_CATALOG_DATA) {
      try {
        await db.insert(activityCatalog).values(item).onConflictDoNothing();
      } catch (e) {
        console.log(`  Skipping duplicate: ${item.name}`);
      }
    }
    console.log(`  Inserted ${ACTIVITY_CATALOG_DATA.length} activity catalog items`);
    
    console.log("Database seed completed!");
    
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  } finally {
    await client.end();
  }
}

seedDatabase().catch(console.error);
