import { Router, Request, Response, NextFunction } from "express";
import passport from "passport";
import rateLimit from "express-rate-limit";
import { db } from "./db";
import { usersAuth, users, usernameChanges, invites, inviteRequests, betaWaitlist, insertAuthUserSchema, normalizeSource } from "@shared/schema";
import { eq, and, gte, gt, sql, desc } from "drizzle-orm";
import { hashPassword, requireAuth } from "./auth";
import { z } from "zod";
import { validateUsername, normalizeUsername } from "@shared/username-validation";
import { sendVerificationEmail, sendWelcomeEmail, sendPasswordResetEmail, getEmailConfig } from "./lib/email";
import { createVerificationToken, verifyToken, getUserIdByEmail } from "./lib/verification-tokens";
import { createPasswordResetToken, verifyPasswordResetToken, invalidatePasswordResetToken, getUserByEmail } from "./lib/password-reset-tokens";
import { getVapidPublicKey, isPushEnabled, saveSubscription, removeSubscription, sendPushToUser } from "./lib/push-notifications";
import { hashToken } from "./invite-routes";
import { getBetaUserLimit } from "./lib/beta-cap";

const router = Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { message: "Too many attempts, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const loginSchema = z.object({
  identifier: z.string().min(1, "Email or username is required"),
  password: z.string().min(1, "Password is required"),
});

router.post("/register", authLimiter, async (req: Request, res: Response) => {
  try {
    const { inviteToken, source: rawSource, ...registrationData } = req.body;

    if (!inviteToken || typeof inviteToken !== "string") {
      console.warn("[auth][register] BLOCKED: Missing invite code in registration request");
      return res.status(403).json({ message: "A valid invite is required to register." });
    }

    const inviteTokenHash = hashToken(inviteToken);
    const requestSource = rawSource ? normalizeSource(rawSource) : null;

    const parseResult = insertAuthUserSchema.safeParse(registrationData);
    if (!parseResult.success) {
      const issues = parseResult.error.issues.map(issue => ({
        field: issue.path.join("."),
        reason: issue.message,
      }));
      console.log("[auth][register][validation] Validation failed:", JSON.stringify(issues, null, 2));
      return res.status(400).json({ 
        message: "Validation error", 
        issues,
      });
    }

    const { email, username, password } = parseResult.data;

    const existingEmail = await db.query.usersAuth.findFirst({
      where: eq(usersAuth.email, email),
    });
    if (existingEmail) {
      return res.status(409).json({ message: "Email already registered" });
    }

    const existingUsername = await db.query.usersAuth.findFirst({
      where: eq(usersAuth.username, username),
    });
    if (existingUsername) {
      return res.status(409).json({ message: "Username already taken" });
    }

    const passwordHash = await hashPassword(password);
    const betaLimit = getBetaUserLimit();

    const txResult = await db.transaction(async (tx) => {
      const [countResult] = await tx.select({ count: sql<number>`count(*)::int` }).from(usersAuth);
      const activeCount = countResult.count;

      if (activeCount >= betaLimit) {
        await tx.insert(betaWaitlist).values({ email, source: "registration" });
        console.warn(`[auth][register] BETA FULL: cap=${betaLimit}, active=${activeCount}. Added ${email.substring(0, 3)}*** to waitlist`);
        return { success: false as const, reason: "beta_full" as const };
      }

      const [redeemedInvite] = await tx.update(invites)
        .set({
          uses: sql`uses + 1`,
          usedAt: new Date(),
        })
        .where(and(
          eq(invites.tokenHash, inviteTokenHash),
          gt(invites.expiresAt, new Date()),
          sql`uses < max_uses`,
        ))
        .returning();

      if (!redeemedInvite) {
        return { success: false as const, reason: "invalid_invite" as const };
      }

      let finalSource = "unknown";
      if (requestSource && requestSource !== "unknown") {
        finalSource = requestSource;
      } else {
        const inviteReq = await tx.select({ source: inviteRequests.source })
          .from(inviteRequests)
          .where(eq(inviteRequests.email, redeemedInvite.email))
          .orderBy(desc(inviteRequests.createdAt))
          .limit(1);
        if (inviteReq.length > 0 && inviteReq[0].source && inviteReq[0].source !== "unknown") {
          finalSource = inviteReq[0].source;
        }
      }

      const [authUser] = await tx.insert(usersAuth).values({
        email,
        username,
        passwordHash,
        source: finalSource,
      }).returning();

      const [profileUser] = await tx.insert(users).values({
        username,
        authUserId: authUser.id,
        source: finalSource,
      }).returning();

      await tx.update(invites)
        .set({ usedByUserId: authUser.id })
        .where(eq(invites.id, redeemedInvite.id));

      return { success: true as const, authUser, redeemedInvite };
    });

    if (!txResult.success && txResult.reason === "beta_full") {
      return res.status(403).json({ message: "Beta is currently full. You've been added to the waitlist." });
    }

    if (!txResult.success && txResult.reason === "invalid_invite") {
      const debugInvite = await db.query.invites.findFirst({
        where: eq(invites.tokenHash, inviteTokenHash),
      });
      if (!debugInvite) {
        console.warn(`[auth][register] BLOCKED: Invite code not found (hash prefix: ${inviteTokenHash.substring(0, 8)}...)`);
      } else if (debugInvite.expiresAt <= new Date()) {
        console.warn(`[auth][register] BLOCKED: Invite expired at ${debugInvite.expiresAt.toISOString()}, inviteId=${debugInvite.id}`);
      } else if (debugInvite.uses >= debugInvite.maxUses) {
        console.warn(`[auth][register] BLOCKED: Invite already used (uses=${debugInvite.uses}/${debugInvite.maxUses}), inviteId=${debugInvite.id}`);
      }
      return res.status(403).json({ message: "This invite code is invalid, expired, or has already been used." });
    }

    if (!txResult.success) {
      return res.status(500).json({ message: "Registration failed" });
    }

    const { authUser, redeemedInvite } = txResult;

    const verificationToken = await createVerificationToken(authUser.id);
    
    sendVerificationEmail(email, username, verificationToken).catch(err => {
      console.error("Failed to send verification email:", err);
    });
    
    sendWelcomeEmail(email, username).catch(err => {
      console.error("Failed to send welcome email:", err);
    });

    console.log(`[auth][register] User registered via invite: userId=${authUser.id}, inviteId=${redeemedInvite.id}, email=${email.substring(0,3)}***`);

    req.login({ id: authUser.id, email: authUser.email, username: authUser.username }, (err) => {
      if (err) {
        console.error("Login after register failed:", err);
        return res.status(500).json({ message: "Registration successful but login failed" });
      }
      res.status(201).json({ 
        user: { id: authUser.id, email: authUser.email, username: authUser.username, emailVerified: false } 
      });
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ message: "Registration failed" });
  }
});

router.post("/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
  const parseResult = loginSchema.safeParse(req.body);
  if (!parseResult.success) {
    return res.status(400).json({ 
      message: "Validation error", 
      errors: parseResult.error.flatten().fieldErrors 
    });
  }

  passport.authenticate("local", (err: Error | null, user: Express.User | false, info: { message: string } | undefined) => {
    if (err) {
      console.error("Login error:", err);
      return res.status(500).json({ message: "Login failed" });
    }
    if (!user) {
      return res.status(401).json({ message: info?.message || "Invalid credentials." });
    }
    req.login(user, async (loginErr) => {
      if (loginErr) {
        console.error("Session login error:", loginErr);
        return res.status(500).json({ message: "Login failed" });
      }
      const authUser = await db.query.usersAuth.findFirst({
        where: eq(usersAuth.id, user.id),
      });
      res.json({ user: { id: user.id, email: user.email, username: user.username, emailVerified: authUser?.emailVerified ?? false } });
    });
  })(req, res, next);
});

router.post("/logout", (req: Request, res: Response) => {
  req.logout((err) => {
    if (err) {
      console.error("Logout error:", err);
      return res.status(500).json({ message: "Logout failed" });
    }
    req.session.destroy((sessionErr) => {
      if (sessionErr) {
        console.error("Session destroy error:", sessionErr);
      }
      res.clearCookie("connect.sid");
      res.json({ ok: true });
    });
  });
});

router.get("/me", async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  const authUser = await db.query.usersAuth.findFirst({
    where: eq(usersAuth.id, req.user.id),
  });
  res.json({ 
    user: { 
      id: req.user.id, 
      email: req.user.email, 
      username: req.user.username,
      emailVerified: authUser?.emailVerified ?? false,
    } 
  });
});

const resendLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 3,
  message: { message: "Too many requests, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

router.post("/resend-verification", resendLimiter, requireAuth, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const authUser = await db.query.usersAuth.findFirst({
      where: eq(usersAuth.id, req.user.id),
    });

    if (!authUser) {
      return res.json({ message: "If your email is registered, you will receive a verification email." });
    }

    if (authUser.emailVerified) {
      return res.json({ message: "Email already verified." });
    }

    const token = await createVerificationToken(authUser.id);
    
    const emailResult = await sendVerificationEmail(authUser.email, authUser.username, token);
    
    if (!emailResult.success) {
      console.error("Failed to send verification email:", emailResult.error);
      return res.status(502).json({ error: "Email service error" });
    }

    res.json({ message: "If your email is registered, you will receive a verification email." });
  } catch (error) {
    console.error("Resend verification error:", error);
    res.status(502).json({ error: "Email service error" });
  }
});

router.get("/verify-email", async (req: Request, res: Response) => {
  try {
    const { token } = req.query;
    
    if (!token || typeof token !== "string") {
      console.log("[auth][verify-email] No token provided");
      return res.redirect("/verify-email?error=invalid");
    }

    const result = await verifyToken(token);
    
    if (!result.valid) {
      console.log(`[auth][verify-email] tokenHash=... success=false reason=${result.error}`);
      return res.redirect(`/verify-email?error=${encodeURIComponent(result.error || "invalid")}`);
    }

    console.log(`[auth][verify-email] tokenHash=... userId=${result.userId} success=true`);
    res.redirect("/verify-email?success=1");
  } catch (error) {
    console.error("[auth][verify-email] Server error:", error);
    res.redirect("/verify-email?error=server");
  }
});

// ========== PASSWORD RESET ==========

const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { message: "Too many password reset requests, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const forgotPasswordSchema = z.object({
  email: z.string().email().transform(s => s.toLowerCase()),
});

router.post("/forgot-password", forgotPasswordLimiter, async (req: Request, res: Response) => {
  try {
    const parseResult = forgotPasswordSchema.safeParse(req.body);
    if (!parseResult.success) {
      console.log("[auth][password-reset] Invalid email format in request");
      return res.json({ message: "If that email is registered, you will receive a password reset link." });
    }

    const { email } = parseResult.data;
    console.log(`[auth][password-reset] Reset requested for email: ${email.substring(0, 3)}***`);

    const user = await getUserByEmail(email);
    
    if (user) {
      const token = await createPasswordResetToken(user.id);
      
      const emailResult = await sendPasswordResetEmail(email, user.username, token);
      
      if (!emailResult.success) {
        console.error(`[auth][password-reset] Failed to send email: ${emailResult.error}`);
      } else {
        console.log(`[auth][password-reset] Reset email sent to userId: ${user.id}`);
      }
    } else {
      console.log(`[auth][password-reset] No user found for email (not revealed to client)`);
    }

    res.json({ message: "If that email is registered, you will receive a password reset link." });
  } catch (error) {
    console.error("[auth][password-reset] Error:", error);
    res.json({ message: "If that email is registered, you will receive a password reset link." });
  }
});

const resetPasswordSchema = z.object({
  token: z.string().min(1),
  password: z.string().min(8).regex(/^(?=.*[a-zA-Z])(?=.*\d)/, "Password must contain at least 1 letter and 1 number"),
});

router.post("/reset-password", authLimiter, async (req: Request, res: Response) => {
  try {
    const parseResult = resetPasswordSchema.safeParse(req.body);
    if (!parseResult.success) {
      const issues = parseResult.error.issues.map(issue => ({
        field: issue.path.join("."),
        reason: issue.message,
      }));
      console.log("[auth][password-reset] Validation failed:", JSON.stringify(issues, null, 2));
      return res.status(400).json({ 
        message: "Validation error", 
        issues,
      });
    }

    const { token, password } = parseResult.data;

    const tokenResult = await verifyPasswordResetToken(token);
    
    if (!tokenResult.valid || !tokenResult.userId || !tokenResult.tokenId) {
      console.log(`[auth][password-reset] Token validation failed`);
      return res.status(400).json({ message: tokenResult.error || "Invalid or expired reset link" });
    }

    const passwordHash = await hashPassword(password);

    await db.update(usersAuth)
      .set({ 
        passwordHash,
        updatedAt: new Date(),
      })
      .where(eq(usersAuth.id, tokenResult.userId));

    await invalidatePasswordResetToken(tokenResult.tokenId);

    console.log(`[auth][password-reset] Password reset successful for userId: ${tokenResult.userId}`);

    res.json({ message: "Password reset successful. You can now log in with your new password." });
  } catch (error) {
    console.error("[auth][password-reset] Error:", error);
    res.status(500).json({ message: "Failed to reset password" });
  }
});

const changeEmailSchema = z.object({
  newEmail: z.string().email().transform(s => s.toLowerCase()),
});

router.post("/change-email", authLimiter, requireAuth, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const parseResult = changeEmailSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: parseResult.error.flatten().fieldErrors 
      });
    }

    const { newEmail } = parseResult.data;

    const existingEmail = await db.query.usersAuth.findFirst({
      where: eq(usersAuth.email, newEmail),
    });
    
    if (existingEmail && existingEmail.id !== req.user.id) {
      return res.status(409).json({ message: "Email already in use" });
    }

    await db.update(usersAuth)
      .set({ 
        email: newEmail, 
        emailVerified: false,
        emailVerifiedAt: null,
        updatedAt: new Date(),
      })
      .where(eq(usersAuth.id, req.user.id));

    const token = await createVerificationToken(req.user.id);
    
    const emailResult = await sendVerificationEmail(newEmail, req.user.username, token);
    
    if (!emailResult.success) {
      console.error("Failed to send verification email after email change:", emailResult.error);
      return res.status(502).json({ error: "Email service error" });
    }

    res.json({ message: "Email updated. Please verify your new email address." });
  } catch (error) {
    console.error("Change email error:", error);
    res.status(500).json({ message: "Failed to change email" });
  }
});

router.get("/debug/email-config", (req: Request, res: Response) => {
  if (!req.isAuthenticated?.() || !req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  res.json(getEmailConfig());
});

// ========== PUSH NOTIFICATIONS ==========

router.get("/notifications/vapid-public-key", (req: Request, res: Response) => {
  const key = getVapidPublicKey();
  if (!key) {
    return res.status(503).json({ message: "Push notifications not configured" });
  }
  res.json({ publicKey: key });
});

router.get("/notifications/status", (req: Request, res: Response) => {
  res.json({ enabled: isPushEnabled() });
});

const subscriptionSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({
    p256dh: z.string(),
    auth: z.string(),
  }),
});

router.post("/notifications/subscribe", requireAuth, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const parseResult = subscriptionSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ message: "Invalid subscription data" });
    }

    await saveSubscription(req.user.id, parseResult.data);
    console.log(`[push] User ${req.user.id} subscribed to push notifications`);
    res.json({ message: "Subscription saved" });
  } catch (error) {
    console.error("[push] Subscribe error:", error);
    res.status(500).json({ message: "Failed to save subscription" });
  }
});

router.post("/notifications/unsubscribe", requireAuth, async (req: Request, res: Response) => {
  try {
    const { endpoint } = req.body;
    if (!endpoint) {
      return res.status(400).json({ message: "Endpoint required" });
    }

    await removeSubscription(endpoint);
    console.log(`[push] Subscription removed`);
    res.json({ message: "Subscription removed" });
  } catch (error) {
    console.error("[push] Unsubscribe error:", error);
    res.status(500).json({ message: "Failed to remove subscription" });
  }
});

router.post("/notifications/test", requireAuth, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    if (!isPushEnabled()) {
      return res.status(503).json({ message: "Push notifications not configured" });
    }

    const result = await sendPushToUser(req.user.id, {
      title: "PRFMR Test Notification",
      body: "Push notifications are working!",
      data: { url: "/dashboard" },
    });

    console.log(`[push] Test notification sent to user ${req.user.id}: sent=${result.sent}, failed=${result.failed}`);
    res.json({ message: "Test notification sent", ...result });
  } catch (error) {
    console.error("[push] Test notification error:", error);
    res.status(500).json({ message: "Failed to send test notification" });
  }
});

router.get("/username-available", async (req: Request, res: Response) => {
  const raw = req.query.username;
  if (!raw || typeof raw !== "string") {
    return res.status(400).json({ error: "Username query parameter is required" });
  }

  const result = validateUsername(raw);
  if (!result.valid) {
    return res.json({ available: false, error: result.error });
  }

  const existing = await db.query.usersAuth.findFirst({
    where: eq(usersAuth.username, result.normalized),
  });

  res.json({ available: !existing });
});

router.patch("/username", requireAuth, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated", code: "UNAUTHENTICATED" });
    }

    const userId = req.user.id;
    const currentUsername = req.user.username;

    const { username: rawUsername } = req.body || {};
    if (!rawUsername || typeof rawUsername !== "string") {
      return res.status(400).json({ error: "Username is required", code: "VALIDATION_ERROR" });
    }

    const validation = validateUsername(rawUsername);
    if (!validation.valid) {
      console.log(`[auth][username] userId=${userId} format_fail: ${validation.error}`);
      return res.status(400).json({ error: validation.error, code: "INVALID_FORMAT" });
    }

    const newUsername = validation.normalized;

    if (newUsername === currentUsername.toLowerCase()) {
      return res.status(400).json({ error: "New username is the same as current", code: "SAME_USERNAME" });
    }

    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentChanges = await db.select().from(usernameChanges)
      .where(and(
        eq(usernameChanges.userId, userId),
        gte(usernameChanges.createdAt, twentyFourHoursAgo)
      ));

    if (recentChanges.length >= 3) {
      const oldest = recentChanges.reduce((a, b) => a.createdAt < b.createdAt ? a : b);
      const nextAllowed = new Date(oldest.createdAt.getTime() + 24 * 60 * 60 * 1000);
      console.log(`[auth][username] userId=${userId} rate_limited: ${recentChanges.length}/3 changes in 24h`);
      return res.status(429).json({
        error: `Too many username changes. Try again ${nextAllowed.toISOString()}`,
        code: "RATE_LIMITED",
        nextAllowedAt: nextAllowed.toISOString(),
      });
    }

    const existingAuth = await db.query.usersAuth.findFirst({
      where: eq(usersAuth.username, newUsername),
    });
    if (existingAuth && existingAuth.id !== userId) {
      console.log(`[auth][username] userId=${userId} taken: ${newUsername}`);
      return res.status(409).json({ error: "Username is already taken", code: "USERNAME_TAKEN" });
    }

    await db.update(usersAuth)
      .set({ username: newUsername, updatedAt: new Date() })
      .where(eq(usersAuth.id, userId));

    await db.update(users)
      .set({ username: newUsername })
      .where(eq(users.authUserId, userId));

    await db.insert(usernameChanges).values({
      userId,
      oldUsername: currentUsername,
      newUsername,
    });

    console.log(`[auth][username] userId=${userId} success: ${currentUsername} -> ${newUsername}`);
    res.json({
      id: userId,
      username: newUsername,
      email: req.user.email,
    });
  } catch (error) {
    console.error("[auth][username] Error:", error);
    res.status(500).json({ error: "Failed to change username", code: "SERVER_ERROR" });
  }
});

export default router;
