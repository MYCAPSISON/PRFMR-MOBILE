import { db } from "./db";
import { eq, and, gte, lte, ilike, sql, inArray, or, desc, between } from "drizzle-orm";
import { classifyDayLoad } from "./lib/training-load";
import {
  users, logs, foodEntries, weights,
  supplements, supplementStacks, stackSupplements, stackReminders, supplementLogs, userDisclaimerAcceptance,
  supplementCatalog, supplementIntakes,
  exerciseCatalog, workoutSessions, workoutExercises, workoutSets, activityCatalog, sessionActivities,
  offProductMappings, customFoods, mealTemplates, mealTemplateItems, feedback, feedbackAttachments,
  type User, type InsertUser, type Log, type InsertLog, type FoodEntry, type InsertFoodEntry, type Weight, type InsertWeight,
  type Supplement, type InsertSupplement, type SupplementStack, type InsertSupplementStack,
  type StackSupplement, type InsertStackSupplement, type StackReminder, type InsertStackReminder,
  type SupplementLog, type InsertSupplementLog, type UserDisclaimerAcceptance, type InsertUserDisclaimerAcceptance,
  type SupplementCatalogItem, type InsertSupplementCatalogItem, type SupplementIntake, type InsertSupplementIntake,
  type ExerciseCatalogItem, type InsertExerciseCatalogItem, type WorkoutSession, type InsertWorkoutSession,
  type WorkoutExercise, type InsertWorkoutExercise, type WorkoutSet, type InsertWorkoutSet,
  type ActivityCatalogItem, type InsertActivityCatalogItem, type SessionActivity, type InsertSessionActivity,
  type OffProductMapping, type InsertOffProductMapping,
  type CustomFood, type InsertCustomFood,
  type MealTemplate, type InsertMealTemplate, type MealTemplateItem, type InsertMealTemplateItem,
  type Feedback, type InsertFeedback,
  type FeedbackAttachment, type InsertFeedbackAttachment,
  sleepLogs, type SleepLog, type InsertSleepLog,
  weightCutPlans, type WeightCutPlan, type InsertWeightCutPlan,
  provisionalCheckins, type ProvisionalCheckin, type InsertProvisionalCheckin,
  restDayLogs,
  trainingLoadOverrides,
  trainingBlocks, trainingBlockDays, type BlockActivityTemplate,
} from "@shared/schema";
import type { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  async getUser(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByAuthId(authUserId: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.authUserId, authUserId));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async updateUser(username: string, userData: Partial<InsertUser>): Promise<User> {
    const [updated] = await db.update(users)
      .set(userData)
      .where(eq(users.username, username))
      .returning();
    return updated;
  }

  async getLogs(userId: number): Promise<Log[]> {
    return db.select().from(logs).where(eq(logs.userId, userId));
  }

  async createLog(log: InsertLog): Promise<Log> {
    const [created] = await db.insert(logs).values(log).returning();
    return created;
  }

  async updateLog(id: number, logData: Partial<InsertLog>): Promise<Log> {
    const [updated] = await db.update(logs).set(logData).where(eq(logs.id, id)).returning();
    return updated;
  }

  async getFoodEntries(userId: number, date: string): Promise<FoodEntry[]> {
    return db.select().from(foodEntries)
      .where(and(eq(foodEntries.userId, userId), eq(foodEntries.date, date)));
  }

  async getFoodEntriesRange(userId: number, startDate: string, endDate: string): Promise<FoodEntry[]> {
    return db.select().from(foodEntries)
      .where(and(
        eq(foodEntries.userId, userId),
        gte(foodEntries.date, startDate),
        lte(foodEntries.date, endDate)
      ));
  }

  async createFoodEntry(entry: InsertFoodEntry): Promise<FoodEntry> {
    const [created] = await db.insert(foodEntries).values(entry).returning();
    return created;
  }

  async updateFoodEntry(id: number, entry: Partial<InsertFoodEntry>): Promise<FoodEntry> {
    const [updated] = await db.update(foodEntries).set(entry).where(eq(foodEntries.id, id)).returning();
    return updated;
  }

  async deleteFoodEntry(id: number): Promise<void> {
    await db.delete(foodEntries).where(eq(foodEntries.id, id));
  }

  async getWeightsRange(userId: number, startDate: string, endDate: string): Promise<Weight[]> {
    return db.select().from(weights)
      .where(and(
        eq(weights.userId, userId),
        gte(weights.date, startDate),
        lte(weights.date, endDate)
      ));
  }

  async upsertWeight(entry: InsertWeight): Promise<Weight> {
    const existing = await db.select().from(weights)
      .where(and(eq(weights.userId, entry.userId), eq(weights.date, entry.date)));
    
    if (existing.length > 0) {
      const [updated] = await db.update(weights)
        .set({ weight: entry.weight })
        .where(eq(weights.id, existing[0].id))
        .returning();
      return updated;
    }
    
    const [created] = await db.insert(weights).values(entry).returning();
    return created;
  }

  async deleteWeight(id: number): Promise<void> {
    await db.delete(weights).where(eq(weights.id, id));
  }

  // Supplements
  async getSupplements(userId: number): Promise<Supplement[]> {
    return db.select().from(supplements).where(eq(supplements.userId, userId));
  }

  async getSupplement(id: number): Promise<Supplement | undefined> {
    const [supplement] = await db.select().from(supplements).where(eq(supplements.id, id));
    return supplement;
  }

  async createSupplement(supplement: InsertSupplement): Promise<Supplement> {
    const [created] = await db.insert(supplements).values(supplement).returning();
    return created;
  }

  async updateSupplement(id: number, supplementData: Partial<InsertSupplement>): Promise<Supplement> {
    const [updated] = await db.update(supplements).set(supplementData).where(eq(supplements.id, id)).returning();
    return updated;
  }

  async deleteSupplement(id: number): Promise<void> {
    await db.delete(supplements).where(eq(supplements.id, id));
  }

  // Stacks
  async getStacks(userId: number): Promise<SupplementStack[]> {
    return db.select().from(supplementStacks).where(eq(supplementStacks.userId, userId));
  }

  async getStack(id: number): Promise<SupplementStack | undefined> {
    const [stack] = await db.select().from(supplementStacks).where(eq(supplementStacks.id, id));
    return stack;
  }

  async createStack(stack: InsertSupplementStack): Promise<SupplementStack> {
    const [created] = await db.insert(supplementStacks).values(stack).returning();
    return created;
  }

  async updateStack(id: number, stackData: Partial<InsertSupplementStack>): Promise<SupplementStack> {
    const [updated] = await db.update(supplementStacks).set(stackData).where(eq(supplementStacks.id, id)).returning();
    return updated;
  }

  async deleteStack(id: number): Promise<void> {
    await db.delete(supplementStacks).where(eq(supplementStacks.id, id));
  }

  // Stack-Supplement relationships
  async getStackSupplements(stackId: number): Promise<StackSupplement[]> {
    return db.select().from(stackSupplements).where(eq(stackSupplements.stackId, stackId));
  }

  async addSupplementToStack(entry: InsertStackSupplement): Promise<StackSupplement> {
    const [created] = await db.insert(stackSupplements).values(entry).returning();
    return created;
  }

  async removeSupplementFromStack(stackId: number, supplementId: number): Promise<void> {
    await db.delete(stackSupplements)
      .where(and(eq(stackSupplements.stackId, stackId), eq(stackSupplements.supplementId, supplementId)));
  }

  // Reminders
  async getStackReminders(stackId: number): Promise<StackReminder[]> {
    return db.select().from(stackReminders).where(eq(stackReminders.stackId, stackId));
  }

  async getAllRemindersForUser(userId: number): Promise<StackReminder[]> {
    const userStacks = await this.getStacks(userId);
    if (userStacks.length === 0) return [];
    
    const stackIds = userStacks.map(s => s.id);
    return db.select().from(stackReminders).where(inArray(stackReminders.stackId, stackIds));
  }

  async getTodaysRemindersForUser(userId: number): Promise<Array<StackReminder & { stackName: string }>> {
    const userStacks = await this.getStacks(userId);
    if (userStacks.length === 0) return [];
    
    const stackIds = userStacks.map(s => s.id);
    const reminders = await db.select().from(stackReminders).where(inArray(stackReminders.stackId, stackIds));
    
    return reminders.map(r => ({
      ...r,
      stackName: userStacks.find(s => s.id === r.stackId)?.name || "Unknown Stack"
    }));
  }

  async createReminder(reminder: InsertStackReminder): Promise<StackReminder> {
    const [created] = await db.insert(stackReminders).values(reminder).returning();
    return created;
  }

  async updateReminder(id: number, reminderData: Partial<InsertStackReminder>): Promise<StackReminder> {
    const [updated] = await db.update(stackReminders).set(reminderData).where(eq(stackReminders.id, id)).returning();
    return updated;
  }

  async deleteReminder(id: number): Promise<void> {
    await db.delete(stackReminders).where(eq(stackReminders.id, id));
  }

  // Supplement Logs
  async getSupplementLogs(userId: number, date: string): Promise<SupplementLog[]> {
    return db.select().from(supplementLogs)
      .where(and(eq(supplementLogs.userId, userId), eq(supplementLogs.date, date)));
  }

  async createSupplementLog(log: InsertSupplementLog): Promise<SupplementLog> {
    const [created] = await db.insert(supplementLogs).values(log).returning();
    return created;
  }

  async deleteSupplementLog(id: number): Promise<void> {
    await db.delete(supplementLogs).where(eq(supplementLogs.id, id));
  }

  // Disclaimer acceptance
  async getDisclaimerAcceptance(userId: number, type: string): Promise<UserDisclaimerAcceptance | undefined> {
    const [acceptance] = await db.select().from(userDisclaimerAcceptance)
      .where(and(eq(userDisclaimerAcceptance.userId, userId), eq(userDisclaimerAcceptance.disclaimerType, type)));
    return acceptance;
  }

  async createDisclaimerAcceptance(acceptance: InsertUserDisclaimerAcceptance): Promise<UserDisclaimerAcceptance> {
    const [created] = await db.insert(userDisclaimerAcceptance).values(acceptance).returning();
    return created;
  }

  // Supplement Catalog
  async getSupplementCatalog(query?: string): Promise<SupplementCatalogItem[]> {
    if (query) {
      return db.select().from(supplementCatalog).where(ilike(supplementCatalog.name, `%${query}%`));
    }
    return db.select().from(supplementCatalog);
  }

  async getSupplementCatalogItem(id: number): Promise<SupplementCatalogItem | undefined> {
    const [item] = await db.select().from(supplementCatalog).where(eq(supplementCatalog.id, id));
    return item;
  }

  // Supplement Intakes
  async getSupplementIntakes(userId: number, date: string): Promise<SupplementIntake[]> {
    return db.select().from(supplementIntakes)
      .where(and(eq(supplementIntakes.userId, userId), eq(supplementIntakes.date, date)));
  }

  async getSupplementIntakesRange(userId: number, startDate: string, endDate: string): Promise<SupplementIntake[]> {
    return db.select().from(supplementIntakes)
      .where(and(
        eq(supplementIntakes.userId, userId),
        gte(supplementIntakes.date, startDate),
        lte(supplementIntakes.date, endDate)
      ));
  }

  async createSupplementIntake(intake: InsertSupplementIntake): Promise<SupplementIntake> {
    const [created] = await db.insert(supplementIntakes).values(intake).returning();
    return created;
  }

  async updateSupplementIntake(id: number, intakeData: Partial<InsertSupplementIntake>): Promise<SupplementIntake> {
    const [updated] = await db.update(supplementIntakes).set(intakeData).where(eq(supplementIntakes.id, id)).returning();
    return updated;
  }

  async deleteSupplementIntake(id: number): Promise<void> {
    await db.delete(supplementIntakes).where(eq(supplementIntakes.id, id));
  }

  // Training - Exercise Catalog
  async getExerciseCatalog(query?: string): Promise<ExerciseCatalogItem[]> {
    if (query) {
      return db.select().from(exerciseCatalog).where(ilike(exerciseCatalog.name, `%${query}%`));
    }
    return db.select().from(exerciseCatalog);
  }

  async getExerciseCatalogItem(id: number): Promise<ExerciseCatalogItem | undefined> {
    const [item] = await db.select().from(exerciseCatalog).where(eq(exerciseCatalog.id, id));
    return item;
  }

  // Training - Activity Catalog
  async getActivityCatalog(query?: string): Promise<ActivityCatalogItem[]> {
    if (query) {
      return db.select().from(activityCatalog)
        .where(ilike(activityCatalog.name, `%${query}%`))
        .orderBy(activityCatalog.name);
    }
    return db.select().from(activityCatalog).orderBy(activityCatalog.name);
  }

  async getActivityCatalogItem(id: number): Promise<ActivityCatalogItem | undefined> {
    const [item] = await db.select().from(activityCatalog).where(eq(activityCatalog.id, id));
    return item;
  }

  // Training - Workout Sessions
  async getWorkoutSessions(userId: number, startDate: string, endDate: string): Promise<WorkoutSession[]> {
    return db.select().from(workoutSessions)
      .where(and(
        eq(workoutSessions.userId, userId),
        gte(workoutSessions.date, startDate),
        lte(workoutSessions.date, endDate)
      ));
  }

  async getWorkoutSession(id: number): Promise<WorkoutSession | undefined> {
    const [session] = await db.select().from(workoutSessions).where(eq(workoutSessions.id, id));
    return session;
  }

  async createWorkoutSession(session: InsertWorkoutSession): Promise<WorkoutSession> {
    const [created] = await db.insert(workoutSessions).values(session).returning();
    return created;
  }

  async updateWorkoutSession(id: number, sessionData: Partial<InsertWorkoutSession>): Promise<WorkoutSession> {
    const [updated] = await db.update(workoutSessions).set(sessionData).where(eq(workoutSessions.id, id)).returning();
    return updated;
  }

  async deleteWorkoutSession(id: number): Promise<void> {
    await db.delete(workoutSessions).where(eq(workoutSessions.id, id));
  }

  // Training - Workout Exercises
  async getWorkoutExercises(sessionId: number): Promise<WorkoutExercise[]> {
    return db.select().from(workoutExercises).where(eq(workoutExercises.sessionId, sessionId));
  }

  async getWorkoutExercise(id: number): Promise<WorkoutExercise | undefined> {
    const [exercise] = await db.select().from(workoutExercises).where(eq(workoutExercises.id, id));
    return exercise;
  }

  async createWorkoutExercise(exercise: InsertWorkoutExercise): Promise<WorkoutExercise> {
    const [created] = await db.insert(workoutExercises).values(exercise).returning();
    return created;
  }

  async updateWorkoutExercise(id: number, exerciseData: Partial<InsertWorkoutExercise>): Promise<WorkoutExercise> {
    const [updated] = await db.update(workoutExercises).set(exerciseData).where(eq(workoutExercises.id, id)).returning();
    return updated;
  }

  async deleteWorkoutExercise(id: number): Promise<void> {
    await db.delete(workoutExercises).where(eq(workoutExercises.id, id));
  }

  // Training - Workout Sets
  async getWorkoutSets(exerciseId: number): Promise<WorkoutSet[]> {
    return db.select().from(workoutSets).where(eq(workoutSets.workoutExerciseId, exerciseId));
  }

  async createWorkoutSet(set: InsertWorkoutSet): Promise<WorkoutSet> {
    const [created] = await db.insert(workoutSets).values(set).returning();
    return created;
  }

  async updateWorkoutSet(id: number, setData: Partial<InsertWorkoutSet>): Promise<WorkoutSet> {
    const [updated] = await db.update(workoutSets).set(setData).where(eq(workoutSets.id, id)).returning();
    return updated;
  }

  async deleteWorkoutSet(id: number): Promise<void> {
    await db.delete(workoutSets).where(eq(workoutSets.id, id));
  }

  // Training - Session Activities
  async getSessionActivities(sessionId: number): Promise<SessionActivity[]> {
    return db.select().from(sessionActivities).where(eq(sessionActivities.sessionId, sessionId));
  }

  async getSessionActivity(id: number): Promise<SessionActivity | undefined> {
    const [activity] = await db.select().from(sessionActivities).where(eq(sessionActivities.id, id));
    return activity;
  }

  async createSessionActivity(activity: InsertSessionActivity): Promise<SessionActivity> {
    const [created] = await db.insert(sessionActivities).values(activity).returning();
    return created;
  }

  async updateSessionActivity(id: number, activityData: Partial<InsertSessionActivity>): Promise<SessionActivity> {
    const [updated] = await db.update(sessionActivities).set(activityData).where(eq(sessionActivities.id, id)).returning();
    return updated;
  }

  async deleteSessionActivity(id: number): Promise<void> {
    await db.delete(sessionActivities).where(eq(sessionActivities.id, id));
  }

  // ========== OFF PRODUCT MAPPINGS ==========

  async getOffMappingByBarcode(barcode: string): Promise<OffProductMapping | undefined> {
    const [mapping] = await db.select().from(offProductMappings)
      .where(eq(offProductMappings.barcode, barcode));
    return mapping;
  }

  async upsertOffMapping(mapping: InsertOffProductMapping): Promise<OffProductMapping> {
    const existing = await this.getOffMappingByBarcode(mapping.barcode);
    
    if (existing) {
      const [updated] = await db.update(offProductMappings)
        .set({
          ...mapping,
          updatedAt: new Date(),
        })
        .where(eq(offProductMappings.barcode, mapping.barcode))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(offProductMappings)
        .values({
          ...mapping,
          updatedAt: new Date(),
        })
        .returning();
      return created;
    }
  }

  async getAllOffMappings(): Promise<OffProductMapping[]> {
    return db.select().from(offProductMappings);
  }

  // ========== FOOD ENTRIES WITH INGREDIENT TRACKING ==========

  async getFoodEntriesWithMicrosCount(userId: number, date: string): Promise<{ total: number; withMicros: number }> {
    const entries = await this.getFoodEntries(userId, date);
    const total = entries.length;
    const withMicros = entries.filter(e => e.ingredientIndex !== null && e.microSource === "internal").length;
    return { total, withMicros };
  }

  // ========== CUSTOM FOODS (User's "My Database") ==========

  async getCustomFoods(userId: number, query?: string, limit?: number): Promise<CustomFood[]> {
    let q = db.select().from(customFoods).where(eq(customFoods.userId, userId));
    
    if (query && query.trim()) {
      const searchTerm = `%${query.toLowerCase()}%`;
      q = db.select().from(customFoods).where(
        and(
          eq(customFoods.userId, userId),
          or(
            sql`LOWER(${customFoods.name}) LIKE ${searchTerm}`,
            sql`LOWER(${customFoods.brand}) LIKE ${searchTerm}`
          )
        )
      );
    }
    
    const results = await q.orderBy(desc(customFoods.createdAt));
    return limit ? results.slice(0, limit) : results;
  }

  async getCustomFood(id: number): Promise<CustomFood | undefined> {
    const [food] = await db.select().from(customFoods).where(eq(customFoods.id, id));
    return food;
  }

  async getCustomFoodByBarcode(userId: number, barcode: string): Promise<CustomFood | undefined> {
    const [food] = await db.select().from(customFoods).where(
      and(eq(customFoods.userId, userId), eq(customFoods.barcode, barcode))
    );
    return food;
  }

  async createCustomFood(food: InsertCustomFood): Promise<CustomFood> {
    const [created] = await db.insert(customFoods).values(food).returning();
    return created;
  }

  async updateCustomFood(id: number, updates: Partial<InsertCustomFood>): Promise<CustomFood> {
    const [updated] = await db.update(customFoods)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(customFoods.id, id))
      .returning();
    return updated;
  }

  async deleteCustomFood(id: number): Promise<void> {
    await db.delete(customFoods).where(eq(customFoods.id, id));
  }

  async getMealTemplates(userId: number): Promise<MealTemplate[]> {
    return db.select().from(mealTemplates)
      .where(eq(mealTemplates.userId, userId))
      .orderBy(desc(mealTemplates.createdAt));
  }

  async getMealTemplate(id: number): Promise<MealTemplate | undefined> {
    const [template] = await db.select().from(mealTemplates).where(eq(mealTemplates.id, id));
    return template;
  }

  async createMealTemplate(template: InsertMealTemplate): Promise<MealTemplate> {
    const [created] = await db.insert(mealTemplates).values(template).returning();
    return created;
  }

  async deleteMealTemplate(id: number): Promise<void> {
    await db.delete(mealTemplateItems).where(eq(mealTemplateItems.templateId, id));
    await db.delete(mealTemplates).where(eq(mealTemplates.id, id));
  }

  async getMealTemplateItems(templateId: number): Promise<MealTemplateItem[]> {
    return db.select().from(mealTemplateItems)
      .where(eq(mealTemplateItems.templateId, templateId))
      .orderBy(mealTemplateItems.sortOrder);
  }

  async createMealTemplateItem(item: InsertMealTemplateItem): Promise<MealTemplateItem> {
    const [created] = await db.insert(mealTemplateItems).values(item).returning();
    return created;
  }

  async createMealTemplateItems(items: InsertMealTemplateItem[]): Promise<MealTemplateItem[]> {
    if (items.length === 0) return [];
    return db.insert(mealTemplateItems).values(items).returning();
  }

  async createFoodEntries(entries: InsertFoodEntry[]): Promise<FoodEntry[]> {
    if (entries.length === 0) return [];
    return db.insert(foodEntries).values(entries).returning();
  }
  async createFeedback(fb: InsertFeedback): Promise<Feedback> {
    const [created] = await db.insert(feedback).values(fb).returning();
    return created;
  }

  async getUserFeedback(userId: number, limit: number = 10): Promise<Feedback[]> {
    return db.select().from(feedback)
      .where(eq(feedback.userId, userId))
      .orderBy(desc(feedback.createdAt))
      .limit(limit);
  }

  async createFeedbackAttachments(attachments: InsertFeedbackAttachment[]): Promise<FeedbackAttachment[]> {
    if (attachments.length === 0) return [];
    return db.insert(feedbackAttachments).values(attachments).returning();
  }

  async getFeedbackAttachments(feedbackId: number): Promise<FeedbackAttachment[]> {
    return db.select().from(feedbackAttachments)
      .where(eq(feedbackAttachments.feedbackId, feedbackId));
  }

  async getSleepLog(userId: number, date: string): Promise<SleepLog | undefined> {
    const [log] = await db.select().from(sleepLogs)
      .where(and(eq(sleepLogs.userId, userId), eq(sleepLogs.date, date)));
    return log;
  }

  async upsertSleepLog(data: InsertSleepLog): Promise<SleepLog> {
    const existing = await this.getSleepLog(data.userId, data.date);
    if (existing) {
      const [updated] = await db.update(sleepLogs)
        .set({ hoursSlept: data.hoursSlept, sleepQuality: data.sleepQuality ?? null, updatedAt: new Date() })
        .where(eq(sleepLogs.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(sleepLogs).values(data).returning();
    return created;
  }

  async getSleepLogsRange(userId: number, startDate: string, endDate: string): Promise<SleepLog[]> {
    return db.select().from(sleepLogs)
      .where(and(eq(sleepLogs.userId, userId), gte(sleepLogs.date, startDate), lte(sleepLogs.date, endDate)));
  }

  async getWeightCutPlan(userId: number): Promise<WeightCutPlan | undefined> {
    const [plan] = await db.select().from(weightCutPlans)
      .where(eq(weightCutPlans.userId, userId));
    return plan;
  }

  async createWeightCutPlan(data: InsertWeightCutPlan): Promise<WeightCutPlan> {
    const [plan] = await db.insert(weightCutPlans).values(data).returning();
    return plan;
  }

  async updateWeightCutPlan(id: number, updates: Partial<InsertWeightCutPlan>): Promise<WeightCutPlan> {
    const [updated] = await db.update(weightCutPlans)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(weightCutPlans.id, id))
      .returning();
    return updated;
  }

  async deleteWeightCutPlan(id: number): Promise<void> {
    await db.delete(weightCutPlans).where(eq(weightCutPlans.id, id));
  }

  async getProvisionalCheckin(userId: number, date: string): Promise<ProvisionalCheckin | undefined> {
    const [checkin] = await db.select().from(provisionalCheckins)
      .where(and(eq(provisionalCheckins.userId, userId), eq(provisionalCheckins.date, date)));
    return checkin;
  }

  async upsertProvisionalCheckin(data: InsertProvisionalCheckin): Promise<ProvisionalCheckin> {
    const existing = await this.getProvisionalCheckin(data.userId, data.date);
    if (existing) {
      const [updated] = await db.update(provisionalCheckins)
        .set({
          feelToday: data.feelToday,
          fueledToday: data.fueledToday,
          plannedIntensity: data.plannedIntensity,
          updatedAt: new Date(),
        })
        .where(eq(provisionalCheckins.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(provisionalCheckins).values(data).returning();
    return created;
  }

  async getRestDayLog(userId: number, date: string): Promise<boolean> {
    const [row] = await db.select().from(restDayLogs)
      .where(and(eq(restDayLogs.userId, userId), eq(restDayLogs.date, date)));
    return !!row;
  }

  async setRestDayLog(userId: number, date: string): Promise<void> {
    await db.insert(restDayLogs).values({ userId, date })
      .onConflictDoNothing();
  }

  async deleteRestDayLog(userId: number, date: string): Promise<void> {
    await db.delete(restDayLogs)
      .where(and(eq(restDayLogs.userId, userId), eq(restDayLogs.date, date)));
  }

  async getLoadOverride(userId: number, date: string): Promise<string | null> {
    const [row] = await db.select().from(trainingLoadOverrides)
      .where(and(eq(trainingLoadOverrides.userId, userId), eq(trainingLoadOverrides.date, date)));
    return row?.overrideClassification ?? null;
  }

  async upsertLoadOverride(userId: number, date: string, classification: string): Promise<void> {
    await db.insert(trainingLoadOverrides)
      .values({ userId, date, overrideClassification: classification })
      .onConflictDoUpdate({
        target: [trainingLoadOverrides.userId, trainingLoadOverrides.date],
        set: { overrideClassification: classification },
      });
  }

  async deleteLoadOverride(userId: number, date: string): Promise<void> {
    await db.delete(trainingLoadOverrides)
      .where(and(eq(trainingLoadOverrides.userId, userId), eq(trainingLoadOverrides.date, date)));
  }

  async createTrainingBlock(
    userId: number,
    data: { name: string; startDate: string; weekCount: number },
    days: { dayOfWeek: number; plannedLoad: string; activities: BlockActivityTemplate[]; notes?: string | null }[]
  ) {
    // Archive any existing active block and delete its planned sessions
    const [existingBlock] = await db.select().from(trainingBlocks)
      .where(and(eq(trainingBlocks.userId, userId), eq(trainingBlocks.status, "active")))
      .limit(1);
    if (existingBlock) {
      await db.delete(workoutSessions)
        .where(and(eq(workoutSessions.userId, userId), eq(workoutSessions.trainingBlockId, existingBlock.id), eq(workoutSessions.isPlanned, true)));
      await db.update(trainingBlocks).set({ status: "archived" }).where(eq(trainingBlocks.id, existingBlock.id));
    }

    const [block] = await db.insert(trainingBlocks).values({
      userId,
      name: data.name,
      startDate: data.startDate,
      weekCount: data.weekCount,
      status: "active",
    }).returning();

    // Compute plannedLoad from activities for each day
    const dayRows = days.map(d => {
      const totalLoad = d.activities.reduce((sum, a) => {
        if (a.rpe) return sum + a.rpe * a.durationMinutes;
        if (a.metValue) return sum + a.metValue * a.durationMinutes; // rough proxy
        return sum + a.durationMinutes * 3;
      }, 0);
      const plannedLoad = d.activities.length === 0 ? "rest" : classifyDayLoad(totalLoad);
      return { blockId: block.id, dayOfWeek: d.dayOfWeek, plannedLoad, activities: d.activities, notes: d.notes ?? null };
    });

    const insertedDays = dayRows.length > 0
      ? await db.insert(trainingBlockDays).values(dayRows).returning()
      : [];

    // Find all existing session dates for this user in the block date range
    const startDateObj = new Date(data.startDate);
    const endDateObj = new Date(data.startDate);
    endDateObj.setDate(endDateObj.getDate() + data.weekCount * 7 - 1);
    const startStr = startDateObj.toISOString().split("T")[0];
    const endStr = endDateObj.toISOString().split("T")[0];
    const existingSessions = await db.select({ date: workoutSessions.date })
      .from(workoutSessions)
      .where(and(
        eq(workoutSessions.userId, userId),
        gte(workoutSessions.date, startStr),
        lte(workoutSessions.date, endStr),
      ));
    const existingDates = new Set(existingSessions.map(s => s.date));

    // Map slot → valid timeOfDay (schema only has morning/afternoon/evening)
    const slotToTimeOfDay = (slot: string | undefined): "morning" | "afternoon" | "evening" => {
      if (slot === "afternoon") return "afternoon";
      if (slot === "evening" || slot === "night") return "evening";
      return "morning";
    };

    // Create planned sessions for each week × each day × each slot group
    const activeDays = insertedDays.filter(d => d.activities && (d.activities as BlockActivityTemplate[]).length > 0);
    for (let week = 0; week < data.weekCount; week++) {
      for (const day of activeDays) {
        const dayDate = new Date(startDateObj);
        dayDate.setDate(dayDate.getDate() + week * 7 + day.dayOfWeek);
        const dateStr = dayDate.toISOString().split("T")[0];

        // Skip dates that already have sessions
        if (existingDates.has(dateStr)) continue;

        const activities = day.activities as BlockActivityTemplate[];

        // Group activities by slot so each slot gets its own session
        const slotGroups = new Map<string, BlockActivityTemplate[]>();
        for (const act of activities) {
          const key = act.slot ?? "morning";
          if (!slotGroups.has(key)) slotGroups.set(key, []);
          slotGroups.get(key)!.push(act);
        }

        for (const [slot, slotActs] of slotGroups) {
          const timeOfDay = slotToTimeOfDay(slot);
          const sessionTitle = slotActs.map(a => a.name).join(" + ");
          const totalDuration = slotActs.reduce((s, a) => s + a.durationMinutes, 0);

          const [session] = await db.insert(workoutSessions).values({
            userId,
            date: dateStr,
            timeOfDay,
            title: sessionTitle || "Planned Session",
            durationMinutes: totalDuration,
            isPlanned: true,
            trainingBlockId: block.id,
            estimatedKcal: 0,
          }).returning();

          // Create session_activities for each template activity in this slot
          for (const act of slotActs) {
            const metValue = act.metValue ?? (act.activityType === "lifting" ? 4.0 : 5.0);
            const rpeVal = act.rpe ?? 6;
            const trainingLoadScore = rpeVal * act.durationMinutes;
            const kcalEst = Math.round(metValue * 75 * (act.durationMinutes / 60));
            await db.insert(sessionActivities).values({
              sessionId: session.id,
              name: act.name,
              activityType: act.activityType,
              durationMinutes: act.durationMinutes,
              intensity: act.intensity ?? "moderate",
              metValue,
              estimatedKcal: kcalEst,
              rpe: rpeVal,
              sessionRpe: rpeVal,
              bodyRegion: act.bodyRegion ?? null,
              trainingLoadScore,
              activityCatalogId: act.activityCatalogId ?? null,
            });
          }

          // Update session kcal total
          const totalKcal = slotActs.reduce((s, a) => {
            const met = a.metValue ?? (a.activityType === "lifting" ? 4.0 : 5.0);
            return s + Math.round(met * 75 * (a.durationMinutes / 60));
          }, 0);
          await db.update(workoutSessions).set({ estimatedKcal: totalKcal }).where(eq(workoutSessions.id, session.id));
        }
      }
    }

    return { ...block, days: insertedDays };
  }

  async getActiveTrainingBlock(userId: number) {
    const [block] = await db.select().from(trainingBlocks)
      .where(and(eq(trainingBlocks.userId, userId), eq(trainingBlocks.status, "active")))
      .orderBy(desc(trainingBlocks.createdAt))
      .limit(1);

    if (!block) return null;

    const days = await db.select().from(trainingBlockDays)
      .where(eq(trainingBlockDays.blockId, block.id));

    return { ...block, days };
  }

  async archiveTrainingBlock(userId: number, blockId: number): Promise<void> {
    // Delete planned sessions created by this block
    await db.delete(workoutSessions)
      .where(and(eq(workoutSessions.userId, userId), eq(workoutSessions.trainingBlockId, blockId), eq(workoutSessions.isPlanned, true)));
    await db.update(trainingBlocks)
      .set({ status: "archived" })
      .where(and(eq(trainingBlocks.id, blockId), eq(trainingBlocks.userId, userId)));
  }
}

export const databaseStorage = new DatabaseStorage();
