import { Router, Request, Response } from "express";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import { db } from "./db";
import { inviteRequests, invites, betaWaitlist, normalizeSource } from "@shared/schema";
import { eq, and, gt } from "drizzle-orm";
import { z } from "zod";
import { sendInviteEmail } from "./lib/email";
import { isBetaFull, getBetaUserLimit, getActiveUserCount } from "./lib/beta-cap";

function hashEmail(email: string): string {
  return crypto.createHash("sha256").update(email.toLowerCase().trim()).digest("hex").substring(0, 12);
}

function extractEmailDomain(email: string): string {
  return email.split("@")[1] || "unknown";
}

const router = Router();

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  const bytes = crypto.randomBytes(10);
  for (let i = 0; i < 10; i++) {
    code += chars[bytes[i] % chars.length];
  }
  return code;
}

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token.toUpperCase().trim()).digest("hex");
}

const requestInviteLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { message: "Too many requests. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const requestInviteSchema = z.object({
  email: z.string().email().transform((s) => s.toLowerCase().trim()),
  source: z.string().optional(),
});

router.post("/request", requestInviteLimiter, async (req: Request, res: Response) => {
  try {
    const parseResult = requestInviteSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ message: "Please enter a valid email address." });
    }

    const { email, source: rawSource } = parseResult.data;
    const source = normalizeSource(rawSource);
    const ip = req.ip || req.socket.remoteAddress || null;
    const userAgent = req.headers["user-agent"] || null;

    await db.insert(inviteRequests).values({
      email,
      source,
      ip,
      userAgent,
    });

    const emailHash = hashEmail(email);
    const toDomain = extractEmailDomain(email);

    if (await isBetaFull()) {
      const count = await getActiveUserCount();
      const limit = getBetaUserLimit();
      await db.insert(betaWaitlist).values({ email, source: "invite_request" });
      console.warn(`[invite][request] email=${emailHash} toDomain=${toDomain} success=false reason=beta_full cap=${limit} active=${count}`);
      return res.status(403).json({ message: "Beta is currently full. You've been added to the waitlist." });
    }

    const code = generateCode();
    const tokenHash = hashToken(code);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await db.insert(invites).values({
      email,
      tokenHash,
      expiresAt,
      maxUses: 1,
      uses: 0,
    });

    console.log(`[invite][request] email=${emailHash} toDomain=${toDomain} success=true`);

    const emailResult = await sendInviteEmail(email, code, email.split("@")[0]);

    if (emailResult.success) {
      console.log(`[invite][email] from=team@prfmr.link toDomain=${toDomain} success=true`);
    } else {
      console.error(`[invite][email][error] toDomain=${toDomain} reason=${emailResult.error}`);
    }

    res.json({ message: "Check your email for your invite code." });
  } catch (error) {
    console.error("[invites] Request error:", error);
    res.status(500).json({ message: "Something went wrong. Please try again." });
  }
});

router.get("/validate", async (req: Request, res: Response) => {
  try {
    const rawToken = (req.query.token as string) || "";
    if (!rawToken) {
      return res.json({ valid: false, error: "Missing invite code." });
    }

    const tokenHash = hashToken(rawToken);

    const invite = await db.query.invites.findFirst({
      where: and(
        eq(invites.tokenHash, tokenHash),
        gt(invites.expiresAt, new Date()),
      ),
    });

    if (!invite) {
      return res.json({ valid: false, error: "This invite code is invalid or has expired." });
    }

    if (invite.uses >= invite.maxUses) {
      return res.json({ valid: false, error: "This invite code has already been used." });
    }

    res.json({ valid: true, email: invite.email });
  } catch (error) {
    console.error("[invites] Validate error:", error);
    res.json({ valid: false, error: "Unable to validate invite." });
  }
});

export { hashToken };
export default router;
