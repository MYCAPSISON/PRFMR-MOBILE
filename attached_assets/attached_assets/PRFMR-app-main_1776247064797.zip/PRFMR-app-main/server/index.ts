import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { seedCatalogsIfEmpty } from "./seed-catalogs";
import { setupAuth } from "./auth";

const app = express();
app.disable("etag"); // Prevent 304 responses for API endpoints
app.set("trust proxy", 1); // Trust first proxy for rate limiting and session handling
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

setupAuth(app);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const dbUrl = process.env.DATABASE_URL || "";
  if (dbUrl) {
    const urlParts = dbUrl.match(/@([^:\/]+)/);
    const host = urlParts?.[1] || "unknown";
    const urlHash = Buffer.from(dbUrl.slice(-20)).toString("base64").slice(0, 12);
    log(`Database: host=${host}, fingerprint=${urlHash}`, "db");
  }
  
  await seedCatalogsIfEmpty();
  
  // Validate composite food ingredient references at startup
  const { validateCompositeIngredients } = await import("./lib/micros");
  validateCompositeIngredients();
  
  await registerRoutes(httpServer, app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || "5000", 10);
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    async () => {
      log(`serving on port ${port}`);
      try {
        const { getAppVersion, getEnvironment } = await import("./lib/version");
        log(`[version] ${getAppVersion()} (${getEnvironment()})`);
      } catch {}
      try {
        const { getActiveUserCount, getBetaUserLimit } = await import("./lib/beta-cap");
        const activeCount = await getActiveUserCount();
        const limit = getBetaUserLimit();
        log(`[beta] Active users: ${activeCount}/${limit} (${limit - activeCount} slots remaining)`);
        if (activeCount >= limit) {
          log(`[beta] WARNING: Beta user cap reached! No new registrations will be accepted.`);
        }
      } catch (e) {
        log(`[beta] Could not check active user count at startup`);
      }
      try {
        const { betaWaitlist } = await import("@shared/schema");
        const { sql } = await import("drizzle-orm");
        const { db: dbInstance } = await import("./db");
        const [wlResult] = await dbInstance.select({ count: sql<number>`count(*)::int` }).from(betaWaitlist);
        log(`[beta] Waitlist entries: ${wlResult.count}`);
      } catch (e: any) {
        log(`[beta] Could not check waitlist count at startup: ${e?.message || e}`);
      }
    },
  );
})();
