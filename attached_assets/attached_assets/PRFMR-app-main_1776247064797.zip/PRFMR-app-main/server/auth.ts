import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as GoogleStrategy, Profile as GoogleProfile, VerifyCallback } from "passport-google-oauth20";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { Express, Request, Response, NextFunction } from "express";
import argon2 from "argon2";
import { db } from "./db";
import { usersAuth, users } from "@shared/schema";
import { eq, or } from "drizzle-orm";

const PgSession = connectPgSimple(session);

declare global {
  namespace Express {
    interface User {
      id: number;
      email: string;
      username: string;
    }
  }
}

export async function hashPassword(password: string): Promise<string> {
  return argon2.hash(password);
}

export async function verifyPassword(hash: string, password: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET;
  
  if (process.env.NODE_ENV === "production" && !sessionSecret) {
    console.error("FATAL: SESSION_SECRET environment variable is required in production");
    process.exit(1);
  }
  
  if (!sessionSecret) {
    console.warn("WARNING: SESSION_SECRET not set. Using fallback for development only.");
  }

  const sessionStore = new PgSession({
    conString: process.env.DATABASE_URL,
    tableName: "session",
    createTableIfMissing: true,
  });

  const BROWSER_SESSION_MAX_AGE = 30 * 24 * 60 * 60 * 1000; // 30 days
  const PWA_SESSION_MAX_AGE = 90 * 24 * 60 * 60 * 1000; // 90 days

  app.use(
    session({
      store: sessionStore,
      secret: sessionSecret || "dev-fallback-secret-change-in-production",
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: BROWSER_SESSION_MAX_AGE,
      },
    })
  );

  app.use(passport.initialize());
  app.use(passport.session());

  app.use((req, _res, next) => {
    if (req.session && req.isAuthenticated()) {
      const isPWA = req.headers["x-app-mode"] === "standalone";
      const targetMaxAge = isPWA ? PWA_SESSION_MAX_AGE : BROWSER_SESSION_MAX_AGE;
      if (req.session.cookie.maxAge !== targetMaxAge) {
        req.session.cookie.maxAge = targetMaxAge;
      }
    }
    next();
  });

  passport.use(
    new LocalStrategy(
      {
        usernameField: "identifier",
        passwordField: "password",
      },
      async (identifier, password, done) => {
        try {
          const normalizedIdentifier = identifier.toLowerCase().trim();
          const isEmail = normalizedIdentifier.includes("@");

          const user = await db.query.usersAuth.findFirst({
            where: isEmail
              ? eq(usersAuth.email, normalizedIdentifier)
              : eq(usersAuth.username, normalizedIdentifier),
          });

          if (!user) {
            return done(null, false, { message: "Invalid credentials." });
          }

          if (!user.passwordHash) {
            return done(null, false, { message: "This account uses Google login. Please sign in with Google." });
          }

          const isValid = await verifyPassword(user.passwordHash, password);
          if (!isValid) {
            return done(null, false, { message: "Invalid credentials." });
          }

          return done(null, {
            id: user.id,
            email: user.email,
            username: user.username,
          });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;

  if (googleClientId && googleClientSecret) {
    const callbackURL = process.env.GOOGLE_CALLBACK_URL || `${process.env.APP_BASE_URL || ""}/auth/google/callback`;

    passport.use(
      new GoogleStrategy(
        {
          clientID: googleClientId,
          clientSecret: googleClientSecret,
          callbackURL,
          scope: ["profile", "email"],
        },
        async (_accessToken: string, _refreshToken: string, profile: GoogleProfile, done: VerifyCallback) => {
          try {
            const email = profile.emails?.[0]?.value?.toLowerCase().trim();
            if (!email) {
              return done(null, false, { message: "No email returned from Google. Please use an account with an email address." } as any);
            }

            const googleId = profile.id;

            const result = await db.transaction(async (tx) => {
              const existingUser = await tx.query.usersAuth.findFirst({
                where: eq(usersAuth.email, email),
              });

              if (existingUser) {
                if (existingUser.provider === "google" && existingUser.providerUserId === googleId) {
                  return { id: existingUser.id, email: existingUser.email, username: existingUser.username };
                }

                if (existingUser.provider === "local" && !existingUser.emailVerified) {
                  return null;
                }

                await tx.update(usersAuth)
                  .set({
                    provider: "google",
                    providerUserId: googleId,
                    emailVerified: true,
                    emailVerifiedAt: existingUser.emailVerifiedAt || new Date(),
                    updatedAt: new Date(),
                  })
                  .where(eq(usersAuth.id, existingUser.id));

                console.log(`[auth][google] Linked Google to existing user: userId=${existingUser.id}`);
                return { id: existingUser.id, email: existingUser.email, username: existingUser.username };
              }

              const displayName = profile.displayName || email.split("@")[0];
              let baseUsername = displayName.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 16) || "user";
              if (baseUsername.length < 3) baseUsername = baseUsername + "user";

              let username = baseUsername;
              let suffix = 1;
              while (true) {
                const taken = await tx.query.usersAuth.findFirst({
                  where: eq(usersAuth.username, username),
                });
                if (!taken) break;
                username = `${baseUsername.slice(0, 14)}${suffix}`;
                suffix++;
                if (suffix > 999) {
                  username = `user${Date.now().toString(36)}`;
                  break;
                }
              }

              const [authUser] = await tx.insert(usersAuth).values({
                email,
                username,
                passwordHash: null,
                provider: "google",
                providerUserId: googleId,
                emailVerified: true,
                emailVerifiedAt: new Date(),
                source: "google",
              }).returning();

              await tx.insert(users).values({
                username,
                authUserId: authUser.id,
                source: "google",
              });

              console.log(`[auth][google] New user created: userId=${authUser.id}, email=${email.substring(0, 3)}***`);
              return { id: authUser.id, email: authUser.email, username: authUser.username };
            });

            if (!result) {
              return done(null, false, { message: "An account with this email exists but is not verified. Please verify your email first or log in with your password." } as any);
            }

            return done(null, result);
          } catch (error) {
            console.error("[auth][google] Strategy error:", error);
            return done(error as Error);
          }
        }
      )
    );
    console.log("[auth] Google OAuth strategy configured");
  } else {
    console.log("[auth] Google OAuth not configured (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET missing)");
  }

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await db.query.usersAuth.findFirst({
        where: eq(usersAuth.id, id),
      });

      if (!user) {
        return done(null, false);
      }

      done(null, {
        id: user.id,
        email: user.email,
        username: user.username,
      });
    } catch (error) {
      done(error);
    }
  });
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

export function getCurrentUser(req: Request): Express.User | undefined {
  return req.user;
}
