/**
 * searchRanking.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Query-aware food search ranking engine for Open Food Facts results.
 *
 * Architecture:
 *  1. normText()            – normalise raw strings for comparison
 *  2. UK_BRAND_ALIASES      – brand alias map (easy to extend)
 *  3. parseFoodSearchQuery() – detect brand vs generic intent
 *  4. scoreOffResult()       – tiered relevance score + UK quality tiebreaker
 *
 * Scoring contract:
 *   score = relevanceTier (0–100) × 1000  +  ukQuality (0–20)
 *
 * This ensures relevance always dominates; UK quality only breaks ties within
 * the same tier. A wrong-brand result can never outrank a right-brand result
 * regardless of how good its UK data quality is.
 *
 * Tier table (branded query, e.g. "m&s milk"):
 *   100  exact full match
 *    90  brand prefix match + all product tokens
 *    85  brand match + all product tokens
 *    60–80  brand match + partial product tokens (scales with coverage)
 *    40  brand match only (no product tokens in result)
 *    20  all product tokens but NO brand — hard cap below brand results
 *    10  partial product tokens, no brand
 *     2  weak / irrelevant
 *
 * Tier table (generic query, e.g. "semi skimmed milk"):
 *   100  exact name match
 *    90  name starts with full query
 *    75  all tokens in name (any order)
 *    60  all tokens across name+brand combined
 *    40  > 2/3 token coverage
 *    20  > 1/3 token coverage
 *     5  weak fallback
 */

// ─── Text normalisation ──────────────────────────────────────────────────────

/**
 * Normalise a raw string for comparison:
 *  - lowercase
 *  - "m&s" → "m and s"  (spaces around & so tokens split cleanly)
 *  - strip apostrophes / backticks
 *  - dashes/underscores → spaces
 *  - remaining punctuation → spaces
 *  - collapse multiple spaces
 */
export function normText(s: string): string {
  return s
    .toLowerCase()
    .replace(/\s*&\s*/g, " and ")   // m&s → m and s, marks & spencer → marks and spencer
    .replace(/['\u2019`]/g, "")      // mark's → marks
    .replace(/[-–—_]/g, " ")         // dashes → spaces
    .replace(/[^a-z0-9\s]/g, " ")    // remaining punctuation → space
    .replace(/\s+/g, " ")            // collapse spaces
    .trim();
}

// ─── Brand alias map ─────────────────────────────────────────────────────────

/**
 * UK_BRAND_ALIASES
 *
 * Maps every normalised form a user might type → the normalised form(s) to
 * look for in Open Food Facts `brands` field or product name.
 *
 * Rules for adding entries:
 *  - Keys must be the output of normText() (lowercase, & expanded, no punct)
 *  - Values must also be normText()-safe strings
 *  - Add the most common misspellings / abbreviations as additional keys
 *  - Values can include multiple accepted forms for one brand
 */
export const UK_BRAND_ALIASES: Record<string, string[]> = {
  // ── Marks & Spencer ──────────────────────────────────────────────────────
  "ms":                   ["marks and spencer", "m and s"],
  "m and s":              ["marks and spencer", "m and s"],
  "marks and spencer":    ["marks and spencer"],
  "marks and spencers":   ["marks and spencer"],

  // ── Major UK supermarkets ─────────────────────────────────────────────────
  "tesco":                ["tesco"],
  "tescos":               ["tesco"],
  "sainsburys":           ["sainsburys", "sainsbury"],
  "sainsbury":            ["sainsburys", "sainsbury"],
  "asda":                 ["asda"],
  "morrisons":            ["morrisons", "morrison"],
  "morrison":             ["morrisons", "morrison"],
  "waitrose":             ["waitrose"],
  "lidl":                 ["lidl"],
  "aldi":                 ["aldi"],
  "coop":                 ["coop", "co op", "cooperative"],
  "co op":                ["coop", "co op"],
  "iceland":              ["iceland"],
  "ocado":                ["ocado"],

  // ── Bread / bakery ────────────────────────────────────────────────────────
  "warburtons":           ["warburtons"],
  "kingsmill":            ["kingsmill"],
  "hovis":                ["hovis"],
  "roberts":              ["roberts"],

  // ── Breakfast / cereal ────────────────────────────────────────────────────
  "kelloggs":             ["kelloggs", "kellogg"],
  "kellogs":              ["kelloggs", "kellogg"],
  "kellogg":              ["kellogg", "kelloggs"],
  "quaker":               ["quaker"],
  "weetabix":             ["weetabix"],
  "jordans":              ["jordans"],
  "nature valley":        ["nature valley"],

  // ── Dairy / spreads ───────────────────────────────────────────────────────
  "lurpak":               ["lurpak"],
  "anchor":               ["anchor"],
  "flora":                ["flora"],
  "utterly butterly":     ["utterly butterly"],
  "philadelphia":         ["philadelphia"],
  "philly":               ["philadelphia"],
  "muller":               ["muller", "müller"],
  "mullller":             ["muller"],               // common typo
  "danone":               ["danone"],
  "activia":              ["activia"],
  "fage":                 ["fage"],
  "yeo valley":           ["yeo valley"],

  // ── Plant-based ───────────────────────────────────────────────────────────
  "alpro":                ["alpro"],
  "oatly":                ["oatly"],
  "minor figures":        ["minor figures"],
  "oat ly":               ["oatly"],               // common typo

  // ── Snacks / condiments ───────────────────────────────────────────────────
  "heinz":                ["heinz"],
  "cadbury":              ["cadbury"],
  "cadburys":             ["cadbury"],
  "walkers":              ["walkers"],
  "pringles":             ["pringles"],
  "mcvities":             ["mcvities", "mcvitie"],
  "hartleys":             ["hartley", "hartleys"],
  "robinson":             ["robinson", "robinsons"],
  "ribena":               ["ribena"],

  // ── Drinks ────────────────────────────────────────────────────────────────
  "innocent":             ["innocent"],
  "tropicana":            ["tropicana"],
  "coca cola":            ["coca cola", "coca-cola"],
  "coke":                 ["coca cola"],
  "pepsi":                ["pepsi"],
  "lucozade":             ["lucozade"],

  // ── Protein / sports ──────────────────────────────────────────────────────
  "myprotein":            ["myprotein", "my protein"],
  "optimum nutrition":    ["optimum nutrition"],
  "bulk":                 ["bulk"],
  "huel":                 ["huel"],
  "grenade":              ["grenade"],
};

// Sorted longest-first: prevents "m and s" being shadowed by partial key "m"
const BRAND_KEYS = Object.keys(UK_BRAND_ALIASES).sort((a, b) => b.length - a.length);

// ─── Query parsing ────────────────────────────────────────────────────────────

export interface ParsedFoodQuery {
  /** Raw input normalised via normText */
  normalized: string;
  /** All tokens after normText (space-split) */
  tokens: string[];
  /** True when a recognised brand key was detected at the start of the query */
  isBrandedQuery: boolean;
  /** The matched key in UK_BRAND_ALIASES (undefined for generic queries) */
  brandKey?: string;
  /** Normalised forms to look for in OFF brand/name fields */
  brandForms?: string[];
  /** Tokens that represent the product (everything after the brand tokens) */
  productTokens: string[];
}

/**
 * Parse a raw search query into brand intent + product tokens.
 *
 * Strategy: scan tokens from the start against BRAND_KEYS (longest-first).
 * If a match is found, everything before it is the brand; everything after
 * is the product.
 *
 * Examples:
 *   "m&s milk"          → isBrandedQuery:true,  brandKey:"m and s", productTokens:["milk"]
 *   "tesco bagel"       → isBrandedQuery:true,  brandKey:"tesco",   productTokens:["bagel"]
 *   "semi skimmed milk" → isBrandedQuery:false,                      productTokens:["semi","skimmed","milk"]
 *   "eggs"              → isBrandedQuery:false,                      productTokens:["eggs"]
 */
export function parseFoodSearchQuery(raw: string): ParsedFoodQuery {
  const normalized = normText(raw);
  const tokens = normalized.split(" ").filter((t) => t.length > 0);

  for (const key of BRAND_KEYS) {
    const keyTokens = key.split(" ");
    const head = tokens.slice(0, keyTokens.length).join(" ");
    if (head === key) {
      return {
        normalized,
        tokens,
        isBrandedQuery: true,
        brandKey: key,
        brandForms: UK_BRAND_ALIASES[key],
        productTokens: tokens.slice(keyTokens.length),
      };
    }
  }

  return { normalized, tokens, isBrandedQuery: false, productTokens: tokens };
}

// ─── Scoring helpers ──────────────────────────────────────────────────────────

function textContainsBrand(text: string, forms: string[]): boolean {
  return forms.some((f) => text.includes(f));
}

function tokenCoverage(text: string, tokens: string[]): number {
  if (tokens.length === 0) return 1;
  return tokens.filter((t) => text.includes(t)).length / tokens.length;
}

// ─── Main scoring function ────────────────────────────────────────────────────

/**
 * Score a single OFF result against the parsed query.
 * Returns: relevanceTier × 1000 + ukQuality
 *
 * The ×1000 multiplier means relevance always dominates; two results in the
 * same relevance tier are then broken by UK quality (source, country tag,
 * barcode, image, protein data).
 */
export function scoreOffResult(result: any, pq: ParsedFoodQuery): number {
  const normName  = normText(result.name  || "");
  const normBrand = normText(result.brand || "");
  // combined is what we match tokens against
  const combined  = (normName + " " + normBrand).trim();

  let tier = 0;

  if (pq.isBrandedQuery && pq.brandForms && pq.brandForms.length > 0) {
    // ── Branded query path ────────────────────────────────────────────────
    const hasBrand  = textContainsBrand(combined, pq.brandForms);
    const prodCov   = tokenCoverage(combined, pq.productTokens);
    const exact     = normName === pq.normalized;

    if (exact) {
      // Tier 1: exact full name match (rare but possible)
      tier = 100;
    } else if (hasBrand && prodCov >= 1.0) {
      // Tier 2: brand present + all product tokens found
      tier = 85;
      // Bonus: brand appears at the start of name/brand field (prefix boost)
      const brandPrefix = pq.brandForms.some(
        (f) => normName.startsWith(f) || normBrand.startsWith(f)
      );
      if (brandPrefix) tier += 5; // → 90
    } else if (hasBrand && prodCov >= 0.5) {
      // Tier 3: brand present + partial product match (scales 60→80)
      tier = 60 + Math.round(prodCov * 20);
    } else if (hasBrand) {
      // Tier 4: brand present but product tokens absent — brand-only match
      tier = 40;
    } else if (pq.productTokens.length > 0 && prodCov >= 1.0) {
      // Tier 5: all product tokens but NO brand — hard-capped below brand results
      tier = 20;
    } else if (pq.productTokens.length > 0 && prodCov >= 0.5) {
      // Tier 6: partial product match, no brand
      tier = 10;
    } else {
      // Tier 7: weak / irrelevant match
      tier = 2;
    }
  } else {
    // ── Generic query path ────────────────────────────────────────────────
    const cov           = tokenCoverage(combined, pq.tokens);
    const nameExact     = normName === pq.normalized;
    const namePrefix    = normName.startsWith(pq.normalized);
    const allInName     = pq.tokens.every((t) => normName.includes(t));

    if (nameExact) {
      tier = 100;  // exact name
    } else if (namePrefix) {
      tier = 90;   // name starts with full query string
    } else if (allInName) {
      tier = 75;   // all tokens in name (any order)
    } else if (cov >= 1.0) {
      tier = 60;   // all tokens covered across name+brand combined
    } else if (cov >= 0.67) {
      tier = 40;   // > 2/3 tokens matched
    } else if (cov >= 0.33) {
      tier = 20;   // > 1/3 tokens matched
    } else {
      tier = 5;    // weak fallback
    }
  }

  // ── UK quality tiebreaker (max 20 pts) ───────────────────────────────────
  let quality = 0;
  if (result.source === "uk") quality += 8;                           // UK endpoint
  const tags: string[] = result.countries_tags || [];
  if (tags.includes("en:united-kingdom")) quality += 6;              // UK country tag
  if (result.barcode) quality += 3;                                   // scanned product
  if (result.image)   quality += 2;                                   // has photo
  if ((result.protein || 0) > 0 && (result.carbs || 0) >= 0) quality += 1; // macro data

  return tier * 1000 + quality;
}
