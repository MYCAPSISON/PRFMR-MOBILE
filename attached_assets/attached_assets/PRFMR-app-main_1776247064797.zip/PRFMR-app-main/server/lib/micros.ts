import { IStorage } from "../storage";
import { Ingredient, getMicronutrientValue } from "@shared/utils";
import * as fs from "fs";
import * as path from "path";

let ingredientsCache: Ingredient[] | null = null;

export function getIngredients(): Ingredient[] {
  if (!ingredientsCache) {
    const filePath = path.join(process.cwd(), "data", "ingredients.json");
    const data = fs.readFileSync(filePath, "utf-8");
    ingredientsCache = JSON.parse(data) as Ingredient[];
  }
  return ingredientsCache;
}

// Decomposition map for composite "core food" meals into constituent ingredients
// with gram amounts per stated serving size. This allows AMQS to extract micros
// from combo meals that don't have a single ingredient match.
interface CompositeComponent {
  ingredient: string; // must match an ingredient name in ingredients.json (case-insensitive)
  grams: number;      // grams of this ingredient per serving
}
const COMPOSITE_FOODS: Record<string, { serving: number; components: CompositeComponent[] }> = {
  "porridge (oats + milk)": {
    serving: 250,
    components: [
      { ingredient: "Oats (Raw)", grams: 40 },
      { ingredient: "Milk (Whole)", grams: 200 },
    ],
  },
  "porridge (oats + water)": {
    serving: 250,
    components: [
      { ingredient: "Oats (Raw)", grams: 45 },
    ],
  },
  "cappuccino (whole milk)": {
    serving: 240,
    components: [
      { ingredient: "Milk (Whole)", grams: 120 },
    ],
  },
  "latte (whole milk)": {
    serving: 350,
    components: [
      { ingredient: "Milk (Whole)", grams: 200 },
    ],
  },
  "flat white": {
    serving: 200,
    components: [
      { ingredient: "Milk (Whole)", grams: 130 },
    ],
  },
  "cappuccino (oat milk)": {
    serving: 240,
    components: [
      { ingredient: "Oat Milk", grams: 120 },
    ],
  },
  "toast with butter (white)": {
    serving: 45,
    components: [
      { ingredient: "Bread (White Sliced)", grams: 30 },
      { ingredient: "Butter", grams: 10 },
    ],
  },
  "toast without butter (white)": {
    serving: 30,
    components: [
      { ingredient: "Bread (White Sliced)", grams: 30 },
    ],
  },
  "toast with butter (wholemeal)": {
    serving: 50,
    components: [
      { ingredient: "Bread (Wholemeal)", grams: 36 },
      { ingredient: "Butter", grams: 10 },
    ],
  },
  "mashed potato": {
    serving: 200,
    components: [
      { ingredient: "Potatoes (Boiled)", grams: 180 },
      { ingredient: "Butter", grams: 10 },
      { ingredient: "Milk (Whole)", grams: 20 },
    ],
  },
  "scrambled eggs (2 eggs, butter)": {
    serving: 130,
    components: [
      { ingredient: "Eggs, Whole (Raw)", grams: 100 },
      { ingredient: "Butter", grams: 10 },
      { ingredient: "Milk (Whole)", grams: 20 },
    ],
  },
  "overnight oats": {
    serving: 300,
    components: [
      { ingredient: "Oats (Raw)", grams: 50 },
      { ingredient: "Milk (Whole)", grams: 150 },
      { ingredient: "Greek Yogurt (Plain)", grams: 50 },
    ],
  },
  "beans on toast": {
    serving: 260,
    components: [
      { ingredient: "Baked Beans (Canned)", grams: 200 },
      { ingredient: "Bread (White Sliced)", grams: 60 },
    ],
  },
  "greek yoghurt with honey": {
    serving: 170,
    components: [
      { ingredient: "Greek Yogurt (Plain)", grams: 150 },
      { ingredient: "Honey", grams: 15 },
    ],
  },
  "cereal with milk": {
    serving: 270,
    components: [
      { ingredient: "Milk (Whole)", grams: 200 },
    ],
  },
};

export function isCompositeFoodEntry(name: string): boolean {
  return name.toLowerCase().trim() in COMPOSITE_FOODS;
}

export function validateCompositeIngredients(): void {
  const ingredients = getIngredients();
  const names = new Set(ingredients.map(i => i.name.toLowerCase().trim()));
  for (const [food, def] of Object.entries(COMPOSITE_FOODS)) {
    for (const comp of def.components) {
      if (!names.has(comp.ingredient.toLowerCase().trim())) {
        console.warn(`[micros] COMPOSITE_FOODS: "${food}" references unknown ingredient "${comp.ingredient}"`);
      }
    }
  }
}

const MICRO_KEYS = [
  "iron_mg",
  "calcium_mg",
  "vitamin_d_ug",
  "magnesium_mg",
  "zinc_mg",
  "iodine_ug",
  "selenium_ug",
  "folate_ug",
  "vitamin_b12_ug",
  "vitamin_c_mg",
  "vitamin_a_ug",
  "potassium_mg",
  // Layer 2 additions — B vitamins and Omega-3
  "vitamin_b1_mg",
  "vitamin_b2_mg",
  "vitamin_b3_mg",
  "vitamin_b6_mg",
  "omega3_g",
];

export interface MicroTotals {
  [key: string]: number;
}

export interface MicrosBreakdown {
  food: MicroTotals;
  supplements: MicroTotals;
}

export interface DailyMicrosResult {
  date: string;
  totals: MicroTotals;
  breakdown: MicrosBreakdown;
}

export async function getSupplementMicrosForDate(
  storage: IStorage,
  userId: number,
  date: string
): Promise<MicroTotals> {
  const intakes = await storage.getSupplementIntakes(userId, date);
  const supplements = await storage.getSupplements(userId);
  const catalog = await storage.getSupplementCatalog();

  const microTotals: MicroTotals = {};

  for (const intake of intakes) {
    if (!intake.taken) continue;

    const supplement = supplements.find((s) => s.id === intake.supplementId);
    if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;

    const catalogItem = catalog.find((c) => c.id === supplement.catalogId);
    if (!catalogItem) continue;

    // microsPerUnit is JSONB, so it's already an object (or null/empty)
    const microsPerUnit = catalogItem.microsPerUnit as Record<string, number> | null;
    if (!microsPerUnit || typeof microsPerUnit !== 'object') continue;
    
    for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
      if (typeof valuePerUnit !== 'number') continue;
      
      // The catalog's microsPerUnit already encodes the correct mcg/mg value per unit of defaultUnit.
      // We just need to handle unit mismatches between user's doseUnit and catalog's defaultUnit.
      let doseInCatalogUnits = supplement.doseAmount;
      
      // Handle Vitamin D IU <-> mcg conversion when units don't match
      if (key === "vitamin_d_ug" && supplement.doseUnit !== catalogItem.defaultUnit) {
        if (supplement.doseUnit === "IU" && catalogItem.defaultUnit === "mcg") {
          // User entered IU but catalog expects mcg: convert IU to mcg (1 IU = 0.025 mcg)
          doseInCatalogUnits = supplement.doseAmount * 0.025;
        } else if (supplement.doseUnit === "mcg" && catalogItem.defaultUnit === "IU") {
          // User entered mcg but catalog expects IU: convert mcg to IU (1 mcg = 40 IU)
          doseInCatalogUnits = supplement.doseAmount * 40;
        }
      }
      
      const contribution = valuePerUnit * doseInCatalogUnits;
      microTotals[key] = (microTotals[key] || 0) + contribution;
    }
  }

  return microTotals;
}

export async function getFoodMicrosForDate(
  storage: IStorage,
  userId: number,
  date: string
): Promise<MicroTotals> {
  const foodEntries = await storage.getFoodEntries(userId, date);
  const ingredients = getIngredients();

  const microTotals: MicroTotals = {};

  for (const entry of foodEntries) {
    const entryGrams = (entry as any).normalizedGrams || entry.grams || 0;
    if (entryGrams <= 0) continue;

    // Check if this is a composite/core food with known decomposition
    const compositeKey = entry.name.toLowerCase().trim();
    const composite = COMPOSITE_FOODS[compositeKey];
    if (composite) {
      // Scale component grams by the ratio of logged grams to reference serving
      const scale = entryGrams / composite.serving;
      for (const comp of composite.components) {
        const ing = ingredients.find(
          (i) => i.name.toLowerCase().trim() === comp.ingredient.toLowerCase().trim()
        );
        if (!ing) continue;
        const compGrams = comp.grams * scale;
        for (const key of MICRO_KEYS) {
          const val = getMicronutrientValue(ing, `${key}_per_100g`);
          if (val !== null) {
            microTotals[key] = (microTotals[key] || 0) + (val * compGrams) / 100;
          }
        }
      }
      continue;
    }

    let ingredient: Ingredient | undefined = undefined;
    
    // Check if this is a mapped OFF entry with ingredientIndex
    if (
      entry.sourceType === "off" &&
      entry.microSource === "ingredient" &&
      typeof entry.ingredientIndex === "number" &&
      entry.ingredientIndex >= 0 &&
      entry.ingredientIndex < ingredients.length
    ) {
      // Use the mapped ingredient by index
      ingredient = ingredients[entry.ingredientIndex];
    } else if (entry.sourceType !== "off") {
      // For non-OFF entries, fall back to case-insensitive name matching (whole food entries)
      ingredient = ingredients.find(
        (i) => i.name.toLowerCase().trim() === entry.name.toLowerCase().trim()
      );
    }
    // For OFF entries without valid mapping (microSource !== "ingredient"), skip micros
    
    if (!ingredient) continue;

    for (const key of MICRO_KEYS) {
      const val = getMicronutrientValue(ingredient, `${key}_per_100g`);
      if (val !== null) {
        const contribution = (val * entryGrams) / 100;
        microTotals[key] = (microTotals[key] || 0) + contribution;
      }
    }
  }

  return microTotals;
}

export function mergeMicros(a: MicroTotals, b: MicroTotals): MicroTotals {
  const result: MicroTotals = { ...a };
  for (const [key, value] of Object.entries(b)) {
    result[key] = (result[key] || 0) + value;
  }
  return result;
}

export async function getDailyMicros(
  storage: IStorage,
  userId: number,
  date: string
): Promise<DailyMicrosResult> {
  const [foodMicros, supplementMicros] = await Promise.all([
    getFoodMicrosForDate(storage, userId, date),
    getSupplementMicrosForDate(storage, userId, date),
  ]);

  return {
    date,
    totals: mergeMicros(foodMicros, supplementMicros),
    breakdown: {
      food: foodMicros,
      supplements: supplementMicros,
    },
  };
}
