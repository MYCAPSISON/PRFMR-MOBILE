import { db } from "../db";
import { usersAuth } from "@shared/schema";
import { sql } from "drizzle-orm";

export function getBetaUserLimit(): number {
  const envVal = process.env.BETA_USER_LIMIT;
  const limit = envVal ? parseInt(envVal, 10) : 50;
  return isNaN(limit) ? 50 : limit;
}

export async function getActiveUserCount(): Promise<number> {
  const [result] = await db.select({ count: sql<number>`count(*)::int` }).from(usersAuth);
  return result.count;
}

export async function isBetaFull(): Promise<boolean> {
  const count = await getActiveUserCount();
  const limit = getBetaUserLimit();
  return count >= limit;
}

export async function getActiveUserCountWithTx(tx: Parameters<Parameters<typeof db.transaction>[0]>[0]): Promise<number> {
  const [result] = await tx.select({ count: sql<number>`count(*)::int` }).from(usersAuth);
  return result.count;
}
