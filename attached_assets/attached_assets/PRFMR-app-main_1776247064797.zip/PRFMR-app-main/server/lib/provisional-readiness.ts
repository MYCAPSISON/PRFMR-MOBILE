/**
 * Provisional Readiness & Fuel Estimation
 *
 * This module computes estimated readiness and fuel status when objective
 * nutrition and training data from yesterday is unavailable. It relies entirely
 * on self-reported answers from the Quick Check-in card.
 *
 * SCIENTIFIC BASIS
 * Subjective wellness monitoring is a well-established screening layer in athlete
 * monitoring (Hooper et al. 1995; Saw et al. 2016; Meeusen et al. 2013).
 * Self-reported fatigue, perceived fueling, and planned intensity together provide
 * a defensible qualitative signal when objective data is absent.
 *
 * WHAT PROVISIONAL MODE DOES NOT CLAIM
 * - It does not measure actual glycogen levels or carbohydrate availability.
 * - It does not replace objective nutrition tracking.
 * - It does not calculate energy availability (EA) or carbs per kg.
 * - All outputs are estimates based on self-perception, not biomarkers.
 *
 * FUEL RISK vs GLYCOGEN RISK
 * "Glycogen risk" is only used when actual carbohydrate intake data (g/kg) is
 * available from food logs. In provisional mode, we use "fuel availability risk"
 * instead — a broader, self-report-appropriate term.
 */

export type FeelToday = "fresh" | "okay" | "tired";
export type FueledToday = "yes" | "somewhat" | "no";
export type PlannedIntensity = "light" | "moderate" | "hard";
export type TrainingIntensity = "light" | "moderate" | "hard";

export type ProvisionalReadinessLabel = "Good" | "Moderate" | "Caution" | "Low";

/** Fuel availability risk — used in provisional mode only. */
export type ProvisionalFuelRisk = "Low" | "Elevated" | "Unclear";

export interface ProvisionalReadinessResult {
  score: number;
  label: ProvisionalReadinessLabel;
  feelScore: number;
  fuelScore: number;
  intensityScore: number;
  message: string;
  suggestedFix: string;
}

export interface ProvisionalFuelResult {
  /** Broad self-report fuel status. Capped at "Adequate" — "High" requires real intake data. */
  fuelStatus: "Adequate" | "Low";
  /** Fuel availability risk based on self-report. NOT a glycogen measurement. */
  fuelRisk: ProvisionalFuelRisk;
  message: string;
  suggestedFix: string;
}

// ─── Readiness scoring ────────────────────────────────────────────────────────
// Subjective wellness + perceived fueling + session demand.
// Hard sessions score lower because they place higher demands on available resources —
// the same self-reported state is riskier when the planned load is greater.

const FEEL_SCORES: Record<FeelToday, number> = {
  fresh: 40,
  okay: 28,
  tired: 16,
};

const FUEL_SCORES: Record<FueledToday, number> = {
  yes: 40,
  somewhat: 25,
  no: 10,
};

const INTENSITY_SCORES: Record<PlannedIntensity, number> = {
  light: 20,
  moderate: 15,
  hard: 10,
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * When the athlete trained yesterday (especially hard), apply a small fatigue
 * penalty to acknowledge residual fatigue is plausible even if they feel "fresh".
 * Penalty is additive context rather than a physiological measurement.
 */
function yesterdayTrainingPenalty(
  trainedYesterday: boolean | null | undefined,
  intensity: TrainingIntensity | null | undefined
): number {
  if (!trainedYesterday) return 0;
  if (intensity === "hard") return -8;
  if (intensity === "moderate") return -4;
  return -2; // light
}

export function calculateProvisionalReadiness(
  feelToday: FeelToday,
  fueledToday: FueledToday,
  plannedIntensity: PlannedIntensity,
  trainedYesterday?: boolean | null,
  yesterdayTrainingIntensity?: TrainingIntensity | null
): ProvisionalReadinessResult {
  const feelScore = FEEL_SCORES[feelToday];
  const fuelScore = FUEL_SCORES[fueledToday];
  const intensityScore = INTENSITY_SCORES[plannedIntensity];
  const trainingPenalty = yesterdayTrainingPenalty(trainedYesterday, yesterdayTrainingIntensity ?? null);
  const score = Math.max(0, feelScore + fuelScore + intensityScore + trainingPenalty);

  let label: ProvisionalReadinessLabel;
  if (score >= 80) label = "Good";
  else if (score >= 65) label = "Moderate";
  else if (score >= 50) label = "Caution";
  else label = "Low";

  const feelLabel = { fresh: "Feeling fresh", okay: "Feeling okay", tired: "Feeling tired" }[feelToday];
  const fuelLabel = { yes: "well fueled", somewhat: "partially fueled", no: "under-fueled" }[fueledToday];
  const intensityLabel = { light: "light", moderate: "moderate", hard: "hard" }[plannedIntensity];

  const trainingContext = trainedYesterday
    ? ` (trained ${yesterdayTrainingIntensity ?? "yesterday"})`
    : "";
  const message = `${feelLabel}${trainingContext}, ${fuelLabel} — ${intensityLabel} session planned`;

  let suggestedFix: string;
  if (trainedYesterday && yesterdayTrainingIntensity === "hard" && plannedIntensity === "hard") {
    suggestedFix = "Back-to-back hard sessions — prioritise carb and protein recovery before training";
  } else if (feelToday === "tired" && plannedIntensity === "hard") {
    suggestedFix = "Consider reducing intensity or adding extra fuel before training";
  } else if (fueledToday === "no" && plannedIntensity !== "light") {
    suggestedFix = "Eat before training — carbs (oats, banana, rice) help restore energy";
  } else if (label === "Good") {
    suggestedFix = "You're in a good place — stick to your plan";
  } else if (label === "Moderate") {
    suggestedFix = "Train as planned and check in with your body during warm-up";
  } else if (label === "Caution") {
    suggestedFix = "Lighter intensity or extra recovery may serve you better today";
  } else {
    suggestedFix = "Consider rest or a very light session — log food and sleep for a fuller picture";
  }

  return { score, label, feelScore, fuelScore, intensityScore, message, suggestedFix };
}

export function calculateProvisionalFuel(
  fueledToday: FueledToday,
  plannedIntensity: PlannedIntensity
): ProvisionalFuelResult {
  // "yes" — athlete reports feeling well fueled
  if (fueledToday === "yes") {
    return {
      fuelStatus: "Adequate",
      fuelRisk: "Low",
      message: "Feeling fueled — fuel availability risk appears low",
      suggestedFix: plannedIntensity === "hard"
        ? "Log yesterday's food to confirm carb availability for your hard session"
        : "Log yesterday's food to get a precise fuel estimate",
    };
  }

  // "somewhat" — athlete reports partial fueling
  if (fueledToday === "somewhat") {
    if (plannedIntensity === "hard") {
      return {
        fuelStatus: "Low",
        fuelRisk: "Elevated",
        message: "Partially fueled with a hard session planned — fuel availability may be limited",
        suggestedFix: "A carb-rich snack before training (oats, banana, rice) can help top up energy levels",
      };
    }
    return {
      fuelStatus: "Adequate",
      fuelRisk: "Elevated",
      message: "Partially fueled — a light pre-session snack may help",
      suggestedFix: "A small carb snack (fruit, toast) before training can help sustain energy",
    };
  }

  // "no" — athlete reports feeling under-fueled
  if (plannedIntensity === "hard") {
    return {
      fuelStatus: "Low",
      fuelRisk: "Elevated",
      message: "Feeling under-fueled with a hard session planned — fuel availability risk is elevated",
      suggestedFix: "Eat before training: oats, banana, rice, or toast can restore fuel levels",
    };
  }

  return {
    fuelStatus: "Low",
    fuelRisk: "Elevated",
    message: "Feeling under-fueled — lighter intensity is recommended",
    suggestedFix: "Have a proper meal and log yesterday's food for a more complete fuel picture",
  };
}
