import crypto from "crypto";
import { db } from "../db";
import { emailVerificationTokens, usersAuth } from "@shared/schema";
import { eq } from "drizzle-orm";

const TOKEN_EXPIRY_HOURS = 24;

export function generateToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createVerificationToken(userId: number): Promise<string> {
  const token = generateToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

  await db.delete(emailVerificationTokens)
    .where(eq(emailVerificationTokens.userId, userId));

  await db.insert(emailVerificationTokens).values({
    userId,
    tokenHash,
    expiresAt,
  });

  return token;
}

export async function verifyToken(token: string): Promise<{ valid: boolean; userId?: number; error?: string }> {
  const tokenHash = hashToken(token);
  
  const tokenRecord = await db.query.emailVerificationTokens.findFirst({
    where: eq(emailVerificationTokens.tokenHash, tokenHash),
  });

  if (!tokenRecord) {
    return { valid: false, error: "Invalid or expired token" };
  }

  if (new Date() > tokenRecord.expiresAt) {
    await db.delete(emailVerificationTokens)
      .where(eq(emailVerificationTokens.id, tokenRecord.id));
    return { valid: false, error: "Token has expired" };
  }

  await db.update(usersAuth)
    .set({ 
      emailVerified: true, 
      emailVerifiedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(usersAuth.id, tokenRecord.userId));

  await db.delete(emailVerificationTokens)
    .where(eq(emailVerificationTokens.id, tokenRecord.id));

  return { valid: true, userId: tokenRecord.userId };
}

export async function getUserIdByEmail(email: string): Promise<number | null> {
  const user = await db.query.usersAuth.findFirst({
    where: eq(usersAuth.email, email.toLowerCase()),
  });
  return user?.id || null;
}
