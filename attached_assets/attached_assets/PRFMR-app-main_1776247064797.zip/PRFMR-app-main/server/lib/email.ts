import { Resend } from "resend";

const DEV_EMAIL_MODE = process.env.DEV_EMAIL_MODE === "log";
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const EMAIL_FROM = process.env.EMAIL_FROM || "PRFMR <team@prfmr.link>";
const REPLY_TO = process.env.EMAIL_REPLY_TO || "team@prfmr.link";
const APP_BASE_URL = process.env.APP_BASE_URL || (process.env.NODE_ENV === "production" ? "https://app.prfmr.link" : "http://localhost:5000");

const resend = RESEND_API_KEY ? new Resend(RESEND_API_KEY) : null;

function extractDomain(value: string): string | null {
  try {
    if (value.includes("@")) {
      return value.split("@").pop()?.trim().replace(/>$/, "") || null;
    }
    const url = new URL(value);
    return url.hostname.replace(/^(app|www|api)\./, "");
  } catch {
    return null;
  }
}

console.log(`[config] APP_BASE_URL=${APP_BASE_URL}`);
if (!process.env.APP_BASE_URL && process.env.NODE_ENV === "production") {
  console.warn("[config] WARNING: APP_BASE_URL is not set in production. Links in emails may be incorrect.");
}

console.log("=== EMAIL SERVICE CONFIG ===");
console.log(`DEV_EMAIL_MODE: ${process.env.DEV_EMAIL_MODE || "(not set)"}`);
console.log(`RESEND_API_KEY set: ${!!RESEND_API_KEY}`);
console.log(`EMAIL_FROM: ${EMAIL_FROM}`);
console.log(`REPLY_TO: ${REPLY_TO}`);
console.log(`APP_BASE_URL: ${APP_BASE_URL}`);

if (!process.env.EMAIL_FROM) {
  console.warn("[email] WARNING: EMAIL_FROM env var is not set. Using default fallback.");
}

const fromDomain = extractDomain(EMAIL_FROM);
const baseDomain = extractDomain(APP_BASE_URL);
if (fromDomain && baseDomain && fromDomain !== baseDomain) {
  console.warn(`[email] WARNING: EMAIL_FROM domain (${fromDomain}) does not match APP_BASE_URL domain (${baseDomain}). This may hurt deliverability.`);
}

if (DEV_EMAIL_MODE) {
  console.log("MODE: Development (emails logged to console, not sent)");
} else if (resend) {
  console.log("MODE: Production (emails will be sent via Resend)");
} else {
  console.warn("WARNING: No RESEND_API_KEY and DEV_EMAIL_MODE is not 'log' - emails will fail!");
}
console.log("============================");

export function getEmailConfig() {
  return {
    mode: DEV_EMAIL_MODE ? "dev_log" : (resend ? "resend" : "misconfigured"),
    hasResendKey: !!RESEND_API_KEY,
    emailFrom: EMAIL_FROM,
    replyTo: REPLY_TO,
    appBaseUrl: APP_BASE_URL,
    domainMatch: fromDomain === baseDomain,
  };
}

interface SendEmailOptions {
  to: string;
  subject: string;
  text: string;
  html: string;
}

export async function sendEmail(options: SendEmailOptions): Promise<{ success: boolean; error?: string }> {
  if (DEV_EMAIL_MODE) {
    console.log("=== DEV EMAIL MODE ===");
    console.log(`To: ${options.to}`);
    console.log(`Subject: ${options.subject}`);
    console.log(`Text: ${options.text}`);
    console.log("======================");
    return { success: true };
  }

  if (!resend) {
    const errorMsg = "Email service misconfigured: RESEND_API_KEY missing and DEV_EMAIL_MODE is not 'log'";
    console.error(errorMsg);
    return { success: false, error: errorMsg };
  }

  console.log(`[Email] Attempting to send email to: ${options.to}, subject: "${options.subject}"`);
  
  try {
    const { data, error } = await resend.emails.send({
      from: EMAIL_FROM,
      to: options.to,
      replyTo: REPLY_TO,
      subject: options.subject,
      text: options.text,
      html: options.html,
    });

    if (error) {
      console.error("[Email] Resend API error:", JSON.stringify(error, null, 2));
      return { success: false, error: `Resend API error: ${error.message || JSON.stringify(error)}` };
    }

    console.log(`[Email] Successfully sent email, message ID: ${data?.id || "unknown"}`);
    return { success: true };
  } catch (error: any) {
    console.error("[Email] Exception during send:", error);
    console.error("[Email] Stack trace:", error?.stack);
    return { success: false, error: `Email exception: ${error?.message || String(error)}` };
  }
}

export async function sendVerificationEmail(email: string, username: string, token: string): Promise<{ success: boolean; error?: string }> {
  const verifyUrl = `${APP_BASE_URL}/api/auth/verify-email?token=${token}`;
  
  const subject = "Verify your PRFMR email";
  const text = `Hi ${username},

Thanks for signing up for PRFMR. To get started, please verify your email address by visiting the link below:

${verifyUrl}

This link will expire in 24 hours.

If you didn't create an account with PRFMR, you can safely ignore this email.

Best,
The PRFMR Team`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 32px 20px; }
    .button { display: inline-block; background-color: #f97316; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; font-weight: 500; }
    .footer { color: #888; font-size: 13px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <h2 style="margin-top:0;">Verify your email</h2>
    <p>Hi ${username},</p>
    <p>Thanks for signing up for PRFMR. Please verify your email address by clicking the button below:</p>
    <a href="${verifyUrl}" class="button">Verify Email</a>
    <p style="font-size:13px;color:#666;">Or copy and paste this link into your browser:</p>
    <p style="word-break: break-all; font-size:13px; color:#666;">${verifyUrl}</p>
    <p>This link will expire in 24 hours.</p>
    <div class="footer">
      <p>If you didn't create an account with PRFMR, you can safely ignore this email.</p>
      <p>Best,<br>The PRFMR Team</p>
    </div>
  </div>
</body>
</html>`;

  return sendEmail({ to: email, subject, text, html });
}

export async function sendPasswordResetEmail(email: string, username: string, token: string): Promise<{ success: boolean; error?: string }> {
  const resetUrl = `${APP_BASE_URL}/reset-password?token=${token}`;
  
  const subject = "Reset your PRFMR password";
  const text = `Hi ${username},

We received a request to reset the password for your PRFMR account. You can set a new password by visiting the link below:

${resetUrl}

This link will expire in 1 hour.

If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.

Best,
The PRFMR Team`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 32px 20px; }
    .button { display: inline-block; background-color: #f97316; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; font-weight: 500; }
    .footer { color: #888; font-size: 13px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <h2 style="margin-top:0;">Reset your password</h2>
    <p>Hi ${username},</p>
    <p>We received a request to reset the password for your PRFMR account. Click the button below to set a new password:</p>
    <a href="${resetUrl}" class="button">Reset Password</a>
    <p style="font-size:13px;color:#666;">Or copy and paste this link into your browser:</p>
    <p style="word-break: break-all; font-size:13px; color:#666;">${resetUrl}</p>
    <p>This link will expire in 1 hour.</p>
    <div class="footer">
      <p>If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.</p>
      <p>Best,<br>The PRFMR Team</p>
    </div>
  </div>
</body>
</html>`;

  return sendEmail({ to: email, subject, text, html });
}

export async function sendWelcomeEmail(email: string, username: string): Promise<{ success: boolean; error?: string }> {
  const subject = "Welcome to PRFMR";
  const text = `Hi ${username},

Welcome to PRFMR! We're glad to have you on board.

Once you verify your email, you can start using the app to:

- Track your daily nutrition and macros
- Log your workouts and training
- Monitor your progress with detailed charts
- Get personalized calorie and macro targets

Ready to get started? Verify your email and complete your profile setup.

If you have any questions, just reply to this email.

Best,
The PRFMR Team`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 32px 20px; }
    h2 { color: #f97316; margin-top: 0; }
    ul { padding-left: 20px; }
    .footer { color: #888; font-size: 13px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Welcome to PRFMR</h2>
    <p>Hi ${username},</p>
    <p>We're glad to have you on board. Once you verify your email, you can start using the app to:</p>
    <ul>
      <li>Track your daily nutrition and macros</li>
      <li>Log your workouts and training</li>
      <li>Monitor your progress with detailed charts</li>
      <li>Get personalized calorie and macro targets</li>
    </ul>
    <p>Ready to get started? Verify your email and complete your profile setup.</p>
    <div class="footer">
      <p>If you have any questions, just reply to this email.</p>
      <p>Best,<br>The PRFMR Team</p>
    </div>
  </div>
</body>
</html>`;

  return sendEmail({ to: email, subject, text, html });
}

export async function sendInviteEmail(email: string, code: string, name?: string): Promise<{ success: boolean; error?: string }> {
  const signupUrl = `${APP_BASE_URL}/signup?email=${encodeURIComponent(email)}&invite=${encodeURIComponent(code)}`;
  const greeting = name && !name.includes("@") ? `Hi ${name},` : "Hi there,";
  
  const subject = "Your PRFMR invite code";
  const text = `${greeting}

You've been invited to join PRFMR, a nutrition and training tracker built for athletes.

Your personal invite code is: ${code}

You can sign up directly using this link:
${signupUrl}

This code is valid for 7 days and can only be used once.

If you have any questions, just reply to this email.

If this email landed in Spam or Junk, please mark it as "Not junk" and add team@prfmr.link to your contacts so future emails arrive correctly.

Best,
The PRFMR Team`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 32px 20px; }
    .code { display: inline-block; background-color: #f3f4f6; color: #111; font-family: monospace; font-size: 22px; letter-spacing: 3px; padding: 10px 18px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 12px 0; }
    .button { display: inline-block; background-color: #f97316; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; font-weight: 500; }
    .footer { color: #888; font-size: 13px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <h2 style="margin-top:0;">You're invited to PRFMR</h2>
    <p>${greeting}</p>
    <p>You've been invited to join PRFMR, a nutrition and training tracker built for athletes. We'd love to have you on board.</p>
    <p>Your personal invite code:</p>
    <div class="code">${code}</div>
    <p>Or click below to sign up with your code pre-filled:</p>
    <a href="${signupUrl}" class="button">Create Your Account</a>
    <p style="margin-top:20px; font-size:14px; color:#666;">
      If this email landed in Spam or Junk, please mark it as <strong>Not junk</strong> and add <strong>team@prfmr.link</strong> to your contacts so future emails arrive correctly.
    </p>
    <div class="footer">
      <p>This code is valid for 7 days and can only be used once.</p>
      <p>If you have any questions, just reply to this email.</p>
      <p>Best,<br>The PRFMR Team</p>
    </div>
  </div>
</body>
</html>`;

  return sendEmail({ to: email, subject, text, html });
}
