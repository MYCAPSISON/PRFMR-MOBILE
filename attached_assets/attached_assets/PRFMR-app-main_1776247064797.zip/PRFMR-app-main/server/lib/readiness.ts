import type { DayClassification } from "./training-load";

export interface SleepScoreResult {
  score: number;
  maxPoints: 30;
  hoursSlept: number;
  qualityAdjustment: number;
}

export function calculateSleepScore(hoursSlept: number, sleepQuality?: number | null): SleepScoreResult {
  let base: number;
  if (hoursSlept >= 8.0) base = 30;
  else if (hoursSlept >= 7.0) base = 26;
  else if (hoursSlept >= 6.0) base = 20;
  else if (hoursSlept >= 5.0) base = 14;
  else base = 8;

  let qualityAdj = 0;
  if (sleepQuality != null) {
    if (sleepQuality >= 4) qualityAdj = 2;
    else if (sleepQuality <= 2) qualityAdj = -2;
  }

  const score = Math.max(0, Math.min(30, base + qualityAdj));
  return { score, maxPoints: 30, hoursSlept, qualityAdjustment: qualityAdj };
}

export interface EnergyAvailabilityResult {
  score: number;
  maxPoints: 30;
  eaValue: number;
  eaSmoothed: number | null;
  available: boolean;
  ffmKg: number | null;
  bodyFatPctUsed: number;
}

const ASSUMED_BODY_FAT = 0.15;

/**
 * Compute energy availability using fat-free mass (FFM).
 *
 * EA = (caloriesConsumed - exerciseKcal) / FFM
 * FFM = bodyweightKg × (1 - bodyFatPct)
 *
 * If no body fat percentage is provided, assumes 15% body fat.
 * Accepts an optional smoothed EA (average of last 2–3 days) — when
 * present it is used for scoring instead of the raw single-day value.
 *
 * @param caloriesYesterday  Total kcal consumed yesterday
 * @param exerciseKcalYesterday  Total exercise kcal burned yesterday
 * @param bodyweightKg  Current bodyweight (kg)
 * @param bodyFatPct  Optional body fat fraction 0–1 (e.g. 0.18 = 18%)
 * @param smoothedEa  Optional rolling average EA (last 2–3 days)
 */
export function calculateEnergyAvailability(
  caloriesYesterday: number,
  exerciseKcalYesterday: number,
  bodyweightKg: number | null | undefined,
  bodyFatPct?: number | null,
  smoothedEa?: number | null,
): EnergyAvailabilityResult {
  if (!bodyweightKg || bodyweightKg <= 0) {
    return { score: 15, maxPoints: 30, eaValue: 0, eaSmoothed: smoothedEa ?? null, available: false, ffmKg: null, bodyFatPctUsed: ASSUMED_BODY_FAT };
  }

  const bfPct = (bodyFatPct != null && bodyFatPct > 0 && bodyFatPct < 1) ? bodyFatPct : ASSUMED_BODY_FAT;
  const ffmKg = bodyweightKg * (1 - bfPct);

  const eaValue = (caloriesYesterday - exerciseKcalYesterday) / ffmKg;
  const eaForScoring = smoothedEa ?? eaValue;

  let score: number;
  if (eaForScoring >= 40) score = 30;
  else if (eaForScoring >= 35) score = 25;
  else if (eaForScoring >= 30) score = 18;
  else if (eaForScoring >= 25) score = 10;
  else score = 5;

  return {
    score,
    maxPoints: 30,
    eaValue: Math.round(eaValue * 10) / 10,
    eaSmoothed: smoothedEa != null ? Math.round(smoothedEa * 10) / 10 : null,
    available: true,
    ffmKg: Math.round(ffmKg * 10) / 10,
    bodyFatPctUsed: bfPct,
  };
}

// ─── Carb sufficiency ─────────────────────────────────────────────────────────

/**
 * Carb target (g per kg bodyweight) keyed to the day's training load classification.
 * Derived from sport-nutrition periodisation guidelines.
 *
 *   light      → 3 g/kg  (low-demand day)
 *   moderate   → 5 g/kg  (typical training day)
 *   hard       → 6 g/kg  (hard session)
 *   very_hard  → 7 g/kg  (double-day / very high load)
 */
const CARB_TARGET_BY_DAY: Record<DayClassification, number> = {
  light: 3,
  moderate: 5,
  hard: 6,
  very_hard: 7,
};

export interface CarbSufficiencyResult {
  score: number;
  maxPoints: 25;
  carbsPerKg: number;
  carbPerKgTarget: number;
  dayClassification: DayClassification;
  pct: number;
  suggestion: string;
}

/**
 * Calculate carb sufficiency relative to a demand-driven target.
 *
 * Score = clamp(pct × 25, 0, 25) where pct = carbsYesterdayG / (carbPerKgTarget × bodyweightKg).
 * This replaces the previous fixed stepped score with a proportional model.
 *
 * @param carbsYesterdayG   Yesterday's carb intake (g)
 * @param bodyweightKg       Bodyweight (kg)
 * @param dayClassification  Today's training load classification (drives the carb target)
 */
export function calculateCarbSufficiency(
  carbsYesterdayG: number,
  bodyweightKg: number | null | undefined,
  dayClassification: DayClassification,
): CarbSufficiencyResult {
  const carbPerKgTarget = CARB_TARGET_BY_DAY[dayClassification] ?? 5;

  if (!bodyweightKg || bodyweightKg <= 0) {
    return {
      score: 12,
      maxPoints: 25,
      carbsPerKg: 0,
      carbPerKgTarget,
      dayClassification,
      pct: 0,
      suggestion: "",
    };
  }

  const carbsPerKg = carbsYesterdayG / bodyweightKg;
  const carbTarget = carbPerKgTarget * bodyweightKg;
  const pct = carbsYesterdayG / carbTarget;
  const score = Math.round(Math.min(25, Math.max(0, pct * 25)));

  let suggestion = "";
  if (pct < 0.5) {
    // Below 50% of target — always flag
    if (dayClassification === "very_hard") {
      suggestion = "High training demand — prioritise carbs before and after sessions";
    } else if (dayClassification === "hard" || dayClassification === "moderate") {
      suggestion = "Increase carbs to support training — e.g. oats, rice, fruit, bread";
    } else {
      suggestion = "You're under-fuelling slightly — consider adding carbs if training later";
    }
  } else if (pct < 0.8 && (dayClassification === "hard" || dayClassification === "very_hard")) {
    suggestion = "Carbs could be higher for this level of training demand";
  }

  return {
    score,
    maxPoints: 25,
    carbsPerKg: Math.round(carbsPerKg * 10) / 10,
    carbPerKgTarget,
    dayClassification,
    pct: Math.round(pct * 100) / 100,
    suggestion,
  };
}

export interface AmqsSufficiencyResult {
  score: number;
  maxPoints: 15;
  amqsScore: number;
}

export function calculateAmqsSufficiency(amqsScore: number): AmqsSufficiencyResult {
  let score: number;
  if (amqsScore >= 85) score = 15;
  else if (amqsScore >= 75) score = 12;
  else if (amqsScore >= 60) score = 9;
  else score = 5;

  return { score, maxPoints: 15, amqsScore };
}

export interface ReadinessComponent {
  name: string;
  score: number;
  maxPoints: number;
  detail?: string;
}

export interface SessionReadinessResult {
  total: number;
  label: "High" | "Moderate" | "Low" | "Poor" | "Provisional";
  primaryLimiter: string;
  suggestedFix: string;
  components: ReadinessComponent[];
  incomplete: boolean;
  provisional: boolean;
  missingData: string[];
  crossSignal: string | null;
}

export interface ReadinessOptions {
  hasSleepData: boolean;
  hasYesterdayFood: boolean;
  hasYesterdayTraining: boolean;
  bodyweightSource: "today" | "recent" | "profile" | null;
  bodyweightKg: number | null;
}

export function calculateSessionReadiness(
  sleep: SleepScoreResult | null,
  energy: EnergyAvailabilityResult,
  carbs: CarbSufficiencyResult,
  amqs: AmqsSufficiencyResult,
  opts?: ReadinessOptions
): SessionReadinessResult {
  const sleepScore = sleep?.score ?? 0;
  const sleepMax = 30;

  const components: ReadinessComponent[] = [
    {
      name: "Sleep",
      score: sleepScore,
      maxPoints: sleepMax,
      detail: sleep ? `${sleep.hoursSlept}h` : "Not logged",
    },
    {
      name: "Energy Availability",
      score: energy.score,
      maxPoints: energy.maxPoints,
      detail: energy.available
        ? `${energy.eaSmoothed ?? energy.eaValue} kcal/kg FFM${energy.eaSmoothed != null ? " (3-day avg)" : ""}`
        : "Weight not set",
    },
    {
      name: "Carbs",
      score: carbs.score,
      maxPoints: carbs.maxPoints,
      detail: `${carbs.carbsPerKg} g/kg (target ${carbs.carbPerKgTarget}, ${Math.round(carbs.pct * 100)}%)`,
    },
    {
      name: "AMQS",
      score: amqs.score,
      maxPoints: amqs.maxPoints,
      detail: `Score ${amqs.amqsScore}`,
    },
  ];

  const total = sleepScore + energy.score + carbs.score + amqs.score;

  const missingData: string[] = [];
  if (opts) {
    if (!opts.hasSleepData) missingData.push("sleep");
    if (!opts.hasYesterdayFood) missingData.push("yesterday's food");
    if (!opts.hasYesterdayTraining) missingData.push("yesterday's training");
  } else {
    if (!sleep) missingData.push("sleep");
  }

  const isProvisional = missingData.length > 0;

  let label: SessionReadinessResult["label"];
  if (isProvisional) {
    label = "Provisional";
  } else if (total >= 85) {
    label = "High";
  } else if (total >= 70) {
    label = "Moderate";
  } else if (total >= 55) {
    label = "Low";
  } else {
    label = "Poor";
  }

  const lowestPct = components.map((c) => ({
    name: c.name,
    pct: c.maxPoints > 0 ? c.score / c.maxPoints : 1,
    score: c.score,
    maxPoints: c.maxPoints,
  }));
  lowestPct.sort((a, b) => a.pct - b.pct);
  const limiter = lowestPct[0];

  let primaryLimiter = `Low ${limiter.name.toLowerCase()}`;
  let suggestedFix = "";

  if (isProvisional) {
    primaryLimiter = "Incomplete data";
    const missing = missingData.join(", ");
    suggestedFix = `Log ${missing} for a complete readiness score`;
  } else {
    switch (limiter.name) {
      case "Sleep":
        primaryLimiter = sleep ? "Poor sleep last night" : "Sleep not logged";
        suggestedFix = sleep
          ? "Prioritize 7-8h sleep tonight"
          : "Log last night's sleep for a complete score";
        break;
      case "Energy Availability": {
        const currentEa = energy.eaSmoothed ?? energy.eaValue;
        if (!energy.available) {
          primaryLimiter = "Bodyweight not set";
          suggestedFix = "Set your bodyweight in profile for accurate scoring";
        } else if (currentEa < 30) {
          primaryLimiter = "Low energy availability";
          suggestedFix = `Increase intake to stay above 30 kcal/kg FFM (currently ${currentEa})`;
        } else if (currentEa < 40) {
          primaryLimiter = "Energy availability could be higher";
          suggestedFix = `Above minimum threshold; higher intake may support performance (currently ${currentEa})`;
        } else {
          primaryLimiter = "Energy availability supports performance";
          suggestedFix = `Energy availability is in a good range (currently ${currentEa})`;
        }
        break;
      }
      case "Carbs":
        primaryLimiter = "Low carbohydrate availability";
        suggestedFix = carbs.suggestion
          ? carbs.suggestion
          : carbs.pct > 0
          ? `+${Math.round((carbs.carbPerKgTarget - carbs.carbsPerKg) * (opts?.bodyweightKg || 75))}g carbs — e.g. bagel + jam, banana + oats, or rice + honey`
          : "Log yesterday's food for a complete carb score";
        break;
      case "AMQS":
        primaryLimiter = "Low micronutrient coverage";
        suggestedFix = "Add nutrient-dense foods (leafy greens, fruit, nuts)";
        break;
    }
  }

  // ─── Cross-signal integration ──────────────────────────────────────────────
  let crossSignal: string | null = null;
  if (!isProvisional && energy.available) {
    const eaLow = energy.score <= 12;
    const carbsLow = carbs.score <= 12;
    if (eaLow && carbsLow) {
      crossSignal = "Under-fuelled — both energy and carb availability are low";
    } else if (!eaLow && carbsLow) {
      crossSignal = "Performance may suffer — energy is adequate but carbs are low for training";
    } else if (eaLow && !carbsLow) {
      crossSignal = "Energy deficit despite adequate carbs — check overall calorie intake";
    }
  }

  return {
    total,
    label,
    primaryLimiter,
    suggestedFix,
    components,
    incomplete: !sleep,
    provisional: isProvisional,
    missingData,
    crossSignal,
  };
}
