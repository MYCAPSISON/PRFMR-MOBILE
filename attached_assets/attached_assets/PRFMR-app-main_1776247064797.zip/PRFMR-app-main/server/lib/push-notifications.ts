import webpush from "web-push";
import { db } from "../db";
import { pushSubscriptions } from "@shared/schema";
import { eq } from "drizzle-orm";

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:noreply@prfmr.com";

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
  console.log("[push] VAPID keys configured");
} else {
  console.warn("[push] VAPID keys not configured - push notifications disabled");
}

export function getVapidPublicKey(): string | null {
  return VAPID_PUBLIC_KEY || null;
}

export function isPushEnabled(): boolean {
  return !!(VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY);
}

interface SubscriptionKeys {
  p256dh: string;
  auth: string;
}

interface PushSubscriptionData {
  endpoint: string;
  keys: SubscriptionKeys;
}

export async function saveSubscription(userId: number, subscription: PushSubscriptionData): Promise<void> {
  await db.delete(pushSubscriptions)
    .where(eq(pushSubscriptions.endpoint, subscription.endpoint));

  await db.insert(pushSubscriptions).values({
    userId,
    endpoint: subscription.endpoint,
    p256dh: subscription.keys.p256dh,
    auth: subscription.keys.auth,
  });
  
  console.log(`[push] Subscription saved for userId=${userId}`);
}

export async function removeSubscription(endpoint: string): Promise<void> {
  await db.delete(pushSubscriptions)
    .where(eq(pushSubscriptions.endpoint, endpoint));
  
  console.log(`[push] Subscription removed for endpoint`);
}

export async function getUserSubscriptions(userId: number) {
  return db.select().from(pushSubscriptions)
    .where(eq(pushSubscriptions.userId, userId));
}

interface NotificationPayload {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  data?: Record<string, any>;
}

export async function sendPushToUser(userId: number, payload: NotificationPayload): Promise<{ sent: number; failed: number }> {
  if (!isPushEnabled()) {
    console.warn("[push] Cannot send - VAPID keys not configured");
    return { sent: 0, failed: 0 };
  }

  const subscriptions = await getUserSubscriptions(userId);
  let sent = 0;
  let failed = 0;

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth,
          },
        },
        JSON.stringify(payload)
      );
      sent++;
      console.log(`[push] Notification sent to userId=${userId}`);
    } catch (error: any) {
      failed++;
      console.error(`[push] Failed to send notification:`, error.message);
      
      if (error.statusCode === 404 || error.statusCode === 410) {
        await removeSubscription(sub.endpoint);
      }
    }
  }

  return { sent, failed };
}
