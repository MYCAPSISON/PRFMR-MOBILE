import { IStorage } from "../storage";
import { getDailyMicros, MicroTotals, getIngredients, isCompositeFoodEntry } from "./micros";
import { getMicronutrientValue } from "@shared/utils";

interface UserProfile {
  sex: "male" | "female";
  age: number;
  diet: "omnivore" | "vegan";
}

const DEFAULT_PROFILE: UserProfile = {
  sex: "male",
  age: 25,
  diet: "omnivore",
};

interface NutrientDef {
  key: string;
  displayName: string;
  unit: string;
  weight: number;
  // Layer 1 target — baseline adequacy (UK/DRI-style population reference)
  getTarget: (profile: UserProfile) => number;
  // Layer 2 target — athlete optimization target. Falls back to Layer 1 if not set.
  getL2Target?: (profile: UserProfile) => number;
}

// ===========================================================================
// LAYER 1 = Baseline adequacy (UK/DRI-style reference nutrient intakes)
// LAYER 2 = Athlete optimization targets (stricter, sport-nutrition informed)
//
// See docs/amqs_athlete_refinement.md for full source rationale.
// ===========================================================================

const NUTRIENTS: NutrientDef[] = [
  // --- HIGH PRIORITY (athlete-critical) ---
  {
    key: "iron_mg",
    displayName: "Iron",
    unit: "mg",
    weight: 2.0,
    getTarget: (p) => (p.sex === "female" ? 14.8 : 8.7),
    getL2Target: (p) => (p.sex === "female" ? 14.8 : 8.7), // individualized — keep same
  },
  {
    key: "calcium_mg",
    displayName: "Calcium",
    unit: "mg",
    weight: 2.0,
    getTarget: () => 700,
    getL2Target: () => 1000,
  },
  {
    key: "vitamin_d_ug",
    displayName: "Vitamin D",
    unit: "µg",
    weight: 2.0,
    getTarget: () => 10,
    getL2Target: () => 25, // athletes often need more; 1000 IU
  },
  {
    key: "magnesium_mg",
    displayName: "Magnesium",
    unit: "mg",
    weight: 1.5,
    getTarget: (p) => (p.sex === "female" ? 270 : 300),
    getL2Target: (p) => (p.sex === "female" ? 350 : 400),
  },
  {
    key: "zinc_mg",
    displayName: "Zinc",
    unit: "mg",
    weight: 1.5,
    getTarget: (p) => (p.sex === "female" ? 7.0 : 9.5),
    getL2Target: (p) => (p.sex === "female" ? 9 : 12),
  },

  // --- MODERATE PRIORITY ---
  {
    key: "iodine_ug",
    displayName: "Iodine",
    unit: "µg",
    weight: 1.0,
    getTarget: () => 140,
    getL2Target: () => 150,
  },
  {
    key: "selenium_ug",
    displayName: "Selenium",
    unit: "µg",
    weight: 1.0,
    getTarget: (p) => (p.sex === "female" ? 60 : 75),
    getL2Target: (p) => (p.sex === "female" ? 60 : 75), // aligned with L1 — no stronger athlete target; L2 must not be easier
  },
  {
    key: "folate_ug",
    displayName: "Folate",
    unit: "µg",
    weight: 1.0,
    getTarget: () => 200,
    getL2Target: () => 400,
  },
  {
    key: "vitamin_b12_ug",
    displayName: "Vitamin B12",
    unit: "µg",
    weight: 1.0,
    getTarget: () => 1.5,
    getL2Target: () => 2.4,
  },
  {
    key: "vitamin_c_mg",
    displayName: "Vitamin C",
    unit: "mg",
    weight: 1.0,
    getTarget: () => 40,
    getL2Target: (p) => (p.sex === "female" ? 100 : 120),
  },
  {
    key: "vitamin_a_ug",
    displayName: "Vitamin A",
    unit: "µg",
    weight: 1.0,
    getTarget: (p) => (p.sex === "female" ? 600 : 700),
    getL2Target: (p) => (p.sex === "female" ? 700 : 900),
  },
  {
    key: "potassium_mg",
    displayName: "Potassium",
    unit: "mg",
    weight: 1.0,
    getTarget: () => 3500,
    getL2Target: (p) => (p.sex === "female" ? 3500 : 4000),
  },

  // --- B VITAMINS (Layer 2 additions; moderate weight) ---
  {
    key: "vitamin_b1_mg",
    displayName: "Vitamin B1",
    unit: "mg",
    weight: 0.75,
    getTarget: (p) => (p.sex === "female" ? 1.1 : 1.2),
    getL2Target: () => 1.4,
  },
  {
    key: "vitamin_b2_mg",
    displayName: "Vitamin B2",
    unit: "mg",
    weight: 0.75,
    getTarget: (p) => (p.sex === "female" ? 1.1 : 1.3),
    getL2Target: () => 1.5,
  },
  {
    key: "vitamin_b3_mg",
    displayName: "Vitamin B3",
    unit: "mg",
    weight: 0.75,
    getTarget: (p) => (p.sex === "female" ? 14 : 16),
    getL2Target: () => 18,
  },
  {
    key: "vitamin_b6_mg",
    displayName: "Vitamin B6",
    unit: "mg",
    weight: 0.75,
    getTarget: () => 1.3,
    getL2Target: () => 1.6,
  },

  // --- OMEGA-3 (important for athlete recovery) ---
  {
    key: "omega3_g",
    displayName: "Omega-3",
    unit: "g",
    weight: 1.0,
    getTarget: (p) => (p.sex === "female" ? 1.1 : 1.6),
    getL2Target: () => 2.0,
  },
];

// Critical nutrients that must not be clearly below Layer-1 target for Elite tier
const CRITICAL_NUTRIENT_KEYS = ["iron_mg", "calcium_mg", "vitamin_d_ug", "magnesium_mg", "zinc_mg"];
// Below this % of Layer-1 target = "clearly below" → blocks Elite
const CRITICAL_FLOOR_PCT = 70;

function getTier(score: number): "Basic" | "Fair" | "Good" | "Optimal" | "Elite" {
  if (score >= 95) return "Elite";
  if (score >= 85) return "Optimal";
  if (score >= 70) return "Good";
  if (score >= 50) return "Fair";
  return "Basic";
}

// Apply critical nutrient floor: if any critical nutrient is clearly below its
// Layer-1 target, the tier cannot exceed Optimal regardless of the raw score.
function applyTierFloor(
  rawTier: "Basic" | "Fair" | "Good" | "Optimal" | "Elite",
  coverage: Record<string, { pctOfTarget: number; status: string }>
): "Basic" | "Fair" | "Good" | "Optimal" | "Elite" {
  if (rawTier !== "Elite") return rawTier;
  for (const key of CRITICAL_NUTRIENT_KEYS) {
    const item = coverage[key];
    if (item && item.pctOfTarget < CRITICAL_FLOOR_PCT) {
      return "Optimal"; // cap at Optimal
    }
  }
  return "Elite";
}

export interface CoverageItem {
  pctOfTarget: number;
  status: "low" | "ok" | "high";
}

export interface TopGap {
  microKey: string;
  label: string;
  pctOfTarget: number;
  suggestion?: string;
}

export interface CoverageStats {
  totalFoodEntries: number;
  foodEntriesWithMicros: number;
  totalTakenSupplements: number;
  takenSupplementsWithMicros: number;
  overallCoverage: number;
}

export interface AMQSScoreResult {
  date: string;
  // Layer 1 — baseline adequacy
  score: number;
  tier: "Basic" | "Fair" | "Good" | "Optimal" | "Elite";
  confidence: "Low" | "Medium" | "High";
  coverageStats: CoverageStats;
  totals: MicroTotals;
  targets: MicroTotals;
  coverage: Record<string, CoverageItem>;
  topGaps: TopGap[];
  allMet: boolean; // true when all Layer-1 targets are ≥100% — Layer 1 complete
  breakdown: {
    food: MicroTotals;
    supplements: MicroTotals;
  };
  // Layer 2 — athlete optimization
  layer2Score: number;
  layer2Tier: "Basic" | "Fair" | "Good" | "Optimal" | "Elite";
  layer2Targets: MicroTotals;
  layer2Coverage: Record<string, CoverageItem>;
  layer2TopGaps: TopGap[];
}

function getUserProfile(user: any): UserProfile {
  return {
    sex: user?.gender === "female" ? "female" : "male",
    age: user?.age || 25,
    diet: "omnivore",
  };
}

export async function computeAMQSScore(
  storage: IStorage,
  userId: number,
  date: string,
  user?: any
): Promise<AMQSScoreResult> {
  const micros = await getDailyMicros(storage, userId, date);
  const profile = getUserProfile(user);
  const ingredients = getIngredients();

  // Get food entries and supplement intakes for coverage calculation
  const foodEntries = await storage.getFoodEntries(userId, date);
  const intakes = await storage.getSupplementIntakes(userId, date);
  const takenSupplements = intakes.filter((i) => i.taken);
  const supplements = await storage.getSupplements(userId);
  const catalog = await storage.getSupplementCatalog();

  // Calculate coverage-based confidence
  let foodEntriesWithMicros = 0;
  for (const entry of foodEntries) {
    if (isCompositeFoodEntry(entry.name)) {
      foodEntriesWithMicros++;
      continue;
    }

    let matchedIngredient = null;

    if (
      entry.sourceType === "off" &&
      entry.microSource === "ingredient" &&
      typeof entry.ingredientIndex === "number" &&
      entry.ingredientIndex >= 0 &&
      entry.ingredientIndex < ingredients.length
    ) {
      matchedIngredient = ingredients[entry.ingredientIndex];
    } else if (entry.sourceType !== "off") {
      matchedIngredient = ingredients.find(
        (i) => i.name.toLowerCase().trim() === entry.name.toLowerCase().trim()
      );
    }

    if (matchedIngredient) {
      let hasAnyMicro = false;
      for (const n of NUTRIENTS) {
        const val = getMicronutrientValue(matchedIngredient, `${n.key}_per_100g`);
        if (val !== null && val > 0) {
          hasAnyMicro = true;
          break;
        }
      }
      if (hasAnyMicro) foodEntriesWithMicros++;
    }
  }

  let takenSupplementsWithMicros = 0;
  for (const intake of takenSupplements) {
    const supplement = supplements.find((s) => s.id === intake.supplementId);
    if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
    const catalogItem = catalog.find((c) => c.id === supplement.catalogId);
    if (!catalogItem || !catalogItem.microsPerUnit) continue;
    const microsData = catalogItem.microsPerUnit as Record<string, number> | null;
    if (microsData && typeof microsData === "object" && Object.keys(microsData).length > 0) {
      takenSupplementsWithMicros++;
    }
  }

  const totalFoodEntries = foodEntries.length;
  const totalTakenSupplements = takenSupplements.length;
  const totalItems = totalFoodEntries + totalTakenSupplements;
  const itemsWithMicros = foodEntriesWithMicros + takenSupplementsWithMicros;
  const overallCoverage = totalItems === 0 ? 0 : itemsWithMicros / totalItems;

  let confidence: "Low" | "Medium" | "High" = "Low";
  if (totalItems === 0) {
    confidence = "Low";
  } else if (overallCoverage >= 0.75) {
    confidence = "High";
  } else if (overallCoverage >= 0.4) {
    confidence = "Medium";
  } else {
    confidence = "Low";
  }

  const coverageStats: CoverageStats = {
    totalFoodEntries,
    foodEntriesWithMicros,
    totalTakenSupplements,
    takenSupplementsWithMicros,
    overallCoverage: Math.round(overallCoverage * 100) / 100,
  };

  // -------------------------------------------------------------------------
  // LAYER 1 — baseline adequacy scoring
  // -------------------------------------------------------------------------
  const targets: MicroTotals = {};
  const coverage: Record<string, CoverageItem> = {};
  let sumWeightAdequacy = 0;
  let sumWeight = 0;

  const gapData: { key: string; displayName: string; pct: number; suggestion: string }[] = [];

  for (const n of NUTRIENTS) {
    const target = n.getTarget(profile);
    targets[n.key] = target;

    const intake = micros.totals[n.key] || 0;
    const rawPct = target > 0 ? (intake / target) * 100 : 0;
    // Cap displayed percentage at 100 so it matches the capped adequacy used in scoring.
    // Status "high" is still derived from the uncapped raw value.
    const pctOfTarget = Math.round(Math.min(rawPct, 100));
    const adequacy = Math.min(intake / target, 1.0);

    let status: "low" | "ok" | "high" = "ok";
    if (rawPct < 50) status = "low";
    else if (rawPct > 150) status = "high";

    coverage[n.key] = { pctOfTarget, status };

    let weight = n.weight;
    if (n.key === "vitamin_b12_ug" && profile.diet === "vegan") weight = 2.0;
    if (n.key === "iron_mg" && profile.sex === "female") weight = 2.5;

    sumWeightAdequacy += weight * adequacy;
    sumWeight += weight;

    const microKey = `${n.key}_per_100g`;
    const candidates = [...ingredients]
      .filter((ing) => {
        const val = getMicronutrientValue(ing, microKey) || 0;
        return val > 0;
      })
      .map((ing) => {
        const potency = getMicronutrientValue(ing, microKey) || 0;
        const common = (ing as any).commonScore ?? 0.5;
        return { name: ing.name, potency, common, score: potency * 0.6 + potency * common * 0.4 };
      })
      .sort((a, b) => b.score - a.score);

    const bestCommon = candidates.find((c) => c.common >= 0.5);
    const bestFood = bestCommon || candidates[0];

    gapData.push({
      key: n.key,
      displayName: n.displayName,
      pct: pctOfTarget,
      suggestion: bestFood?.name || "N/A",
    });
  }

  const rawScore = sumWeight === 0 ? 0 : Math.round((100 * sumWeightAdequacy) / sumWeight);

  const underTarget = gapData.filter((g) => g.pct < 100);
  const displayGaps = underTarget.sort((a, b) => a.pct - b.pct).slice(0, 3);
  const allMet = underTarget.length === 0;

  const topGaps: TopGap[] = displayGaps.map((g) => ({
    microKey: g.key,
    label: g.displayName,
    pctOfTarget: g.pct,
    suggestion: g.suggestion,
  }));

  // Apply critical nutrient floor (blocks Elite if critical nutrients < 70% of L1 target)
  const rawTier = getTier(rawScore);
  const tier = applyTierFloor(rawTier, coverage);
  const score = rawScore;

  // -------------------------------------------------------------------------
  // LAYER 2 — athlete optimization scoring (stricter targets)
  // -------------------------------------------------------------------------
  const layer2Targets: MicroTotals = {};
  const layer2Coverage: Record<string, CoverageItem> = {};
  let l2SumWeightAdequacy = 0;
  let l2SumWeight = 0;

  const l2GapData: { key: string; displayName: string; pct: number; suggestion: string }[] = [];

  for (const n of NUTRIENTS) {
    const l2Target = n.getL2Target ? n.getL2Target(profile) : n.getTarget(profile);
    layer2Targets[n.key] = l2Target;

    const intake = micros.totals[n.key] || 0;
    const rawPctL2 = l2Target > 0 ? (intake / l2Target) * 100 : 0;
    const pctOfL2 = Math.round(Math.min(rawPctL2, 100));
    const l2Adequacy = Math.min(intake / l2Target, 1.0);

    let l2Status: "low" | "ok" | "high" = "ok";
    if (rawPctL2 < 50) l2Status = "low";
    else if (rawPctL2 > 150) l2Status = "high";

    layer2Coverage[n.key] = { pctOfTarget: pctOfL2, status: l2Status };

    let weight = n.weight;
    if (n.key === "vitamin_b12_ug" && profile.diet === "vegan") weight = 2.0;
    if (n.key === "iron_mg" && profile.sex === "female") weight = 2.5;

    l2SumWeightAdequacy += weight * l2Adequacy;
    l2SumWeight += weight;

    // Use same suggestion engine as Layer 1
    const microKey = `${n.key}_per_100g`;
    const candidates = [...ingredients]
      .filter((ing) => (getMicronutrientValue(ing, microKey) || 0) > 0)
      .map((ing) => {
        const potency = getMicronutrientValue(ing, microKey) || 0;
        const common = (ing as any).commonScore ?? 0.5;
        return { name: ing.name, potency, common, score: potency * 0.6 + potency * common * 0.4 };
      })
      .sort((a, b) => b.score - a.score);

    const bestFood = candidates.find((c) => c.common >= 0.5) || candidates[0];

    l2GapData.push({
      key: n.key,
      displayName: n.displayName,
      pct: pctOfL2,
      suggestion: bestFood?.name || "N/A",
    });
  }

  const layer2RawScore =
    l2SumWeight === 0 ? 0 : Math.round((100 * l2SumWeightAdequacy) / l2SumWeight);
  // The critical floor always checks against Layer-1 coverage (baseline targets),
  // consistent with the comment on applyTierFloor: "clearly below its Layer-1 target".
  const layer2Tier = applyTierFloor(getTier(layer2RawScore), coverage);
  const layer2Score = layer2RawScore;

  const l2UnderTarget = l2GapData.filter((g) => g.pct < 100);
  const layer2TopGaps: TopGap[] = l2UnderTarget
    .sort((a, b) => a.pct - b.pct)
    .slice(0, 3)
    .map((g) => ({
      microKey: g.key,
      label: g.displayName,
      pctOfTarget: g.pct,
      suggestion: g.suggestion,
    }));

  return {
    date,
    score,
    tier,
    confidence,
    coverageStats,
    totals: micros.totals,
    targets,
    coverage,
    topGaps,
    allMet,
    breakdown: micros.breakdown,
    layer2Score,
    layer2Tier,
    layer2Targets,
    layer2Coverage,
    layer2TopGaps,
  };
}

export interface WeeklyAMQSResult {
  startDate: string;
  endDate: string;
  averageScore: number;
  tier: "Basic" | "Fair" | "Good" | "Optimal" | "Elite";
  dailyScores: { date: string; score: number; tier: string }[];
}

export async function computeWeeklyAMQS(
  storage: IStorage,
  userId: number,
  startDate: string,
  endDate: string,
  user?: any
): Promise<WeeklyAMQSResult> {
  const dates: string[] = [];
  const start = new Date(startDate);
  const end = new Date(endDate);
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    dates.push(d.toISOString().split("T")[0]);
  }

  const dailyScores: { date: string; score: number; tier: string }[] = [];
  let totalScore = 0;

  for (const date of dates) {
    const result = await computeAMQSScore(storage, userId, date, user);
    dailyScores.push({ date, score: result.score, tier: result.tier });
    totalScore += result.score;
  }

  const averageScore = dates.length > 0 ? Math.round(totalScore / dates.length) : 0;

  return {
    startDate,
    endDate,
    averageScore,
    tier: getTier(averageScore),
    dailyScores,
  };
}

// ---------------------------------------------------------------------------
// AMQS WEEKLY TREND — compares current 7 days vs previous 7 days for both layers
// ---------------------------------------------------------------------------

export interface AMQSTrendResult {
  layer1: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
  layer2: {
    currentWeekAvg: number;
    prevWeekAvg: number;
    delta: number;
    trend: "improving" | "steady" | "slightly_down";
    dailyScores: { date: string; score: number }[];
  };
}

// Threshold: ≥ +3 = improving, ≤ -3 = slightly_down, otherwise steady
const TREND_THRESHOLD = 3;

function classifyTrend(delta: number): "improving" | "steady" | "slightly_down" {
  if (delta >= TREND_THRESHOLD) return "improving";
  if (delta <= -TREND_THRESHOLD) return "slightly_down";
  return "steady";
}

export async function computeAMQSTrend(
  storage: IStorage,
  userId: number,
  asOfDate: string,
  user?: any
): Promise<AMQSTrendResult> {
  // Build 14 date strings: [oldest=-13 days, ..., newest=asOfDate]
  const as = new Date(asOfDate);
  const dates14: string[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(as);
    d.setDate(d.getDate() - i);
    dates14.push(d.toISOString().split("T")[0]);
  }

  // Compute AMQS for all 14 days
  const allScores: { date: string; l1: number; l2: number }[] = [];
  for (const date of dates14) {
    const result = await computeAMQSScore(storage, userId, date, user);
    allScores.push({ date, l1: result.score, l2: result.layer2Score });
  }

  // Split: previous 7 (indices 0-6) and current 7 (indices 7-13)
  const prevWeek = allScores.slice(0, 7);
  const currentWeek = allScores.slice(7);

  function avg(vals: number[]) {
    return vals.length === 0 ? 0 : Math.round(vals.reduce((s, v) => s + v, 0) / vals.length);
  }

  const l1Cur = avg(currentWeek.map((s) => s.l1));
  const l1Prev = avg(prevWeek.map((s) => s.l1));
  const l1Delta = l1Cur - l1Prev;

  const l2Cur = avg(currentWeek.map((s) => s.l2));
  const l2Prev = avg(prevWeek.map((s) => s.l2));
  const l2Delta = l2Cur - l2Prev;

  return {
    layer1: {
      currentWeekAvg: l1Cur,
      prevWeekAvg: l1Prev,
      delta: l1Delta,
      trend: classifyTrend(l1Delta),
      dailyScores: currentWeek.map((s) => ({ date: s.date, score: s.l1 })),
    },
    layer2: {
      currentWeekAvg: l2Cur,
      prevWeekAvg: l2Prev,
      delta: l2Delta,
      trend: classifyTrend(l2Delta),
      dailyScores: currentWeek.map((s) => ({ date: s.date, score: s.l2 })),
    },
  };
}
