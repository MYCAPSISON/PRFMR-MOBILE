import crypto from "crypto";
import { db } from "../db";
import { passwordResetTokens, usersAuth } from "@shared/schema";
import { eq, and, isNull, gt } from "drizzle-orm";

const TOKEN_EXPIRY_HOURS = 1;

export function generateToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createPasswordResetToken(userId: number): Promise<string> {
  const token = generateToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

  await db.insert(passwordResetTokens).values({
    userId,
    tokenHash,
    expiresAt,
  });

  console.log(`[auth][password-reset] Token created for userId: ${userId}, expires: ${expiresAt.toISOString()}`);

  return token;
}

export async function verifyPasswordResetToken(token: string): Promise<{ 
  valid: boolean; 
  userId?: number; 
  tokenId?: number;
  error?: string 
}> {
  const tokenHash = hashToken(token);
  
  const tokenRecord = await db.query.passwordResetTokens.findFirst({
    where: and(
      eq(passwordResetTokens.tokenHash, tokenHash),
      isNull(passwordResetTokens.usedAt),
      gt(passwordResetTokens.expiresAt, new Date())
    ),
  });

  if (!tokenRecord) {
    console.log(`[auth][password-reset] Token validation failed: invalid, used, or expired`);
    return { valid: false, error: "Invalid or expired reset link" };
  }

  console.log(`[auth][password-reset] Token validated for userId: ${tokenRecord.userId}`);
  return { valid: true, userId: tokenRecord.userId, tokenId: tokenRecord.id };
}

export async function invalidatePasswordResetToken(tokenId: number): Promise<void> {
  await db.update(passwordResetTokens)
    .set({ usedAt: new Date() })
    .where(eq(passwordResetTokens.id, tokenId));
  
  console.log(`[auth][password-reset] Token ${tokenId} marked as used`);
}

export async function getUserByEmail(email: string): Promise<{ id: number; username: string } | null> {
  const user = await db.query.usersAuth.findFirst({
    where: eq(usersAuth.email, email.toLowerCase()),
  });
  return user ? { id: user.id, username: user.username } : null;
}
