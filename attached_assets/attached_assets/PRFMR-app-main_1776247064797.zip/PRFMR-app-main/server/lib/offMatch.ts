import type { MatchConfidence, MatchMethod } from "../../shared/schema";

interface Ingredient {
  name: string;
  calories_per_100g: number;
  protein_g_per_100g: number;
  carbs_g_per_100g: number;
  fat_g_per_100g: number;
  fibre_g_per_100g: number;
  [key: string]: any;
}

interface MatchCandidate {
  ingredientIndex: number;
  ingredientName: string;
  confidence: MatchConfidence;
  method: MatchMethod;
  score: number;
  reasons?: string[];
}

interface MatchResult {
  bestCandidate: MatchCandidate | null;
  topCandidates: MatchCandidate[];
}

const STOP_WORDS = new Set([
  "tesco", "asda", "aldi", "lidl", "sainsbury", "morrisons", "waitrose", "coop", "marks", "spencer", "m&s",
  "ltd", "limited", "inc", "co", "uk", "pack", "packs", "x",
  "original", "new", "classic", "bio", "100%", "the", "a", "an",
  "mini", "large", "small", "medium", "regular",
  "british", "scottish", "english", "irish", "french", "italian", "spanish", "german",
  "premium", "finest", "value", "essential", "everyday", "best", "simply", "just",
  "light", "low", "fat", "free", "fresh", "natural", "organic",
]);

const PROCESSED_SIGNALS = [
  "ready meal", "prepared", "pre-made", "snack", "dessert", "beverage", "drink",
  "protein bar", "energy bar", "cereal bar", "sauce", "confectionery", "candy", "sweets",
  "chips", "crisps", "biscuit", "cookie", "cake", "ice cream", "frozen meal",
  "pizza", "burger", "nugget", "sausage roll", "pasty", "pie", "ready to eat",
  "instant", "microwave", "heat and serve",
];

const KEY_TOKENS = new Set([
  "liver", "breast", "thigh", "wing", "drumstick", "heart", "gizzard", 
  "kidney", "fillet", "mince", "leg", "steak", "chop", "loin", "rib",
  "shoulder", "belly", "neck", "offal", "tongue", "brain"
]);

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  dairy: ["milk", "cheese", "yogurt", "yoghurt", "cream", "butter", "kefir", "quark", "curd", "whey", "cottage", "ricotta", "mozzarella", "cheddar", "brie", "camembert", "parmesan", "gouda", "edam", "feta", "halloumi", "mascarpone"],
  meat: ["chicken", "beef", "pork", "lamb", "turkey", "duck", "venison", "veal", "goat", "rabbit", "liver", "mince", "steak", "breast", "thigh", "sausage", "bacon", "ham", "salami", "chorizo", "pepperoni"],
  fish: ["salmon", "tuna", "cod", "haddock", "mackerel", "trout", "sardine", "prawn", "shrimp", "crab", "lobster", "mussel", "oyster", "anchovy", "herring", "bass", "bream", "plaice", "sole", "halibut", "pollock", "tilapia"],
  grain: ["oats", "rice", "wheat", "bread", "pasta", "noodle", "flour", "cereal", "quinoa", "couscous", "barley", "rye", "corn", "maize", "bulgur", "millet", "buckwheat", "wrap", "tortilla", "bagel", "crumpet"],
  fruit: ["apple", "banana", "orange", "strawberry", "blueberry", "raspberry", "grape", "mango", "pineapple", "peach", "pear", "plum", "cherry", "melon", "watermelon", "kiwi", "avocado", "fig", "date", "lemon", "lime"],
  vegetable: ["potato", "carrot", "broccoli", "spinach", "kale", "pepper", "tomato", "onion", "garlic", "mushroom", "courgette", "zucchini", "aubergine", "eggplant", "cabbage", "cauliflower", "pea", "bean", "lentil", "sweetcorn", "beetroot", "celery", "cucumber", "lettuce"],
  nut: ["almond", "walnut", "cashew", "peanut", "pistachio", "pecan", "hazelnut", "macadamia", "brazil", "nut butter", "peanut butter", "almond butter"],
  supplement: ["whey", "isolate", "casein", "mass gainer", "protein powder", "bcaa", "creatine", "pre workout", "post workout", "recovery"],
  egg: ["egg", "eggs", "omelette", "omelet", "scrambled", "poached", "boiled"],
  oil: ["oil", "olive", "coconut", "sunflower", "rapeseed", "sesame", "vegetable oil"],
};

const SUPPLEMENT_SIGNALS = ["whey", "isolate", "mass gainer", "protein powder", "bcaa", "creatine", "casein", "pre workout", "post workout"];

function extractKeyTokens(str: string): Set<string> {
  const normalized = str.toLowerCase();
  const tokens = normalized.split(/[\s\-_()\/,]+/).filter(w => w.length > 0);
  const found = new Set<string>();
  for (const token of tokens) {
    if (KEY_TOKENS.has(token)) {
      found.add(token);
    }
  }
  return found;
}

function keyTokenPenalty(offName: string, candidateName: string): number {
  const offKeys = extractKeyTokens(offName);
  const candKeys = extractKeyTokens(candidateName);
  const offKeysArr = Array.from(offKeys);
  
  if (offKeys.size === 0) return 0;
  
  for (const offKey of offKeysArr) {
    for (const candKey of Array.from(candKeys)) {
      if (offKey !== candKey) {
        return 0.8;
      }
    }
  }
  
  if (offKeys.size > 0 && candKeys.size === 0) {
    return 0.5;
  }
  
  for (const offKey of offKeysArr) {
    if (candKeys.has(offKey)) {
      return -0.2;
    }
  }
  
  return 0;
}

const SYNONYMS: Record<string, string[]> = {
  "kefir drink": ["kefir", "kefir milk", "drinking kefir"],
  "liver (chicken)": ["chicken liver", "chicken livers", "poultry liver"],
  "liver (beef)": ["beef liver", "ox liver", "calves liver", "calf liver", "lambs liver", "lamb liver"],
  "chicken deli slices": ["chicken breast slices", "sliced chicken", "chicken slices", "deli chicken"],
  "flavoured yogurt": ["yoghurt", "fruit yogurt", "yogurt drink", "drinking yogurt", "flavored yogurt"],
  "greek yogurt (plain)": ["greek yoghurt", "greek style yogurt", "natural greek yogurt", "plain greek yogurt"],
  "protein bar": ["protein snack", "whey bar", "fitness bar", "sports bar"],
  "bread (white sliced)": ["white bread", "sliced bread", "sandwich bread", "loaf bread"],
  "ready meal (generic)": ["ready meal", "microwave meal", "tv dinner", "prepared meal"],
  "chicken breast": ["chicken", "grilled chicken", "roast chicken", "baked chicken", "poultry"],
  "beef mince (5% fat)": ["ground beef", "minced beef", "beef mince", "lean beef mince"],
  "eggs": ["egg", "whole egg", "large egg", "medium egg", "free range egg"],
  "salmon": ["salmon fillet", "fresh salmon", "atlantic salmon", "wild salmon"],
  "tuna (canned in water)": ["tuna", "canned tuna", "tuna chunks", "tuna flakes"],
  "milk (whole)": ["milk", "whole milk", "full fat milk", "dairy milk", "cows milk"],
  "oats (raw)": ["oats", "porridge oats", "rolled oats", "oatmeal"],
  "banana": ["bananas", "fresh banana"],
  "apple": ["apples", "fresh apple"],
  "avocado": ["avocados", "hass avocado", "ripe avocado"],
  "cream cheese": ["cream cheese", "soft cheese", "philadelphia", "spreadable cheese"],
};

export function normalize(str: string): string {
  if (!str) return "";
  let result = str.toLowerCase();
  result = result.replace(/[^\w\s]/g, " ");
  const words = result.split(/\s+/).filter(w => w.length > 1 && !STOP_WORDS.has(w));
  return words.join(" ").trim();
}

function tokenize(str: string): Set<string> {
  return new Set(normalize(str).split(/\s+/).filter(w => w.length > 0));
}

function jaccardSimilarity(set1: Set<string>, set2: Set<string>): number {
  if (set1.size === 0 && set2.size === 0) return 0;
  const arr1 = Array.from(set1);
  const intersection = arr1.filter(x => set2.has(x));
  const unionSet = new Set([...arr1, ...Array.from(set2)]);
  return intersection.length / unionSet.size;
}

function diceSimilarity(set1: Set<string>, set2: Set<string>): number {
  if (set1.size === 0 && set2.size === 0) return 0;
  const arr1 = Array.from(set1);
  const intersection = arr1.filter(x => set2.has(x));
  return (2 * intersection.length) / (set1.size + set2.size);
}

function isProcessedProduct(offCategories: string | null | undefined): boolean {
  if (!offCategories) return false;
  const lower = offCategories.toLowerCase();
  return PROCESSED_SIGNALS.some(signal => lower.includes(signal));
}

function detectCategories(text: string): Set<string> {
  const lower = text.toLowerCase();
  const found = new Set<string>();
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    for (const kw of keywords) {
      if (lower.includes(kw)) {
        found.add(category);
        break;
      }
    }
  }
  return found;
}

function categorySimilarity(offCategories: Set<string>, ingredientCategories: Set<string>): number {
  if (offCategories.size === 0 || ingredientCategories.size === 0) return 0;
  const offArr = Array.from(offCategories);
  const intersection = offArr.filter(c => ingredientCategories.has(c));
  if (intersection.length === 0) {
    const hasConflict = (offArr.includes("meat") && ingredientCategories.has("dairy")) ||
      (offArr.includes("dairy") && ingredientCategories.has("meat")) ||
      (offArr.includes("fish") && (ingredientCategories.has("meat") || ingredientCategories.has("dairy"))) ||
      (offArr.includes("supplement") && !ingredientCategories.has("supplement")) ||
      (!offArr.includes("supplement") && ingredientCategories.has("supplement"));
    return hasConflict ? -0.3 : 0;
  }
  const unionSize = new Set([...offArr, ...Array.from(ingredientCategories)]).size;
  return intersection.length / unionSize;
}

function macroSanityScore(
  offMacros: { kcal: number; protein: number; carbs: number; fat: number },
  ingMacros: { kcal: number; protein: number; carbs: number; fat: number }
): { score: number; reason?: string } {
  if (offMacros.kcal === 0 && ingMacros.kcal === 0) return { score: 0 };
  if (offMacros.kcal === 0 || ingMacros.kcal === 0) return { score: -0.1, reason: "missing kcal data" };

  const offTotal = offMacros.protein + offMacros.carbs + offMacros.fat;
  const ingTotal = ingMacros.protein + ingMacros.carbs + ingMacros.fat;
  if (offTotal === 0 || ingTotal === 0) return { score: 0 };

  const offRatios = {
    protein: offMacros.protein / offTotal,
    carbs: offMacros.carbs / offTotal,
    fat: offMacros.fat / offTotal,
  };
  const ingRatios = {
    protein: ingMacros.protein / ingTotal,
    carbs: ingMacros.carbs / ingTotal,
    fat: ingMacros.fat / ingTotal,
  };

  const proteinDiff = Math.abs(offRatios.protein - ingRatios.protein);
  const carbsDiff = Math.abs(offRatios.carbs - ingRatios.carbs);
  const fatDiff = Math.abs(offRatios.fat - ingRatios.fat);
  const avgDiff = (proteinDiff + carbsDiff + fatDiff) / 3;

  if (avgDiff > 0.35) return { score: -0.3, reason: "macro profile very different" };
  if (avgDiff > 0.25) return { score: -0.15, reason: "macro profile differs" };
  if (avgDiff < 0.10) return { score: 0.1, reason: "macro profile similar" };
  return { score: 0 };
}

function isSupplementProduct(name: string, categories: string | null | undefined): boolean {
  const lower = (name + " " + (categories || "")).toLowerCase();
  return SUPPLEMENT_SIGNALS.some(s => lower.includes(s));
}

function findExactMatch(offName: string, ingredients: Ingredient[]): { index: number; name: string } | null {
  const normalizedOff = normalize(offName);
  for (let i = 0; i < ingredients.length; i++) {
    const normalizedIng = normalize(ingredients[i].name);
    if (normalizedOff === normalizedIng) {
      return { index: i, name: ingredients[i].name };
    }
  }
  return null;
}

function findSynonymMatch(offName: string, ingredients: Ingredient[]): { index: number; name: string; synonym: string } | null {
  const normalizedOff = normalize(offName);
  const offWords = new Set(normalizedOff.split(/\s+/).filter(w => w.length > 0));
  
  for (const [ingredientKey, synonymList] of Object.entries(SYNONYMS)) {
    for (const synonym of synonymList) {
      const normalizedSynonym = normalize(synonym);
      const synonymWords = normalizedSynonym.split(/\s+/).filter(w => w.length > 0);
      
      if (synonymWords.length === 0) continue;
      
      const allWordsMatch = synonymWords.every(sw => offWords.has(sw));
      
      if (allWordsMatch || normalizedOff === normalizedSynonym) {
        const ingredientIndex = ingredients.findIndex(ing => 
          normalize(ing.name) === normalize(ingredientKey)
        );
        if (ingredientIndex >= 0) {
          const penalty = keyTokenPenalty(offName, ingredients[ingredientIndex].name);
          if (penalty >= 0.5) {
            continue;
          }
          return { index: ingredientIndex, name: ingredients[ingredientIndex].name, synonym };
        }
      }
    }
  }
  return null;
}

interface ScoringContext {
  offName: string;
  offBrand: string | null;
  offCategories: string | null;
  offMacros?: { kcal: number; protein: number; carbs: number; fat: number } | null;
}

function scoreCandidate(
  ingredient: Ingredient,
  ingredientIndex: number,
  ctx: ScoringContext
): MatchCandidate | null {
  const reasons: string[] = [];

  const offTokens = tokenize(`${ctx.offName} ${ctx.offBrand || ""}`);
  const ingTokens = tokenize(ingredient.name);
  const jaccard = jaccardSimilarity(offTokens, ingTokens);
  const dice = diceSimilarity(offTokens, ingTokens);
  let nameSim = (jaccard + dice) / 2;

  const penalty = keyTokenPenalty(ctx.offName, ingredient.name);
  nameSim = Math.max(0, nameSim - penalty);

  if (nameSim > 0.3) {
    const matchedTokens = Array.from(offTokens).filter(t => ingTokens.has(t));
    if (matchedTokens.length > 0) reasons.push(`keywords: ${matchedTokens.join(", ")}`);
  }

  const offCats = detectCategories(`${ctx.offName} ${ctx.offBrand || ""} ${ctx.offCategories || ""}`);
  const ingCats = detectCategories(ingredient.name);
  const catSim = categorySimilarity(offCats, ingCats);
  if (catSim > 0) {
    const shared = Array.from(offCats).filter(c => ingCats.has(c));
    reasons.push(`category: ${shared.join(", ")}`);
  } else if (catSim < 0) {
    reasons.push("category mismatch");
  }

  let macroScore = 0;
  let macroReason: string | undefined;
  if (ctx.offMacros && ctx.offMacros.kcal > 0) {
    const ingMacros = {
      kcal: ingredient.calories_per_100g,
      protein: ingredient.protein_g_per_100g,
      carbs: ingredient.carbs_g_per_100g,
      fat: ingredient.fat_g_per_100g,
    };
    const macro = macroSanityScore(ctx.offMacros, ingMacros);
    macroScore = macro.score;
    macroReason = macro.reason;
    if (macroReason) reasons.push(macroReason);
  }

  const isSuppOff = isSupplementProduct(ctx.offName, ctx.offCategories);
  const isSuppIng = ingredient.name.toLowerCase().match(/whey|isolate|casein|protein powder|mass gainer|bcaa|creatine/);
  let supplementPenalty = 0;
  if (isSuppOff && !isSuppIng) {
    supplementPenalty = -0.3;
    reasons.push("supplement vs food mismatch");
  } else if (!isSuppOff && isSuppIng) {
    supplementPenalty = -0.3;
    reasons.push("food vs supplement mismatch");
  }

  const NAME_WEIGHT = 0.55;
  const CATEGORY_WEIGHT = 0.20;
  const MACRO_WEIGHT = 0.15;
  const BRAND_WEIGHT = 0.10;

  let brandSim = 0;
  if (ctx.offBrand) {
    const brandTokens = tokenize(ctx.offBrand);
    const ingNameTokens = tokenize(ingredient.name);
    brandSim = diceSimilarity(brandTokens, ingNameTokens);
  }

  const finalScore = Math.max(0,
    (nameSim * NAME_WEIGHT) +
    (catSim * CATEGORY_WEIGHT) +
    (macroScore * MACRO_WEIGHT) +
    (brandSim * BRAND_WEIGHT) +
    supplementPenalty
  );

  if (finalScore < 0.08) return null;

  let confidence: MatchConfidence = "low";
  if (finalScore >= 0.45) confidence = "high";
  else if (finalScore >= 0.25) confidence = "medium";

  return {
    ingredientIndex,
    ingredientName: ingredient.name,
    confidence,
    method: "fuzzy",
    score: Math.round(finalScore * 1000) / 1000,
    reasons,
  };
}

export function matchOffToIngredients(
  offName: string,
  offBrand: string | null | undefined,
  offCategories: string | null | undefined,
  ingredientsList: Ingredient[],
  offMacros?: { kcal: number; protein: number; carbs: number; fat: number } | null
): MatchResult {
  const isProcessed = isProcessedProduct(offCategories);
  
  const exactMatch = findExactMatch(offName, ingredientsList);
  if (exactMatch) {
    const candidate: MatchCandidate = {
      ingredientIndex: exactMatch.index,
      ingredientName: exactMatch.name,
      confidence: "high",
      method: "exact",
      score: 1.0,
      reasons: ["exact name match"],
    };
    return { bestCandidate: candidate, topCandidates: [candidate] };
  }
  
  const synonymMatch = findSynonymMatch(offName, ingredientsList);
  if (synonymMatch) {
    let confidence: MatchConfidence = "high";
    if (isProcessed) confidence = "medium";
    
    const candidate: MatchCandidate = {
      ingredientIndex: synonymMatch.index,
      ingredientName: synonymMatch.name,
      confidence,
      method: "synonym",
      score: 0.85,
      reasons: [`synonym: "${synonymMatch.synonym}"`],
    };
    return { bestCandidate: candidate, topCandidates: [candidate] };
  }
  
  const ctx: ScoringContext = {
    offName,
    offBrand: offBrand || null,
    offCategories: offCategories || null,
    offMacros: offMacros || null,
  };

  const candidates: MatchCandidate[] = [];
  for (let i = 0; i < ingredientsList.length; i++) {
    const result = scoreCandidate(ingredientsList[i], i, ctx);
    if (result) candidates.push(result);
  }

  candidates.sort((a, b) => b.score - a.score);
  const topCandidates = candidates.slice(0, 5);

  if (topCandidates.length > 0) {
    let best = topCandidates[0];
    
    if (isProcessed && best.confidence === "high") {
      const isProcessedIngredient = ["kefir drink", "protein bar", "bread (white sliced)", 
        "chicken deli slices", "ready meal (generic)", "flavoured yogurt"]
        .some(p => normalize(best.ingredientName).includes(normalize(p)));
      
      if (!isProcessedIngredient) {
        best = { ...best, confidence: "medium" };
        topCandidates[0] = best;
      }
    }
    
    console.log(`[match] "${offName}" -> best: "${best.ingredientName}" score=${best.score} confidence=${best.confidence} reasons=[${best.reasons?.join("; ")}]`);
    
    return { bestCandidate: best, topCandidates };
  }
  
  console.log(`[match] "${offName}" -> no candidates found`);
  return { bestCandidate: null, topCandidates: [] };
}

export function getProcessedSignals(): string[] {
  return PROCESSED_SIGNALS;
}

export function getSynonyms(): Record<string, string[]> {
  return SYNONYMS;
}
