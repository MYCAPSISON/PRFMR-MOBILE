const BODY_REGION_MULTIPLIERS: Record<string, number> = {
  upper: 1.0,
  lower: 1.25,
  full: 1.1,
};

const LIFTING_KCAL_BODY_REGION_MULTIPLIERS: Record<string, number> = {
  upper: 1.0,
  lower: 1.1,
  full: 1.15,
};

const RPE_TO_MET: [number, number, number][] = [
  [1, 3, 3.5],
  [4, 5, 4.5],
  [6, 7, 5.0],
  [8, 9, 6.0],
  [10, 10, 6.5],
];

export type BodyRegion = "upper" | "lower" | "full";

export interface TrainingLoadInput {
  durationMinutes: number;
  sessionRpe: number;
  bodyRegion: BodyRegion;
}

export interface TrainingLoadResult {
  sessionType: "lifting";
  bodyRegion: BodyRegion;
  durationMinutes: number;
  sessionRpe: number;
  bodyRegionMultiplier: number;
  trainingLoadScore: number;
}

export interface LiftingCalorieInput {
  durationMinutes: number;
  sessionRpe: number;
  bodyRegion: BodyRegion;
  bodyweightKg: number;
}

export interface LiftingCalorieResult {
  estimatedKcal: number;
  metFromRpe: number;
  bodyRegionKcalMultiplier: number;
}

export function getMetFromRpe(rpe: number): number {
  for (const [lo, hi, met] of RPE_TO_MET) {
    if (rpe >= lo && rpe <= hi) return met;
  }
  return 5.0;
}

export function estimateLiftingCalories(input: LiftingCalorieInput): LiftingCalorieResult {
  const met = getMetFromRpe(input.sessionRpe);
  const regionMultiplier = LIFTING_KCAL_BODY_REGION_MULTIPLIERS[input.bodyRegion] ?? 1.0;
  const durationHours = input.durationMinutes / 60;
  const kcal = Math.round(met * input.bodyweightKg * durationHours * regionMultiplier);

  return {
    estimatedKcal: kcal,
    metFromRpe: met,
    bodyRegionKcalMultiplier: regionMultiplier,
  };
}

export function calculateTrainingLoad(input: TrainingLoadInput): TrainingLoadResult {
  const multiplier = BODY_REGION_MULTIPLIERS[input.bodyRegion] ?? 1.0;
  const score = Math.round(input.durationMinutes * input.sessionRpe * multiplier);

  return {
    sessionType: "lifting",
    bodyRegion: input.bodyRegion,
    durationMinutes: input.durationMinutes,
    sessionRpe: input.sessionRpe,
    bodyRegionMultiplier: multiplier,
    trainingLoadScore: score,
  };
}

export function getBodyRegionMultiplier(region: string): number {
  return BODY_REGION_MULTIPLIERS[region] ?? 1.0;
}

/**
 * computeSessionLoad — simple training load estimate for any activity type.
 * If an RPE is available: load = rpe × durationMinutes (session-RPE method).
 * Fallback: use estimatedKcal as a proxy (comparable magnitude for most activities).
 */
export function computeSessionLoad(activity: {
  rpe?: number | null;
  durationMinutes: number;
  estimatedKcal?: number | null;
}): number {
  if (activity.rpe) {
    return Math.round(activity.rpe * activity.durationMinutes);
  }
  return activity.estimatedKcal ?? 0;
}

// ─── Day classification ────────────────────────────────────────────────────────

export type DayClassification = "light" | "moderate" | "hard" | "very_hard";

export interface DailyLoadResult {
  totalLoad: number;
  classification: DayClassification;
  provisional: boolean;
  sessionCount: number;
  totalDurationMinutes: number;
  totalKcal: number;
}

/**
 * Classify a day's total training load into four tiers.
 *
 * Thresholds (RPE × minutes basis):
 *   < 300       → light
 *   300–599     → moderate
 *   600–899     → hard
 *   ≥ 900       → very_hard
 */
export function classifyDayLoad(totalLoad: number): DayClassification {
  if (totalLoad < 300) return "light";
  if (totalLoad < 600) return "moderate";
  if (totalLoad < 900) return "hard";
  return "very_hard";
}

/**
 * Compute the daily training load for a given set of activities and return
 * a classification result.
 */
export function computeDailyLoad(
  activities: Array<{ rpe?: number | null; durationMinutes: number; estimatedKcal?: number | null }>,
  sessionCount: number,
  isPartialDay = false
): DailyLoadResult {
  if (activities.length === 0 && sessionCount === 0) {
    return {
      totalLoad: 0,
      classification: "light",
      provisional: false,
      sessionCount: 0,
      totalDurationMinutes: 0,
      totalKcal: 0,
    };
  }

  let totalLoad = 0;
  let totalDurationMinutes = 0;
  let totalKcal = 0;

  for (const act of activities) {
    totalLoad += computeSessionLoad(act);
    totalDurationMinutes += act.durationMinutes ?? 0;
    totalKcal += act.estimatedKcal ?? 0;
  }

  const provisional = isPartialDay || (sessionCount > 0 && activities.length === 0);

  return {
    totalLoad,
    classification: classifyDayLoad(totalLoad),
    provisional,
    sessionCount,
    totalDurationMinutes,
    totalKcal,
  };
}

/**
 * Map a DayClassification to the PlannedIntensity scale used by readiness /
 * fuel-availability (very_hard → hard since there are only 4 levels vs 3).
 */
export function classificationToPlannedIntensity(
  c: DayClassification
): "light" | "moderate" | "hard" {
  if (c === "very_hard") return "hard";
  return c;
}

// ─── Load warnings & acute/chronic context ────────────────────────────────────

export type LoadStatus = "low" | "stable" | "spike" | null;

export interface LoadWarningResult {
  warnings: string[];
  backToBackHardDays: boolean;
  highLoadCluster: boolean;
  threeDayStreak: boolean;
  /** Sum of last 7 days. */
  acuteLoad: number;
  /** acuteLoad / 7 */
  acuteDaily: number;
  /** Avg daily load over the baseline window (28→14→7 days). Null if < 7 days. */
  baselineLoad: number | null;
  /** How many days were used for the baseline (28, 14, or 7). */
  baselineDaysUsed: number | null;
  /** ACWR = acuteDaily / baselineLoad. Null when insufficient training history. */
  acwr: number | null;
  /** Today's load / baselineLoad. Null when insufficient training history. */
  relativeLoad: number | null;
  /** true when today is a high-stress day */
  highStress: boolean;
  /** true when today is a very-high-stress day */
  veryHighStress: boolean;
  /** Alias for acwr — kept for backward compatibility. */
  chronicLoad: number;
  loadRatio: number | null;
  loadStatus: LoadStatus;
  /** Number of days with non-zero training in the window. */
  activeDaysInWindow: number;
  /** True when there are fewer than 7 training days in history — ACWR/relative-load metrics are unreliable. */
  insufficientHistory: boolean;
}

function isHighStress(totalLoad: number, relativeLoad: number | null): boolean {
  if (relativeLoad !== null) return relativeLoad > 1.2;
  return totalLoad >= 600;
}

/**
 * Compute stacking flags and ACWR-based load metrics.
 *
 * @param todayLoad  Daily load result for the reference date.
 * @param priorDays  Prior days ordered newest-first: [yesterday, 2-days-ago, ...].
 *                   Pass at least 2 for cluster detection, 27 for full chronic load.
 *
 * Baseline window: 28 days → 14 days → 7 days (fallback chain). Null if < 7 days.
 * Acute load  = sum(last 7 days)
 * ACWR        = (acuteLoad / 7) / baselineLoad
 * relativeLoad = todayLoad / baselineLoad
 *
 * High stress: relativeLoad > 1.2  (fallback: totalLoad ≥ 600)
 * Very high:   relativeLoad > 1.4
 * Cluster:     2+ high-stress days out of today/y1/y2
 * ThreeDayStreak: all three high-stress
 */
// Minimum number of days with actual training before ACWR / relative-load
// metrics are considered reliable. Below this, baselines built on mostly-zero
// days inflate the ratio and produce spurious warnings.
const MIN_ACTIVE_DAYS_FOR_ACWR = 7;

export function computeLoadWarnings(
  todayLoad: DailyLoadResult,
  priorDays: DailyLoadResult[]
): LoadWarningResult {
  const allDays = [todayLoad, ...priorDays];

  // ── Acute load (last 7 days) ──────────────────────────────────────────────
  const last7 = allDays.slice(0, 7);
  const acuteLoad = last7.reduce((s, d) => s + d.totalLoad, 0);
  const acuteDaily = Math.round((acuteLoad / 7) * 10) / 10;

  // ── Active day count — days with real training in the window ─────────────
  const activeDaysInWindow = allDays.filter(d => d.totalLoad > 0).length;
  const insufficientHistory = activeDaysInWindow < MIN_ACTIVE_DAYS_FOR_ACWR;

  // ── Baseline load (28 → 14 → 7 fallback) ─────────────────────────────────
  let baselineLoad: number | null = null;
  let baselineDaysUsed: number | null = null;

  for (const n of [28, 14, 7]) {
    if (allDays.length >= n) {
      const slice = allDays.slice(0, n);
      baselineLoad = Math.round((slice.reduce((s, d) => s + d.totalLoad, 0) / n) * 10) / 10;
      baselineDaysUsed = n;
      break;
    }
  }

  // ── ACWR — suppressed when history is too sparse ──────────────────────────
  // A baseline built from fewer than 7 active training days is dominated by
  // zero-load rest days, making the average artificially low and the ratio
  // meaninglessly high (e.g. 4.00 on a light day for a new user).
  let acwr: number | null = null;
  if (!insufficientHistory && baselineLoad !== null && baselineLoad > 0) {
    acwr = Math.round((acuteDaily / baselineLoad) * 100) / 100;
  }

  // ── Relative load (today vs baseline) — also suppressed when sparse ───────
  let relativeLoad: number | null = null;
  if (!insufficientHistory && baselineLoad !== null && baselineLoad > 0) {
    relativeLoad = Math.round((todayLoad.totalLoad / baselineLoad) * 100) / 100;
  }

  // ── Per-day relative loads for stacking ──────────────────────────────────
  const y1RelLoad = (!insufficientHistory && baselineLoad !== null && baselineLoad > 0 && priorDays.length >= 1)
    ? priorDays[0].totalLoad / baselineLoad
    : null;
  const y2RelLoad = (!insufficientHistory && baselineLoad !== null && baselineLoad > 0 && priorDays.length >= 2)
    ? priorDays[1].totalLoad / baselineLoad
    : null;

  // ── Stress flags ──────────────────────────────────────────────────────────
  // When history is insufficient, fall back to absolute thresholds only
  // (≥600 = high-stress, ≥900 = very-high). This prevents a 119-pt light
  // session from being flagged as "high stress" just because the baseline
  // is near zero for a new user.
  const todayHigh = isHighStress(todayLoad.totalLoad, relativeLoad);
  const y1High = priorDays.length >= 1 && isHighStress(priorDays[0].totalLoad, y1RelLoad);
  const y2High = priorDays.length >= 2 && isHighStress(priorDays[1].totalLoad, y2RelLoad);

  const highStress = todayHigh;
  const veryHighStress = relativeLoad !== null ? relativeLoad > 1.4 : todayLoad.totalLoad >= 900;

  const highLoadDaysIn3 = [todayHigh, y1High, y2High].filter(Boolean).length;
  const backToBackHardDays = todayHigh && y1High;
  const highLoadCluster = highLoadDaysIn3 >= 2;
  const threeDayStreak = todayHigh && y1High && y2High;

  // ── ACWR status ───────────────────────────────────────────────────────────
  let loadStatus: LoadStatus = null;
  if (acwr !== null) {
    if (acwr < 0.8) loadStatus = "low";
    else if (acwr <= 1.5) loadStatus = "stable";
    else loadStatus = "spike";
  }

  // ── Warnings ──────────────────────────────────────────────────────────────
  // ACWR / relative-load warnings are only emitted when history is sufficient.
  // Stacking warnings (cluster, streak) use absolute thresholds when sparse,
  // so they still fire for genuinely hard accumulation even for new users.
  // Priority ordering: spike > elevated (mutually exclusive), then stacking.
  // Cap at 2 warnings to avoid noise.
  const warnings: string[] = [];

  if (acwr !== null && acwr > 1.5) {
    warnings.push("Today's load is well above your recent baseline. Consider keeping the next session lighter or prioritising recovery.");
  } else if (relativeLoad !== null && relativeLoad > 1.3) {
    warnings.push("Today's load is above your recent baseline. A lighter follow-up session or extra recovery may help.");
  }

  if (threeDayStreak) {
    warnings.push("Training stress has been building across the last 3 days. It may help to reduce intensity or include a lighter day.");
  } else if (highLoadCluster) {
    warnings.push("Training stress is accumulating across recent days. Recovery needs may be higher than usual over the next 24–48 hours.");
  }

  const finalWarnings = warnings.slice(0, 2);

  return {
    warnings: finalWarnings,
    backToBackHardDays,
    highLoadCluster,
    threeDayStreak,
    acuteLoad,
    acuteDaily,
    baselineLoad,
    baselineDaysUsed,
    acwr,
    relativeLoad,
    highStress,
    veryHighStress,
    chronicLoad: baselineLoad ?? 0,
    loadRatio: acwr,
    loadStatus,
    activeDaysInWindow,
    insufficientHistory,
  };
}
