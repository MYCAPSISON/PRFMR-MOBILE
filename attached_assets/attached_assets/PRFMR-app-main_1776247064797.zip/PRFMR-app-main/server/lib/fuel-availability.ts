import type { PlannedIntensity } from "./readiness";

export type FuelStatus = "High" | "Adequate" | "Low";
export type GlycogenRisk = "Low" | "Moderate" | "High";

const ASSUMED_BODY_FAT = 0.15;

export interface FuelAvailabilityResult {
  fuelStatus: FuelStatus;
  glycogenRisk: GlycogenRisk;
  constraint: string;
  suggestedFix: string;
  eaValue: number | null;
  carbsPerKg: number | null;
  ffmKg: number | null;
}

export function calculateFuelStatus(
  caloriesYesterday: number,
  exerciseKcalYesterday: number,
  bodyweightKg: number | null | undefined,
  bodyFatPct?: number | null,
): { status: FuelStatus; eaValue: number | null; ffmKg: number | null } {
  if (!bodyweightKg || bodyweightKg <= 0) {
    return { status: "Adequate", eaValue: null, ffmKg: null };
  }

  const bfPct = (bodyFatPct != null && bodyFatPct > 0 && bodyFatPct < 1) ? bodyFatPct : ASSUMED_BODY_FAT;
  const ffmKg = bodyweightKg * (1 - bfPct);

  const ea = (caloriesYesterday - exerciseKcalYesterday) / ffmKg;

  let status: FuelStatus;
  if (ea >= 40) status = "High";
  else if (ea >= 30) status = "Adequate";
  else status = "Low";

  return { status, eaValue: Math.round(ea * 10) / 10, ffmKg: Math.round(ffmKg * 10) / 10 };
}

export function calculateGlycogenRisk(
  carbsYesterdayG: number,
  bodyweightKg: number | null | undefined,
  plannedIntensity: PlannedIntensity
): { risk: GlycogenRisk; carbsPerKg: number | null } {
  if (!bodyweightKg || bodyweightKg <= 0) {
    return { risk: "Moderate", carbsPerKg: null };
  }

  const carbsPerKg = carbsYesterdayG / bodyweightKg;
  let risk: GlycogenRisk;

  if (plannedIntensity === "hard") {
    if (carbsPerKg < 4) risk = "High";
    else if (carbsPerKg <= 6) risk = "Moderate";
    else risk = "Low";
  } else if (plannedIntensity === "moderate") {
    if (carbsPerKg < 3.5) risk = "High";
    else if (carbsPerKg <= 5) risk = "Moderate";
    else risk = "Low";
  } else {
    if (carbsPerKg < 2.5) risk = "High";
    else if (carbsPerKg <= 4) risk = "Moderate";
    else risk = "Low";
  }

  return { risk, carbsPerKg: Math.round(carbsPerKg * 10) / 10 };
}

export function calculateFuelAvailability(
  caloriesYesterday: number,
  exerciseKcalYesterday: number,
  carbsYesterdayG: number,
  bodyweightKg: number | null | undefined,
  plannedIntensity: PlannedIntensity,
  bodyFatPct?: number | null,
): FuelAvailabilityResult {
  const { status: fuelStatus, eaValue, ffmKg } = calculateFuelStatus(
    caloriesYesterday,
    exerciseKcalYesterday,
    bodyweightKg,
    bodyFatPct,
  );

  const { risk: glycogenRisk, carbsPerKg } = calculateGlycogenRisk(
    carbsYesterdayG,
    bodyweightKg,
    plannedIntensity
  );

  let constraint = "";
  let suggestedFix = "";

  if (glycogenRisk === "High") {
    const intensityLabel = plannedIntensity === "hard" ? "hard session" : "training";
    constraint = `${intensityLabel} planned, carbs too low yesterday`;
    const deficit = bodyweightKg ? Math.round((plannedIntensity === "hard" ? 6 : 4) * bodyweightKg - carbsYesterdayG) : 80;
    const clampedDeficit = Math.max(40, Math.min(120, deficit));
    suggestedFix = plannedIntensity === "hard"
      ? `+${clampedDeficit}g carbs before training — e.g., bagel + jam, banana + oats, or rice + honey`
      : `+${clampedDeficit}g carbs before training — e.g., toast + jam, banana + oats, or yogurt + cereal`;
  } else if (fuelStatus === "Low") {
    constraint = "Overall energy intake was low yesterday";
    suggestedFix = "A carb-rich meal or snack before training — e.g., oats, rice bowl, or pasta";
  } else if (glycogenRisk === "Moderate") {
    constraint = "Carb stores may be slightly depleted";
    suggestedFix = "+40–60g carbs pre-session — e.g., banana + oats, toast + jam, or yogurt + cereal";
  } else {
    constraint = "Fuel stores look adequate";
    suggestedFix = "Fuel looks good — stay hydrated and maintain your normal eating";
  }

  return {
    fuelStatus,
    glycogenRisk,
    constraint,
    suggestedFix,
    eaValue,
    carbsPerKg,
    ffmKg,
  };
}
