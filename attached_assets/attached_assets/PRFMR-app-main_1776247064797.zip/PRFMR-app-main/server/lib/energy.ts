/**
 * Energy/calorie calculation utilities using MET-based formulas
 * 
 * MET (Metabolic Equivalent of Task) formula:
 * kcal/min = MET × 3.5 × weight(kg) / 200
 * 
 * This is the standard Compendium-style formula used in exercise science.
 * 
 * DISCLAIMER: These are estimates only. Actual calorie burn varies significantly
 * based on individual factors including age, fitness level, body composition,
 * technique, and environmental conditions.
 */

// Default MET values for strength training intensities
export const STRENGTH_MET_VALUES = {
  light: 3.5,    // Light resistance training
  moderate: 5.0, // Moderate effort
  vigorous: 6.0, // High intensity
} as const;

// Default set timing assumptions (in seconds)
export const DEFAULT_SET_TIMING = {
  avgSetTimeSeconds: 35,  // Average time to complete a set
  defaultRestSeconds: 90, // Default rest between sets if not specified
} as const;

/**
 * Calculate calories burned using MET formula
 * @param met - Metabolic Equivalent of Task value
 * @param weightKg - Body weight in kilograms
 * @param minutes - Duration in minutes
 * @returns Estimated calories burned
 */
export function kcalFromMET(met: number, weightKg: number, minutes: number): number {
  if (!met || !weightKg || !minutes || met <= 0 || weightKg <= 0 || minutes <= 0) {
    return 0;
  }
  return (met * 3.5 * weightKg / 200) * minutes;
}

/**
 * Get MET value for strength training based on intensity
 * @param intensity - light/moderate/vigorous
 * @returns MET value
 */
export function getStrengthMET(intensity?: string | null): number {
  if (!intensity) return STRENGTH_MET_VALUES.moderate;
  const key = intensity.toLowerCase() as keyof typeof STRENGTH_MET_VALUES;
  return STRENGTH_MET_VALUES[key] ?? STRENGTH_MET_VALUES.moderate;
}

/**
 * Estimate workout duration from sets if not explicitly provided
 * @param sets - Array of sets with optional rest_seconds
 * @returns Estimated duration in minutes
 */
export function estimateDurationFromSets(
  sets: Array<{ restSeconds?: number | null }>
): number {
  if (!sets || sets.length === 0) return 0;
  
  // Calculate average rest time from provided values or use default
  const providedRests = sets.filter(s => s.restSeconds != null).map(s => s.restSeconds!);
  const avgRest = providedRests.length > 0 
    ? providedRests.reduce((a, b) => a + b, 0) / providedRests.length
    : DEFAULT_SET_TIMING.defaultRestSeconds;
  
  // Total time = sets × (set time + rest time)
  const totalSeconds = sets.length * (DEFAULT_SET_TIMING.avgSetTimeSeconds + avgRest);
  
  return Math.ceil(totalSeconds / 60);
}

/**
 * Calculate total workout session calories
 * Combines strength training calories + cardio/activity calories
 */
export interface SessionCalorieInput {
  durationMinutes?: number | null;
  intensity?: string | null;
  sets?: Array<{ restSeconds?: number | null }>;
  activities?: Array<{ metValue: number; durationMinutes: number }>;
}

export function calculateSessionCalories(
  weightKg: number,
  input: SessionCalorieInput
): { totalKcal: number; strengthKcal: number; activityKcal: number; estimatedMinutes: number } {
  if (!weightKg || weightKg <= 0) {
    return { totalKcal: 0, strengthKcal: 0, activityKcal: 0, estimatedMinutes: 0 };
  }
  
  const { durationMinutes, intensity, sets = [], activities = [] } = input;
  
  // Calculate strength training duration
  let strengthMinutes = durationMinutes ?? 0;
  if (!strengthMinutes && sets.length > 0) {
    strengthMinutes = estimateDurationFromSets(sets);
  }
  
  // Calculate strength calories
  const strengthMet = getStrengthMET(intensity);
  const strengthKcal = kcalFromMET(strengthMet, weightKg, strengthMinutes);
  
  // Calculate activity/cardio calories
  const activityKcal = activities.reduce((total, activity) => {
    return total + kcalFromMET(activity.metValue, weightKg, activity.durationMinutes);
  }, 0);
  
  return {
    totalKcal: Math.round(strengthKcal + activityKcal),
    strengthKcal: Math.round(strengthKcal),
    activityKcal: Math.round(activityKcal),
    estimatedMinutes: strengthMinutes,
  };
}

/**
 * Calculate approximate kcal per rep (for display only - not scientifically accurate)
 * This is purely a rough estimate for user reference, NOT a medical measurement
 */
export function estimateKcalPerRep(totalKcal: number, totalReps: number): number | null {
  if (!totalKcal || !totalReps || totalReps <= 0) return null;
  return Math.round((totalKcal / totalReps) * 10) / 10; // Round to 1 decimal
}

// ─── RPE Calorie Adjustment ───────────────────────────────────────────────────
//
// Applies a small scaling factor to MET-based cardio kcal estimates when the
// user logs an RPE value, reflecting that the same activity done harder burns
// more calories.
//
// Formula: adjustmentFactor = 0.9 + (rpe / 10) × 0.2
//   RPE 1  → ×0.92   RPE 5  → ×1.00   RPE 10 → ×1.10
//
// Excluded activities (leisure/recovery) are not adjusted because their MET
// values already assume low effort and RPE doesn't meaningfully shift kcal.
//
// Lifting sessions are excluded here — they use their own RPE-based calorie
// model (estimateLiftingCalories) and must NOT be double-adjusted.
// ─────────────────────────────────────────────────────────────────────────────

/** Keywords that identify leisure / recovery / low-effort activities */
const RPE_EXCLUSION_KEYWORDS: readonly string[] = [
  "leisure",
  "easy",
  "recovery",
  "warmup",
  "warm-up",
  "warm up",
  "cooldown",
  "cool-down",
  "cool down",
  "mobility",
  "stretch",
  "stretching",
  "gentle",
  "casual",
  "walking",
  "walk",
];

/**
 * Returns true when an RPE-based kcal adjustment should be applied to this
 * activity.  Returns false for:
 *  - lifting activities (already use RPE-based estimateLiftingCalories)
 *  - leisure / recovery / low-effort activities (name-matched)
 */
export function shouldApplyRpeKcalAdjustment(
  activityName: string,
  activityType?: string | null,
): boolean {
  // Lifting already has its own RPE model — never double-adjust
  if (activityType === "lifting") return false;

  const normalized = activityName.toLowerCase();

  // Exclude any activity whose name contains a leisure/recovery keyword
  if (RPE_EXCLUSION_KEYWORDS.some((kw) => normalized.includes(kw))) return false;

  return true;
}

/**
 * Returns the RPE-based multiplier for cardio kcal.
 * If rpe is null/undefined the factor is 1.0 (no change).
 */
export function getRpeKcalAdjustmentFactor(rpe: number | null | undefined): number {
  if (rpe == null) return 1.0;
  const clampedRpe = Math.max(1, Math.min(10, rpe));
  return 0.9 + (clampedRpe / 10) * 0.2;
}
