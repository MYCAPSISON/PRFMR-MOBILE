import { execSync } from "child_process";

let cachedVersion: string | null = null;

export function getAppVersion(): string {
  if (cachedVersion) return cachedVersion;

  if (process.env.APP_VERSION) {
    cachedVersion = process.env.APP_VERSION;
    return cachedVersion;
  }

  const isProduction = process.env.NODE_ENV === "production";

  if (isProduction) {
    try {
      const sha = execSync("git rev-parse --short=7 HEAD", { timeout: 3000 })
        .toString()
        .trim();
      if (sha) {
        cachedVersion = sha;
        return cachedVersion;
      }
    } catch {}
    cachedVersion = "beta";
    return cachedVersion;
  }

  try {
    const sha = execSync("git rev-parse --short=7 HEAD", { timeout: 3000 })
      .toString()
      .trim();
    if (sha) {
      cachedVersion = `dev-${sha}`;
      return cachedVersion;
    }
  } catch {}

  cachedVersion = "beta";
  return cachedVersion;
}

export function getEnvironment(): string {
  return process.env.NODE_ENV || "development";
}
