export type CutStatus = "on_track" | "aggressive" | "very_aggressive" | "unrealistic" | "complete" | "past_date";
export type WeighInTiming = "same_day" | "day_before";

export interface WeeklyTarget {
  week: number;
  targetWeight: number;
}

export interface WeightCutPlanResult {
  currentWeight: number;
  targetWeight: number;
  fightDate: string;
  daysUntil: number;
  weeksUntil: number;
  totalToLose: number;
  fatLossRequired: number;
  tempCut: number;
  tempCutDisplayed: number;
  // requiredWeeklyRate: the pace needed to hit the pre-final-cut target in the available time
  requiredWeeklyRate: number;
  requiredWeeklyRatePct: number;
  // recommendedWeeklyRate: required rate capped at 1% BW/wk — used for targets and deficit
  recommendedWeeklyRate: number;
  recommendedWeeklyRatePct: number;
  // weeklyRate / weeklyRatePct kept for UI backward compatibility (= recommendedWeeklyRate)
  weeklyRate: number;
  weeklyRatePct: number;
  dayMinus4Target: number | null;
  // Pre-final-cut target weights
  predictedWeekMinus1Weight: number | null; // day_before: bodyweight target at T-7d
  predictedDayMinus4Weight: number | null;  // same_day: bodyweight target at T-4d
  status: CutStatus;
  statusLabel: string;
  weeklyTargets: WeeklyTarget[];
  suggestedDeficitKcal: number;
  manualTempReductionKg: number | null;
}

export function calculateWeightCutPlan(
  currentWeight: number,
  targetWeight: number,
  fightDateStr: string,
  weighInTiming: WeighInTiming = "same_day",
  todayStr?: string,
  manualTempReductionKg?: number | null
): WeightCutPlanResult {
  const today = todayStr ? new Date(todayStr) : new Date();
  const fightDate = new Date(fightDateStr);
  const diffMs = fightDate.getTime() - today.getTime();
  const daysUntil = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  const weeksUntil = daysUntil / 7;

  const totalToLose = Math.max(0, currentWeight - targetWeight);
  const hasManualTemp = typeof manualTempReductionKg === "number" && manualTempReductionKg > 0;

  // ── Early exits ───────────────────────────────────────────────────────────
  if (daysUntil <= 0) {
    return earlyExit(currentWeight, targetWeight, fightDateStr, daysUntil, weeksUntil, totalToLose, manualTempReductionKg, hasManualTemp, "past_date", "Fight date has passed", weighInTiming);
  }
  if (totalToLose <= 0) {
    return earlyExit(currentWeight, targetWeight, fightDateStr, daysUntil, weeksUntil, totalToLose, manualTempReductionKg, hasManualTemp, "complete", "Already at or below target", weighInTiming);
  }

  // ── SEPARATE FLOWS ────────────────────────────────────────────────────────
  if (weighInTiming === "day_before") {
    return dayBeforeFlow(currentWeight, targetWeight, fightDateStr, daysUntil, weeksUntil, totalToLose, hasManualTemp, manualTempReductionKg ?? null);
  } else {
    return sameDayFlow(currentWeight, targetWeight, fightDateStr, daysUntil, weeksUntil, totalToLose, hasManualTemp, manualTempReductionKg ?? null);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DAY-BEFORE FLOW
//   Fat loss phase runs until T-7 days.
//   Temporary reduction covers the final week (fluid, etc.).
// ─────────────────────────────────────────────────────────────────────────────
function dayBeforeFlow(
  currentWeight: number,
  targetWeight: number,
  fightDateStr: string,
  daysUntil: number,
  weeksUntil: number,
  totalToLose: number,
  hasManualTemp: boolean,
  manualTempReductionKg: number | null,
): WeightCutPlanResult {

  // Step 1: Pre-final-cut target at T-7 days
  let predictedWeekMinus1Weight: number;
  if (hasManualTemp) {
    const raw = targetWeight + manualTempReductionKg!;
    const maxSafe = raw * 0.10; // cap temp cut at 10% of that weight
    const cappedTemp = Math.min(manualTempReductionKg!, maxSafe);
    predictedWeekMinus1Weight = Math.round((targetWeight + cappedTemp) * 100) / 100;
  } else {
    predictedWeekMinus1Weight = Math.round((targetWeight / (1 - 0.06)) * 100) / 100;
  }

  // Step 2: Fat loss required (current → T-7 target)
  const fatLossRequired = Math.max(0, Math.round((currentWeight - predictedWeekMinus1Weight) * 10) / 10);

  // Temporary cut = difference between T-7 target and fight weight,
  // capped so fatLossRequired + tempCut ≤ totalToLose (consistency guard).
  const rawTempCut = Math.max(0, predictedWeekMinus1Weight - targetWeight);
  const tempCut = Math.round(Math.min(rawTempCut, Math.max(0, totalToLose - fatLossRequired)) * 10) / 10;

  // Step 3: Time available for fat loss
  const weeksForFatLoss = Math.max(0.5, (daysUntil - 7) / 7);

  // Step 4: Required weekly rate
  const requiredWeeklyRate = Math.round((fatLossRequired / weeksForFatLoss) * 100) / 100;
  const requiredWeeklyRatePct = Math.round((requiredWeeklyRate / currentWeight) * 10000) / 100;

  // Step 5: Recommended rate (capped at 1% BW/wk)
  const maxWeeklyRate = currentWeight * 0.01;
  const recommendedWeeklyRate = Math.round(Math.min(requiredWeeklyRate, maxWeeklyRate) * 100) / 100;
  const recommendedWeeklyRatePct = Math.round((recommendedWeeklyRate / currentWeight) * 10000) / 100;

  // Step 6: Status from REQUIRED rate
  const { status, statusLabel } = deriveStatus(requiredWeeklyRatePct);

  // Step 7: Temp cut display — only in final 10 days for day_before
  const tempCutDisplayed = daysUntil <= 10 && tempCut > 0 ? Math.round(tempCut * 10) / 10 : 0;

  // Step 8: Weekly targets toward predictedWeekMinus1Weight using recommended rate
  const weeklyTargets = buildWeeklyTargets(currentWeight, predictedWeekMinus1Weight, recommendedWeeklyRate, weeksForFatLoss);

  // Deficit from recommended rate
  const suggestedDeficitKcal = Math.round(recommendedWeeklyRate * 7700 / 7);

  return {
    currentWeight,
    targetWeight,
    fightDate: fightDateStr,
    daysUntil,
    weeksUntil: Math.round(weeksUntil * 10) / 10,
    totalToLose: Math.round(totalToLose * 10) / 10,
    fatLossRequired,
    tempCut,
    tempCutDisplayed,
    requiredWeeklyRate,
    requiredWeeklyRatePct,
    recommendedWeeklyRate,
    recommendedWeeklyRatePct,
    weeklyRate: recommendedWeeklyRate,
    weeklyRatePct: recommendedWeeklyRatePct,
    dayMinus4Target: null,
    predictedWeekMinus1Weight,
    predictedDayMinus4Weight: null,
    status,
    statusLabel,
    weeklyTargets,
    suggestedDeficitKcal,
    manualTempReductionKg: hasManualTemp ? manualTempReductionKg : null,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// SAME-DAY FLOW
//   Fat loss phase runs until T-4 days.
//   Temporary reduction is minimal (athlete should be very close by T-4).
// ─────────────────────────────────────────────────────────────────────────────
function sameDayFlow(
  currentWeight: number,
  targetWeight: number,
  fightDateStr: string,
  daysUntil: number,
  weeksUntil: number,
  totalToLose: number,
  hasManualTemp: boolean,
  manualTempReductionKg: number | null,
): WeightCutPlanResult {

  // Step 1: Pre-final-cut target at T-4 days
  let predictedDayMinus4Weight: number;
  if (hasManualTemp) {
    const raw = targetWeight + manualTempReductionKg!;
    const maxSafe = raw * 0.02; // cap at 2% of that weight for same-day
    const cappedTemp = Math.min(manualTempReductionKg!, maxSafe);
    predictedDayMinus4Weight = Math.round((targetWeight + cappedTemp) * 100) / 100;
  } else {
    predictedDayMinus4Weight = Math.round((targetWeight / (1 - 0.01)) * 100) / 100;
  }

  // Step 2: Fat loss required (current → T-4 target)
  const fatLossRequired = Math.max(0, Math.round((currentWeight - predictedDayMinus4Weight) * 10) / 10);

  // Temporary cut = difference between T-4 target and fight weight,
  // capped so fatLossRequired + tempCut ≤ totalToLose (consistency guard).
  const rawTempCut = Math.max(0, predictedDayMinus4Weight - targetWeight);
  const tempCut = Math.round(Math.min(rawTempCut, Math.max(0, totalToLose - fatLossRequired)) * 10) / 10;

  // Step 3: Time available for fat loss
  const weeksForFatLoss = Math.max(0.5, (daysUntil - 4) / 7);

  // Step 4: Required weekly rate
  const requiredWeeklyRate = Math.round((fatLossRequired / weeksForFatLoss) * 100) / 100;
  const requiredWeeklyRatePct = Math.round((requiredWeeklyRate / currentWeight) * 10000) / 100;

  // Step 5: Recommended rate (capped at 1% BW/wk)
  const maxWeeklyRate = currentWeight * 0.01;
  const recommendedWeeklyRate = Math.round(Math.min(requiredWeeklyRate, maxWeeklyRate) * 100) / 100;
  const recommendedWeeklyRatePct = Math.round((recommendedWeeklyRate / currentWeight) * 10000) / 100;

  // Step 6: Status from REQUIRED rate
  const { status, statusLabel } = deriveStatus(requiredWeeklyRatePct);

  // Step 7: Temp cut display — tighter window for same-day (final 5 days)
  const tempCutDisplayed = daysUntil <= 5 && tempCut > 0 ? Math.round(tempCut * 10) / 10 : 0;

  // dayMinus4Target is the bodyweight the athlete should hit by T-4
  const dayMinus4Target = Math.round(predictedDayMinus4Weight * 10) / 10;

  // Step 8: Weekly targets toward predictedDayMinus4Weight using recommended rate
  const weeklyTargets = buildWeeklyTargets(currentWeight, predictedDayMinus4Weight, recommendedWeeklyRate, weeksForFatLoss);

  // Deficit from recommended rate
  const suggestedDeficitKcal = Math.round(recommendedWeeklyRate * 7700 / 7);

  return {
    currentWeight,
    targetWeight,
    fightDate: fightDateStr,
    daysUntil,
    weeksUntil: Math.round(weeksUntil * 10) / 10,
    totalToLose: Math.round(totalToLose * 10) / 10,
    fatLossRequired,
    tempCut,
    tempCutDisplayed,
    requiredWeeklyRate,
    requiredWeeklyRatePct,
    recommendedWeeklyRate,
    recommendedWeeklyRatePct,
    weeklyRate: recommendedWeeklyRate,
    weeklyRatePct: recommendedWeeklyRatePct,
    dayMinus4Target,
    predictedWeekMinus1Weight: null,
    predictedDayMinus4Weight,
    status,
    statusLabel,
    weeklyTargets,
    suggestedDeficitKcal,
    manualTempReductionKg: hasManualTemp ? manualTempReductionKg : null,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

function deriveStatus(requiredWeeklyRatePct: number): { status: CutStatus; statusLabel: string } {
  if (requiredWeeklyRatePct <= 0.5) {
    return { status: "on_track", statusLabel: "Steady pace" };
  } else if (requiredWeeklyRatePct <= 1.0) {
    return { status: "on_track", statusLabel: "On track" };
  } else if (requiredWeeklyRatePct <= 1.5) {
    return { status: "aggressive", statusLabel: "Quite aggressive — consider extending timeline" };
  } else if (requiredWeeklyRatePct <= 2.0) {
    return { status: "very_aggressive", statusLabel: "Very aggressive — adjust target or date" };
  } else {
    return { status: "unrealistic", statusLabel: "Timeline too tight — adjust target or date" };
  }
}

/**
 * Build fat-loss trajectory weekly targets from currentWeight toward preFinalCutTarget
 * using the recommended (capped) weekly rate.
 * Returns empty if recommendedWeeklyRate is zero (athlete already at/below target).
 */
function buildWeeklyTargets(
  currentWeight: number,
  preFinalCutTarget: number,
  recommendedWeeklyRate: number,
  weeksForFatLoss: number,
): WeeklyTarget[] {
  if (recommendedWeeklyRate <= 0) return [];
  const targets: WeeklyTarget[] = [];
  const fullWeeks = Math.floor(weeksForFatLoss);
  const floorTarget = Math.round(preFinalCutTarget * 10) / 10;
  for (let w = 1; w <= fullWeeks; w++) {
    const projected = Math.round((currentWeight - recommendedWeeklyRate * w) * 10) / 10;
    targets.push({
      week: fullWeeks - w + 1,
      targetWeight: Math.max(floorTarget, projected),
    });
  }
  return targets;
}

/**
 * Return a zero/minimal result for edge cases (fight passed or already at weight).
 */
function earlyExit(
  currentWeight: number,
  targetWeight: number,
  fightDateStr: string,
  daysUntil: number,
  weeksUntil: number,
  totalToLose: number,
  manualTempReductionKg: number | null | undefined,
  hasManualTemp: boolean,
  status: CutStatus,
  statusLabel: string,
  weighInTiming: WeighInTiming,
): WeightCutPlanResult {
  return {
    currentWeight,
    targetWeight,
    fightDate: fightDateStr,
    daysUntil,
    weeksUntil: Math.round(weeksUntil * 10) / 10,
    totalToLose: Math.round(totalToLose * 10) / 10,
    fatLossRequired: 0,
    tempCut: 0,
    tempCutDisplayed: 0,
    requiredWeeklyRate: 0,
    requiredWeeklyRatePct: 0,
    recommendedWeeklyRate: 0,
    recommendedWeeklyRatePct: 0,
    weeklyRate: 0,
    weeklyRatePct: 0,
    dayMinus4Target: weighInTiming === "same_day" ? Math.round(targetWeight * 10) / 10 : null,
    predictedWeekMinus1Weight: weighInTiming === "day_before" ? targetWeight : null,
    predictedDayMinus4Weight: weighInTiming === "same_day" ? targetWeight : null,
    status,
    statusLabel,
    weeklyTargets: [],
    suggestedDeficitKcal: 0,
    manualTempReductionKg: hasManualTemp ? (manualTempReductionKg ?? null) : null,
  };
}
