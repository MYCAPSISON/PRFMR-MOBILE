import { 
  users, logs, foodEntries, weights, 
  supplements, supplementStacks, stackSupplements, stackReminders, supplementLogs, userDisclaimerAcceptance,
  supplementCatalog, supplementIntakes,
  exerciseCatalog, workoutSessions, workoutExercises, workoutSets, activityCatalog, sessionActivities,
  offProductMappings, customFoods, mealTemplates, mealTemplateItems, restDayLogs,
  type User, type InsertUser, type Log, type InsertLog, type FoodEntry, type InsertFoodEntry, type Weight, type InsertWeight,
  type Supplement, type InsertSupplement, type SupplementStack, type InsertSupplementStack,
  type StackSupplement, type InsertStackSupplement, type StackReminder, type InsertStackReminder,
  type SupplementLog, type InsertSupplementLog, type UserDisclaimerAcceptance, type InsertUserDisclaimerAcceptance,
  type SupplementCatalogItem, type InsertSupplementCatalogItem, type SupplementIntake, type InsertSupplementIntake,
  type ExerciseCatalogItem, type InsertExerciseCatalogItem, type WorkoutSession, type InsertWorkoutSession,
  type WorkoutExercise, type InsertWorkoutExercise, type WorkoutSet, type InsertWorkoutSet,
  type ActivityCatalogItem, type InsertActivityCatalogItem, type SessionActivity, type InsertSessionActivity,
  type OffProductMapping, type InsertOffProductMapping,
  type SleepLog, type InsertSleepLog,
  type WeightCutPlan, type InsertWeightCutPlan,
  type ProvisionalCheckin, type InsertProvisionalCheckin,
  type CustomFood, type InsertCustomFood,
  type MealTemplate, type InsertMealTemplate, type MealTemplateItem, type InsertMealTemplateItem,
  type Feedback, type InsertFeedback,
  feedbackAttachments,
  type FeedbackAttachment, type InsertFeedbackAttachment
} from "@shared/schema";

export interface IStorage {
  getUser(username: string): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByAuthId(authUserId: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(username: string, user: Partial<InsertUser>): Promise<User>;
  getLogs(userId: number): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
  updateLog(id: number, log: Partial<InsertLog>): Promise<Log>;
  getFoodEntries(userId: number, date: string): Promise<FoodEntry[]>;
  getFoodEntriesRange(userId: number, startDate: string, endDate: string): Promise<FoodEntry[]>;
  createFoodEntry(entry: InsertFoodEntry): Promise<FoodEntry>;
  updateFoodEntry(id: number, entry: Partial<InsertFoodEntry>): Promise<FoodEntry>;
  deleteFoodEntry(id: number): Promise<void>;
  getWeightsRange(userId: number, startDate: string, endDate: string): Promise<Weight[]>;
  upsertWeight(entry: InsertWeight): Promise<Weight>;
  deleteWeight(id: number): Promise<void>;
  
  // Supplements
  getSupplements(userId: number): Promise<Supplement[]>;
  getSupplement(id: number): Promise<Supplement | undefined>;
  createSupplement(supplement: InsertSupplement): Promise<Supplement>;
  updateSupplement(id: number, supplement: Partial<InsertSupplement>): Promise<Supplement>;
  deleteSupplement(id: number): Promise<void>;
  
  // Stacks
  getStacks(userId: number): Promise<SupplementStack[]>;
  getStack(id: number): Promise<SupplementStack | undefined>;
  createStack(stack: InsertSupplementStack): Promise<SupplementStack>;
  updateStack(id: number, stack: Partial<InsertSupplementStack>): Promise<SupplementStack>;
  deleteStack(id: number): Promise<void>;
  
  // Stack-Supplement relationships
  getStackSupplements(stackId: number): Promise<StackSupplement[]>;
  addSupplementToStack(entry: InsertStackSupplement): Promise<StackSupplement>;
  removeSupplementFromStack(stackId: number, supplementId: number): Promise<void>;
  
  // Reminders
  getStackReminders(stackId: number): Promise<StackReminder[]>;
  getAllRemindersForUser(userId: number): Promise<StackReminder[]>;
  getTodaysRemindersForUser(userId: number): Promise<Array<StackReminder & { stackName: string }>>;
  createReminder(reminder: InsertStackReminder): Promise<StackReminder>;
  updateReminder(id: number, reminder: Partial<InsertStackReminder>): Promise<StackReminder>;
  deleteReminder(id: number): Promise<void>;
  
  // Supplement Logs
  getSupplementLogs(userId: number, date: string): Promise<SupplementLog[]>;
  createSupplementLog(log: InsertSupplementLog): Promise<SupplementLog>;
  deleteSupplementLog(id: number): Promise<void>;
  
  // Disclaimer acceptance
  getDisclaimerAcceptance(userId: number, type: string): Promise<UserDisclaimerAcceptance | undefined>;
  createDisclaimerAcceptance(acceptance: InsertUserDisclaimerAcceptance): Promise<UserDisclaimerAcceptance>;
  
  // Supplement Catalog
  getSupplementCatalog(query?: string): Promise<SupplementCatalogItem[]>;
  getSupplementCatalogItem(id: number): Promise<SupplementCatalogItem | undefined>;
  
  // Supplement Intakes
  getSupplementIntakes(userId: number, date: string): Promise<SupplementIntake[]>;
  getSupplementIntakesRange(userId: number, startDate: string, endDate: string): Promise<SupplementIntake[]>;
  createSupplementIntake(intake: InsertSupplementIntake): Promise<SupplementIntake>;
  updateSupplementIntake(id: number, intake: Partial<InsertSupplementIntake>): Promise<SupplementIntake>;
  deleteSupplementIntake(id: number): Promise<void>;
  
  // Training - Exercise Catalog
  getExerciseCatalog(query?: string): Promise<ExerciseCatalogItem[]>;
  getExerciseCatalogItem(id: number): Promise<ExerciseCatalogItem | undefined>;
  
  // Training - Activity Catalog
  getActivityCatalog(query?: string): Promise<ActivityCatalogItem[]>;
  getActivityCatalogItem(id: number): Promise<ActivityCatalogItem | undefined>;
  
  // Training - Workout Sessions
  getWorkoutSessions(userId: number, startDate: string, endDate: string): Promise<WorkoutSession[]>;
  getWorkoutSession(id: number): Promise<WorkoutSession | undefined>;
  createWorkoutSession(session: InsertWorkoutSession): Promise<WorkoutSession>;
  updateWorkoutSession(id: number, session: Partial<InsertWorkoutSession>): Promise<WorkoutSession>;
  deleteWorkoutSession(id: number): Promise<void>;
  
  // Training - Workout Exercises
  getWorkoutExercises(sessionId: number): Promise<WorkoutExercise[]>;
  getWorkoutExercise(id: number): Promise<WorkoutExercise | undefined>;
  createWorkoutExercise(exercise: InsertWorkoutExercise): Promise<WorkoutExercise>;
  updateWorkoutExercise(id: number, exercise: Partial<InsertWorkoutExercise>): Promise<WorkoutExercise>;
  deleteWorkoutExercise(id: number): Promise<void>;
  
  // Training - Workout Sets
  getWorkoutSets(exerciseId: number): Promise<WorkoutSet[]>;
  createWorkoutSet(set: InsertWorkoutSet): Promise<WorkoutSet>;
  updateWorkoutSet(id: number, set: Partial<InsertWorkoutSet>): Promise<WorkoutSet>;
  deleteWorkoutSet(id: number): Promise<void>;
  
  // Training - Session Activities
  getSessionActivities(sessionId: number): Promise<SessionActivity[]>;
  getSessionActivity(id: number): Promise<SessionActivity | undefined>;
  createSessionActivity(activity: InsertSessionActivity): Promise<SessionActivity>;
  updateSessionActivity(id: number, activity: Partial<InsertSessionActivity>): Promise<SessionActivity>;
  deleteSessionActivity(id: number): Promise<void>;
  
  // OFF Product Mappings
  getOffMappingByBarcode(barcode: string): Promise<OffProductMapping | undefined>;
  upsertOffMapping(mapping: InsertOffProductMapping): Promise<OffProductMapping>;
  getAllOffMappings(): Promise<OffProductMapping[]>;
  
  // Food Entries with Micronutrient Tracking
  getFoodEntriesWithMicrosCount(userId: number, date: string): Promise<{ total: number; withMicros: number }>;
  
  // Custom Foods (User's "My Database")
  getCustomFoods(userId: number, query?: string, limit?: number): Promise<CustomFood[]>;
  getCustomFood(id: number): Promise<CustomFood | undefined>;
  getCustomFoodByBarcode(userId: number, barcode: string): Promise<CustomFood | undefined>;
  createCustomFood(food: InsertCustomFood): Promise<CustomFood>;
  updateCustomFood(id: number, food: Partial<InsertCustomFood>): Promise<CustomFood>;
  deleteCustomFood(id: number): Promise<void>;
  
  // Meal Templates (Saved Meals)
  getMealTemplates(userId: number): Promise<MealTemplate[]>;
  getMealTemplate(id: number): Promise<MealTemplate | undefined>;
  createMealTemplate(template: InsertMealTemplate): Promise<MealTemplate>;
  deleteMealTemplate(id: number): Promise<void>;
  getMealTemplateItems(templateId: number): Promise<MealTemplateItem[]>;
  createMealTemplateItem(item: InsertMealTemplateItem): Promise<MealTemplateItem>;
  createMealTemplateItems(items: InsertMealTemplateItem[]): Promise<MealTemplateItem[]>;
  createFoodEntries(entries: InsertFoodEntry[]): Promise<FoodEntry[]>;

  // Feedback
  createFeedback(fb: InsertFeedback): Promise<Feedback>;
  getUserFeedback(userId: number, limit?: number): Promise<Feedback[]>;
  createFeedbackAttachments(attachments: InsertFeedbackAttachment[]): Promise<FeedbackAttachment[]>;
  getFeedbackAttachments(feedbackId: number): Promise<FeedbackAttachment[]>;

  // Sleep Logs
  getSleepLog(userId: number, date: string): Promise<SleepLog | undefined>;
  upsertSleepLog(data: InsertSleepLog): Promise<SleepLog>;
  getSleepLogsRange(userId: number, startDate: string, endDate: string): Promise<SleepLog[]>;

  // Rest Day Logs
  getRestDayLog(userId: number, date: string): Promise<boolean>;
  setRestDayLog(userId: number, date: string): Promise<void>;
  deleteRestDayLog(userId: number, date: string): Promise<void>;

  // Weight Cut Plans
  getWeightCutPlan(userId: number): Promise<WeightCutPlan | undefined>;
  createWeightCutPlan(data: InsertWeightCutPlan): Promise<WeightCutPlan>;
  updateWeightCutPlan(id: number, updates: Partial<InsertWeightCutPlan>): Promise<WeightCutPlan>;
  deleteWeightCutPlan(id: number): Promise<void>;
  // Provisional Check-ins
  getProvisionalCheckin(userId: number, date: string): Promise<ProvisionalCheckin | undefined>;
  upsertProvisionalCheckin(data: InsertProvisionalCheckin): Promise<ProvisionalCheckin>;
  // Training load overrides
  getLoadOverride(userId: number, date: string): Promise<string | null>;
  upsertLoadOverride(userId: number, date: string, classification: string): Promise<void>;
  deleteLoadOverride(userId: number, date: string): Promise<void>;

  // Training Block Planner
  createTrainingBlock(
    userId: number,
    data: { name: string; startDate: string; weekCount: number },
    days: { dayOfWeek: number; plannedLoad: string; activities: import("@shared/schema").BlockActivityTemplate[]; notes?: string | null }[]
  ): Promise<any>;
  getActiveTrainingBlock(userId: number): Promise<any>;
  archiveTrainingBlock(userId: number, blockId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private logs: Map<number, Log>;
  private foodEntries: Map<number, FoodEntry>;
  private weights: Map<number, Weight>;
  private supplementsMap: Map<number, Supplement>;
  private stacksMap: Map<number, SupplementStack>;
  private stackSupplementsMap: Map<number, StackSupplement>;
  private remindersMap: Map<number, StackReminder>;
  private supplementLogsMap: Map<number, SupplementLog>;
  private disclaimerAcceptancesMap: Map<number, UserDisclaimerAcceptance>;
  private supplementCatalogMap: Map<number, SupplementCatalogItem>;
  private supplementIntakesMap: Map<number, SupplementIntake>;
  private exerciseCatalogMap: Map<number, ExerciseCatalogItem>;
  private activityCatalogMap: Map<number, ActivityCatalogItem>;
  private workoutSessionsMap: Map<number, WorkoutSession>;
  private workoutExercisesMap: Map<number, WorkoutExercise>;
  private workoutSetsMap: Map<number, WorkoutSet>;
  private sessionActivitiesMap: Map<number, SessionActivity>;
  private mealTemplatesMap: Map<number, MealTemplate>;
  private mealTemplateItemsMap: Map<number, MealTemplateItem>;
  
  private userIdCounter: number;
  private logIdCounter: number;
  private foodIdCounter: number;
  private weightIdCounter: number;
  private supplementIdCounter: number;
  private stackIdCounter: number;
  private stackSupplementIdCounter: number;
  private reminderIdCounter: number;
  private supplementLogIdCounter: number;
  private disclaimerIdCounter: number;
  private supplementIntakeIdCounter: number;
  private workoutSessionIdCounter: number;
  private workoutExerciseIdCounter: number;
  private workoutSetIdCounter: number;
  private sessionActivityIdCounter: number;
  private mealTemplateIdCounter: number;
  private mealTemplateItemIdCounter: number;

  constructor() {
    this.users = new Map();
    this.logs = new Map();
    this.foodEntries = new Map();
    this.weights = new Map();
    this.supplementsMap = new Map();
    this.stacksMap = new Map();
    this.stackSupplementsMap = new Map();
    this.remindersMap = new Map();
    this.supplementLogsMap = new Map();
    this.disclaimerAcceptancesMap = new Map();
    this.supplementCatalogMap = new Map();
    this.supplementIntakesMap = new Map();
    this.exerciseCatalogMap = new Map();
    this.activityCatalogMap = new Map();
    this.workoutSessionsMap = new Map();
    this.workoutExercisesMap = new Map();
    this.workoutSetsMap = new Map();
    this.sessionActivitiesMap = new Map();
    this.mealTemplatesMap = new Map();
    this.mealTemplateItemsMap = new Map();
    
    this.userIdCounter = 1;
    this.logIdCounter = 1;
    this.foodIdCounter = 1;
    this.weightIdCounter = 1;
    this.supplementIdCounter = 1;
    this.stackIdCounter = 1;
    this.stackSupplementIdCounter = 1;
    this.reminderIdCounter = 1;
    this.supplementLogIdCounter = 1;
    this.disclaimerIdCounter = 1;
    this.supplementIntakeIdCounter = 1;
    this.workoutSessionIdCounter = 1;
    this.workoutExerciseIdCounter = 1;
    this.workoutSetIdCounter = 1;
    this.sessionActivityIdCounter = 1;
    this.mealTemplateIdCounter = 1;
    this.mealTemplateItemIdCounter = 1;
    
    this.seedSupplementCatalog();
    this.seedExerciseCatalog();
    this.seedActivityCatalog();
  }
  
  private seedSupplementCatalog() {
    const catalogItems: Omit<SupplementCatalogItem, "id">[] = [
      { name: "Vitamin D3", defaultUnit: "mcg", microsPerUnit: { vitamin_d_ug: 1 }, notes: "Also available in IU (1 IU = 0.025 mcg)" },
      { name: "Vitamin D3 (IU)", defaultUnit: "IU", microsPerUnit: { vitamin_d_ug: 0.025 }, notes: "1 IU = 0.025 mcg" },
      { name: "Magnesium Glycinate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: "Highly bioavailable form" },
      { name: "Magnesium Citrate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: null },
      { name: "Zinc", defaultUnit: "mg", microsPerUnit: { zinc_mg: 1 }, notes: null },
      { name: "Iron", defaultUnit: "mg", microsPerUnit: { iron_mg: 1 }, notes: "Best absorbed with vitamin C" },
      { name: "Vitamin B12", defaultUnit: "mcg", microsPerUnit: { vitamin_b12_ug: 1 }, notes: "Essential for vegans" },
      { name: "Folate (5-MTHF)", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Active form of folate" },
      { name: "Folic Acid", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Synthetic form" },
      { name: "Calcium", defaultUnit: "mg", microsPerUnit: { calcium_mg: 1 }, notes: "Take separately from iron/zinc" },
      { name: "Iodine", defaultUnit: "mcg", microsPerUnit: { iodine_ug: 1 }, notes: null },
      { name: "Selenium", defaultUnit: "mcg", microsPerUnit: { selenium_ug: 1 }, notes: null },
      { name: "Vitamin C", defaultUnit: "mg", microsPerUnit: { vitamin_c_mg: 1 }, notes: "Enhances iron absorption" },
      { name: "Vitamin A", defaultUnit: "mcg", microsPerUnit: { vitamin_a_ug: 1 }, notes: "RAE (Retinol Activity Equivalents)" },
      { name: "Potassium", defaultUnit: "mg", microsPerUnit: { potassium_mg: 1 }, notes: null },
      { name: "Omega-3 (EPA/DHA)", defaultUnit: "mg", microsPerUnit: {}, notes: "Combined EPA+DHA content" },
      { name: "Fish Oil", defaultUnit: "mg", microsPerUnit: {}, notes: "Check EPA/DHA content on label" },
      { name: "Creatine Monohydrate", defaultUnit: "g", microsPerUnit: {}, notes: "Standard dose 3-5g daily" },
      { name: "Vitamin K2 (MK-7)", defaultUnit: "mcg", microsPerUnit: {}, notes: "Synergistic with Vitamin D" },
      { name: "Vitamin E", defaultUnit: "mg", microsPerUnit: {}, notes: null },
      { name: "Biotin", defaultUnit: "mcg", microsPerUnit: {}, notes: "B7 - Hair, skin, nails" },
      { name: "CoQ10", defaultUnit: "mg", microsPerUnit: {}, notes: "Ubiquinone or Ubiquinol" },
      { name: "Ashwagandha", defaultUnit: "mg", microsPerUnit: {}, notes: "Adaptogen" },
      { name: "Turmeric/Curcumin", defaultUnit: "mg", microsPerUnit: {}, notes: "Take with black pepper for absorption" },
      { name: "Probiotics", defaultUnit: "CFU", microsPerUnit: {}, notes: "Colony Forming Units" },
      { name: "Vitamin B Complex", defaultUnit: "serving", microsPerUnit: { vitamin_b12_ug: 2.4, folate_ug: 400 }, notes: "Contains multiple B vitamins" },
      { name: "Multivitamin", defaultUnit: "serving", microsPerUnit: { vitamin_d_ug: 10, vitamin_c_mg: 80, iron_mg: 14, zinc_mg: 10, selenium_ug: 55, vitamin_b12_ug: 2.5, folate_ug: 200, vitamin_a_ug: 800, calcium_mg: 200, magnesium_mg: 100, iodine_ug: 150 }, notes: "Amounts vary by brand - update based on your label" },
      { name: "Electrolytes", defaultUnit: "serving", microsPerUnit: { potassium_mg: 200, magnesium_mg: 60 }, notes: "Amounts vary by product" },
      { name: "Collagen Peptides", defaultUnit: "g", microsPerUnit: {}, notes: "Protein supplement" },
      { name: "L-Theanine", defaultUnit: "mg", microsPerUnit: {}, notes: "Often paired with caffeine" },
    ];
    
    let id = 1;
    for (const item of catalogItems) {
      this.supplementCatalogMap.set(id, { ...item, id });
      id++;
    }
  }

  private seedExerciseCatalog() {
    const exercises: Omit<ExerciseCatalogItem, "id">[] = [
      // Push exercises
      { name: "Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
      { name: "Incline Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
      { name: "Decline Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
      { name: "Dumbbell Bench Press", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
      { name: "Incline Dumbbell Press", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
      { name: "Overhead Press", category: "push", equipment: "barbell", primaryMuscle: "shoulders", isCommon: true },
      { name: "Dumbbell Shoulder Press", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
      { name: "Arnold Press", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
      { name: "Push-Up", category: "push", equipment: "bodyweight", primaryMuscle: "chest", isCommon: true },
      { name: "Dips", category: "push", equipment: "bodyweight", primaryMuscle: "triceps", isCommon: true },
      { name: "Tricep Pushdown", category: "push", equipment: "cable", primaryMuscle: "triceps", isCommon: true },
      { name: "Skull Crushers", category: "push", equipment: "barbell", primaryMuscle: "triceps", isCommon: true },
      { name: "Overhead Tricep Extension", category: "push", equipment: "dumbbell", primaryMuscle: "triceps", isCommon: true },
      { name: "Chest Fly", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
      { name: "Cable Fly", category: "push", equipment: "cable", primaryMuscle: "chest", isCommon: true },
      { name: "Lateral Raise", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
      { name: "Front Raise", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
      { name: "Machine Chest Press", category: "push", equipment: "machine", primaryMuscle: "chest", isCommon: true },
      { name: "Machine Shoulder Press", category: "push", equipment: "machine", primaryMuscle: "shoulders", isCommon: true },
      // Pull exercises
      { name: "Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Conventional Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Sumo Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Romanian Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "hamstrings", isCommon: true },
      { name: "Bent Over Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Dumbbell Row", category: "pull", equipment: "dumbbell", primaryMuscle: "back", isCommon: true },
      { name: "Pendlay Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Pull-Up", category: "pull", equipment: "bodyweight", primaryMuscle: "back", isCommon: true },
      { name: "Chin-Up", category: "pull", equipment: "bodyweight", primaryMuscle: "back", isCommon: true },
      { name: "Lat Pulldown", category: "pull", equipment: "cable", primaryMuscle: "back", isCommon: true },
      { name: "Seated Cable Row", category: "pull", equipment: "cable", primaryMuscle: "back", isCommon: true },
      { name: "T-Bar Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
      { name: "Face Pull", category: "pull", equipment: "cable", primaryMuscle: "rear delts", isCommon: true },
      { name: "Rear Delt Fly", category: "pull", equipment: "dumbbell", primaryMuscle: "rear delts", isCommon: true },
      { name: "Barbell Curl", category: "pull", equipment: "barbell", primaryMuscle: "biceps", isCommon: true },
      { name: "Dumbbell Curl", category: "pull", equipment: "dumbbell", primaryMuscle: "biceps", isCommon: true },
      { name: "Hammer Curl", category: "pull", equipment: "dumbbell", primaryMuscle: "biceps", isCommon: true },
      { name: "Preacher Curl", category: "pull", equipment: "barbell", primaryMuscle: "biceps", isCommon: true },
      { name: "Cable Curl", category: "pull", equipment: "cable", primaryMuscle: "biceps", isCommon: true },
      { name: "Shrugs", category: "pull", equipment: "barbell", primaryMuscle: "traps", isCommon: true },
      // Leg exercises
      { name: "Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
      { name: "Back Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
      { name: "Front Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
      { name: "Goblet Squat", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
      { name: "Leg Press", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
      { name: "Hack Squat", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
      { name: "Lunges", category: "legs", equipment: "bodyweight", primaryMuscle: "quads", isCommon: true },
      { name: "Walking Lunges", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
      { name: "Bulgarian Split Squat", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
      { name: "Step Ups", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
      { name: "Leg Extension", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
      { name: "Leg Curl", category: "legs", equipment: "machine", primaryMuscle: "hamstrings", isCommon: true },
      { name: "Seated Leg Curl", category: "legs", equipment: "machine", primaryMuscle: "hamstrings", isCommon: true },
      { name: "Hip Thrust", category: "legs", equipment: "barbell", primaryMuscle: "glutes", isCommon: true },
      { name: "Glute Bridge", category: "legs", equipment: "bodyweight", primaryMuscle: "glutes", isCommon: true },
      { name: "Cable Pull Through", category: "legs", equipment: "cable", primaryMuscle: "glutes", isCommon: true },
      { name: "Good Morning", category: "legs", equipment: "barbell", primaryMuscle: "hamstrings", isCommon: true },
      { name: "Calf Raise", category: "legs", equipment: "machine", primaryMuscle: "calves", isCommon: true },
      { name: "Seated Calf Raise", category: "legs", equipment: "machine", primaryMuscle: "calves", isCommon: true },
      { name: "Standing Calf Raise", category: "legs", equipment: "bodyweight", primaryMuscle: "calves", isCommon: true },
      { name: "Adductor Machine", category: "legs", equipment: "machine", primaryMuscle: "adductors", isCommon: true },
      { name: "Abductor Machine", category: "legs", equipment: "machine", primaryMuscle: "abductors", isCommon: true },
      // Core exercises
      { name: "Plank", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Side Plank", category: "core", equipment: "bodyweight", primaryMuscle: "obliques", isCommon: true },
      { name: "Crunch", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Sit-Up", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Leg Raise", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Hanging Leg Raise", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Russian Twist", category: "core", equipment: "bodyweight", primaryMuscle: "obliques", isCommon: true },
      { name: "Ab Wheel Rollout", category: "core", equipment: "other", primaryMuscle: "abs", isCommon: true },
      { name: "Cable Crunch", category: "core", equipment: "cable", primaryMuscle: "abs", isCommon: true },
      { name: "Dead Bug", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
      { name: "Bird Dog", category: "core", equipment: "bodyweight", primaryMuscle: "core", isCommon: true },
      // Full body
      { name: "Clean", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
      { name: "Clean and Jerk", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
      { name: "Snatch", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
      { name: "Power Clean", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
      { name: "Kettlebell Swing", category: "full_body", equipment: "kettlebell", primaryMuscle: "full body", isCommon: true },
      { name: "Thruster", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
      { name: "Burpee", category: "full_body", equipment: "bodyweight", primaryMuscle: "full body", isCommon: true },
      { name: "Turkish Get Up", category: "full_body", equipment: "kettlebell", primaryMuscle: "full body", isCommon: true },
      { name: "Farmer's Walk", category: "full_body", equipment: "dumbbell", primaryMuscle: "full body", isCommon: true },
    ];
    
    let id = 1;
    for (const exercise of exercises) {
      this.exerciseCatalogMap.set(id, { ...exercise, id });
      id++;
    }
  }

  private seedActivityCatalog() {
    const activities: Omit<ActivityCatalogItem, "id">[] = [
      // Running
      { name: "Running (easy pace)", intensity: "light", metValue: 6.0 },
      { name: "Running (moderate)", intensity: "moderate", metValue: 8.3 },
      { name: "Running (vigorous)", intensity: "vigorous", metValue: 11.0 },
      { name: "Jogging", intensity: "moderate", metValue: 7.0 },
      { name: "Sprinting", intensity: "vigorous", metValue: 14.5 },
      // Cycling - MET values based on speed ranges
      { name: "Cycling (leisure, <10 mph)", intensity: "light", metValue: 4.0 },
      { name: "Cycling (10-12 mph)", intensity: "moderate", metValue: 6.8 },
      { name: "Cycling (12-14 mph)", intensity: "moderate", metValue: 8.0 },
      { name: "Cycling (14-16 mph)", intensity: "vigorous", metValue: 10.0 },
      { name: "Cycling (16-19 mph)", intensity: "vigorous", metValue: 12.0 },
      { name: "Stationary Bike (light)", intensity: "light", metValue: 3.5 },
      { name: "Stationary Bike (moderate)", intensity: "moderate", metValue: 6.8 },
      { name: "Stationary Bike (vigorous)", intensity: "vigorous", metValue: 11.0 },
      // Swimming
      { name: "Swimming (leisure)", intensity: "light", metValue: 4.5 },
      { name: "Swimming (moderate)", intensity: "moderate", metValue: 7.0 },
      { name: "Swimming (laps, vigorous)", intensity: "vigorous", metValue: 9.8 },
      // Combat/Martial Arts - MET values from compendium
      { name: "Boxing (sparring)", intensity: "vigorous", metValue: 9.0 },
      { name: "Boxing (bag work)", intensity: "moderate", metValue: 5.5 },
      { name: "Kickboxing", intensity: "vigorous", metValue: 10.0 },
      { name: "Muay Thai", intensity: "vigorous", metValue: 10.3 },
      { name: "MMA Training", intensity: "vigorous", metValue: 10.0 },
      { name: "Wrestling", intensity: "vigorous", metValue: 9.0 },
      { name: "Jiu-Jitsu (rolling)", intensity: "vigorous", metValue: 8.0 },
      { name: "Judo", intensity: "vigorous", metValue: 10.0 },
      { name: "Karate (moderate)", intensity: "moderate", metValue: 6.5 },
      { name: "Karate (vigorous)", intensity: "vigorous", metValue: 10.0 },
      { name: "Taekwondo", intensity: "moderate", metValue: 6.5 },
      // Team Sports
      { name: "Football/Soccer (match)", intensity: "vigorous", metValue: 10.0 },
      { name: "Football/Soccer (training)", intensity: "moderate", metValue: 7.0 },
      { name: "Basketball (game)", intensity: "vigorous", metValue: 8.0 },
      { name: "Basketball (shooting around)", intensity: "light", metValue: 4.5 },
      { name: "Tennis (singles)", intensity: "vigorous", metValue: 8.0 },
      { name: "Tennis (doubles)", intensity: "moderate", metValue: 5.0 },
      { name: "Volleyball", intensity: "moderate", metValue: 4.0 },
      { name: "Rugby", intensity: "vigorous", metValue: 10.0 },
      { name: "American Football", intensity: "vigorous", metValue: 8.0 },
      { name: "Hockey", intensity: "vigorous", metValue: 8.0 },
      { name: "Lacrosse", intensity: "vigorous", metValue: 8.0 },
      // Cardio Machines
      { name: "Rowing Machine (moderate)", intensity: "moderate", metValue: 7.0 },
      { name: "Rowing Machine (vigorous)", intensity: "vigorous", metValue: 12.0 },
      { name: "Elliptical (moderate)", intensity: "moderate", metValue: 5.0 },
      { name: "Elliptical (vigorous)", intensity: "vigorous", metValue: 8.0 },
      { name: "Stair Climber (moderate)", intensity: "moderate", metValue: 6.0 },
      { name: "Stair Climber (vigorous)", intensity: "vigorous", metValue: 9.0 },
      // HIIT / Conditioning
      { name: "HIIT", intensity: "vigorous", metValue: 9.0 },
      { name: "Circuit Training", intensity: "vigorous", metValue: 8.0 },
      { name: "CrossFit WOD", intensity: "vigorous", metValue: 9.0 },
      { name: "Jump Rope (moderate)", intensity: "moderate", metValue: 8.8 },
      { name: "Jump Rope (fast)", intensity: "vigorous", metValue: 12.3 },
      { name: "Battle Ropes", intensity: "vigorous", metValue: 10.3 },
      // Walking / Hiking
      { name: "Walking (casual)", intensity: "light", metValue: 2.5 },
      { name: "Walking (brisk)", intensity: "moderate", metValue: 3.5 },
      { name: "Hiking (light)", intensity: "moderate", metValue: 5.3 },
      { name: "Hiking (steep/backpack)", intensity: "vigorous", metValue: 7.8 },
      // Other
      { name: "Yoga", intensity: "light", metValue: 2.5 },
      { name: "Pilates", intensity: "moderate", metValue: 3.0 },
      { name: "Stretching", intensity: "light", metValue: 2.3 },
      { name: "Dancing (moderate)", intensity: "moderate", metValue: 5.0 },
      { name: "Dancing (vigorous)", intensity: "vigorous", metValue: 7.8 },
      { name: "Rock Climbing", intensity: "vigorous", metValue: 8.0 },
      { name: "Skiing (downhill)", intensity: "moderate", metValue: 5.3 },
      { name: "Snowboarding", intensity: "moderate", metValue: 5.3 },
      { name: "Surfing", intensity: "moderate", metValue: 5.0 },
      { name: "Golf (walking)", intensity: "light", metValue: 4.3 },
    ];
    
    let id = 1;
    for (const activity of activities) {
      this.activityCatalogMap.set(id, { ...activity, id });
      id++;
    }
  }

  async getUser(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }
  
  async getUserById(userId: number): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.id === userId);
  }

  async getUserByAuthId(authUserId: number): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.authUserId === authUserId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, authUserId: insertUser.authUserId ?? null, profilePhotoUrl: insertUser.profilePhotoUrl ?? null, age: null, gender: null, height: null, currentWeight: null, activityLevel: null, goal: null, experienceLevel: null, targetCalories: null, targetProtein: null, targetCarbs: null, targetFat: null, usernameChangedAt: null };
    this.users.set(insertUser.username, user);
    return user;
  }

  async updateUser(username: string, updates: Partial<InsertUser>): Promise<User> {
    const user = await this.getUser(username);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...updates };
    this.users.set(username, updatedUser);
    return updatedUser;
  }

  async getLogs(userId: number): Promise<Log[]> {
    return Array.from(this.logs.values()).filter(log => log.userId === userId);
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const id = this.logIdCounter++;
    const log: Log = { 
      ...insertLog, 
      id, 
      weight: insertLog.weight ?? null,
      calories: insertLog.calories ?? 0, 
      protein: insertLog.protein ?? 0, 
      carbs: insertLog.carbs ?? 0, 
      fat: insertLog.fat ?? 0, 
      fibre: insertLog.fibre ?? 0 
    };
    this.logs.set(id, log);
    return log;
  }

  async updateLog(id: number, updates: Partial<InsertLog>): Promise<Log> {
    const log = this.logs.get(id);
    if (!log) throw new Error("Log not found");
    
    const updatedLog = { ...log, ...updates } as Log;
    this.logs.set(id, updatedLog);
    return updatedLog;
  }

  async getFoodEntries(userId: number, date: string): Promise<FoodEntry[]> {
    return Array.from(this.foodEntries.values()).filter(entry => entry.userId === userId && entry.date === date);
  }

  async getFoodEntriesRange(userId: number, startDate: string, endDate: string): Promise<FoodEntry[]> {
    return Array.from(this.foodEntries.values())
      .filter(entry => entry.userId === userId && entry.date >= startDate && entry.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async createFoodEntry(insertEntry: InsertFoodEntry): Promise<FoodEntry> {
    const id = this.foodIdCounter++;
    const entry: FoodEntry = { 
      ...insertEntry, 
      id,
      fibre: insertEntry.fibre ?? 0,
      grams: insertEntry.grams ?? 100,
      meal: insertEntry.meal ?? "lunch",
      snackIndex: insertEntry.snackIndex ?? null,
      sourceType: insertEntry.sourceType ?? "manual",
      offBarcode: insertEntry.offBarcode ?? null,
      ingredientIndex: insertEntry.ingredientIndex ?? null,
      macroSource: insertEntry.macroSource ?? "manual",
      microSource: insertEntry.microSource ?? "none",
    };
    this.foodEntries.set(id, entry);
    return entry;
  }

  async updateFoodEntry(id: number, updates: Partial<InsertFoodEntry>): Promise<FoodEntry> {
    const entry = this.foodEntries.get(id);
    if (!entry) throw new Error("Food entry not found");
    const updatedEntry = { ...entry, ...updates } as FoodEntry;
    this.foodEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteFoodEntry(id: number): Promise<void> {
    this.foodEntries.delete(id);
  }

  async getWeightsRange(userId: number, startDate: string, endDate: string): Promise<Weight[]> {
    return Array.from(this.weights.values())
      .filter(w => w.userId === userId && w.date >= startDate && w.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async upsertWeight(entry: InsertWeight): Promise<Weight> {
    const existing = Array.from(this.weights.values()).find(
      w => w.userId === entry.userId && w.date === entry.date
    );
    if (existing) {
      const updated: Weight = { ...existing, weight: entry.weight };
      this.weights.set(existing.id, updated);
      return updated;
    }
    const id = this.weightIdCounter++;
    const newWeight: Weight = { ...entry, id };
    this.weights.set(id, newWeight);
    return newWeight;
  }

  async deleteWeight(id: number): Promise<void> {
    this.weights.delete(id);
  }

  // Supplements
  async getSupplements(userId: number): Promise<Supplement[]> {
    return Array.from(this.supplementsMap.values()).filter(s => s.userId === userId);
  }

  async getSupplement(id: number): Promise<Supplement | undefined> {
    return this.supplementsMap.get(id);
  }

  async createSupplement(insert: InsertSupplement): Promise<Supplement> {
    const id = this.supplementIdCounter++;
    const supplement: Supplement = { 
      ...insert, 
      id, 
      brand: insert.brand ?? null,
      form: insert.form ?? null,
      notes: insert.notes ?? null,
      catalogId: insert.catalogId ?? null,
      doseAmount: insert.doseAmount ?? null,
      doseUnit: insert.doseUnit ?? null
    };
    this.supplementsMap.set(id, supplement);
    return supplement;
  }

  async updateSupplement(id: number, updates: Partial<InsertSupplement>): Promise<Supplement> {
    const supplement = this.supplementsMap.get(id);
    if (!supplement) throw new Error("Supplement not found");
    const updated = { ...supplement, ...updates } as Supplement;
    this.supplementsMap.set(id, updated);
    return updated;
  }

  async deleteSupplement(id: number): Promise<void> {
    this.supplementsMap.delete(id);
    // Also remove from any stacks
    Array.from(this.stackSupplementsMap.entries()).forEach(([key, ss]) => {
      if (ss.supplementId === id) this.stackSupplementsMap.delete(key);
    });
  }

  // Stacks
  async getStacks(userId: number): Promise<SupplementStack[]> {
    return Array.from(this.stacksMap.values()).filter(s => s.userId === userId);
  }

  async getStack(id: number): Promise<SupplementStack | undefined> {
    return this.stacksMap.get(id);
  }

  async createStack(insert: InsertSupplementStack): Promise<SupplementStack> {
    const id = this.stackIdCounter++;
    const stack: SupplementStack = { 
      ...insert, 
      id, 
      description: insert.description ?? null
    };
    this.stacksMap.set(id, stack);
    return stack;
  }

  async updateStack(id: number, updates: Partial<InsertSupplementStack>): Promise<SupplementStack> {
    const stack = this.stacksMap.get(id);
    if (!stack) throw new Error("Stack not found");
    const updated = { ...stack, ...updates } as SupplementStack;
    this.stacksMap.set(id, updated);
    return updated;
  }

  async deleteStack(id: number): Promise<void> {
    this.stacksMap.delete(id);
    // Remove stack supplements and reminders
    Array.from(this.stackSupplementsMap.entries()).forEach(([key, ss]) => {
      if (ss.stackId === id) this.stackSupplementsMap.delete(key);
    });
    Array.from(this.remindersMap.entries()).forEach(([key, r]) => {
      if (r.stackId === id) this.remindersMap.delete(key);
    });
  }

  // Stack-Supplement relationships
  async getStackSupplements(stackId: number): Promise<StackSupplement[]> {
    return Array.from(this.stackSupplementsMap.values()).filter(ss => ss.stackId === stackId);
  }

  async addSupplementToStack(insert: InsertStackSupplement): Promise<StackSupplement> {
    // Check if already exists
    const existing = Array.from(this.stackSupplementsMap.values()).find(
      ss => ss.stackId === insert.stackId && ss.supplementId === insert.supplementId
    );
    if (existing) return existing;
    
    const id = this.stackSupplementIdCounter++;
    const entry: StackSupplement = { ...insert, id };
    this.stackSupplementsMap.set(id, entry);
    return entry;
  }

  async removeSupplementFromStack(stackId: number, supplementId: number): Promise<void> {
    const entries = Array.from(this.stackSupplementsMap.entries());
    for (let i = 0; i < entries.length; i++) {
      const [key, ss] = entries[i];
      if (ss.stackId === stackId && ss.supplementId === supplementId) {
        this.stackSupplementsMap.delete(key);
        break;
      }
    }
  }

  // Reminders
  async getStackReminders(stackId: number): Promise<StackReminder[]> {
    return Array.from(this.remindersMap.values()).filter(r => r.stackId === stackId);
  }

  async getAllRemindersForUser(userId: number): Promise<StackReminder[]> {
    const userStacks = await this.getStacks(userId);
    const stackIds = new Set(userStacks.map(s => s.id));
    return Array.from(this.remindersMap.values()).filter(r => stackIds.has(r.stackId));
  }

  async getTodaysRemindersForUser(userId: number): Promise<Array<StackReminder & { stackName: string }>> {
    const userStacks = await this.getStacks(userId);
    const stackMap = new Map(userStacks.map(s => [s.id, s.name]));
    const reminders = Array.from(this.remindersMap.values()).filter(
      r => r.enabled && stackMap.has(r.stackId)
    );
    return reminders.map(r => ({
      ...r,
      stackName: stackMap.get(r.stackId) || "Unknown Stack",
      daysOfWeek: r.daysOfWeek
    }));
  }

  async createReminder(insert: InsertStackReminder): Promise<StackReminder> {
    const id = this.reminderIdCounter++;
    const reminder: StackReminder = { 
      ...insert, 
      id,
      enabled: insert.enabled ?? true
    };
    this.remindersMap.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: number, updates: Partial<InsertStackReminder>): Promise<StackReminder> {
    const reminder = this.remindersMap.get(id);
    if (!reminder) throw new Error("Reminder not found");
    const updated = { ...reminder, ...updates } as StackReminder;
    this.remindersMap.set(id, updated);
    return updated;
  }

  async deleteReminder(id: number): Promise<void> {
    this.remindersMap.delete(id);
  }

  // Supplement Logs
  async getSupplementLogs(userId: number, date: string): Promise<SupplementLog[]> {
    return Array.from(this.supplementLogsMap.values()).filter(
      l => l.userId === userId && l.date === date
    );
  }

  async createSupplementLog(insert: InsertSupplementLog): Promise<SupplementLog> {
    const id = this.supplementLogIdCounter++;
    const log: SupplementLog = { 
      ...insert, 
      id,
      stackId: insert.stackId ?? null,
      time: insert.time ?? null,
      taken: insert.taken ?? true
    };
    this.supplementLogsMap.set(id, log);
    return log;
  }

  async deleteSupplementLog(id: number): Promise<void> {
    this.supplementLogsMap.delete(id);
  }

  // Disclaimer acceptance
  async getDisclaimerAcceptance(userId: number, type: string): Promise<UserDisclaimerAcceptance | undefined> {
    return Array.from(this.disclaimerAcceptancesMap.values()).find(
      a => a.userId === userId && a.disclaimerType === type
    );
  }

  async createDisclaimerAcceptance(insert: InsertUserDisclaimerAcceptance): Promise<UserDisclaimerAcceptance> {
    const id = this.disclaimerIdCounter++;
    const acceptance: UserDisclaimerAcceptance = { ...insert, id };
    this.disclaimerAcceptancesMap.set(id, acceptance);
    return acceptance;
  }

  // Supplement Catalog
  async getSupplementCatalog(query?: string): Promise<SupplementCatalogItem[]> {
    const items = Array.from(this.supplementCatalogMap.values());
    if (!query || query.trim() === "") return items;
    const q = query.toLowerCase();
    return items.filter(item => item.name.toLowerCase().includes(q));
  }

  async getSupplementCatalogItem(id: number): Promise<SupplementCatalogItem | undefined> {
    return this.supplementCatalogMap.get(id);
  }

  // Supplement Intakes
  async getSupplementIntakes(userId: number, date: string): Promise<SupplementIntake[]> {
    return Array.from(this.supplementIntakesMap.values()).filter(
      i => i.userId === userId && i.date === date
    );
  }

  async getSupplementIntakesRange(userId: number, startDate: string, endDate: string): Promise<SupplementIntake[]> {
    return Array.from(this.supplementIntakesMap.values()).filter(
      i => i.userId === userId && i.date >= startDate && i.date <= endDate
    );
  }

  async createSupplementIntake(insert: InsertSupplementIntake): Promise<SupplementIntake> {
    const id = this.supplementIntakeIdCounter++;
    const intake: SupplementIntake = {
      ...insert,
      id,
      stackId: insert.stackId ?? null,
      reminderId: insert.reminderId ?? null,
      taken: insert.taken ?? true,
      takenAt: insert.takenAt ?? null
    };
    this.supplementIntakesMap.set(id, intake);
    return intake;
  }

  async updateSupplementIntake(id: number, updates: Partial<InsertSupplementIntake>): Promise<SupplementIntake> {
    const intake = this.supplementIntakesMap.get(id);
    if (!intake) throw new Error("Supplement intake not found");
    const updated = { ...intake, ...updates } as SupplementIntake;
    this.supplementIntakesMap.set(id, updated);
    return updated;
  }

  async deleteSupplementIntake(id: number): Promise<void> {
    this.supplementIntakesMap.delete(id);
  }

  // Training - Exercise Catalog
  async getExerciseCatalog(query?: string): Promise<ExerciseCatalogItem[]> {
    const items = Array.from(this.exerciseCatalogMap.values());
    if (!query || query.trim() === "") return items;
    const q = query.toLowerCase();
    return items.filter(item => 
      item.name.toLowerCase().includes(q) || 
      item.category.toLowerCase().includes(q) ||
      item.primaryMuscle.toLowerCase().includes(q)
    );
  }

  async getExerciseCatalogItem(id: number): Promise<ExerciseCatalogItem | undefined> {
    return this.exerciseCatalogMap.get(id);
  }

  // Training - Activity Catalog
  async getActivityCatalog(query?: string): Promise<ActivityCatalogItem[]> {
    const items = Array.from(this.activityCatalogMap.values());
    if (!query || query.trim() === "") return items;
    const q = query.toLowerCase();
    return items.filter(item => item.name.toLowerCase().includes(q));
  }

  async getActivityCatalogItem(id: number): Promise<ActivityCatalogItem | undefined> {
    return this.activityCatalogMap.get(id);
  }

  // Training - Workout Sessions
  async getWorkoutSessions(userId: number, startDate: string, endDate: string): Promise<WorkoutSession[]> {
    return Array.from(this.workoutSessionsMap.values())
      .filter(s => s.userId === userId && s.date >= startDate && s.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async getWorkoutSession(id: number): Promise<WorkoutSession | undefined> {
    return this.workoutSessionsMap.get(id);
  }

  async createWorkoutSession(insert: InsertWorkoutSession): Promise<WorkoutSession> {
    const id = this.workoutSessionIdCounter++;
    const session: WorkoutSession = {
      ...insert,
      id,
      title: insert.title ?? null,
      notes: insert.notes ?? null,
      durationMinutes: insert.durationMinutes ?? null,
      intensity: insert.intensity ?? null,
      estimatedMet: insert.estimatedMet ?? null,
      estimatedKcal: insert.estimatedKcal ?? 0,
      isPlanned: insert.isPlanned ?? false,
      trainingBlockId: insert.trainingBlockId ?? null,
    };
    this.workoutSessionsMap.set(id, session);
    return session;
  }

  async updateWorkoutSession(id: number, updates: Partial<InsertWorkoutSession>): Promise<WorkoutSession> {
    const session = this.workoutSessionsMap.get(id);
    if (!session) throw new Error("Workout session not found");
    const updated = { ...session, ...updates } as WorkoutSession;
    this.workoutSessionsMap.set(id, updated);
    return updated;
  }

  async deleteWorkoutSession(id: number): Promise<void> {
    this.workoutSessionsMap.delete(id);
    // Also delete exercises and activities for this session
    Array.from(this.workoutExercisesMap.entries()).forEach(([key, e]) => {
      if (e.sessionId === id) {
        // Delete sets for this exercise
        Array.from(this.workoutSetsMap.entries()).forEach(([setKey, s]) => {
          if (s.workoutExerciseId === e.id) this.workoutSetsMap.delete(setKey);
        });
        this.workoutExercisesMap.delete(key);
      }
    });
    Array.from(this.sessionActivitiesMap.entries()).forEach(([key, a]) => {
      if (a.sessionId === id) this.sessionActivitiesMap.delete(key);
    });
  }

  // Training - Workout Exercises
  async getWorkoutExercises(sessionId: number): Promise<WorkoutExercise[]> {
    return Array.from(this.workoutExercisesMap.values())
      .filter(e => e.sessionId === sessionId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getWorkoutExercise(id: number): Promise<WorkoutExercise | undefined> {
    return this.workoutExercisesMap.get(id);
  }

  async createWorkoutExercise(insert: InsertWorkoutExercise): Promise<WorkoutExercise> {
    const id = this.workoutExerciseIdCounter++;
    const exercise: WorkoutExercise = {
      id,
      sessionId: insert.sessionId,
      name: insert.name,
      exerciseCatalogId: insert.exerciseCatalogId ?? null,
      orderIndex: insert.orderIndex ?? 0,
      intensity: insert.intensity ?? "moderate",
      durationMinutes: insert.durationMinutes ?? null,
      estimatedKcal: insert.estimatedKcal ?? 0,
    };
    this.workoutExercisesMap.set(id, exercise);
    return exercise;
  }

  async updateWorkoutExercise(id: number, updates: Partial<InsertWorkoutExercise>): Promise<WorkoutExercise> {
    const exercise = this.workoutExercisesMap.get(id);
    if (!exercise) throw new Error("Workout exercise not found");
    // Convert undefined values to null for compatibility
    const cleanUpdates: Record<string, any> = {};
    for (const [key, value] of Object.entries(updates)) {
      cleanUpdates[key] = value === undefined ? null : value;
    }
    const updated: WorkoutExercise = { ...exercise, ...cleanUpdates };
    this.workoutExercisesMap.set(id, updated);
    return updated;
  }

  async deleteWorkoutExercise(id: number): Promise<void> {
    // Delete sets for this exercise
    Array.from(this.workoutSetsMap.entries()).forEach(([key, s]) => {
      if (s.workoutExerciseId === id) this.workoutSetsMap.delete(key);
    });
    this.workoutExercisesMap.delete(id);
  }

  // Training - Workout Sets
  async getWorkoutSets(exerciseId: number): Promise<WorkoutSet[]> {
    return Array.from(this.workoutSetsMap.values())
      .filter(s => s.workoutExerciseId === exerciseId)
      .sort((a, b) => a.setIndex - b.setIndex);
  }

  async createWorkoutSet(insert: InsertWorkoutSet): Promise<WorkoutSet> {
    const id = this.workoutSetIdCounter++;
    const set: WorkoutSet = {
      ...insert,
      id,
      weightKg: insert.weightKg ?? null,
      rpe: insert.rpe ?? null,
      restSeconds: insert.restSeconds ?? null,
      tempo: insert.tempo ?? null,
      durationSeconds: insert.durationSeconds ?? null
    };
    this.workoutSetsMap.set(id, set);
    return set;
  }

  async updateWorkoutSet(id: number, updates: Partial<InsertWorkoutSet>): Promise<WorkoutSet> {
    const set = this.workoutSetsMap.get(id);
    if (!set) throw new Error("Workout set not found");
    const updated = { ...set, ...updates } as WorkoutSet;
    this.workoutSetsMap.set(id, updated);
    return updated;
  }

  async deleteWorkoutSet(id: number): Promise<void> {
    this.workoutSetsMap.delete(id);
  }

  // Training - Session Activities
  async getSessionActivities(sessionId: number): Promise<SessionActivity[]> {
    return Array.from(this.sessionActivitiesMap.values())
      .filter(a => a.sessionId === sessionId);
  }

  async getSessionActivity(id: number): Promise<SessionActivity | undefined> {
    return this.sessionActivitiesMap.get(id);
  }

  async createSessionActivity(insert: InsertSessionActivity): Promise<SessionActivity> {
    const id = this.sessionActivityIdCounter++;
    const activity: SessionActivity = {
      ...insert,
      id,
      activityCatalogId: insert.activityCatalogId ?? null,
      estimatedKcal: insert.estimatedKcal ?? 0,
      activityType: insert.activityType ?? "cardio",
      sessionRpe: insert.sessionRpe ?? null,
      bodyRegion: insert.bodyRegion ?? null,
      trainingLoadScore: insert.trainingLoadScore ?? null,
      rpe: insert.rpe ?? null,
    };
    this.sessionActivitiesMap.set(id, activity);
    return activity;
  }

  async updateSessionActivity(id: number, updates: Partial<InsertSessionActivity>): Promise<SessionActivity> {
    const activity = this.sessionActivitiesMap.get(id);
    if (!activity) throw new Error("Session activity not found");
    const updated = { ...activity, ...updates } as SessionActivity;
    this.sessionActivitiesMap.set(id, updated);
    return updated;
  }

  async deleteSessionActivity(id: number): Promise<void> {
    this.sessionActivitiesMap.delete(id);
  }

  // OFF Product Mappings - stub implementations for MemStorage
  private offMappingsMap: Map<string, OffProductMapping> = new Map();
  private offMappingIdCounter: number = 1;

  async getOffMappingByBarcode(barcode: string): Promise<OffProductMapping | undefined> {
    return this.offMappingsMap.get(barcode);
  }

  async upsertOffMapping(mapping: InsertOffProductMapping): Promise<OffProductMapping> {
    const existing = this.offMappingsMap.get(mapping.barcode);
    if (existing) {
      const updated = { ...existing, ...mapping, updatedAt: new Date() };
      this.offMappingsMap.set(mapping.barcode, updated);
      return updated;
    }
    const id = this.offMappingIdCounter++;
    const created: OffProductMapping = {
      id,
      barcode: mapping.barcode,
      offName: mapping.offName,
      offBrand: mapping.offBrand ?? null,
      offCategories: mapping.offCategories ?? null,
      ingredientIndex: mapping.ingredientIndex,
      ingredientName: mapping.ingredientName,
      matchConfidence: mapping.matchConfidence ?? "low",
      matchMethod: mapping.matchMethod ?? "user_selected",
      verifiedByUser: mapping.verifiedByUser ?? false,
      updatedAt: new Date(),
    };
    this.offMappingsMap.set(mapping.barcode, created);
    return created;
  }

  async getAllOffMappings(): Promise<OffProductMapping[]> {
    return Array.from(this.offMappingsMap.values());
  }

  async getFoodEntriesWithMicrosCount(userId: number, date: string): Promise<{ total: number; withMicros: number }> {
    const entries = await this.getFoodEntries(userId, date);
    const total = entries.length;
    const withMicros = entries.filter(e => e.ingredientIndex !== null && e.microSource === "internal").length;
    return { total, withMicros };
  }

  // Custom Foods - in-memory stub implementations (database storage is used in production)
  private customFoodsMap: Map<number, CustomFood> = new Map();
  private customFoodIdCounter = 1;

  async getCustomFoods(userId: number, query?: string, limit?: number): Promise<CustomFood[]> {
    let foods = Array.from(this.customFoodsMap.values()).filter(f => f.userId === userId);
    if (query) {
      const q = query.toLowerCase();
      foods = foods.filter(f => f.name.toLowerCase().includes(q) || f.brand?.toLowerCase().includes(q));
    }
    foods.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return limit ? foods.slice(0, limit) : foods;
  }

  async getCustomFood(id: number): Promise<CustomFood | undefined> {
    return this.customFoodsMap.get(id);
  }

  async getCustomFoodByBarcode(userId: number, barcode: string): Promise<CustomFood | undefined> {
    return Array.from(this.customFoodsMap.values()).find(f => f.userId === userId && f.barcode === barcode);
  }

  async createCustomFood(food: InsertCustomFood): Promise<CustomFood> {
    const id = this.customFoodIdCounter++;
    const created: CustomFood = {
      ...food,
      id,
      brand: food.brand ?? null,
      servingSizeG: food.servingSizeG ?? null,
      proteinPer100g: food.proteinPer100g ?? null,
      carbsPer100g: food.carbsPer100g ?? null,
      fatPer100g: food.fatPer100g ?? null,
      fibrePer100g: food.fibrePer100g ?? null,
      saltPer100g: food.saltPer100g ?? null,
      sugarPer100g: food.sugarPer100g ?? null,
      barcode: food.barcode ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.customFoodsMap.set(id, created);
    return created;
  }

  async updateCustomFood(id: number, updates: Partial<InsertCustomFood>): Promise<CustomFood> {
    const existing = this.customFoodsMap.get(id);
    if (!existing) throw new Error("Custom food not found");
    const updated = { ...existing, ...updates, updatedAt: new Date() };
    this.customFoodsMap.set(id, updated);
    return updated;
  }

  async deleteCustomFood(id: number): Promise<void> {
    this.customFoodsMap.delete(id);
  }

  async getMealTemplates(userId: number): Promise<MealTemplate[]> {
    return Array.from(this.mealTemplatesMap.values())
      .filter(t => t.userId === userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async getMealTemplate(id: number): Promise<MealTemplate | undefined> {
    return this.mealTemplatesMap.get(id);
  }

  async createMealTemplate(template: InsertMealTemplate): Promise<MealTemplate> {
    const id = this.mealTemplateIdCounter++;
    const created: MealTemplate = {
      ...template,
      id,
      defaultMeal: template.defaultMeal ?? null,
    };
    this.mealTemplatesMap.set(id, created);
    return created;
  }

  async deleteMealTemplate(id: number): Promise<void> {
    this.mealTemplatesMap.delete(id);
    for (const [itemId, item] of this.mealTemplateItemsMap) {
      if (item.templateId === id) this.mealTemplateItemsMap.delete(itemId);
    }
  }

  async getMealTemplateItems(templateId: number): Promise<MealTemplateItem[]> {
    return Array.from(this.mealTemplateItemsMap.values())
      .filter(i => i.templateId === templateId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }

  async createMealTemplateItem(item: InsertMealTemplateItem): Promise<MealTemplateItem> {
    const id = this.mealTemplateItemIdCounter++;
    const created: MealTemplateItem = {
      ...item,
      id,
      grams: item.grams ?? 100,
      fibre: item.fibre ?? 0,
      sourceType: item.sourceType ?? "manual",
      ingredientIndex: item.ingredientIndex ?? null,
      offBarcode: item.offBarcode ?? null,
      macroSource: item.macroSource ?? "manual",
      microSource: item.microSource ?? "none",
      sortOrder: item.sortOrder ?? 0,
    };
    this.mealTemplateItemsMap.set(id, created);
    return created;
  }

  async createMealTemplateItems(items: InsertMealTemplateItem[]): Promise<MealTemplateItem[]> {
    return Promise.all(items.map(i => this.createMealTemplateItem(i)));
  }

  async createFoodEntries(entries: InsertFoodEntry[]): Promise<FoodEntry[]> {
    return Promise.all(entries.map(e => this.createFoodEntry(e)));
  }

  private feedbackMap: Map<number, Feedback> = new Map();
  private feedbackIdCounter: number = 1;

  async createFeedback(fb: InsertFeedback): Promise<Feedback> {
    const id = this.feedbackIdCounter++;
    const created: Feedback = {
      ...fb,
      id,
      route: fb.route ?? null,
      userAgent: fb.userAgent ?? null,
      viewport: fb.viewport ?? null,
      appVersion: fb.appVersion ?? null,
      status: "new",
      createdAt: new Date(),
    };
    this.feedbackMap.set(id, created);
    return created;
  }

  async getUserFeedback(userId: number, limit: number = 10): Promise<Feedback[]> {
    return Array.from(this.feedbackMap.values())
      .filter(f => f.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  private feedbackAttachmentsMap: Map<number, FeedbackAttachment> = new Map();
  private feedbackAttachmentIdCounter: number = 1;

  async createFeedbackAttachments(attachments: InsertFeedbackAttachment[]): Promise<FeedbackAttachment[]> {
    return attachments.map(a => {
      const id = this.feedbackAttachmentIdCounter++;
      const created: FeedbackAttachment = {
        ...a,
        id,
        createdAt: new Date(),
      };
      this.feedbackAttachmentsMap.set(id, created);
      return created;
    });
  }

  async getFeedbackAttachments(feedbackId: number): Promise<FeedbackAttachment[]> {
    return Array.from(this.feedbackAttachmentsMap.values())
      .filter(a => a.feedbackId === feedbackId);
  }

  private sleepLogsMap: Map<string, SleepLog> = new Map();
  private sleepLogIdCounter: number = 1;

  async getSleepLog(userId: number, date: string): Promise<SleepLog | undefined> {
    return this.sleepLogsMap.get(`${userId}-${date}`);
  }

  async upsertSleepLog(data: InsertSleepLog): Promise<SleepLog> {
    const key = `${data.userId}-${data.date}`;
    const existing = this.sleepLogsMap.get(key);
    if (existing) {
      const updated: SleepLog = { ...existing, ...data, updatedAt: new Date() };
      this.sleepLogsMap.set(key, updated);
      return updated;
    }
    const id = this.sleepLogIdCounter++;
    const log: SleepLog = { ...data, id, sleepQuality: data.sleepQuality ?? null, createdAt: new Date(), updatedAt: new Date() };
    this.sleepLogsMap.set(key, log);
    return log;
  }

  async getSleepLogsRange(userId: number, startDate: string, endDate: string): Promise<SleepLog[]> {
    return Array.from(this.sleepLogsMap.values())
      .filter(l => l.userId === userId && l.date >= startDate && l.date <= endDate);
  }

  async getRestDayLog(userId: number, date: string): Promise<boolean> {
    const [row] = await db
      .select({ id: restDayLogs.id })
      .from(restDayLogs)
      .where(and(eq(restDayLogs.userId, userId), eq(restDayLogs.date, date)))
      .limit(1);
    return !!row;
  }

  async setRestDayLog(userId: number, date: string): Promise<void> {
    await db
      .insert(restDayLogs)
      .values({ userId, date })
      .onConflictDoNothing();
  }

  async deleteRestDayLog(userId: number, date: string): Promise<void> {
    await db
      .delete(restDayLogs)
      .where(and(eq(restDayLogs.userId, userId), eq(restDayLogs.date, date)));
  }

  private weightCutPlansMap: Map<number, WeightCutPlan> = new Map();
  private weightCutPlanIdCounter: number = 1;

  async getWeightCutPlan(userId: number): Promise<WeightCutPlan | undefined> {
    return Array.from(this.weightCutPlansMap.values()).find(p => p.userId === userId);
  }

  async createWeightCutPlan(data: InsertWeightCutPlan): Promise<WeightCutPlan> {
    const id = this.weightCutPlanIdCounter++;
    const plan: WeightCutPlan = {
      ...data,
      id,
      weighInTiming: data.weighInTiming ?? "same_day",
      manualTempReductionKg: data.manualTempReductionKg ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.weightCutPlansMap.set(id, plan);
    return plan;
  }

  async updateWeightCutPlan(id: number, updates: Partial<InsertWeightCutPlan>): Promise<WeightCutPlan> {
    const plan = this.weightCutPlansMap.get(id);
    if (!plan) throw new Error("Weight cut plan not found");
    const updated: WeightCutPlan = { ...plan, ...updates, updatedAt: new Date() };
    this.weightCutPlansMap.set(id, updated);
    return updated;
  }

  async deleteWeightCutPlan(id: number): Promise<void> {
    this.weightCutPlansMap.delete(id);
  }

  private provisionalCheckinsMap: Map<string, ProvisionalCheckin> = new Map();
  private provisionalCheckinIdCounter: number = 1;

  async getProvisionalCheckin(userId: number, date: string): Promise<ProvisionalCheckin | undefined> {
    return this.provisionalCheckinsMap.get(`${userId}:${date}`);
  }

  async upsertProvisionalCheckin(data: InsertProvisionalCheckin): Promise<ProvisionalCheckin> {
    const existing = await this.getProvisionalCheckin(data.userId, data.date);
    if (existing) {
      const updated: ProvisionalCheckin = { ...existing, ...data, updatedAt: new Date() };
      this.provisionalCheckinsMap.set(`${data.userId}:${data.date}`, updated);
      return updated;
    }
    const id = this.provisionalCheckinIdCounter++;
    const created: ProvisionalCheckin = {
      ...data,
      id,
      trainedYesterday: data.trainedYesterday ?? null,
      yesterdayTrainingIntensity: data.yesterdayTrainingIntensity ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.provisionalCheckinsMap.set(`${data.userId}:${data.date}`, created);
    return created;
  }

  private loadOverridesMap: Map<string, string> = new Map();

  async getLoadOverride(userId: number, date: string): Promise<string | null> {
    return this.loadOverridesMap.get(`${userId}:${date}`) ?? null;
  }

  async upsertLoadOverride(userId: number, date: string, classification: string): Promise<void> {
    this.loadOverridesMap.set(`${userId}:${date}`, classification);
  }

  async deleteLoadOverride(userId: number, date: string): Promise<void> {
    this.loadOverridesMap.delete(`${userId}:${date}`);
  }

  async createTrainingBlock(_userId: number, _data: any, _days: any[]): Promise<any> { throw new Error("Not implemented"); }
  async getActiveTrainingBlock(_userId: number): Promise<any> { return null; }
  async archiveTrainingBlock(_userId: number, _blockId: number): Promise<void> {}
}

import { databaseStorage } from "./database-storage";

// Use PostgreSQL storage instead of in-memory storage
export const storage: IStorage = databaseStorage;
