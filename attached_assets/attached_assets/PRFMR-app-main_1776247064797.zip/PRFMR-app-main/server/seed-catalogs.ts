import { db } from "./db";
import { exerciseCatalog, activityCatalog, supplementCatalog } from "@shared/schema";
import { sql } from "drizzle-orm";

// Catalog table registry for audit purposes
export interface CatalogTableStatus {
  table: string;
  count: number;
  status: "ok" | "empty" | "seeded" | "error";
  error?: string;
}

export interface SeedAuditResult {
  environment: string;
  database: string;
  tables: CatalogTableStatus[];
  warnings: string[];
  seeded: boolean;
}

// Get catalog counts without seeding (for diagnostics)
export async function getCatalogStatus(): Promise<SeedAuditResult> {
  const environment = process.env.NODE_ENV || "development";
  const dbUrl = process.env.DATABASE_URL || "";
  const dbHost = dbUrl.match(/@([^:\/]+)/)?.[1] || "unknown";
  
  const tables: CatalogTableStatus[] = [];
  const warnings: string[] = [];
  
  try {
    const exerciseCount = Number((await db.select({ count: sql<number>`count(*)` }).from(exerciseCatalog))[0]?.count || 0);
    tables.push({
      table: "exercise_catalog",
      count: exerciseCount,
      status: exerciseCount > 0 ? "ok" : "empty"
    });
    if (exerciseCount === 0) warnings.push("exercise_catalog is empty - seeding required");
  } catch (error) {
    tables.push({ table: "exercise_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`exercise_catalog query failed: ${error}`);
  }
  
  try {
    const activityCount = Number((await db.select({ count: sql<number>`count(*)` }).from(activityCatalog))[0]?.count || 0);
    tables.push({
      table: "activity_catalog",
      count: activityCount,
      status: activityCount > 0 ? "ok" : "empty"
    });
    if (activityCount === 0) warnings.push("activity_catalog is empty - seeding required");
  } catch (error) {
    tables.push({ table: "activity_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`activity_catalog query failed: ${error}`);
  }
  
  try {
    const supplementCount = Number((await db.select({ count: sql<number>`count(*)` }).from(supplementCatalog))[0]?.count || 0);
    tables.push({
      table: "supplement_catalog",
      count: supplementCount,
      status: supplementCount > 0 ? "ok" : "empty"
    });
    if (supplementCount === 0) warnings.push("supplement_catalog is empty - seeding required");
  } catch (error) {
    tables.push({ table: "supplement_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`supplement_catalog query failed: ${error}`);
  }
  
  return {
    environment,
    database: dbHost,
    tables,
    warnings,
    seeded: false
  };
}

export async function seedCatalogsIfEmpty(): Promise<SeedAuditResult> {
  const environment = process.env.NODE_ENV || "development";
  const dbUrl = process.env.DATABASE_URL || "";
  const dbHost = dbUrl.match(/@([^:\/]+)/)?.[1] || "unknown";
  
  console.log(`[seed][audit] Starting catalog audit for ${environment} (db: ${dbHost})`);
  
  const tables: CatalogTableStatus[] = [];
  const warnings: string[] = [];
  let anySeeded = false;
  
  // Exercise Catalog
  try {
    const exerciseCount = Number((await db.select({ count: sql<number>`count(*)` }).from(exerciseCatalog))[0]?.count || 0);
    console.log(`[seed][audit] exercise_catalog: ${exerciseCount} rows`);
    
    if (exerciseCount === 0) {
      console.log("[seed][run] Seeding exercise_catalog...");
      await seedExercises();
      const newCount = Number((await db.select({ count: sql<number>`count(*)` }).from(exerciseCatalog))[0]?.count || 0);
      console.log(`[seed][run] exercise_catalog seeded with ${newCount} rows`);
      tables.push({ table: "exercise_catalog", count: newCount, status: "seeded" });
      anySeeded = true;
    } else {
      console.log(`[seed][skip] exercise_catalog already populated (${exerciseCount} rows)`);
      tables.push({ table: "exercise_catalog", count: exerciseCount, status: "ok" });
    }
  } catch (error) {
    console.error(`[seed][error] exercise_catalog failed:`, error);
    tables.push({ table: "exercise_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`exercise_catalog seeding failed: ${error}`);
  }
  
  // Activity Catalog — always upsert so new entries are added even when table already exists
  try {
    const beforeCount = Number((await db.select({ count: sql<number>`count(*)` }).from(activityCatalog))[0]?.count || 0);
    console.log(`[seed][audit] activity_catalog: ${beforeCount} rows`);
    await seedActivities();
    const afterCount = Number((await db.select({ count: sql<number>`count(*)` }).from(activityCatalog))[0]?.count || 0);
    const added = afterCount - beforeCount;
    if (added > 0) {
      console.log(`[seed][run] activity_catalog: added ${added} new entries (total ${afterCount})`);
      tables.push({ table: "activity_catalog", count: afterCount, status: "seeded" });
      anySeeded = true;
    } else {
      console.log(`[seed][skip] activity_catalog already up-to-date (${afterCount} rows)`);
      tables.push({ table: "activity_catalog", count: afterCount, status: "ok" });
    }
  } catch (error) {
    console.error(`[seed][error] activity_catalog failed:`, error);
    tables.push({ table: "activity_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`activity_catalog seeding failed: ${error}`);
  }
  
  // Supplement Catalog — always upsert so microsPerUnit fixes propagate to existing DBs
  try {
    const beforeCount = Number((await db.select({ count: sql<number>`count(*)` }).from(supplementCatalog))[0]?.count || 0);
    console.log(`[seed][audit] supplement_catalog: ${beforeCount} rows`);
    await seedSupplements();
    const afterCount = Number((await db.select({ count: sql<number>`count(*)` }).from(supplementCatalog))[0]?.count || 0);
    const added = afterCount - beforeCount;
    if (added > 0) {
      console.log(`[seed][run] supplement_catalog: added ${added} new entries (total ${afterCount})`);
      tables.push({ table: "supplement_catalog", count: afterCount, status: "seeded" });
      anySeeded = true;
    } else {
      console.log(`[seed][skip] supplement_catalog already up-to-date (${afterCount} rows)`);
      tables.push({ table: "supplement_catalog", count: afterCount, status: "ok" });
    }
  } catch (error) {
    console.error(`[seed][error] supplement_catalog failed:`, error);
    tables.push({ table: "supplement_catalog", count: 0, status: "error", error: String(error) });
    warnings.push(`supplement_catalog seeding failed: ${error}`);
  }
  
  // Check ingredients.json
  try {
    const fs = await import("fs");
    const path = await import("path");
    const ingredientData = JSON.parse(fs.readFileSync(path.join(process.cwd(), "data", "ingredients.json"), "utf-8"));
    const ingredientCount = Array.isArray(ingredientData) ? ingredientData.length : 0;
    tables.push({ table: "ingredients_json", count: ingredientCount, status: ingredientCount > 0 ? "ok" : "empty" });
    if (ingredientCount === 0) warnings.push("ingredients.json is empty or missing");
    console.log(`[seed][audit] ingredients_json: ${ingredientCount} entries`);
  } catch (error) {
    tables.push({ table: "ingredients_json", count: 0, status: "error", error: String(error) });
    warnings.push(`ingredients.json read failed: ${error}`);
  }

  // Final summary
  const emptyTables = tables.filter(t => t.status === "empty" || (t.status === "error" && t.count === 0));
  if (emptyTables.length > 0) {
    console.warn(`[seed][warning] ${emptyTables.length} catalog tables still empty after seeding!`);
    emptyTables.forEach(t => warnings.push(`${t.table} remains empty`));
  }
  
  const counts: Record<string, number> = {};
  tables.forEach(t => counts[t.table] = t.count);
  console.log(`[seed][counts] ${JSON.stringify(counts)}`);
  console.log(`[seed][audit] Complete: ${tables.map(t => `${t.table}=${t.count}`).join(", ")}`);
  
  return {
    environment,
    database: dbHost,
    tables,
    warnings,
    seeded: anySeeded
  };
}

async function seedSupplements() {
  const supplements = [
    { name: "Vitamin D3", defaultUnit: "mcg", microsPerUnit: { vitamin_d_ug: 1 }, notes: "Also available in IU (1 IU = 0.025 mcg)" },
    { name: "Vitamin D3 (IU)", defaultUnit: "IU", microsPerUnit: { vitamin_d_ug: 0.025 }, notes: "1 IU = 0.025 mcg" },
    { name: "Magnesium Glycinate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: "Highly bioavailable form" },
    { name: "Magnesium Citrate", defaultUnit: "mg", microsPerUnit: { magnesium_mg: 1 }, notes: null },
    { name: "Zinc", defaultUnit: "mg", microsPerUnit: { zinc_mg: 1 }, notes: null },
    { name: "Iron", defaultUnit: "mg", microsPerUnit: { iron_mg: 1 }, notes: "Best absorbed with vitamin C" },
    { name: "Vitamin B12", defaultUnit: "mcg", microsPerUnit: { vitamin_b12_ug: 1 }, notes: "Essential for vegans" },
    { name: "Folate (5-MTHF)", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Active form of folate" },
    { name: "Folic Acid", defaultUnit: "mcg", microsPerUnit: { folate_ug: 1 }, notes: "Synthetic form" },
    { name: "Calcium", defaultUnit: "mg", microsPerUnit: { calcium_mg: 1 }, notes: "Take separately from iron/zinc" },
    { name: "Iodine", defaultUnit: "mcg", microsPerUnit: { iodine_ug: 1 }, notes: null },
    { name: "Selenium", defaultUnit: "mcg", microsPerUnit: { selenium_ug: 1 }, notes: null },
    { name: "Vitamin C", defaultUnit: "mg", microsPerUnit: { vitamin_c_mg: 1 }, notes: "Enhances iron absorption" },
    { name: "Vitamin A", defaultUnit: "mcg", microsPerUnit: { vitamin_a_ug: 1 }, notes: "RAE (Retinol Activity Equivalents)" },
    { name: "Potassium", defaultUnit: "mg", microsPerUnit: { potassium_mg: 1 }, notes: null },
    // Omega-3: microsPerUnit maps mg of fish oil → g of omega-3 (assuming ~30% EPA/DHA content)
    { name: "Omega-3 Fish Oil", defaultUnit: "mg", microsPerUnit: { omega3_g: 0.0003 }, notes: "Assumes ~30% EPA+DHA (300mg per 1000mg capsule). Update if your label specifies exact EPA/DHA." },
    { name: "Omega-3 (EPA/DHA)", defaultUnit: "mg", microsPerUnit: { omega3_g: 0.001 }, notes: "Enter combined EPA+DHA mg directly (1mg = 0.001g)" },
    { name: "Fish Oil", defaultUnit: "mg", microsPerUnit: { omega3_g: 0.0003 }, notes: "Assumes ~30% EPA+DHA. Use Omega-3 (EPA/DHA) for exact values." },
    { name: "Creatine Monohydrate", defaultUnit: "g", microsPerUnit: {}, notes: "Standard dose 3-5g daily" },
    { name: "Vitamin K2 (MK-7)", defaultUnit: "mcg", microsPerUnit: {}, notes: "Synergistic with Vitamin D" },
    { name: "Vitamin E", defaultUnit: "mg", microsPerUnit: {}, notes: null },
    { name: "Biotin", defaultUnit: "mcg", microsPerUnit: {}, notes: "B7 - Hair, skin, nails" },
    { name: "CoQ10", defaultUnit: "mg", microsPerUnit: {}, notes: "Ubiquinone or Ubiquinol" },
    { name: "Ashwagandha", defaultUnit: "mg", microsPerUnit: {}, notes: "Adaptogen" },
    { name: "Turmeric/Curcumin", defaultUnit: "mg", microsPerUnit: {}, notes: "Take with black pepper for absorption" },
    { name: "Probiotics", defaultUnit: "CFU", microsPerUnit: {}, notes: "Colony Forming Units" },
    { name: "Vitamin B Complex", defaultUnit: "serving", microsPerUnit: { vitamin_b12_ug: 2.4, folate_ug: 400 }, notes: "Contains multiple B vitamins" },
    { name: "Multivitamin", defaultUnit: "serving", microsPerUnit: { vitamin_d_ug: 10, vitamin_c_mg: 80, iron_mg: 14, zinc_mg: 10, selenium_ug: 55, vitamin_b12_ug: 2.5, folate_ug: 200, vitamin_a_ug: 800, calcium_mg: 200, magnesium_mg: 100, iodine_ug: 150 }, notes: "Amounts vary by brand - update based on your label" },
    { name: "Electrolytes", defaultUnit: "serving", microsPerUnit: { potassium_mg: 200, magnesium_mg: 60 }, notes: "Amounts vary by product" },
    { name: "Collagen Peptides", defaultUnit: "g", microsPerUnit: {}, notes: "Protein supplement" },
    { name: "L-Theanine", defaultUnit: "mg", microsPerUnit: {}, notes: "Often paired with caffeine" },
  ];
  
  for (const supp of supplements) {
    await db.insert(supplementCatalog).values({
      name: supp.name,
      defaultUnit: supp.defaultUnit,
      microsPerUnit: supp.microsPerUnit,
      notes: supp.notes,
    }).onConflictDoUpdate({
      target: supplementCatalog.name,
      // Update microsPerUnit so fixes (like omega-3 mapping) propagate to existing DBs.
      // Do NOT overwrite defaultUnit — user data depends on it.
      set: { microsPerUnit: supp.microsPerUnit },
    });
  }
  console.log(`[Seed] Upserted ${supplements.length} supplements`);
}

async function seedExercises() {
  const exercises = [
    { name: "Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
    { name: "Incline Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
    { name: "Decline Bench Press", category: "push", equipment: "barbell", primaryMuscle: "chest", isCommon: true },
    { name: "Dumbbell Bench Press", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
    { name: "Incline Dumbbell Press", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
    { name: "Overhead Press", category: "push", equipment: "barbell", primaryMuscle: "shoulders", isCommon: true },
    { name: "Dumbbell Shoulder Press", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
    { name: "Arnold Press", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
    { name: "Push-Up", category: "push", equipment: "bodyweight", primaryMuscle: "chest", isCommon: true },
    { name: "Dips", category: "push", equipment: "bodyweight", primaryMuscle: "triceps", isCommon: true },
    { name: "Tricep Pushdown", category: "push", equipment: "cable", primaryMuscle: "triceps", isCommon: true },
    { name: "Skull Crushers", category: "push", equipment: "barbell", primaryMuscle: "triceps", isCommon: true },
    { name: "Overhead Tricep Extension", category: "push", equipment: "dumbbell", primaryMuscle: "triceps", isCommon: true },
    { name: "Chest Fly", category: "push", equipment: "dumbbell", primaryMuscle: "chest", isCommon: true },
    { name: "Cable Fly", category: "push", equipment: "cable", primaryMuscle: "chest", isCommon: true },
    { name: "Lateral Raise", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
    { name: "Front Raise", category: "push", equipment: "dumbbell", primaryMuscle: "shoulders", isCommon: true },
    { name: "Machine Chest Press", category: "push", equipment: "machine", primaryMuscle: "chest", isCommon: true },
    { name: "Machine Shoulder Press", category: "push", equipment: "machine", primaryMuscle: "shoulders", isCommon: true },
    { name: "Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Conventional Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Sumo Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Romanian Deadlift", category: "pull", equipment: "barbell", primaryMuscle: "hamstrings", isCommon: true },
    { name: "Bent Over Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Dumbbell Row", category: "pull", equipment: "dumbbell", primaryMuscle: "back", isCommon: true },
    { name: "Pendlay Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Pull-Up", category: "pull", equipment: "bodyweight", primaryMuscle: "back", isCommon: true },
    { name: "Chin-Up", category: "pull", equipment: "bodyweight", primaryMuscle: "back", isCommon: true },
    { name: "Lat Pulldown", category: "pull", equipment: "cable", primaryMuscle: "back", isCommon: true },
    { name: "Seated Cable Row", category: "pull", equipment: "cable", primaryMuscle: "back", isCommon: true },
    { name: "T-Bar Row", category: "pull", equipment: "barbell", primaryMuscle: "back", isCommon: true },
    { name: "Face Pull", category: "pull", equipment: "cable", primaryMuscle: "rear delts", isCommon: true },
    { name: "Rear Delt Fly", category: "pull", equipment: "dumbbell", primaryMuscle: "rear delts", isCommon: true },
    { name: "Barbell Curl", category: "pull", equipment: "barbell", primaryMuscle: "biceps", isCommon: true },
    { name: "Dumbbell Curl", category: "pull", equipment: "dumbbell", primaryMuscle: "biceps", isCommon: true },
    { name: "Hammer Curl", category: "pull", equipment: "dumbbell", primaryMuscle: "biceps", isCommon: true },
    { name: "Preacher Curl", category: "pull", equipment: "barbell", primaryMuscle: "biceps", isCommon: true },
    { name: "Cable Curl", category: "pull", equipment: "cable", primaryMuscle: "biceps", isCommon: true },
    { name: "Shrugs", category: "pull", equipment: "barbell", primaryMuscle: "traps", isCommon: true },
    { name: "Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
    { name: "Back Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
    { name: "Front Squat", category: "legs", equipment: "barbell", primaryMuscle: "quads", isCommon: true },
    { name: "Goblet Squat", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
    { name: "Leg Press", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
    { name: "Hack Squat", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
    { name: "Lunges", category: "legs", equipment: "bodyweight", primaryMuscle: "quads", isCommon: true },
    { name: "Walking Lunges", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
    { name: "Bulgarian Split Squat", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
    { name: "Step Ups", category: "legs", equipment: "dumbbell", primaryMuscle: "quads", isCommon: true },
    { name: "Leg Extension", category: "legs", equipment: "machine", primaryMuscle: "quads", isCommon: true },
    { name: "Leg Curl", category: "legs", equipment: "machine", primaryMuscle: "hamstrings", isCommon: true },
    { name: "Seated Leg Curl", category: "legs", equipment: "machine", primaryMuscle: "hamstrings", isCommon: true },
    { name: "Hip Thrust", category: "legs", equipment: "barbell", primaryMuscle: "glutes", isCommon: true },
    { name: "Glute Bridge", category: "legs", equipment: "bodyweight", primaryMuscle: "glutes", isCommon: true },
    { name: "Cable Pull Through", category: "legs", equipment: "cable", primaryMuscle: "glutes", isCommon: true },
    { name: "Good Morning", category: "legs", equipment: "barbell", primaryMuscle: "hamstrings", isCommon: true },
    { name: "Calf Raise", category: "legs", equipment: "machine", primaryMuscle: "calves", isCommon: true },
    { name: "Seated Calf Raise", category: "legs", equipment: "machine", primaryMuscle: "calves", isCommon: true },
    { name: "Standing Calf Raise", category: "legs", equipment: "bodyweight", primaryMuscle: "calves", isCommon: true },
    { name: "Adductor Machine", category: "legs", equipment: "machine", primaryMuscle: "adductors", isCommon: true },
    { name: "Abductor Machine", category: "legs", equipment: "machine", primaryMuscle: "abductors", isCommon: true },
    { name: "Plank", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Side Plank", category: "core", equipment: "bodyweight", primaryMuscle: "obliques", isCommon: true },
    { name: "Crunch", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Sit-Up", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Leg Raise", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Hanging Leg Raise", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Russian Twist", category: "core", equipment: "bodyweight", primaryMuscle: "obliques", isCommon: true },
    { name: "Ab Wheel Rollout", category: "core", equipment: "other", primaryMuscle: "abs", isCommon: true },
    { name: "Cable Crunch", category: "core", equipment: "cable", primaryMuscle: "abs", isCommon: true },
    { name: "Dead Bug", category: "core", equipment: "bodyweight", primaryMuscle: "abs", isCommon: true },
    { name: "Bird Dog", category: "core", equipment: "bodyweight", primaryMuscle: "core", isCommon: true },
    { name: "Clean", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
    { name: "Clean and Jerk", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
    { name: "Snatch", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
    { name: "Power Clean", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
    { name: "Kettlebell Swing", category: "full_body", equipment: "kettlebell", primaryMuscle: "full body", isCommon: true },
    { name: "Thruster", category: "full_body", equipment: "barbell", primaryMuscle: "full body", isCommon: true },
    { name: "Burpee", category: "full_body", equipment: "bodyweight", primaryMuscle: "full body", isCommon: true },
    { name: "Turkish Get Up", category: "full_body", equipment: "kettlebell", primaryMuscle: "full body", isCommon: true },
    { name: "Farmer's Walk", category: "full_body", equipment: "dumbbell", primaryMuscle: "full body", isCommon: true },
  ];
  
  await db.insert(exerciseCatalog).values(exercises);
}

async function seedActivities() {
  // All MET values sourced from 2024 Compendium of Physical Activities where available.
  // Formula: kcal/min = MET × 3.5 × bodyweight(kg) / 200
  const activities = [
    // ── RUNNING ────────────────────────────────────────────────────────
    // Comp 12150 (general running ~8 mph) = 8.0; easy pace ~5 mph ≈ 6.0
    { name: "Running (easy pace)", intensity: "light", metValue: 6.0 },
    // ~6 mph (10 min/mile) ≈ 9.8; moderate label = 8.3 is conservative estimate
    { name: "Running (moderate)", intensity: "moderate", metValue: 8.3 },
    // ~7 mph (8.5 min/mile) ≈ 11.0  [was 9.8 — updated per Compendium speed table]
    { name: "Running (vigorous)", intensity: "vigorous", metValue: 11.0 },
    // 14 mph = 23 MET (Compendium running speed table)
    { name: "Running (sprints)", intensity: "vigorous", metValue: 23.0 },
    // Comp 12200 (running on track, team practice) = 10.0; trail ≈ 9.0
    { name: "Trail Running", intensity: "vigorous", metValue: 9.0 },
    // Comp 12150 "Running (Taylor Code 200)" = 8.0 — general slow jog
    { name: "Jogging", intensity: "moderate", metValue: 8.0 },
    // ── CYCLING ────────────────────────────────────────────────────────
    // Comp 01010 (<10 mph, leisure) = 4.0
    { name: "Cycling (easy)", intensity: "light", metValue: 4.0 },
    // Comp 01020 (10-11.9 mph) = 6.8
    { name: "Cycling (moderate)", intensity: "moderate", metValue: 6.8 },
    // Comp 01040 (14-15.9 mph, vigorous) = 10.0
    { name: "Cycling (vigorous)", intensity: "vigorous", metValue: 10.0 },
    // Comp 01210 (25-30 W, very light) = 3.5
    { name: "Stationary Bike (easy)", intensity: "light", metValue: 3.5 },
    // Comp 01224 (101-125 W) = 6.8
    { name: "Stationary Bike (moderate)", intensity: "moderate", metValue: 6.8 },
    // Comp 01236 (200-229 W) = 10.8 → rounded to 11.0  [was 10.5]
    { name: "Stationary Bike (vigorous)", intensity: "vigorous", metValue: 11.0 },
    // Comp 01270 — Bicycling, stationary, RPM/Spin bike class = 9.0
    { name: "Spin Class (RPM)", intensity: "vigorous", metValue: 9.0 },
    // Comp 01009 — Mountain biking, general = 8.5
    { name: "Mountain Biking", intensity: "vigorous", metValue: 8.5 },
    // ── SWIMMING ───────────────────────────────────────────────────────
    // Comp 18310 — Swimming leisurely, not lap = 6.0
    { name: "Swimming (leisure)", intensity: "light", metValue: 6.0 },
    // Comp 18292 — Freestyle, slow (30-45 yds/min) = 5.8; moderate estimate = 7.0
    { name: "Swimming Laps (moderate)", intensity: "moderate", metValue: 7.0 },
    // Comp 18230 — Freestyle, fast, vigorous = 9.8
    { name: "Swimming Laps (vigorous)", intensity: "vigorous", metValue: 9.8 },
    // Comp 18285 — Open water 5k = 10.5; general open water ≈ 8.0
    { name: "Open Water Swimming", intensity: "vigorous", metValue: 8.0 },
    // Comp 18255 — Backstroke, recreational = 4.8 → 5.0
    { name: "Swimming (backstroke)", intensity: "moderate", metValue: 5.0 },
    // Comp 18265 — Breaststroke, recreational = 5.3
    { name: "Swimming (breaststroke)", intensity: "moderate", metValue: 5.3 },
    // ── WALKING & HIKING ───────────────────────────────────────────────
    // Comp 17170 — Walking 2.5 mph = 3.0; leisure < 2.5 mph ≈ 2.5
    { name: "Walking (leisure)", intensity: "light", metValue: 2.5 },
    // Comp 17200 — Walking 3.5-3.9 mph, brisk = 4.8; 4.3 is conservative  
    { name: "Walking (brisk)", intensity: "moderate", metValue: 4.3 },
    // Trail hiking, moderate grade ≈ 6.0
    { name: "Hiking", intensity: "moderate", metValue: 6.0 },
    // Steep trails / heavy pack ≈ 8.3
    { name: "Hiking (steep/difficult)", intensity: "vigorous", metValue: 8.3 },
    // Comp 02065 — Stair treadmill ergometer = 9.3  [was 8.0]
    { name: "Stair Climbing", intensity: "vigorous", metValue: 9.3 },
    // Comp 02065 (dedicated stair machine/stepper)
    { name: "Stair Machine", intensity: "vigorous", metValue: 9.3 },
    // ── ROWING & CARDIO MACHINES ───────────────────────────────────────
    // Comp 02071 — Rowing ergometer <100 W, moderate = 5.0; general moderate ≈ 7.0
    { name: "Rowing Machine (moderate)", intensity: "moderate", metValue: 7.0 },
    // Comp 02073/74 — 150-199 W = 11.0, ≥200 W = 14.0; vigorous midpoint = 12.0
    { name: "Rowing Machine (vigorous)", intensity: "vigorous", metValue: 12.0 },
    // Comp 02048 — Elliptical, moderate = 5.0
    { name: "Elliptical (moderate)", intensity: "moderate", metValue: 5.0 },
    // Comp 02049 — Elliptical, vigorous = 9.0  [was 8.0]
    { name: "Elliptical (vigorous)", intensity: "vigorous", metValue: 9.0 },
    // Comp 12600 — Skipping 5.5-6 mph = 11.5; general rope skipping ≈ 11.0
    { name: "Jump Rope", intensity: "vigorous", metValue: 11.0 },
    // Fast/double-under ≈ 12.3 (between rope skipping and sprint-pace running)
    { name: "Jump Rope (fast)", intensity: "vigorous", metValue: 12.3 },
    // ── COMBAT SPORTS ──────────────────────────────────────────────────
    // Comp 15100 — Boxing in ring, general = 12.3
    { name: "Boxing (in ring)", intensity: "vigorous", metValue: 12.3 },
    // Comp 15120 — Boxing, sparring = 7.8
    { name: "Boxing (sparring)", intensity: "vigorous", metValue: 7.8 },
    // Comp 15113-15118 — Punching bag 60-120 b/min = 7.0-8.5; ~7.8 midpoint  [was 5.5]
    { name: "Boxing (bag work)", intensity: "vigorous", metValue: 7.8 },
    // Comp 15125 — Simulated boxing round/exercise = 9.3; light shadow = 5.5
    { name: "Boxing (shadowboxing)", intensity: "moderate", metValue: 5.5 },
    // Comp 15457 — Kickboxing, general = 7.3; vigorous bag work ≈ 10.0
    { name: "Kickboxing (bag work)", intensity: "vigorous", metValue: 10.0 },
    // Comp 15430 — Martial arts moderate pace (incl. kickboxing) = 10.3
    { name: "Kickboxing (sparring)", intensity: "vigorous", metValue: 10.3 },
    // Comp 15430 — Martial arts moderate pace (incl. Muay Thai) = 10.3
    { name: "Muay Thai (bag work / pad work)", intensity: "vigorous", metValue: 10.0 },
    { name: "Muay Thai (sparring)", intensity: "vigorous", metValue: 10.3 },
    // Comp 15430 — Martial arts, moderate pace (judo, karate, kickboxing, MMA) = 10.3
    { name: "Mixed Martial Arts", intensity: "vigorous", metValue: 10.3 },
    // Comp 15430 — Martial arts general = 10.3
    { name: "Martial Arts (general)", intensity: "vigorous", metValue: 10.3 },
    // Comp 15425 — Martial arts, slower pace, novice = 5.3; moderate-vigorous = 10.3
    { name: "Karate", intensity: "vigorous", metValue: 10.3 },
    // Comp 15432 — Taekwondo general ≈ 10.3 (combat simulation = 14.3)
    { name: "Taekwondo", intensity: "vigorous", metValue: 10.3 },
    // Comp 15433 — Judo = 11.3  [was 10.0]
    { name: "Judo/Jiu-Jitsu", intensity: "vigorous", metValue: 11.3 },
    // Comp 15730 — Wrestling competitive = 6.0/match; full session ≈ 8.0  [was 6.0]
    { name: "Wrestling", intensity: "vigorous", metValue: 8.0 },
    // ── TEAM SPORTS ────────────────────────────────────────────────────
    // Comp 15040 — Basketball, game = 8.0
    { name: "Basketball (game)", intensity: "vigorous", metValue: 8.0 },
    // Comp 15050 — Basketball, non-game general = 6.0
    { name: "Basketball (casual)", intensity: "moderate", metValue: 6.0 },
    // Comp 15230 — Football, touch/flag = 8.0
    { name: "Football (touch/flag)", intensity: "moderate", metValue: 8.0 },
    // Comp 15210 — Football, competitive = 8.0
    { name: "Football (competitive)", intensity: "vigorous", metValue: 8.0 },
    // Comp 15610 — Soccer, casual = 7.0
    { name: "Soccer (casual)", intensity: "moderate", metValue: 7.0 },
    // Comp 15605 — Soccer, competitive = 9.5  [was 10.0]
    { name: "Soccer (competitive)", intensity: "vigorous", metValue: 9.5 },
    // Comp 15560 — Rugby union, competitive = 8.3
    { name: "Rugby (competitive)", intensity: "vigorous", metValue: 8.3 },
    // Comp 15562 — Rugby, touch, non-competitive = 6.3
    { name: "Rugby (touch)", intensity: "moderate", metValue: 6.3 },
    // ── RACKET SPORTS ──────────────────────────────────────────────────
    // Comp 15690 — Tennis, singles = 8.0
    { name: "Tennis (singles)", intensity: "vigorous", metValue: 8.0 },
    // Comp 15680 — Tennis, doubles = 6.0
    { name: "Tennis (doubles)", intensity: "moderate", metValue: 6.0 },
    // Comp 15650 — Squash (Taylor Code 530) = 12.0 (competitive); 15652 general = 7.3
    { name: "Squash", intensity: "vigorous", metValue: 12.0 },
    // Comp — Badminton = 5.5
    { name: "Badminton", intensity: "moderate", metValue: 5.5 },
    // Comp 15660 — Table tennis / ping pong = 4.0
    { name: "Table Tennis", intensity: "light", metValue: 4.0 },
    // Comp 15710 — Volleyball = 4.0
    { name: "Volleyball", intensity: "moderate", metValue: 4.0 },
    // Beach volleyball (sand adds intensity) ≈ 8.0
    { name: "Beach Volleyball", intensity: "vigorous", metValue: 8.0 },
    // ── GOLF ───────────────────────────────────────────────────────────
    // Comp — Golf, walking = 4.3
    { name: "Golf (walking)", intensity: "light", metValue: 4.3 },
    // Comp — Golf, cart = 3.5
    { name: "Golf (cart)", intensity: "light", metValue: 3.5 },
    // ── ICE & SKATING ──────────────────────────────────────────────────
    // Comp — Ice skating, general = 7.0
    { name: "Ice Skating", intensity: "moderate", metValue: 7.0 },
    // No direct Compendium entry; estimate ≈ 7.0 (similar to ice skating)
    { name: "Roller Skating", intensity: "moderate", metValue: 7.0 },
    // ── WINTER SPORTS ──────────────────────────────────────────────────
    // Cross-country skiing vigorous ≈ 9.0
    { name: "Cross-country Skiing", intensity: "vigorous", metValue: 9.0 },
    // Comp — Downhill skiing moderate ≈ 5.3
    { name: "Downhill Skiing (moderate)", intensity: "moderate", metValue: 5.3 },
    // Comp — Snowboarding ≈ 5.3
    { name: "Snowboarding", intensity: "moderate", metValue: 5.3 },
    // ── CLIMBING ───────────────────────────────────────────────────────
    // Comp — Rock climbing, vigorous ≈ 8.0
    { name: "Rock Climbing", intensity: "vigorous", metValue: 8.0 },
    // ── MIND-BODY ──────────────────────────────────────────────────────
    // Comp 02150 — Yoga, Hatha = 2.3  [was 2.5]
    { name: "Yoga (hatha)", intensity: "light", metValue: 2.3 },
    // Comp 02160 — Yoga, Power = 4.0; Vinyasa 02185 = 2.7 → power/vinyasa midpoint ≈ 4.0
    { name: "Yoga (power/vinyasa)", intensity: "moderate", metValue: 4.0 },
    // Comp 02155 — Yoga, Hot = 3.0
    { name: "Hot Yoga", intensity: "light", metValue: 3.0 },
    // Comp 02105 — Pilates, general = 2.8  [was 3.0]
    { name: "Pilates", intensity: "light", metValue: 2.8 },
    // ── DANCE & AEROBICS ───────────────────────────────────────────────
    // General moderate dancing ≈ 4.5
    { name: "Dancing (moderate)", intensity: "moderate", metValue: 4.5 },
    // Comp 03 — vigorous dance ≈ 7.8
    { name: "Dancing (vigorous)", intensity: "vigorous", metValue: 7.8 },
    // Zumba ≈ 6.5 (between aerobic dance and vigorous dance) — no direct Compendium entry
    { name: "Zumba", intensity: "moderate", metValue: 6.5 },
    // Comp 02005 — Aerobic dance, low impact = 4.8; rounded to 5.0
    { name: "Aerobics (low impact)", intensity: "moderate", metValue: 5.0 },
    // Comp 02006 — Aerobic dance, high impact = 8.0  [was 7.3]
    { name: "Aerobics (high impact)", intensity: "vigorous", metValue: 8.0 },
    // ── STRENGTH & CONDITIONING ────────────────────────────────────────
    // MET = 0 for strength/weight work: app uses set-based kcal estimation instead of MET
    { name: "Strength Training", intensity: "moderate", metValue: 0 },
    { name: "Weight Lifting", intensity: "moderate", metValue: 0 },
    // Comp 02022 — Calisthenics moderate (pushups, lunges) = 3.8
    { name: "Calisthenics (moderate)", intensity: "moderate", metValue: 3.8 },
    // Comp 02020 — Calisthenics vigorous (burpees, jumping jacks, battle ropes) = 7.5
    { name: "Calisthenics (vigorous)", intensity: "vigorous", metValue: 7.5 },
    // Comp 02040 — Circuit training with kettlebells, vigorous = 7.5
    { name: "Circuit Training", intensity: "vigorous", metValue: 7.5 },
    // Comp 02058 — Kettlebell swings = 9.8
    { name: "Kettlebell Swings", intensity: "vigorous", metValue: 9.8 },
    // Research: battle ropes ≈ 10 MET (vigorous upper-body calisthenics); Comp calisthenics vigorous = 7.5
    // Using 9.8 (same as kettlebell swings — similar metabolic demand)
    { name: "Battle Ropes", intensity: "vigorous", metValue: 9.8 },
    // Sled push/pull — no direct Compendium entry; research ≈ 8.0-9.0 MET
    { name: "Sled Push/Pull", intensity: "vigorous", metValue: 8.5 },
    // Comp vigorous HIIT (burpees, tabata) = 11.0  [was 8.0]
    { name: "HIIT", intensity: "vigorous", metValue: 11.0 },
    // CrossFit: between vigorous circuit (7.5) and HIIT (11) → 10.0  [was 8.0]
    { name: "CrossFit (general)", intensity: "vigorous", metValue: 10.0 },
    // ── WATER SPORTS ───────────────────────────────────────────────────
    // Comp 18100 — Kayaking, moderate effort = 5.0  [was 3.5]
    { name: "Kayaking (leisure)", intensity: "light", metValue: 5.0 },
    // Comp 18106 — Kayaking slalom, flat water = 9.0; vigorous recreational ≈ 10.0
    { name: "Kayaking (vigorous)", intensity: "vigorous", metValue: 10.0 },
    // Comp 18226-18227 — SUP 20-39 strokes/min ≈ 3.8-5.0; moderate ≈ 5.0-6.0
    { name: "Paddleboarding", intensity: "moderate", metValue: 5.0 },
    // Comp — Surfing, body/board, moderate = ~5.0  [was 3.0]
    { name: "Surfing", intensity: "moderate", metValue: 5.0 },
  ];

  // Use onConflictDoUpdate so MET corrections propagate to existing databases (dev + prod)
  await db
    .insert(activityCatalog)
    .values(activities)
    .onConflictDoUpdate({
      target: activityCatalog.name,
      set: {
        metValue: sql`excluded.met_value`,
        intensity: sql`excluded.intensity`,
      },
    });
}
