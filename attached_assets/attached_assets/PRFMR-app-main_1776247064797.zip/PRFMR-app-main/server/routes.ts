import type { Express } from "express";
import { createServer, type Server } from "http";
import passport from "passport";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { sql } from "drizzle-orm";
import ingredients from "../data/ingredients.json";
import authRoutes from "./auth-routes";
import inviteRoutes from "./invite-routes";
import feedbackRoutes from "./feedback-routes";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";

import { getMicronutrientValue } from "@shared/utils";
import { validateUsername, normalizeUsername, RESERVED_USERNAMES } from "@shared/username-validation";
import { calculateTrainingLoad, estimateLiftingCalories, computeDailyLoad, classifyDayLoad, classificationToPlannedIntensity, computeLoadWarnings, type BodyRegion, type DayClassification, type DailyLoadResult, type LoadWarningResult } from "./lib/training-load";
import { shouldApplyRpeKcalAdjustment, getRpeKcalAdjustmentFactor } from "./lib/energy";

/**
 * Training calorie credit percentages by goal.
 * These represent what fraction of training calories are added back to the daily target.
 * 
 * Research rationale:
 * - Fat loss (50%): Conservative approach to maintain deficit despite activity estimation errors
 * - Maintenance (75%): Most training calories should be replaced to maintain weight, small buffer for estimation error
 * - Weight gain (100%): Full replacement + surplus ensures consistent surplus even on training days
 */
const TRAINING_CALORIE_CREDIT_PCT: Record<string, number> = {
    fat_loss: 0.5,      // 50% - conservative to maintain deficit
    maintenance: 0.75,  // 75% - replace most but allow for estimation error
    weight_gain: 1.0,   // 100% - full replacement to maintain surplus
};

function calculateTargets(data: any) {
    const { gender, weight, height, age, activityLevel, goal = 'fat_loss' } = data;
    
    // 1. BMR (Mifflin-St Jeor)
    let bmr = (10 * weight) + (6.25 * height) - (5 * age);
    if (gender === 'male') {
        bmr += 5;
    } else {
        bmr -= 161;
    }

    // 2. TDEE
    const multipliers: Record<string, number> = {
        sedentary: 1.2,
        light: 1.375,
        moderate: 1.55,
        active: 1.725,
        very_active: 1.9
    };
    const tdee = Math.round(bmr * (multipliers[activityLevel] || 1.2));

    // 3. Base calories (before training adjustment) - depends on goal
    let targetCalories: number;
    let targetProtein: number;
    let targetFat: number;
    
    switch (goal) {
        case 'maintenance':
            // Maintenance: eat at TDEE
            targetCalories = tdee;
            // Protein: 1.8g/kg (mid-range of 1.6-2.2g/kg for athletes)
            targetProtein = Math.round(weight * 1.8);
            // Fat: 0.8g/kg (mid-range of 0.6-1.0g/kg)
            targetFat = Math.round(weight * 0.8);
            break;
            
        case 'weight_gain':
            // Weight gain: TDEE + 300kcal surplus
            // Target: ~0.25-0.5% bodyweight gain per week (lean gain)
            // 300kcal/day × 7 = 2100kcal/week surplus
            // At ~7700kcal per kg fat/muscle, this supports ~0.27kg/week gain
            targetCalories = tdee + 300;
            // Protein: 1.8g/kg (sufficient for muscle protein synthesis)
            targetProtein = Math.round(weight * 1.8);
            // Fat: 0.9g/kg (slightly higher for hormonal support during surplus)
            targetFat = Math.round(weight * 0.9);
            break;
            
        case 'fat_loss':
        default:
            // Fat loss: TDEE - 500kcal (conservative deficit)
            targetCalories = tdee - 500;
            // Protein: 2.0g/kg (higher to preserve muscle in deficit)
            targetProtein = Math.round(weight * 2.0);
            // Fat: 0.9g/kg (adequate for hormones)
            targetFat = Math.round(weight * 0.9);
            break;
    }

    // 4. Carbs: Remainder after protein and fat
    const proteinCals = targetProtein * 4;
    const fatCals = targetFat * 9;
    const remainingCals = targetCalories - proteinCals - fatCals;
    const targetCarbs = Math.max(0, Math.round(remainingCals / 4));

    // 5. Training calorie credit percentage for this goal
    const trainingCalorieCreditPct = TRAINING_CALORIE_CREDIT_PCT[goal] ?? 0.5;

    return {
        bmr: Math.round(bmr),
        targetCalories,
        targetProtein,
        targetFat,
        targetCarbs,
        tdee,
        trainingCalorieCreditPct,
        goal
    };
}

// Export for use in other routes
export { TRAINING_CALORIE_CREDIT_PCT };

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ========== GLOBAL API CACHE PREVENTION ==========
  // All /api/ responses must not be cached by CDN/proxy/browser
  // This prevents stale data after mutations (critical for food diary, AMQS, etc.)
  app.use("/api", (req, res, next) => {
    res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    res.set("Surrogate-Control", "no-store");
    next();
  });

  async function getAuthenticatedUser(req: any, res: any): Promise<{ authUser: any; profileUser: any } | null> {
    if (!req.isAuthenticated() || !req.user) {
      res.status(401).json({ error: "Not authenticated" });
      return null;
    }
    const profileUser = await storage.getUserByAuthId(req.user.id);
    if (!profileUser) {
      res.status(404).json({ error: "User profile not found" });
      return null;
    }
    return { authUser: req.user, profileUser };
  }

  // ========== AUTH ROUTES ==========
  app.use("/api/auth", authRoutes);

  // ========== GOOGLE OAUTH ROUTES ==========
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    app.get("/auth/google", passport.authenticate("google", { scope: ["profile", "email"] }));

    app.get("/auth/google/callback",
      passport.authenticate("google", { failureRedirect: "/?error=google_auth_failed" }),
      (req, res) => {
        res.redirect("/dashboard");
      }
    );
  }

  // ========== INVITE ROUTES ==========
  app.use("/api/invites", inviteRoutes);
  
  // ========== FEEDBACK ROUTES ==========
  app.use(feedbackRoutes);

  // ========== OBJECT STORAGE ROUTES ==========
  registerObjectStorageRoutes(app);
  
  // ========== DEBUG ENDPOINTS ==========
  
  // Debug endpoint to send a test email via Resend
  app.post("/api/debug/send-test-email", async (req, res) => {
    try {
      const { z } = await import("zod");
      const { sendEmail, getEmailConfig } = await import("./lib/email");

      const parseResult = z.object({ email: z.string().email() }).safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Please provide a valid email address." });
      }

      const { email } = parseResult.data;
      const config = getEmailConfig();

      console.log(`[debug] Sending test email to ${email}`);
      console.log(`[debug] Email config: mode=${config.mode}, hasKey=${config.hasResendKey}, from=${config.emailFrom}`);

      const result = await sendEmail({
        to: email,
        subject: "PRFMR Test Email",
        text: "This is a test email from PRFMR. If you received this, your email configuration is working correctly.",
        html: `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="font-family: sans-serif; padding: 20px;"><h2>PRFMR Test Email</h2><p>If you received this, your email configuration is working correctly.</p><p style="color: #666; font-size: 14px;">Sent at: ${new Date().toISOString()}</p></body></html>`,
      });

      if (result.success) {
        console.log(`[debug] Test email sent successfully to ${email}`);
        res.json({ success: true, message: "Test email sent." });
      } else {
        console.error(`[debug] Test email failed: ${result.error}`);
        res.status(500).json({ success: false, error: result.error });
      }
    } catch (error: any) {
      console.error("[debug] Test email exception:", error);
      res.status(500).json({ success: false, error: error?.message || "Unknown error" });
    }
  });

  // Debug endpoint to confirm DB connection
  app.get("/api/debug/db", async (req, res) => {
    try {
      const { db } = await import("./db");
      const { sql } = await import("drizzle-orm");
      
      // Get DB info - postgres-js returns arrays directly
      const dbInfo = await db.execute(sql`SELECT current_database(), inet_server_addr(), inet_server_port()`);
      
      // Get row counts
      const supplementCount = await db.execute(sql`SELECT count(*) as count FROM supplements`);
      const catalogCount = await db.execute(sql`SELECT count(*) as count FROM supplement_catalog`);
      const intakesCount = await db.execute(sql`SELECT count(*) as count FROM supplement_intakes`);
      const logsCount = await db.execute(sql`SELECT count(*) as count FROM supplement_logs`);
      const usersCount = await db.execute(sql`SELECT count(*) as count FROM users`);
      const foodEntriesCount = await db.execute(sql`SELECT count(*) as count FROM food_entries`);
      
      // postgres-js returns arrays directly, not {rows: [...]}
      res.json({
        database_url: process.env.DATABASE_URL ? `${process.env.DATABASE_URL.substring(0, 30)}...` : "NOT SET",
        db_info: (dbInfo as any)[0],
        row_counts: {
          users: (usersCount as any)[0]?.count ?? 0,
          supplements: (supplementCount as any)[0]?.count ?? 0,
          supplement_catalog: (catalogCount as any)[0]?.count ?? 0,
          supplement_intakes: (intakesCount as any)[0]?.count ?? 0,
          supplement_logs: (logsCount as any)[0]?.count ?? 0,
          food_entries: (foodEntriesCount as any)[0]?.count ?? 0,
        }
      });
    } catch (error) {
      res.status(500).json({ error: String(error) });
    }
  });
  
  // Debug AMQS endpoint to verify the math
  app.get("/api/debug/amqs/:username/:date", async (req, res) => {
    try {
      const { getDailyMicros, getSupplementMicrosForDate, getFoodMicrosForDate } = await import("./lib/micros");
      const { computeAMQSScore } = await import("./lib/amqs");
      
      const user = await storage.getUser(req.params.username);
      if (!user) return res.status(404).json({ message: "User not found" });
      
      const date = req.params.date;
      
      // Get raw data from DB
      const intakes = await storage.getSupplementIntakes(user.id, date);
      const supplements = await storage.getSupplements(user.id);
      const catalog = await storage.getSupplementCatalog();
      const foodEntries = await storage.getFoodEntries(user.id, date);
      
      // Get computed micros
      const supplementMicros = await getSupplementMicrosForDate(storage, user.id, date);
      const foodMicros = await getFoodMicrosForDate(storage, user.id, date);
      const dailyMicros = await getDailyMicros(storage, user.id, date);
      const amqsScore = await computeAMQSScore(storage, user.id, date, user);
      
      // Build detailed supplement breakdown
      const supplementDetails = intakes.filter(i => i.taken).map(intake => {
        const supplement = supplements.find(s => s.id === intake.supplementId);
        const catalogItem = supplement?.catalogId ? catalog.find(c => c.id === supplement.catalogId) : null;
        return {
          intakeId: intake.id,
          supplementId: intake.supplementId,
          supplementName: supplement?.name ?? "Unknown",
          taken: intake.taken,
          catalogId: supplement?.catalogId,
          catalogName: catalogItem?.name ?? null,
          doseAmount: supplement?.doseAmount,
          doseUnit: supplement?.doseUnit,
          catalogDefaultUnit: catalogItem?.defaultUnit ?? null,
          microsPerUnit: catalogItem?.microsPerUnit ?? null,
          hasMicros: !!catalogItem?.microsPerUnit && Object.keys(catalogItem.microsPerUnit as object || {}).length > 0,
        };
      });
      
      res.json({
        user: { id: user.id, username: user.username },
        date,
        raw_data: {
          total_intakes: intakes.length,
          taken_intakes: intakes.filter(i => i.taken).length,
          total_supplements: supplements.length,
          catalog_size: catalog.length,
          food_entries_count: foodEntries.length,
        },
        supplement_details: supplementDetails,
        computed_micros: {
          food: foodMicros,
          supplements: supplementMicros,
          combined: dailyMicros.totals,
        },
        amqs_score: amqsScore,
      });
    } catch (error) {
      res.status(500).json({ error: String(error) });
    }
  });
  
  // ─── Open Food Facts search ──────────────────────────────────────────────────
  // Architecture:
  //   fetchOFF()    – reusable per-region fetch + normalise
  //   normalizeKey()– dedupe key: normalised brand+name
  //   dedupeResults()– removes cross-region duplicates
  //   /api/foods/search – UK-first, world fallback if < 5 results, top 20

  const offSearchCache = new Map<string, { data: any; ts: number }>();
  const OFF_SEARCH_CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  const OFF_FIELDS = "product_name,brands,nutriments,code,image_front_small_url,image_front_url,image_url,countries_tags";
  const OFF_HEADERS = { "User-Agent": "PRFMR/1.0 (https://app.prfmr.link)" };

  /** Lowercase, trim, strip punctuation — used for dedupe keys */
  function normalizeKey(text: string): string {
    return (text || "")
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  /**
   * fetchOFF – fetch using the OFF v2 search API (search.openfoodfacts.org).
   * The v2 API is the recommended endpoint and avoids rate-limit/503 issues
   * that affect the legacy cgi/search.pl endpoint from cloud-hosted IPs.
   * Returns [] on any network / parse error so the caller is never thrown.
   * Response shape is preserved for full compatibility with food logging
   * and micro-source mapping.
   */
  async function fetchOFF(query: string, region: "uk" | "world"): Promise<any[]> {
    try {
      const params: string[] = [
        `q=${encodeURIComponent(query)}`,
        `page_size=20`,
        `json=1`,
        `fields=${OFF_FIELDS}`,
      ];
      // UK-first: filter to UK-tagged products on the primary pass
      if (region === "uk") {
        params.push(`countries_tags_en=united-kingdom`);
      }

      const url = `https://search.openfoodfacts.org/search?${params.join("&")}`;
      const res = await fetch(url, { headers: OFF_HEADERS });
      if (!res.ok) {
        console.error(`[search] ${region} HTTP ${res.status} for "${query}"`);
        return [];
      }

      const data = await res.json();
      // v2 API returns { hits: [...] }, legacy returned { products: [...] }
      const products: any[] = data.hits || data.products || [];

      return products
        .map((p: any) => {
          const n = p.nutriments || {};
          const name = p.product_name || null;
          if (!name) return null;

          const calories =
            parseFloat(n["energy-kcal_100g"]) ||
            (n["energy_100g"] ? parseFloat(n["energy_100g"]) / 4.184 : null);
          if (calories === null || isNaN(calories)) return null;

          const protein = parseFloat(n["proteins_100g"]);
          const carbs   = parseFloat(n["carbohydrates_100g"]);
          const fat      = parseFloat(n["fat_100g"]);
          if (isNaN(protein) && isNaN(carbs) && isNaN(fat)) return null;

          // v2 API returns brands as string[] — join to match v1 string shape
          const brand = Array.isArray(p.brands)
            ? (p.brands.join(", ") || null)
            : (p.brands || null);

          return {
            name,
            brand,
            calories:     Math.round(calories) || 0,
            protein:      Math.round((protein || 0) * 10) / 10,
            carbs:        Math.round((carbs   || 0) * 10) / 10,
            fat:          Math.round((fat     || 0) * 10) / 10,
            fibre:        Math.round((parseFloat(n["fiber_100g"]) || 0) * 10) / 10,
            barcode:      p.code || null,
            image:        p.image_front_small_url || p.image_front_url || p.image_url || null,
            countries_tags: p.countries_tags || [],
            source:       region,
          };
        })
        .filter(Boolean) as any[];
    } catch (e) {
      console.error(`[search] fetchOFF error (${region}):`, e);
      return [];
    }
  }

  /**
   * dedupeResults – remove duplicates across UK + world results.
   * Priority: barcode dedupe first (exact), then normalised name+brand key.
   * UK results win over world results when both share the same key.
   */
  function dedupeResults(items: any[]): any[] {
    const seenBarcodes  = new Set<string>();
    const seenNameKeys  = new Set<string>();
    const out: any[] = [];

    for (const item of items) {
      if (item.barcode) {
        if (seenBarcodes.has(item.barcode)) continue;
        seenBarcodes.add(item.barcode);
      }
      const nameKey = `${normalizeKey(item.brand || "")}|${normalizeKey(item.name || "")}`;
      if (seenNameKeys.has(nameKey)) continue;
      seenNameKeys.add(nameKey);
      out.push(item);
    }

    return out;
  }

  // Search ranking logic lives in server/lib/searchRanking.ts
  const { parseFoodSearchQuery, scoreOffResult: rankOffResult } = await import("./lib/searchRanking");

  app.get("/api/foods/search", async (req, res) => {
    try {
      const q = (req.query.q as string || "").trim();
      if (!q || q.length < 2) return res.json([]);

      const cacheKey = q.toLowerCase();
      const cached = offSearchCache.get(cacheKey);
      if (cached && Date.now() - cached.ts < OFF_SEARCH_CACHE_TTL) {
        return res.json(cached.data);
      }

      // 1. Always search UK first (filtered to UK-tagged products)
      const ukResults = await fetchOFF(q, "uk");

      let worldResults: any[] = [];

      // 2. If UK returns fewer than 5, also search world (no country filter)
      if (ukResults.length < 5) {
        worldResults = await fetchOFF(q, "world");
      }

      console.log(`[search] q: "${q}" uk: ${ukResults.length} world: ${worldResults.length}`);

      // 3. Merge: UK first (higher priority in dedupe), then world
      const merged = dedupeResults([...ukResults, ...worldResults]);

      // 4. Rank using the full query-aware scoring engine
      const parsedQuery = parseFoodSearchQuery(q);
      merged.sort((a, b) => rankOffResult(b, parsedQuery) - rankOffResult(a, parsedQuery));

      // 5. Top 20
      let results = merged.slice(0, 20);

      console.log(`[search] q: "${q}" final: ${results.length}`);

      // Dev-only: attach ranking debug fields
      if (process.env.NODE_ENV === "development") {
        results = results.map((r, i) => ({
          ...r,
          _rank:     i + 1,
          _score:    rankOffResult(r, parsedQuery),
          _branded:  parsedQuery.isBrandedQuery,
          _brandKey: parsedQuery.brandKey ?? null,
        }));
      }

      offSearchCache.set(cacheKey, { data: results, ts: Date.now() });

      // Evict stale cache entries when cache grows large
      if (offSearchCache.size > 200) {
        const now = Date.now();
        for (const key of Array.from(offSearchCache.keys())) {
          const val = offSearchCache.get(key);
          if (val && now - val.ts > OFF_SEARCH_CACHE_TTL) offSearchCache.delete(key);
        }
      }

      return res.json(results);
    } catch (error) {
      console.error("[search] Unhandled error:", error);
      return res.json([]);
    }
  });

  app.post("/api/foods/search/match", async (req, res) => {
    try {
      const { name, brand, calories, protein, carbs, fat } = req.body;
      if (!name) {
        return res.status(400).json({ error: "name is required" });
      }

      const { matchOffToIngredients } = await import("./lib/offMatch");
      const offMacros = {
        kcal: calories || 0,
        protein: protein || 0,
        carbs: carbs || 0,
        fat: fat || 0,
      };
      const matchResult = matchOffToIngredients(name, brand || null, null, ingredients, offMacros);

      return res.json({
        suggestions: {
          best: matchResult.bestCandidate,
          top: matchResult.topCandidates,
        },
      });
    } catch (error) {
      console.error("[search/match] Error:", error);
      return res.status(500).json({ error: "Match failed" });
    }
  });

  app.get("/api/food/barcode/:code", async (req, res) => {
    try {
      const { code } = req.params;
      console.log(`[scanner][lookup] barcode=${code} status=attempt`);

      let offFound = false;
      let offData: any = null;
      try {
        const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${code}.json`);
        if (response.ok) {
          const data = await response.json();
          if (data.product && data.status !== "unknown") {
            offFound = true;
            offData = data;
          }
        }
      } catch (fetchError) {
        console.error("OFF fetch error:", fetchError);
      }

      if (!offFound) {
        const customFood = req.isAuthenticated()
          ? await storage.getCustomFoodByBarcode(req.user!.id, code)
          : undefined;

        if (customFood) {
          console.log(`[scanner][lookup] barcode=${code} source=custom found=true name="${customFood.name}"`);
          return res.json({
            found: true,
            barcode: code,
            source: "custom",
            custom: {
              id: customFood.id,
              name: customFood.name,
              brand: customFood.brand,
              servingSizeG: customFood.servingSizeG,
              macros_per_100g: {
                kcal: customFood.kcalPer100g || 0,
                protein: customFood.proteinPer100g || 0,
                carbs: customFood.carbsPer100g || 0,
                fat: customFood.fatPer100g || 0,
                fibre: customFood.fibrePer100g || 0,
              },
            },
            computedDefaults: {
              macroSource: "custom" as const,
              microSource: "none" as const,
            },
          });
        }

        console.log(`[scanner][lookup] barcode=${code} source=none found=false`);
        return res.json({ found: false, barcode: code, canCreate: req.isAuthenticated() ? true : false });
      }

      const data = offData;

      const p = data.product;
      const n = p.nutriments || {};

      const name = p.product_name || p.product_name_en || p.generic_name || p.name_en || "Unknown product";
      const brand = p.brands || null;
      const categories = p.categories || null;
      const image_url = p.image_front_url || p.image_url || p.selected_images?.front?.display?.en || null;
      
      let kcal = n["energy-kcal_100g"];
      if (kcal === undefined && n["energy_100g"] !== undefined) {
        kcal = n["energy_100g"] / 4.184;
      }

      const offMacros = {
        kcal: Math.round(kcal || 0),
        protein: n.proteins_100g || 0,
        carbs: n.carbohydrates_100g || 0,
        fat: n.fat_100g || 0,
        fibre: n.fiber_100g || n.fibre_100g || 0,
      };

      // Check for existing mapping
      const existingMapping = await storage.getOffMappingByBarcode(code);
      
      // Generate ingredient suggestions using matching algorithm
      const { matchOffToIngredients } = await import("./lib/offMatch");
      const matchResult = matchOffToIngredients(name, brand, categories, ingredients, offMacros);
      
      // Build response
      const responseData: any = {
        found: true,
        barcode: code,
        off: {
          name,
          brand,
          categories,
          image_url,
          macros_per_100g: offMacros,
        },
        mapping: existingMapping ? {
          ingredientIndex: existingMapping.ingredientIndex,
          ingredientName: existingMapping.ingredientName,
          matchConfidence: existingMapping.matchConfidence,
          verifiedByUser: existingMapping.verifiedByUser,
        } : null,
        suggestions: {
          best: matchResult.bestCandidate,
          top: matchResult.topCandidates,
        },
        computedDefaults: {
          macroSource: "off" as const,
          microSource: existingMapping ? "internal" as const : "none" as const,
        },
      };

      console.log(`[scanner][lookup] barcode=${code} source=off found=true name="${name}" mapping=${existingMapping ? 'yes' : 'no'} suggestions=${matchResult.topCandidates.length}`);

      res.json(responseData);
    } catch (error) {
      console.error("Barcode lookup error:", error);
      res.status(500).json({ found: false, message: "Error looking up barcode" });
    }
  });

  // POST endpoint to save barcode-to-ingredient mapping
  app.post("/api/food/barcode/:code/map", async (req, res) => {
    try {
      const { code } = req.params;
      const { ingredientIndex, offName, offBrand, offCategories, verifiedByUser = true, rememberMapping = true } = req.body;

      if (ingredientIndex === undefined || ingredientIndex < 0 || ingredientIndex >= ingredients.length) {
        return res.status(400).json({ error: "Invalid ingredient index" });
      }

      const ingredient = ingredients[ingredientIndex];
      
      // Use matching to determine confidence and method
      const { matchOffToIngredients, normalize } = await import("./lib/offMatch");
      const matchResult = matchOffToIngredients(offName || "", offBrand || null, offCategories || null, ingredients);
      
      // Determine match details
      let matchConfidence = "low";
      let matchMethod = "user_selected";
      
      if (matchResult.bestCandidate && matchResult.bestCandidate.ingredientIndex === ingredientIndex) {
        matchConfidence = matchResult.bestCandidate.confidence;
        matchMethod = matchResult.bestCandidate.method;
      } else if (verifiedByUser) {
        matchConfidence = "high";
        matchMethod = "user_selected";
      }

      if (rememberMapping) {
        const mapping = await storage.upsertOffMapping({
          barcode: code,
          offName: offName || "Unknown",
          offBrand: offBrand || null,
          offCategories: offCategories || null,
          ingredientIndex,
          ingredientName: ingredient.name,
          matchConfidence,
          matchMethod,
          verifiedByUser: verifiedByUser || false,
        });

        console.log(`[Mapping Saved] barcode=${code} -> ingredient=${ingredient.name} (${matchConfidence}/${matchMethod})`);

        res.json({
          success: true,
          mapping: {
            ingredientIndex: mapping.ingredientIndex,
            ingredientName: mapping.ingredientName,
            matchConfidence: mapping.matchConfidence,
            verifiedByUser: mapping.verifiedByUser,
          },
        });
      } else {
        // Return temporary mapping without saving
        res.json({
          success: true,
          mapping: {
            ingredientIndex,
            ingredientName: ingredient.name,
            matchConfidence,
            verifiedByUser: false,
          },
          temporary: true,
        });
      }
    } catch (error) {
      console.error("Mapping save error:", error);
      res.status(500).json({ error: "Failed to save mapping" });
    }
  });

  const createBarcodeFoodSchema = z.object({
    name: z.string().min(1, "Name is required").max(200),
    brand: z.string().max(200).optional(),
    kcal: z.number().min(0).max(9999).default(0),
    protein: z.number().min(0).max(999).default(0),
    carbs: z.number().min(0).max(999).default(0),
    fat: z.number().min(0).max(999).default(0),
    fibre: z.number().min(0).max(999).default(0),
    servingSizeG: z.number().min(1).max(9999).optional(),
  });

  app.post("/api/food/barcode/:code/create", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const { code } = req.params;

      const parseResult = createBarcodeFoodSchema.safeParse(req.body);
      if (!parseResult.success) {
        const msg = parseResult.error.issues[0]?.message || "Invalid input";
        return res.status(400).json({ error: msg });
      }

      const { name, brand, kcal, protein, carbs, fat, fibre, servingSizeG } = parseResult.data;

      const existing = await storage.getCustomFoodByBarcode(req.user!.id, code);
      if (existing) {
        return res.status(409).json({ error: "A food with this barcode already exists in your database", existing });
      }

      const created = await storage.createCustomFood({
        userId: req.user!.id,
        name: name.trim(),
        brand: brand?.trim() || null,
        barcode: code,
        kcalPer100g: kcal,
        proteinPer100g: protein,
        carbsPer100g: carbs,
        fatPer100g: fat,
        fibrePer100g: fibre,
        servingSizeG: servingSizeG ?? null,
      });

      console.log(`[Barcode][Create] userId=${req.user!.id} barcode=${code} name=${created.name}`);
      res.status(201).json(created);
    } catch (error) {
      console.error("Create barcode food error:", error);
      res.status(500).json({ error: "Failed to create food" });
    }
  });

  // Debug endpoint for OFF mapping (dev only)
  app.get("/api/debug/off-mapping/:barcode", async (req, res) => {
    try {
      const { barcode } = req.params;
      const mapping = await storage.getOffMappingByBarcode(barcode);
      
      if (!mapping) {
        return res.json({ found: false, barcode });
      }

      const ingredient = mapping.ingredientIndex >= 0 && mapping.ingredientIndex < ingredients.length 
        ? ingredients[mapping.ingredientIndex] 
        : null;

      res.json({
        found: true,
        mapping,
        resolvedIngredient: ingredient,
      });
    } catch (error) {
      console.error("Debug mapping error:", error);
      res.status(500).json({ error: "Failed to fetch mapping" });
    }
  });

  // ========== DEBUG / STATUS ENDPOINTS ==========

  // Seed status endpoint - confirms catalog row counts and table existence
  app.get("/api/debug/seed-status", async (req, res) => {
    try {
      const { db } = await import("./db");
      const { supplementCatalog, exerciseCatalog, activityCatalog } = await import("@shared/schema");

      const [supCatalog] = await db.select({ count: sql<number>`count(*)::int` }).from(supplementCatalog);
      const [exCatalog] = await db.select({ count: sql<number>`count(*)::int` }).from(exerciseCatalog);
      const [actCatalog] = await db.select({ count: sql<number>`count(*)::int` }).from(activityCatalog);

      const supCount = supCatalog?.count ?? 0;
      const exCount = exCatalog?.count ?? 0;
      const actCount = actCatalog?.count ?? 0;

      res.json({
        environment: process.env.NODE_ENV || "development",
        catalogs: {
          supplement_catalog: supCount,
          exercise_catalog: exCount,
          activity_catalog: actCount,
        },
        status: supCount > 0 && exCount > 0 && actCount > 0 ? "OK" : "MISSING_DATA",
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("[debug][seed-status] Error:", error);
      res.status(500).json({ error: "Failed to check seed status" });
    }
  });

  // Version/meta endpoint
  app.get("/api/meta", async (req, res) => {
    const { getAppVersion, getEnvironment } = await import("./lib/version");
    res.json({
      version: getAppVersion(),
      environment: getEnvironment(),
    });
  });

  // ========== CUSTOM FOODS API (User's "My Database") ==========

  const customFoodSchema = z.object({
    name: z.string().min(1, "Name is required"),
    brand: z.string().optional(),
    servingSizeG: z.number().int().positive().optional(),
    kcalPer100g: z.number().int().min(0, "Calories must be non-negative"),
    proteinPer100g: z.number().min(0).optional(),
    carbsPer100g: z.number().min(0).optional(),
    fatPer100g: z.number().min(0).optional(),
    fibrePer100g: z.number().min(0).optional(),
    saltPer100g: z.number().min(0).optional(),
    sugarPer100g: z.number().min(0).optional(),
    barcode: z.string().optional(),
  });

  // List user's custom foods
  app.get("/api/foods/custom", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const query = typeof req.query.q === "string" ? req.query.q : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
      const foods = await storage.getCustomFoods(req.user!.id, query, limit);
      res.json(foods);
    } catch (error) {
      console.error("[api][custom-foods] List error:", error);
      res.status(500).json({ error: "Failed to fetch custom foods" });
    }
  });

  // Get single custom food
  app.get("/api/foods/custom/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const food = await storage.getCustomFood(parseInt(req.params.id, 10));
      if (!food || food.userId !== req.user!.id) {
        return res.status(404).json({ error: "Custom food not found" });
      }
      res.json(food);
    } catch (error) {
      console.error("[api][custom-foods] Get error:", error);
      res.status(500).json({ error: "Failed to fetch custom food" });
    }
  });

  // Create custom food
  app.post("/api/foods/custom", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const parsed = customFoodSchema.parse(req.body);
      const food = await storage.createCustomFood({
        ...parsed,
        userId: req.user!.id,
      });
      console.log(`[api][custom-foods] Created food id=${food.id} for user=${req.user!.id}`);
      res.status(201).json(food);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation error", issues: error.errors });
      }
      console.error("[api][custom-foods] Create error:", error);
      res.status(500).json({ error: "Failed to create custom food" });
    }
  });

  // Update custom food
  app.put("/api/foods/custom/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const id = parseInt(req.params.id, 10);
      const existing = await storage.getCustomFood(id);
      if (!existing || existing.userId !== req.user!.id) {
        return res.status(404).json({ error: "Custom food not found" });
      }
      const parsed = customFoodSchema.partial().parse(req.body);
      const updated = await storage.updateCustomFood(id, parsed);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation error", issues: error.errors });
      }
      console.error("[api][custom-foods] Update error:", error);
      res.status(500).json({ error: "Failed to update custom food" });
    }
  });

  // Delete custom food
  app.delete("/api/foods/custom/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const id = parseInt(req.params.id, 10);
      const existing = await storage.getCustomFood(id);
      if (!existing || existing.userId !== req.user!.id) {
        return res.status(404).json({ error: "Custom food not found" });
      }
      await storage.deleteCustomFood(id);
      res.status(204).send();
    } catch (error) {
      console.error("[api][custom-foods] Delete error:", error);
      res.status(500).json({ error: "Failed to delete custom food" });
    }
  });

  // Check if barcode exists in user's custom foods (before looking up OFF)
  app.get("/api/foods/custom/barcode/:code", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    try {
      const food = await storage.getCustomFoodByBarcode(req.user!.id, req.params.code);
      if (!food) {
        return res.status(404).json({ found: false });
      }
      res.json({ found: true, food });
    } catch (error) {
      console.error("[api][custom-foods] Barcode lookup error:", error);
      res.status(500).json({ error: "Failed to lookup custom food by barcode" });
    }
  });

  app.post(api.user.create.path, async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const { username } = api.user.create.input.parse(req.body);
      if (username !== req.user.username) {
        return res.status(403).json({ message: "Forbidden" });
      }
      let user = await storage.getUser(username);
      if (!user) {
          user = await storage.createUser({ username, authUserId: req.user.id });
      }
      res.status(201).json(user);
  });

  app.get("/api/user/me", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    try {
      const user = await storage.getUserByAuthId(req.user.id);
      if (!user) {
        console.log(`[user][me] No profile found for authUserId=${req.user.id}, creating one`);
        const created = await storage.createUser({ username: req.user.username, authUserId: req.user.id });
        console.log(`[user][me] Created profile id=${created.id} for authUserId=${req.user.id}`);
        return res.json(created);
      }
      console.log(`[user][me] authUserId=${req.user.id} username=${user.username} onboarded=${user.targetCalories != null}`);
      res.json(user);
    } catch (error) {
      console.error("[user][me] Error:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post("/api/user/me/onboard", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    try {
      const data = api.user.onboard.input.parse(req.body);

      let user = await storage.getUserByAuthId(req.user.id);
      if (!user) {
        user = await storage.createUser({ username: req.user.username, authUserId: req.user.id });
      }

      const sanitizedData = {
        ...data,
        age: (data.age == null || isNaN(data.age)) ? 25 : data.age,
        height: (data.height == null || isNaN(data.height)) ? 170 : data.height,
        currentWeight: (data.currentWeight == null || isNaN(data.currentWeight)) ? 70 : data.currentWeight,
        goal: data.goal || 'fat_loss',
      };

      const targets = calculateTargets({
        gender: sanitizedData.gender,
        weight: sanitizedData.currentWeight,
        height: sanitizedData.height,
        age: sanitizedData.age,
        activityLevel: sanitizedData.activityLevel,
        goal: sanitizedData.goal
      });

      const sanitizedTargets = {
        targetCalories: isNaN(targets.targetCalories) ? 2000 : targets.targetCalories,
        targetProtein: isNaN(targets.targetProtein) ? 150 : targets.targetProtein,
        targetFat: isNaN(targets.targetFat) ? 70 : targets.targetFat,
        targetCarbs: isNaN(targets.targetCarbs) ? 200 : targets.targetCarbs,
      };

      const updatedUser = await storage.updateUser(user.username, {
        ...sanitizedData,
        ...sanitizedTargets
      });

      try {
        const today = new Date().toISOString().split('T')[0];
        await storage.upsertWeight({
          userId: updatedUser.id,
          date: today,
          weight: sanitizedData.currentWeight
        });
        console.log(`[user][onboard] Initial weight seeded: user=${updatedUser.id} date=${today} weight=${sanitizedData.currentWeight}`);
      } catch (weightErr) {
        console.error(`[user][onboard] Failed to seed initial weight (non-fatal):`, weightErr);
      }

      console.log(`[user][onboard] authUserId=${req.user.id} username=${updatedUser.username} calories=${updatedUser.targetCalories}`);
      res.json(updatedUser);
    } catch (error) {
      console.error("[user][onboard] Error:", error);
      res.status(500).json({ message: "Onboarding failed" });
    }
  });

  // ========== USERNAME CHANGE + AVAILABILITY ==========

  app.get("/api/username/available", async (req, res) => {
    const { username } = req.query;
    if (!username || typeof username !== "string") {
      return res.status(400).json({ available: false, reason: "Username is required" });
    }
    const validation = validateUsername(username);
    if (!validation.valid) {
      return res.json({ available: false, reason: validation.error! });
    }
    const normalized = validation.normalized;
    try {
      const { db } = await import("./db");
      const { usersAuth } = await import("@shared/schema");
      const { eq } = await import("drizzle-orm");
      const existingAuth = await db.select().from(usersAuth).where(eq(usersAuth.username, normalized)).limit(1);
      if (existingAuth.length > 0) {
        return res.json({ available: false, reason: "Username is already taken" });
      }
      const existingProfile = await storage.getUser(normalized);
      if (existingProfile) {
        return res.json({ available: false, reason: "Username is already taken" });
      }
      res.json({ available: true });
    } catch (err) {
      console.error("[username][available][error]", err);
      res.status(500).json({ available: false, reason: "Could not check availability" });
    }
  });

  app.patch("/api/me/username", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;

    const { username } = req.body;
    if (!username || typeof username !== "string") {
      return res.status(400).json({ error: "Username is required" });
    }

    const validation = validateUsername(username);
    if (!validation.valid) {
      return res.status(400).json({ error: validation.error! });
    }
    const newUsername = validation.normalized;

    if (newUsername === auth.profileUser.username) {
      return res.status(400).json({ error: "This is already your username" });
    }

    const COOLDOWN_DAYS = 30;
    if (auth.profileUser.usernameChangedAt) {
      const daysSince = (Date.now() - new Date(auth.profileUser.usernameChangedAt).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSince < COOLDOWN_DAYS) {
        const remainingDays = Math.ceil(COOLDOWN_DAYS - daysSince);
        return res.status(429).json({ error: `You can change your username again in ${remainingDays} day${remainingDays === 1 ? '' : 's'}` });
      }
    }

    try {
      const { db } = await import("./db");
      const { usersAuth, users } = await import("@shared/schema");
      const { eq } = await import("drizzle-orm");

      const existingAuth = await db.select().from(usersAuth).where(eq(usersAuth.username, newUsername)).limit(1);
      if (existingAuth.length > 0 && existingAuth[0].id !== auth.authUser.id) {
        return res.status(409).json({ error: "Username is already taken" });
      }
      const existingProfile = await storage.getUser(newUsername);
      if (existingProfile && existingProfile.id !== auth.profileUser.id) {
        return res.status(409).json({ error: "Username is already taken" });
      }

      await db.transaction(async (tx) => {
        await tx.update(usersAuth)
          .set({ username: newUsername, updatedAt: new Date() })
          .where(eq(usersAuth.id, auth.authUser.id));
        await tx.update(users)
          .set({ username: newUsername, usernameChangedAt: new Date() } as any)
          .where(eq(users.id, auth.profileUser.id));
      });

      console.log(`[username][change] authId=${auth.authUser.id} old=${auth.profileUser.username} new=${newUsername} success=true`);

      req.logout((logoutErr) => {
        if (logoutErr) {
          console.error(`[username][change] logout error:`, logoutErr);
        }
        req.session.destroy((sessionErr) => {
          if (sessionErr) {
            console.error(`[username][change] session destroy error:`, sessionErr);
          }
          res.clearCookie("connect.sid");
          res.json({ reloginRequired: true, newUsername });
        });
      });
    } catch (err) {
      console.error(`[username][change][error] authId=${auth.authUser.id} reason=${err}`);
      res.status(500).json({ error: "Failed to update username" });
    }
  });

  // ========== SESSION-BASED /api/me/* ROUTES ==========
  // These routes derive user from session, never from username parameter

  app.get("/api/me/food/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const entries = await storage.getFoodEntries(auth.profileUser.id, req.params.date);
    res.json(entries);
  });

  app.get("/api/me/food-entries/range", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { start, end } = req.query;
    if (!start || !end) return res.status(400).json({ message: "Missing start/end" });
    if (start > end) return res.status(400).json({ message: "Start must be before end" });
    const entries = await storage.getFoodEntriesRange(auth.profileUser.id, start as string, end as string);
    const normalizedEntries = entries.map((e: any) => ({
      ...e,
      date: typeof e.date === 'string' && e.date.includes('T') ? e.date.split('T')[0] : e.date,
    }));
    res.json(normalizedEntries);
  });

  // ========== MEAL TEMPLATES (SAVED MEALS) ==========

  app.get("/api/me/meals/templates", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const templates = await storage.getMealTemplates(auth.profileUser.id);
    const results = await Promise.all(templates.map(async (t) => {
      const items = await storage.getMealTemplateItems(t.id);
      return { ...t, items };
    }));
    res.json(results);
  });

  app.post("/api/me/meals/templates/from-log", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date, meal, name } = req.body;
    if (!date || !meal || !name) {
      return res.status(400).json({ message: "date, meal, and name are required" });
    }
    const entries = await storage.getFoodEntries(auth.profileUser.id, date);
    const mealEntries = entries.filter(e => e.meal === meal);
    if (mealEntries.length === 0) {
      return res.status(400).json({ message: "No food entries found for that meal" });
    }
    const template = await storage.createMealTemplate({
      userId: auth.profileUser.id,
      name,
      defaultMeal: meal,
      createdAt: new Date().toISOString(),
    });
    const items = await storage.createMealTemplateItems(
      mealEntries.map((e, idx) => ({
        templateId: template.id,
        name: e.name,
        grams: e.grams ?? 100,
        calories: e.calories,
        protein: e.protein,
        carbs: e.carbs,
        fat: e.fat,
        fibre: e.fibre ?? 0,
        sourceType: e.sourceType ?? "manual",
        ingredientIndex: e.ingredientIndex ?? null,
        offBarcode: e.offBarcode ?? null,
        macroSource: e.macroSource ?? "manual",
        microSource: e.microSource ?? "none",
        sortOrder: idx,
      }))
    );
    res.status(201).json({ ...template, items });
  });

  app.post("/api/me/meals/templates/:id/log", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const templateId = parseInt(req.params.id);
    const { date, meal } = req.body;
    if (!date || !meal) {
      return res.status(400).json({ message: "date and meal are required" });
    }
    const template = await storage.getMealTemplate(templateId);
    if (!template || template.userId !== auth.profileUser.id) {
      return res.status(404).json({ message: "Template not found" });
    }
    const items = await storage.getMealTemplateItems(templateId);
    if (items.length === 0) {
      return res.status(400).json({ message: "Template has no items" });
    }
    const newEntries = await storage.createFoodEntries(
      items.map(item => ({
        userId: auth.profileUser.id,
        date,
        name: item.name,
        grams: item.grams ?? 100,
        calories: item.calories,
        protein: item.protein,
        carbs: item.carbs,
        fat: item.fat,
        fibre: item.fibre ?? 0,
        meal,
        sourceType: item.sourceType ?? "manual",
        ingredientIndex: item.ingredientIndex ?? null,
        offBarcode: item.offBarcode ?? null,
        macroSource: item.macroSource ?? "manual",
        microSource: item.microSource ?? "none",
      }))
    );
    res.status(201).json({ count: newEntries.length, entries: newEntries });
  });

  app.post("/api/me/meals/copy", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { fromDate, fromMeal, toDate, toMeal } = req.body;
    if (!fromDate || !fromMeal || !toDate) {
      return res.status(400).json({ message: "fromDate, fromMeal, and toDate are required" });
    }
    const targetMeal = toMeal || fromMeal;
    const entries = await storage.getFoodEntries(auth.profileUser.id, fromDate);
    const mealEntries = entries.filter(e => e.meal === fromMeal);
    if (mealEntries.length === 0) {
      return res.status(400).json({ message: "No food entries found for the source meal" });
    }
    const newEntries = await storage.createFoodEntries(
      mealEntries.map(e => ({
        userId: auth.profileUser.id,
        date: toDate,
        name: e.name,
        grams: e.grams ?? 100,
        calories: e.calories,
        protein: e.protein,
        carbs: e.carbs,
        fat: e.fat,
        fibre: e.fibre ?? 0,
        meal: targetMeal,
        sourceType: e.sourceType ?? "manual",
        ingredientIndex: e.ingredientIndex ?? null,
        offBarcode: e.offBarcode ?? null,
        macroSource: e.macroSource ?? "manual",
        microSource: e.microSource ?? "none",
      }))
    );
    res.status(201).json({ count: newEntries.length, entries: newEntries });
  });

  app.delete("/api/me/meals/templates/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const templateId = parseInt(req.params.id);
    const template = await storage.getMealTemplate(templateId);
    if (!template || template.userId !== auth.profileUser.id) {
      return res.status(404).json({ message: "Template not found" });
    }
    await storage.deleteMealTemplate(templateId);
    res.status(204).end();
  });

  app.get("/api/me/logs", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const logs = await storage.getLogs(auth.profileUser.id);
    res.json(logs);
  });

  app.get("/api/me/weights/range", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { start, end } = req.query;
    if (!start || !end) return res.status(400).json({ message: "Missing start/end" });
    if (start > end) return res.status(400).json({ message: "Start must be before end" });
    const weights = await storage.getWeightsRange(auth.profileUser.id, start as string, end as string);
    res.json(weights);
  });

  app.get("/api/me/supplements", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const supplements = await storage.getSupplements(auth.profileUser.id);
    res.json(supplements);
  });

  app.get("/api/me/stacks", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const stacks = await storage.getStacks(auth.profileUser.id);
    res.json(stacks);
  });

  app.get("/api/me/stacks/scheduled", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date } = req.query;
    if (!date) return res.status(400).json({ message: "date is required" });
    const weekday = getWeekdayFromDate(date as string);
    const stacks = await storage.getStacks(auth.profileUser.id);
    const allReminders = await storage.getAllRemindersForUser(auth.profileUser.id);
    const supps = await storage.getSupplements(auth.profileUser.id);
    const slots: Array<{
      stackId: number;
      stackName: string;
      reminderId: number;
      time: string;
      supplementId: number;
      supplementName: string;
      doseAmount: number | null;
      doseUnit: string | null;
    }> = [];
    for (const stack of stacks) {
      const stackReminders = allReminders.filter(r => r.stackId === stack.id);
      const matchingReminders = stackReminders.filter(r => {
        if (!r.enabled) return false;
        const days = parseDaysOfWeek(r.daysOfWeek);
        return days.includes(weekday);
      });
      if (matchingReminders.length === 0) continue;
      const stackSupplementLinks = await storage.getStackSupplements(stack.id);
      const stackSupplements = stackSupplementLinks
        .map(link => supps.find(s => s.id === link.supplementId))
        .filter((s): s is NonNullable<typeof s> => s !== undefined);
      for (const reminder of matchingReminders) {
        for (const supp of stackSupplements) {
          slots.push({
            stackId: stack.id,
            stackName: stack.name,
            reminderId: reminder.id,
            time: reminder.time,
            supplementId: supp.id,
            supplementName: supp.name,
            doseAmount: supp.doseAmount,
            doseUnit: supp.doseUnit,
          });
        }
      }
    }
    slots.sort((a, b) => a.time.localeCompare(b.time) || a.stackName.localeCompare(b.stackName));
    res.json(slots);
  });

  app.get("/api/me/supplements/reminders", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const supps = await storage.getSupplements(auth.profileUser.id);
    const scheduled = supps.filter(s => s.reminderEnabled && s.reminderTime);
    const result = scheduled.map(s => ({
      supplementId: s.id,
      supplementName: s.name,
      doseAmount: s.doseAmount ?? null,
      doseUnit: s.doseUnit ?? null,
      reminderTime: s.reminderTime!,
    }));
    result.sort((a, b) => a.reminderTime.localeCompare(b.reminderTime));
    res.json(result);
  });

  app.get("/api/me/reminders", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const reminders = await storage.getAllRemindersForUser(auth.profileUser.id);
    res.json(reminders);
  });

  app.get("/api/me/reminders/today", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const reminders = await storage.getTodaysRemindersForUser(auth.profileUser.id);
    const parsed = reminders.map((r: any) => ({
      ...r,
      daysOfWeek: typeof r.daysOfWeek === 'string' ? JSON.parse(r.daysOfWeek) : r.daysOfWeek
    }));
    res.json(parsed);
  });

  app.get("/api/me/supplement-logs/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const logs = await storage.getSupplementLogs(auth.profileUser.id, req.params.date);
    res.json(logs);
  });

  app.get("/api/me/supplement-intakes/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const intakes = await storage.getSupplementIntakes(auth.profileUser.id, req.params.date);
    res.json(intakes);
  });

  app.get("/api/me/supplement-intakes/:startDate/:endDate", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const intakes = await storage.getSupplementIntakesRange(auth.profileUser.id, req.params.startDate, req.params.endDate);
    res.json(intakes);
  });

  app.get("/api/me/supplement-micros/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const intakes = await storage.getSupplementIntakes(auth.profileUser.id, req.params.date);
    const supps = await storage.getSupplements(auth.profileUser.id);
    const catalog = await storage.getSupplementCatalog();
    const microTotals: Record<string, number> = {};
    for (const intake of intakes) {
      if (!intake.taken) continue;
      const supplement = supps.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      const microsPerUnit = catalogItem.microsPerUnit as Record<string, number> | null;
      if (!microsPerUnit || typeof microsPerUnit !== 'object') continue;
      for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
        if (typeof valuePerUnit !== 'number') continue;
        const contribution = valuePerUnit * supplement.doseAmount;
        microTotals[key] = (microTotals[key] || 0) + contribution;
      }
    }
    res.json(microTotals);
  });

  app.get("/api/me/supplement-micros-range/:startDate/:endDate", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { startDate, endDate } = req.params;
    const intakes = await storage.getSupplementIntakesRange(auth.profileUser.id, startDate, endDate);
    const supps = await storage.getSupplements(auth.profileUser.id);
    const catalog = await storage.getSupplementCatalog();
    const microsByDate: Record<string, Record<string, number>> = {};
    for (const intake of intakes) {
      if (!intake.taken) continue;
      const supplement = supps.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      if (!microsByDate[intake.date]) {
        microsByDate[intake.date] = {};
      }
      const microsPerUnit = catalogItem.microsPerUnit as Record<string, number> | null;
      if (!microsPerUnit || typeof microsPerUnit !== 'object') continue;
      for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
        if (typeof valuePerUnit !== 'number') continue;
        const contribution = valuePerUnit * supplement.doseAmount;
        microsByDate[intake.date][key] = (microsByDate[intake.date][key] || 0) + contribution;
      }
    }
    res.json(microsByDate);
  });

  app.get("/api/me/amqs/micros/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { getDailyMicros } = await import("./lib/micros");
    const result = await getDailyMicros(storage, auth.profileUser.id, req.params.date);
    res.json(result);
  });

  app.get("/api/me/amqs/score/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    try {
      const { computeAMQSScore } = await import("./lib/amqs");
      const result = await computeAMQSScore(storage, auth.profileUser.id, req.params.date, auth.profileUser);
      res.json(result);
    } catch (err) {
      console.error("[amqs][score] error:", err);
      res.status(500).json({ error: "Failed to compute AMQS score" });
    }
  });

  app.get("/api/me/amqs/score-range/:startDate/:endDate", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    try {
      const { computeWeeklyAMQS } = await import("./lib/amqs");
      const { startDate, endDate } = req.params;
      const result = await computeWeeklyAMQS(storage, auth.profileUser.id, startDate, endDate, auth.profileUser);
      res.json(result);
    } catch (err) {
      console.error("[amqs][score-range] error:", err);
      res.status(500).json({ error: "Failed to compute AMQS score range" });
    }
  });

  app.get("/api/me/amqs/trend/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    try {
      const { computeAMQSTrend } = await import("./lib/amqs");
      const result = await computeAMQSTrend(storage, auth.profileUser.id, req.params.date, auth.profileUser);
      res.json(result);
    } catch (err) {
      console.error("[amqs][trend] error:", err);
      res.status(500).json({ error: "Failed to compute AMQS trend" });
    }
  });

  app.get("/api/me/disclaimer/:type", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const acceptance = await storage.getDisclaimerAcceptance(auth.profileUser.id, req.params.type);
    res.json({ accepted: !!acceptance, acceptedAt: acceptance?.acceptedAt });
  });

  app.get("/api/me/training/summary/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date } = req.params;
    const [sessions, isRestDayMarked] = await Promise.all([
      storage.getWorkoutSessions(auth.profileUser.id, date, date),
      storage.getRestDayLog(auth.profileUser.id, date),
    ]);
    // Sessions override rest day mark
    const isRestDay = isRestDayMarked && sessions.length === 0;
    const totalKcal = isRestDay ? 0 : sessions.reduce((sum, s) => sum + (s.estimatedKcal || 0), 0);
    const sessionSummaries = await Promise.all(sessions.map(async (session) => {
      const exercises = await storage.getWorkoutExercises(session.id);
      const activities = await storage.getSessionActivities(session.id);
      return {
        id: session.id,
        timeOfDay: session.timeOfDay,
        estimatedKcal: session.estimatedKcal || 0,
        exerciseCount: exercises.length,
        activityCount: activities.length,
      };
    }));

    // RPE is baked into estimatedKcal at storage time (applied on create/update).
    // totalKcalAdjusted mirrors totalKcal; kept for backward-compat with clients that read the field.
    const totalKcalAdjusted = totalKcal;

    res.json({ date, totalKcal, totalKcalAdjusted, sessions: sessionSummaries, isRestDay });
  });

  app.post("/api/me/training/manual-burn", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;

    const schema = z.object({
      caloriesBurned: z.number().int().min(1).max(5000),
      durationMinutes: z.number().int().min(1).max(600).optional(),
      label: z.string().max(50).optional(),
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    });

    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: "Invalid input", errors: parsed.error.flatten().fieldErrors });
    }

    const { caloriesBurned, durationMinutes, label } = parsed.data;
    const now = new Date();
    const date = parsed.data.date || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

    const hour = new Date().getHours();
    const timeOfDay = hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    const displayLabel = label || "Manual entry";

    const session = await storage.createWorkoutSession({
      userId: auth.profileUser.id,
      date,
      timeOfDay,
      title: `[Manual] ${displayLabel}`,
      notes: null,
      durationMinutes: durationMinutes || null,
      intensity: "moderate",
      estimatedMet: null,
      estimatedKcal: caloriesBurned,
    });

    await storage.createSessionActivity({
      sessionId: session.id,
      activityCatalogId: null,
      name: `[Manual] ${displayLabel}`,
      durationMinutes: durationMinutes || 0,
      intensity: "moderate",
      metValue: 0,
      estimatedKcal: caloriesBurned,
    });

    res.status(201).json({
      sessionId: session.id,
      caloriesBurned,
      date,
      label: displayLabel,
    });
  });

  app.post("/api/me/training/load", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;

    const schema = z.object({
      durationMinutes: z.number().int().min(1).max(600),
      sessionRpe: z.number().min(1).max(10),
      bodyRegion: z.enum(["upper", "lower", "full"]),
    });

    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: "Invalid input", errors: parsed.error.flatten().fieldErrors });
    }

    const result = calculateTrainingLoad(parsed.data as { durationMinutes: number; sessionRpe: number; bodyRegion: BodyRegion });
    res.json(result);
  });

  app.patch("/api/me/body-composition", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { bodyFatPct } = req.body;
    if (bodyFatPct !== null && bodyFatPct !== undefined) {
      const val = parseFloat(bodyFatPct);
      if (isNaN(val) || val < 0 || val > 1) {
        return res.status(400).json({ message: "bodyFatPct must be a decimal between 0 and 1 (e.g. 0.15 for 15%)" });
      }
      await storage.updateUser(auth.profileUser.username, { bodyFatPct: val });
    } else {
      await storage.updateUser(auth.profileUser.username, { bodyFatPct: null });
    }
    const updated = await storage.getUserById(auth.profileUser.id);
    res.json(updated);
  });

  app.put("/api/me/profile-photo", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { profilePhotoUrl } = req.body;
    if (!profilePhotoUrl) return res.status(400).json({ error: "profilePhotoUrl required" });
    await storage.updateUser(auth.profileUser.username, { profilePhotoUrl });
    const updated = await storage.getUserById(auth.profileUser.id);
    res.json(updated);
  });

  // ========== END SESSION-BASED /api/me/* ROUTES ==========

  app.get(api.user.get.path, async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      if (req.user.username !== req.params.username) {
        console.log(`[user][:username] Denied: authUser=${req.user.username} requested=${req.params.username}`);
        return res.status(404).json({ message: "User not found" });
      }
      const user = await storage.getUserByAuthId(req.user.id);
      if (!user) return res.status(404).json({ message: "User not found" });
      console.log(`[user][:username] authUserId=${req.user.id} username=${user.username} (compat)`);
      res.json(user);
  });

  app.post(api.user.onboard.path, async (req, res) => {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const { username } = req.params;
      if (req.user.username !== username) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const data = api.user.onboard.input.parse(req.body);
      
      const sanitizedData = {
        ...data,
        age: (data.age == null || isNaN(data.age)) ? 25 : data.age,
        height: (data.height == null || isNaN(data.height)) ? 170 : data.height,
        currentWeight: (data.currentWeight == null || isNaN(data.currentWeight)) ? 70 : data.currentWeight,
        goal: data.goal || 'fat_loss',
      };
      
      const targets = calculateTargets({
          gender: sanitizedData.gender,
          weight: sanitizedData.currentWeight,
          height: sanitizedData.height,
          age: sanitizedData.age,
          activityLevel: sanitizedData.activityLevel,
          goal: sanitizedData.goal
      });
      
      const sanitizedTargets = {
        targetCalories: isNaN(targets.targetCalories) ? 2000 : targets.targetCalories,
        targetProtein: isNaN(targets.targetProtein) ? 150 : targets.targetProtein,
        targetFat: isNaN(targets.targetFat) ? 70 : targets.targetFat,
        targetCarbs: isNaN(targets.targetCarbs) ? 200 : targets.targetCarbs,
      };

      const updatedUser = await storage.updateUser(username, {
          ...sanitizedData,
          ...sanitizedTargets
      });
      
      console.log(`[user][onboard] (compat) username=${username} calories=${updatedUser.targetCalories}`);
      res.json(updatedUser);
  });

  
  // Update profile photo URL
  app.put("/api/user/:username/profile-photo", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    
    const { username } = req.params;
    const { photoUrl } = req.body;
    
    // Validate that the user is updating their own profile
    if (req.user!.username !== username) {
      return res.status(403).json({ error: "You can only update your own profile photo" });
    }
    
    if (!photoUrl || typeof photoUrl !== "string") {
      return res.status(400).json({ error: "Photo URL is required" });
    }
    
    // Security: Only allow object storage paths (prevent arbitrary URL injection)
    if (!photoUrl.startsWith("/objects/")) {
      return res.status(400).json({ error: "Invalid photo URL format" });
    }
    
    try {
      const updatedUser = await storage.updateUser(username, { profilePhotoUrl: photoUrl });
      console.log(`[api][profile-photo] Updated photo for: ${username}`);
      res.json({ success: true, profilePhotoUrl: updatedUser.profilePhotoUrl });
    } catch (error) {
      console.error("[api][profile-photo] Failed to update profile photo:", error);
      res.status(500).json({ error: "Failed to update profile photo" });
    }
  });

  app.get(api.logs.list.path, async (req, res) => {
      const user = await storage.getUser(req.params.username);
      if (!user) return res.status(404).json({ message: "User not found" });
      const logs = await storage.getLogs(user.id);
      res.json(logs);
  });

  app.post(api.logs.create.path, async (req, res) => {
      const data = api.logs.create.input.parse(req.body);
      const log = await storage.createLog(data);
      res.status(201).json(log);
  });

  app.patch(api.logs.update.path, async (req, res) => {
      const id = parseInt(req.params.id);
      const data = api.logs.update.input.parse(req.body);
      const log = await storage.updateLog(id, data);
      res.json(log);
  });

  app.get(api.food.list.path, async (req, res) => {
    const { username, date } = req.params;
    const user = await storage.getUser(username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const entries = await storage.getFoodEntries(user.id, date);
    res.json(entries);
  });

  app.get("/api/food-entries/range", async (req, res) => {
    const { username, start, end } = req.query;
    if (!username || !start || !end) {
      return res.status(400).json({ message: "Missing required parameters" });
    }
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    if (start > end) {
      return res.status(400).json({ message: "Start date must be before or equal to end date" });
    }

    // Since we're using MemStorage, we need to add this method or filter manually
    // Adding to IStorage first
    const entries = await (storage as any).getFoodEntriesRange(user.id, start as string, end as string);
    
    // Normalize dates to yyyy-MM-dd format to ensure consistent client-side comparison
    const normalizedEntries = entries.map((entry: any) => ({
      ...entry,
      date: typeof entry.date === 'string' 
        ? entry.date.includes('T') ? entry.date.split('T')[0] : entry.date
        : entry.date instanceof Date 
          ? entry.date.toISOString().split('T')[0] 
          : entry.date
    }));
    
    res.json(normalizedEntries);
  });

  app.post(api.food.create.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      console.log("[food][create][error] reason=not_authenticated");
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    const authUser = req.user!;
    const profileUser = await storage.getUserByAuthId(authUser.id);
    if (!profileUser) {
      console.log(`[food][create][error] authId=${authUser.id} reason=profile_not_found`);
      return res.status(404).json({ error: "User profile not found" });
    }
    
    const foodName = req.body?.name || "unknown";
    const foodDate = req.body?.date || "unknown";
    const source = req.body?.sourceType || "manual";
    console.log(`[food][create] user=${profileUser.id} date=${foodDate} source=${source} name="${foodName}" status=attempt`);
    
    const result = api.food.create.input.safeParse(req.body);
    if (!result.success) {
      const reason = result.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join("; ");
      console.log(`[food][create] user=${profileUser.id} date=${foodDate} source=${source} name="${foodName}" status=error reason="validation: ${reason}"`);
      return res.status(400).json({ 
        error: "Validation failed", 
        issues: result.error.issues.map(i => ({ path: i.path.join('.'), message: i.message }))
      });
    }
    
    try {
      const entry = await storage.createFoodEntry({ ...result.data, userId: profileUser.id });
      
      if (!entry || typeof entry.id !== "number") {
        console.error(`[food][create][error] user=${profileUser.id} date=${foodDate} source=${source} name="${foodName}" reason="INSERT returned no valid entry" returned=${JSON.stringify(entry)}`);
        return res.status(500).json({ error: "Food entry was not persisted — no valid row returned" });
      }
      
      const verified = await storage.getFoodEntries(profileUser.id, foodDate);
      const found = verified.find(e => e.id === entry.id);
      if (!found) {
        console.error(`[food][create][error] user=${profileUser.id} date=${foodDate} source=${source} name="${foodName}" reason="POST-INSERT verification failed: id=${entry.id} not found in SELECT"`);
        return res.status(500).json({ error: "Food entry verification failed — row not found after insert" });
      }
      
      console.log(`[food][create] user=${profileUser.id} date=${foodDate} source=${source} name="${entry.name}" id=${entry.id} verified=true success=true`);
      res.status(201).json(entry);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.error(`[food][create][error] user=${profileUser.id} date=${foodDate} source=${source} name="${foodName}" reason="${reason}" details="${err instanceof Error ? err.stack?.split('\n')[1]?.trim() : ''}"`);
      res.status(500).json({ error: "Failed to save food entry" });
    }
  });

  app.patch("/api/food/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    console.log(`[food][update] id=${id} status=attempt fields=${Object.keys(req.body).join(",")}`);
    try {
      const entry = await storage.updateFoodEntry(id, req.body);
      console.log(`[food][update] id=${id} name="${entry.name}" calories=${entry.calories} protein=${entry.protein} success=true`);
      res.json(entry);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.error(`[food][update][error] id=${id} reason="${reason}"`);
      res.status(404).json({ message: "Food entry not found" });
    }
  });

  app.delete(api.food.delete.path, async (req, res) => {
    const id = parseInt(req.params.id);
    console.log(`[food][delete] id=${id} status=attempt`);
    try {
      await storage.deleteFoodEntry(id);
      console.log(`[food][delete] id=${id} success=true`);
      res.status(204).end();
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.error(`[food][delete][error] id=${id} reason="${reason}"`);
      res.status(500).json({ error: "Failed to delete food entry" });
    }
  });

  app.get("/api/weights/range", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { start, end } = req.query;
    if (!start || !end) {
      return res.status(400).json({ message: "start and end are required" });
    }
    if (start > end) {
      return res.status(400).json({ message: "Start date must be before or equal to end date" });
    }
    const weights = await storage.getWeightsRange(auth.profileUser.id, start as string, end as string);
    res.json(weights);
  });

  app.post("/api/weights", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date, weight, userId: legacyUserId } = req.body;
    if (!date || weight === undefined) {
      return res.status(400).json({ message: "date and weight are required" });
    }

    const user = auth.profileUser;
    const weightNum = parseFloat(weight);
    if (isNaN(weightNum) || weightNum <= 0) {
      return res.status(400).json({ message: "Invalid weight value" });
    }

    try {
      const { db } = await import("./db");
      const { users: usersTable, weights: weightsTable } = await import("@shared/schema");
      const { eq } = await import("drizzle-orm");

      const entry = await storage.upsertWeight({ userId: user.id, date, weight: weightNum });

      const targets = calculateTargets({
        gender: user.gender,
        weight: weightNum,
        height: user.height,
        age: user.age,
        activityLevel: user.activityLevel,
        goal: user.goal
      });

      await db.update(usersTable)
        .set({
          currentWeight: weightNum,
          targetCalories: isNaN(targets.targetCalories) ? user.targetCalories : targets.targetCalories,
          targetProtein: isNaN(targets.targetProtein) ? user.targetProtein : targets.targetProtein,
          targetCarbs: isNaN(targets.targetCarbs) ? user.targetCarbs : targets.targetCarbs,
          targetFat: isNaN(targets.targetFat) ? user.targetFat : targets.targetFat,
        })
        .where(eq(usersTable.id, user.id));

      console.log(`[weight][save] user=${user.id} date=${date} weight=${weightNum} targetsUpdated=true`);
      res.status(201).json(entry);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.error(`[weight][save][error] user=${user.id} reason=${reason}`);
      res.status(500).json({ message: "Failed to save weight" });
    }
  });

  app.delete("/api/weights/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteWeight(id);
    res.status(204).end();
  });

  app.get("/api/ingredients", async (_req, res) => {
    res.json(ingredients);
  });

  // ========== SCHEDULED STACKS API ==========
  
  // Helper to get weekday key from a date string
  function getWeekdayFromDate(dateStr: string): string {
    const date = new Date(dateStr + "T12:00:00Z"); // Use noon to avoid timezone issues
    const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    return days[date.getUTCDay()];
  }
  
  // Helper to safely parse daysOfWeek (handles string or array)
  function parseDaysOfWeek(daysOfWeek: string | string[]): string[] {
    if (Array.isArray(daysOfWeek)) return daysOfWeek.map(d => d.toLowerCase());
    try {
      const parsed = JSON.parse(daysOfWeek);
      if (Array.isArray(parsed)) return parsed.map((d: string) => d.toLowerCase());
      return [];
    } catch {
      return [];
    }
  }
  
  // Get scheduled stacks for a specific date - returns FLAT slots for proper duplicate handling
  app.get("/api/stacks/scheduled", async (req, res) => {
    const { username, date } = req.query;
    
    if (!username || !date) {
      return res.status(400).json({ message: "username and date are required" });
    }
    
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const weekday = getWeekdayFromDate(date as string);
    
    // Get all user data
    const stacks = await storage.getStacks(user.id);
    const allReminders = await storage.getAllRemindersForUser(user.id);
    const supplements = await storage.getSupplements(user.id);
    
    // Return flat slots: one row per (stackId, reminderId, supplementId)
    const slots: Array<{
      stackId: number;
      stackName: string;
      reminderId: number;
      time: string;
      supplementId: number;
      supplementName: string;
      doseAmount: number | null;
      doseUnit: string | null;
    }> = [];
    
    for (const stack of stacks) {
      // Get reminders for this stack that match the date
      const stackReminders = allReminders.filter(r => r.stackId === stack.id);
      const matchingReminders = stackReminders.filter(r => {
        if (!r.enabled) return false;
        const days = parseDaysOfWeek(r.daysOfWeek);
        return days.includes(weekday);
      });
      
      if (matchingReminders.length === 0) continue;
      
      // Get supplements for this stack
      const stackSupplementLinks = await storage.getStackSupplements(stack.id);
      const stackSupplements = stackSupplementLinks
        .map(link => supplements.find(s => s.id === link.supplementId))
        .filter((s): s is NonNullable<typeof s> => s !== undefined);
      
      // Create a slot for each reminder + supplement combination
      for (const reminder of matchingReminders) {
        for (const supp of stackSupplements) {
          slots.push({
            stackId: stack.id,
            stackName: stack.name,
            reminderId: reminder.id,
            time: reminder.time,
            supplementId: supp.id,
            supplementName: supp.name,
            doseAmount: supp.doseAmount,
            doseUnit: supp.doseUnit,
          });
        }
      }
    }
    
    // Sort by time, then stack name
    slots.sort((a, b) => a.time.localeCompare(b.time) || a.stackName.localeCompare(b.stackName));
    
    res.json(slots);
  });

  // ========== SUPPLEMENTS API ==========
  
  // Get all supplements for a user
  app.get("/api/supplements/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const supplements = await storage.getSupplements(user.id);
    res.json(supplements);
  });

  // Create a supplement (session-based)
  app.post("/api/supplements", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { name, brand, form, notes, catalogId, doseAmount, doseUnit, reminderEnabled, reminderTime } = req.body;
    if (!name) {
      return res.status(400).json({ message: "name is required" });
    }
    const supplement = await storage.createSupplement({
      userId: auth.profileUser.id,
      name,
      brand,
      form,
      notes,
      catalogId: catalogId ? parseInt(catalogId) : undefined,
      doseAmount: doseAmount ? parseFloat(doseAmount) : undefined,
      doseUnit: doseUnit || undefined,
      reminderEnabled: reminderEnabled ?? false,
      reminderTime: reminderTime || undefined,
    });
    res.status(201).json(supplement);
  });

  // Update a supplement (session-based)
  app.patch("/api/supplements/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    try {
      const supplement = await storage.updateSupplement(id, req.body);
      res.json(supplement);
    } catch (err) {
      res.status(404).json({ message: "Supplement not found" });
    }
  });

  // Delete a supplement (session-based)
  app.delete("/api/supplements/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    await storage.deleteSupplement(id);
    res.status(204).end();
  });

  // ========== STACKS API ==========
  
  // Get all stacks for a user
  app.get("/api/stacks/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const stacks = await storage.getStacks(user.id);
    res.json(stacks);
  });

  // Create a stack (session-based)
  app.post("/api/stacks", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { name, description } = req.body;
    if (!name) {
      return res.status(400).json({ message: "name is required" });
    }
    const stack = await storage.createStack({ userId: auth.profileUser.id, name, description });
    res.status(201).json(stack);
  });

  // Update a stack (session-based)
  app.patch("/api/stacks/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    try {
      const stack = await storage.updateStack(id, req.body);
      res.json(stack);
    } catch (err) {
      res.status(404).json({ message: "Stack not found" });
    }
  });

  // Delete a stack (session-based)
  app.delete("/api/stacks/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    await storage.deleteStack(id);
    res.status(204).end();
  });

  // ========== STACK-SUPPLEMENTS API ==========
  
  // Get supplements in a stack
  app.get("/api/stacks/:stackId/supplements", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const stackSupplements = await storage.getStackSupplements(stackId);
    res.json(stackSupplements);
  });

  // Add a supplement to a stack (session-based)
  app.post("/api/stacks/:stackId/supplements", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const stackId = parseInt(req.params.stackId);
    const { supplementId } = req.body;
    if (!supplementId) {
      return res.status(400).json({ message: "supplementId is required" });
    }
    const entry = await storage.addSupplementToStack({ stackId, supplementId });
    res.status(201).json(entry);
  });

  // Remove a supplement from a stack (session-based)
  app.delete("/api/stacks/:stackId/supplements/:supplementId", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const stackId = parseInt(req.params.stackId);
    const supplementId = parseInt(req.params.supplementId);
    await storage.removeSupplementFromStack(stackId, supplementId);
    res.status(204).end();
  });

  // ========== REMINDERS API ==========
  
  // Get reminders for a stack
  app.get("/api/stacks/:stackId/reminders", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const reminders = await storage.getStackReminders(stackId);
    res.json(reminders);
  });

  // Get all reminders for a user
  app.get("/api/reminders/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const reminders = await storage.getAllRemindersForUser(user.id);
    res.json(reminders);
  });

  // Get today's enabled reminders with stack names (for reminder engine)
  app.get("/api/reminders/today/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const reminders = await storage.getTodaysRemindersForUser(user.id);
    // Parse daysOfWeek from JSON string to array for client convenience
    const parsed = reminders.map(r => ({
      ...r,
      daysOfWeek: typeof r.daysOfWeek === 'string' ? JSON.parse(r.daysOfWeek) : r.daysOfWeek
    }));
    res.json(parsed);
  });

  // Create a reminder (session-based, requires disclaimer acceptance)
  app.post("/api/reminders", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { stackId, time, daysOfWeek, enabled } = req.body;
    if (!stackId || !time || !daysOfWeek) {
      return res.status(400).json({ message: "stackId, time, and daysOfWeek are required" });
    }
    
    const stack = await storage.getStack(stackId);
    if (!stack) {
      return res.status(404).json({ message: "Stack not found" });
    }
    
    // Check disclaimer acceptance
    const acceptance = await storage.getDisclaimerAcceptance(auth.profileUser.id, "supplement_reminders");
    if (!acceptance) {
      return res.status(403).json({ message: "Disclaimer must be accepted before creating reminders" });
    }
    
    const reminder = await storage.createReminder({ 
      stackId, 
      time, 
      daysOfWeek: JSON.stringify(daysOfWeek), 
      enabled: enabled ?? true 
    });
    res.status(201).json(reminder);
  });

  // Update a reminder (session-based)
  app.patch("/api/reminders/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    const updates = { ...req.body };
    if (updates.daysOfWeek && Array.isArray(updates.daysOfWeek)) {
      updates.daysOfWeek = JSON.stringify(updates.daysOfWeek);
    }
    try {
      const reminder = await storage.updateReminder(id, updates);
      res.json(reminder);
    } catch (err) {
      res.status(404).json({ message: "Reminder not found" });
    }
  });

  // Delete a reminder (session-based)
  app.delete("/api/reminders/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    await storage.deleteReminder(id);
    res.status(204).end();
  });

  // ========== SUPPLEMENT LOGS API ==========
  
  // Get supplement logs for a user on a specific date
  app.get("/api/supplement-logs/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const logs = await storage.getSupplementLogs(user.id, req.params.date);
    res.json(logs);
  });

  // Log a supplement as taken (session-based)
  app.post("/api/supplement-logs", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { supplementId, stackId, date, time, taken } = req.body;
    if (!supplementId || !date) {
      return res.status(400).json({ message: "supplementId and date are required" });
    }
    const log = await storage.createSupplementLog({ userId: auth.profileUser.id, supplementId, stackId, date, time, taken });
    res.status(201).json(log);
  });

  // Delete a supplement log (session-based)
  app.delete("/api/supplement-logs/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    await storage.deleteSupplementLog(id);
    res.status(204).end();
  });

  // ========== DISCLAIMER ACCEPTANCE API ==========
  
  // Check if user has accepted a disclaimer
  app.get("/api/disclaimer/:username/:type", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const acceptance = await storage.getDisclaimerAcceptance(user.id, req.params.type);
    res.json({ accepted: !!acceptance, acceptedAt: acceptance?.acceptedAt });
  });

  // Record disclaimer acceptance (session-based)
  app.post("/api/disclaimer", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { disclaimerType } = req.body;
    if (!disclaimerType) {
      return res.status(400).json({ message: "disclaimerType is required" });
    }
    const acceptance = await storage.createDisclaimerAcceptance({
      userId: auth.profileUser.id,
      disclaimerType,
      acceptedAt: new Date().toISOString(),
    });
    res.status(201).json(acceptance);
  });

  // ========== SUPPLEMENT CATALOG API ==========
  
  // Search/list supplement catalog
  app.get("/api/supplement-catalog", async (req, res) => {
    const userId = req.user?.id ?? null;
    const origin = req.get("origin") || req.get("host") || "unknown";
    console.log(`[supplements][catalog][api] Request - userId: ${userId}, origin: ${origin}`);
    
    try {
      const query = req.query.q as string | undefined;
      const catalog = await storage.getSupplementCatalog(query);
      console.log(`[supplements][catalog][api] Database query result count: ${catalog.length}`);
      
      // Never silently return empty array if catalog is empty (no search query)
      if (catalog.length === 0 && !query) {
        console.error(`[supplements][catalog][api] CRITICAL: Catalog is empty - supplement_catalog table not seeded!`);
        return res.status(503).json({ 
          message: "Supplement catalog is unavailable. Please contact support.",
          error: "CATALOG_EMPTY"
        });
      }
      
      res.json(catalog);
    } catch (error) {
      console.error(`[supplements][catalog][api] Database query FAILED:`, error);
      res.status(500).json({ message: "Failed to fetch supplement catalog", error: String(error) });
    }
  });

  // Get single catalog item
  app.get("/api/supplement-catalog/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const item = await storage.getSupplementCatalogItem(id);
    if (!item) return res.status(404).json({ message: "Catalog item not found" });
    res.json(item);
  });

  // ========== SUPPLEMENT INTAKES API ==========
  
  // Get supplement intakes using query params (for dashboard) - returns slot keys
  app.get("/api/supplement-intakes", async (req, res) => {
    const { username, date } = req.query;
    if (!username || !date) {
      return res.status(400).json({ message: "username and date are required" });
    }
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakes(user.id, date as string);
    // Return slot keys (stackId-reminderId-supplementId) for taken supplements
    // Use actual IDs (not 0 fallback) to match dashboard keys
    const takenSlotKeys = intakes
      .filter(i => i.taken && i.stackId !== null && i.reminderId !== null)
      .map(i => `${i.stackId}-${i.reminderId}-${i.supplementId}`);
    res.json({ takenSlotKeys });
  });
  
  // Get supplement intakes for a user on a specific date
  app.get("/api/supplement-intakes/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakes(user.id, req.params.date);
    res.json(intakes);
  });

  // Get supplement intakes for a date range (for AMQS)
  app.get("/api/supplement-intakes/:username/:startDate/:endDate", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakesRange(user.id, req.params.startDate, req.params.endDate);
    res.json(intakes);
  });

  // Log supplement intake (session-based, upsert per slot)
  app.post("/api/supplement-intakes", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const userId = auth.profileUser.id;
    const { supplementId, stackId, reminderId, date, taken } = req.body;
    if (!supplementId || !date) {
      return res.status(400).json({ message: "supplementId and date are required" });
    }
    
    const normalizedStackId = stackId ?? null;
    const normalizedReminderId = reminderId ?? null;
    
    const existingIntakes = await storage.getSupplementIntakes(userId, date);
    const existing = existingIntakes.find(i => 
      i.supplementId === supplementId && 
      i.stackId === normalizedStackId && 
      i.reminderId === normalizedReminderId
    );
    
    if (taken === false) {
      if (existing) {
        await storage.deleteSupplementIntake(existing.id);
      }
      return res.json({ deleted: true, supplementId, stackId: normalizedStackId, reminderId: normalizedReminderId, date });
    }
    
    if (existing) {
      const updated = await storage.updateSupplementIntake(existing.id, { 
        taken: true, 
        takenAt: new Date().toISOString() 
      });
      return res.json(updated);
    }
    
    const intake = await storage.createSupplementIntake({ 
      userId, 
      supplementId,
      stackId: normalizedStackId,
      reminderId: normalizedReminderId,
      date, 
      taken: true, 
      takenAt: new Date().toISOString() 
    });
    res.status(201).json(intake);
  });

  // Update supplement intake (session-based)
  app.patch("/api/supplement-intakes/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    try {
      const intake = await storage.updateSupplementIntake(id, req.body);
      res.json(intake);
    } catch (err) {
      res.status(404).json({ message: "Intake not found" });
    }
  });

  // Delete supplement intake (session-based)
  app.delete("/api/supplement-intakes/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const id = parseInt(req.params.id);
    await storage.deleteSupplementIntake(id);
    res.status(204).end();
  });

  // ========== SUPPLEMENT MICRONUTRIENTS FOR AMQS ==========
  
  // Get daily supplement micronutrients contribution
  app.get("/api/supplement-micros/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const intakes = await storage.getSupplementIntakes(user.id, req.params.date);
    const supplements = await storage.getSupplements(user.id);
    const catalog = await storage.getSupplementCatalog();
    
    const microTotals: Record<string, number> = {};
    
    for (const intake of intakes) {
      if (!intake.taken) continue;
      
      const supplement = supplements.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      
      // microsPerUnit is JSONB, so it's already an object
      const microsPerUnit = catalogItem.microsPerUnit as Record<string, number> | null;
      if (!microsPerUnit || typeof microsPerUnit !== 'object') continue;
      
      for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
        if (typeof valuePerUnit !== 'number') continue;
        const contribution = valuePerUnit * supplement.doseAmount;
        microTotals[key] = (microTotals[key] || 0) + contribution;
      }
    }
    
    res.json(microTotals);
  });

  // Get supplement micronutrients for a date range (for weekly AMQS)
  app.get("/api/supplement-micros-range/:username/:startDate/:endDate", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const { startDate, endDate } = req.params;
    const intakes = await storage.getSupplementIntakesRange(user.id, startDate, endDate);
    const supplements = await storage.getSupplements(user.id);
    const catalog = await storage.getSupplementCatalog();
    
    // Group by date
    const microsByDate: Record<string, Record<string, number>> = {};
    
    for (const intake of intakes) {
      if (!intake.taken) continue;
      
      const supplement = supplements.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      
      if (!microsByDate[intake.date]) {
        microsByDate[intake.date] = {};
      }
      
      // microsPerUnit is JSONB, so it's already an object
      const microsPerUnit = catalogItem.microsPerUnit as Record<string, number> | null;
      if (!microsPerUnit || typeof microsPerUnit !== 'object') continue;
      
      for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
        if (typeof valuePerUnit !== 'number') continue;
        const contribution = valuePerUnit * supplement.doseAmount;
        microsByDate[intake.date][key] = (microsByDate[intake.date][key] || 0) + contribution;
      }
    }
    
    res.json(microsByDate);
  });

  // ========== AMQS (Athlete Micronutrient Quality Score) API ==========
  
  // Get merged daily micronutrients (food + supplements)
  app.get("/api/amqs/micros/:username/:date", async (req, res) => {
    const { getDailyMicros } = await import("./lib/micros");
    
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const result = await getDailyMicros(storage, user.id, req.params.date);
    res.json(result);
  });

  // Get AMQS score for a single day
  app.get("/api/amqs/score/:username/:date", async (req, res) => {
    const { computeAMQSScore } = await import("./lib/amqs");
    
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const result = await computeAMQSScore(storage, user.id, req.params.date, user);
    res.json(result);
  });

  // Get AMQS scores for a date range (for weekly average)
  app.get("/api/amqs/score-range/:username/:startDate/:endDate", async (req, res) => {
    const { computeWeeklyAMQS } = await import("./lib/amqs");
    
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const { startDate, endDate } = req.params;
    const result = await computeWeeklyAMQS(storage, user.id, startDate, endDate, user);
    res.json(result);
  });

  // ========== DEBUG ENDPOINTS ==========
  
  app.get("/api/debug/catalog-health", async (req, res) => {
    try {
      const { db } = await import("./db");
      const { sql } = await import("drizzle-orm");
      
      const exerciseCount = await storage.getExerciseCatalog();
      const activityCount = await storage.getActivityCatalog();
      
      const dbInfo = await db.execute(sql`
        SELECT current_database() as db_name, current_user as db_user
      `);
      
      const dbUrl = process.env.DATABASE_URL || "";
      const urlHash = dbUrl.length > 0 
        ? Buffer.from(dbUrl.slice(-20)).toString("base64").slice(0, 12)
        : "no-url";
      
      const dbRow = Array.isArray(dbInfo) && dbInfo.length > 0 ? dbInfo[0] : { db_name: "unknown", db_user: "unknown" };
      
      res.json({
        exerciseCatalogCount: exerciseCount.length,
        activityCatalogCount: activityCount.length,
        database: dbRow,
        urlFingerprint: urlHash,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to check catalog health", message: String(error) });
    }
  });

  app.get("/api/admin/debug", async (req, res) => {
    if (process.env.ADMIN_DEBUG !== "true") {
      return res.status(404).json({ error: "Not found" });
    }
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const { db } = await import("./db");
      const { getCatalogStatus } = await import("./seed-catalogs");

      const dbUrl = process.env.DATABASE_URL || "";
      const dbHostRaw = dbUrl.includes("@") ? dbUrl.split("@")[1]?.split("/")[0]?.split(":")[0] : "unknown";
      const dbHost = dbHostRaw ? dbHostRaw.substring(0, 8) + "..." : "unknown";

      let gitHash = "unknown";
      try {
        const { execSync } = await import("child_process");
        gitHash = execSync("git rev-parse --short HEAD").toString().trim();
      } catch {}

      const tableCountQuery = async (table: string) => {
        const [row] = await db.execute(sql.raw(`SELECT count(*)::int AS count FROM ${table}`));
        return (row as any)?.count ?? 0;
      };

      const tables = [
        "users_auth", "users", "food_entries", "custom_foods",
        "supplement_catalog", "exercise_catalog", "activity_catalog",
        "nutrient_catalog", "supplements", "supplement_stacks",
        "training_sessions", "training_exercises", "push_subscriptions",
      ];

      const counts: Record<string, number> = {};
      for (const t of tables) {
        try {
          counts[t] = await tableCountQuery(t);
        } catch {
          counts[t] = -1;
        }
      }

      const seedStatus = await getCatalogStatus();

      const catalogTables = ["supplement_catalog", "exercise_catalog", "activity_catalog", "nutrient_catalog"];
      const emptyCatalogs = catalogTables.filter(t => (counts[t] ?? 0) === 0);
      const populatedCatalogs = catalogTables.filter(t => (counts[t] ?? 0) > 0);

      console.log(`[admin][debug] user=${req.user!.id} tables=${JSON.stringify(counts)}`);

      res.json({
        environment: process.env.NODE_ENV || "development",
        version: gitHash,
        database: {
          host: dbHost,
          migrationSystem: "drizzle-kit (db:push)",
        },
        tableCounts: counts,
        seedStatus: {
          emptyCatalogs,
          populatedCatalogs,
          warnings: seedStatus.warnings,
          allSeeded: emptyCatalogs.length === 0,
        },
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("[admin][debug][error]", error);
      res.status(500).json({ error: "Failed to gather debug info" });
    }
  });

  // ========== TRAINING LOG API ==========
  
  // Exercise Catalog
  app.get("/api/exercises", async (req, res) => {
    try {
      const query = req.query.query as string | undefined;
      const exercises = await storage.getExerciseCatalog(query);
      
      // Never silently return empty array if catalog is empty (no search query)
      if (exercises.length === 0 && !query) {
        console.error(`[training][catalog][api] CRITICAL: Exercise catalog is empty - exercise_catalog table not seeded!`);
        return res.status(503).json({ 
          message: "Exercise catalog is unavailable. Please contact support.",
          error: "CATALOG_EMPTY"
        });
      }
      
      res.json(exercises);
    } catch (error) {
      console.error(`[training][catalog][api] Exercise catalog query FAILED:`, error);
      res.status(500).json({ message: "Failed to fetch exercise catalog", error: String(error) });
    }
  });

  // Activity Catalog
  app.get("/api/activities", async (req, res) => {
    try {
      const query = req.query.query as string | undefined;
      const activities = await storage.getActivityCatalog(query);
      
      // Never silently return empty array if catalog is empty (no search query)
      if (activities.length === 0 && !query) {
        console.error(`[training][catalog][api] CRITICAL: Activity catalog is empty - activity_catalog table not seeded!`);
        return res.status(503).json({ 
          message: "Activity catalog is unavailable. Please contact support.",
          error: "CATALOG_EMPTY"
        });
      }
      
      res.json(activities);
    } catch (error) {
      console.error(`[training][catalog][api] Activity catalog query FAILED:`, error);
      res.status(500).json({ message: "Failed to fetch activity catalog", error: String(error) });
    }
  });

  // Workout Sessions (session-based)
  app.get("/api/workouts/sessions", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { start, end } = req.query;
    if (!start || !end) {
      return res.status(400).json({ message: "start and end are required" });
    }
    
    const sessions = await storage.getWorkoutSessions(auth.profileUser.id, start as string, end as string);
    
    const sessionsWithDetails = await Promise.all(sessions.map(async (session) => {
      const exercises = await storage.getWorkoutExercises(session.id);
      const exercisesWithSets = await Promise.all(exercises.map(async (exercise) => {
        const sets = await storage.getWorkoutSets(exercise.id);
        return { ...exercise, sets };
      }));
      const activities = await storage.getSessionActivities(session.id);
      return { ...session, exercises: exercisesWithSets, activities };
    }));
    
    res.json(sessionsWithDetails);
  });

  app.post("/api/workouts/sessions", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date, timeOfDay, title, notes, intensity, durationMinutes } = req.body;
    if (!date || !timeOfDay) {
      console.log(`[workout][session][create][error] user=${auth.profileUser.id} reason="date and timeOfDay are required"`);
      return res.status(400).json({ message: "date and timeOfDay are required" });
    }
    
    try {
      const session = await storage.createWorkoutSession({
        userId: auth.profileUser.id,
        date,
        timeOfDay,
        title: title || null,
        notes: notes || null,
        durationMinutes: durationMinutes || null,
        intensity: intensity || null,
        estimatedMet: null,
        estimatedKcal: 0
      });

      // Auto-clear rest day mark when a session is created for that date
      await storage.deleteRestDayLog(auth.profileUser.id, date);
      
      console.log(`[workout][session][create] user=${auth.profileUser.id} date=${date} timeOfDay=${timeOfDay} success=true`);
      res.status(201).json(session);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      console.error(`[workout][session][create][error] user=${auth.profileUser.id} reason=${reason}`);
      res.status(500).json({ message: "Failed to create workout session" });
    }
  });

  app.patch("/api/workouts/sessions/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const session = await storage.getWorkoutSession(id);
    if (!session) return res.status(404).json({ message: "Session not found" });
    
    const { title, notes } = req.body;
    const updates: any = {};
    
    if (title !== undefined) updates.title = title;
    if (notes !== undefined) updates.notes = notes;
    // Sessions no longer have intensity/duration - those are on exercises
    
    const updated = await storage.updateWorkoutSession(id, updates);
    res.json(updated);
  });

  app.delete("/api/workouts/sessions/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteWorkoutSession(id);
    res.status(204).end();
  });

  // Training Summary (legacy username-based route kept for backward compat)
  app.get("/api/training/summary/:username/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { date } = req.params;
    
    const sessions = await storage.getWorkoutSessions(auth.profileUser.id, date, date);
    const totalKcal = sessions.reduce((sum, s) => sum + (s.estimatedKcal || 0), 0);
    
    const sessionSummaries = await Promise.all(sessions.map(async (session) => {
      const exercises = await storage.getWorkoutExercises(session.id);
      const activities = await storage.getSessionActivities(session.id);
      return {
        id: session.id,
        timeOfDay: session.timeOfDay,
        estimatedKcal: session.estimatedKcal || 0,
        exerciseCount: exercises.length,
        activityCount: activities.length
      };
    }));
    
    res.json({
      date,
      totalKcal,
      sessions: sessionSummaries
    });
  });

  // Workout Exercises
  app.post("/api/workouts/sessions/:sessionId/exercises", async (req, res) => {
    const sessionId = parseInt(req.params.sessionId);
    const session = await storage.getWorkoutSession(sessionId);
    if (!session) return res.status(404).json({ message: "Session not found" });
    
    const { exerciseCatalogId, name, intensity, durationMinutes } = req.body;
    if (!name) return res.status(400).json({ message: "Exercise name is required" });
    
    // Get current max order index
    const existing = await storage.getWorkoutExercises(sessionId);
    const maxOrder = existing.length > 0 ? Math.max(...existing.map(e => e.orderIndex)) : -1;
    
    const exercise = await storage.createWorkoutExercise({
      sessionId,
      exerciseCatalogId: exerciseCatalogId || null,
      name,
      orderIndex: maxOrder + 1,
      intensity: intensity || "moderate",
      durationMinutes: durationMinutes || null,
      estimatedKcal: 0 // Will be calculated when sets are added or duration specified
    });
    
    // Recalculate session calories
    await recalculateSessionCalories(sessionId);
    
    res.status(201).json(exercise);
  });

  app.patch("/api/workouts/exercises/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updated = await storage.updateWorkoutExercise(id, req.body);
      res.json(updated);
    } catch (err) {
      res.status(404).json({ message: "Exercise not found" });
    }
  });

  app.delete("/api/workouts/exercises/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const exercise = await storage.getWorkoutExercise(id);
    if (exercise) {
      const sessionId = exercise.sessionId;
      await storage.deleteWorkoutExercise(id);
      // Recalculate session calories after removing exercise
      await recalculateSessionCalories(sessionId);
    }
    res.status(204).end();
  });

  // Workout Sets
  app.post("/api/workouts/exercises/:exerciseId/sets", async (req, res) => {
    const exerciseId = parseInt(req.params.exerciseId);
    const exercise = await storage.getWorkoutExercise(exerciseId);
    if (!exercise) return res.status(404).json({ message: "Exercise not found" });
    
    const { reps, weightKg, rpe, restSeconds, tempo, durationSeconds } = req.body;
    if (reps === undefined) return res.status(400).json({ message: "Reps is required" });
    
    // Get current max set index
    const existing = await storage.getWorkoutSets(exerciseId);
    const maxIndex = existing.length > 0 ? Math.max(...existing.map(s => s.setIndex)) : 0;
    
    const set = await storage.createWorkoutSet({
      workoutExerciseId: exerciseId,
      setIndex: maxIndex + 1,
      reps,
      weightKg: weightKg || null,
      rpe: rpe || null,
      restSeconds: restSeconds || null,
      tempo: tempo || null,
      durationSeconds: durationSeconds || null
    });
    
    // Recalculate session calories
    await recalculateSessionCalories(exercise.sessionId);
    
    res.status(201).json(set);
  });

  app.patch("/api/workouts/sets/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updated = await storage.updateWorkoutSet(id, req.body);
      res.json(updated);
    } catch (err) {
      res.status(404).json({ message: "Set not found" });
    }
  });

  app.delete("/api/workouts/sets/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    // Find exercise to get session ID for recalculation
    const sets = Array.from((storage as any).workoutSetsMap?.values() || []) as any[];
    const set = sets.find((s: any) => s.id === id);
    let sessionId: number | null = null;
    
    if (set) {
      const exercise = await storage.getWorkoutExercise(set.workoutExerciseId);
      if (exercise) sessionId = exercise.sessionId;
    }
    
    await storage.deleteWorkoutSet(id);
    
    if (sessionId) {
      await recalculateSessionCalories(sessionId);
    }
    
    res.status(204).end();
  });

  // Session Activities (cardio/sports)
  app.post("/api/workouts/sessions/:sessionId/activities", async (req, res) => {
    const sessionId = parseInt(req.params.sessionId);
    const session = await storage.getWorkoutSession(sessionId);
    if (!session) return res.status(404).json({ message: "Session not found" });
    
    const { activityCatalogId, name, durationMinutes, intensity, metValue, activityType, sessionRpe, bodyRegion, rpe } = req.body;
    if (!name || !durationMinutes) {
      return res.status(400).json({ message: "name and durationMinutes are required" });
    }

    const isLifting = activityType === "lifting";
    let estimatedKcal = 0;
    let trainingLoadScore: number | null = null;

    // Resolve bodyweight from daily logs → recent 7-day → profile (used for both lifting and cardio)
    const activityUser = await storage.getUserById(session.userId);
    const bwForActivity = await resolveBodyweight(session.userId, session.date, activityUser?.currentWeight);
    const resolvedWeight = bwForActivity.kg;

    if (isLifting) {
      if (!sessionRpe || !bodyRegion) {
        return res.status(400).json({ message: "sessionRpe and bodyRegion are required for lifting activities" });
      }
      const loadResult = calculateTrainingLoad({
        durationMinutes,
        sessionRpe,
        bodyRegion: bodyRegion as BodyRegion,
      });
      trainingLoadScore = loadResult.trainingLoadScore;

      if (resolvedWeight) {
        const kcalResult = estimateLiftingCalories({
          durationMinutes,
          sessionRpe,
          bodyRegion: bodyRegion as BodyRegion,
          bodyweightKg: resolvedWeight,
        });
        estimatedKcal = kcalResult.estimatedKcal;
      }
    } else {
      if (!metValue) {
        return res.status(400).json({ message: "metValue is required for cardio activities" });
      }
      const rawKcal = resolvedWeight ? Math.round((metValue * 3.5 * resolvedWeight / 200) * durationMinutes) : 0;
      // Apply RPE factor at storage time so the displayed kcal already reflects effort level
      const cardioRpe: number | null = rpe ?? null;
      const rpeFactor = (cardioRpe != null && shouldApplyRpeKcalAdjustment(name, "cardio"))
        ? getRpeKcalAdjustmentFactor(cardioRpe)
        : 1.0;
      estimatedKcal = Math.round(rawKcal * rpeFactor);
    }
    
    const activity = await storage.createSessionActivity({
      sessionId,
      activityCatalogId: activityCatalogId || null,
      name: isLifting ? `[Lifting] ${name}` : name,
      durationMinutes,
      intensity: intensity || "moderate",
      metValue: metValue || 0,
      estimatedKcal,
      activityType: isLifting ? "lifting" : "cardio",
      sessionRpe: isLifting ? sessionRpe : null,
      bodyRegion: isLifting ? bodyRegion : null,
      trainingLoadScore,
      // universal effort RPE: for lifting, mirror sessionRpe; for cardio, use the provided rpe value
      rpe: isLifting ? (sessionRpe ?? null) : (rpe ?? null),
    });
    
    await recalculateSessionCalories(sessionId);
    
    res.status(201).json(activity);
  });

  app.patch("/api/workouts/activities/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const activity = await storage.getSessionActivity(id);
    if (!activity) return res.status(404).json({ message: "Activity not found" });
    
    const { durationMinutes, metValue, sessionRpe, bodyRegion, rpe: patchRpe } = req.body;
    const updates: any = { ...req.body };
    
    // Recalculate calories when any relevant field changes (including RPE for cardio)
    const calorieTrigger = durationMinutes !== undefined || metValue !== undefined || sessionRpe !== undefined || bodyRegion !== undefined || patchRpe !== undefined;
    if (calorieTrigger) {
      const session = await storage.getWorkoutSession(activity.sessionId);
      if (session) {
        const patchUser = await storage.getUserById(session.userId);
        const bwPatch = await resolveBodyweight(session.userId, session.date, patchUser?.currentWeight);
        const wt = bwPatch.kg;
        const newDuration = durationMinutes ?? activity.durationMinutes;

        if (activity.activityType === "lifting") {
          const newRpe = sessionRpe ?? activity.sessionRpe ?? 7;
          const newRegion = (bodyRegion ?? activity.bodyRegion ?? "full") as BodyRegion;
          updates.estimatedKcal = wt
            ? estimateLiftingCalories({ durationMinutes: newDuration, sessionRpe: newRpe, bodyRegion: newRegion, bodyweightKg: wt }).estimatedKcal
            : 0;
          // Re-compute training load if RPE/duration/region changed
          if (sessionRpe !== undefined || durationMinutes !== undefined || bodyRegion !== undefined) {
            updates.trainingLoadScore = calculateTrainingLoad({ durationMinutes: newDuration, sessionRpe: newRpe, bodyRegion: newRegion }).trainingLoadScore;
          }
        } else {
          const newMet = metValue ?? activity.metValue;
          const rawKcal = wt ? Math.round((newMet * 3.5 * wt / 200) * newDuration) : 0;
          // Apply RPE factor: use updated rpe if provided, else fall back to stored value
          const newRpe: number | null = patchRpe ?? activity.rpe ?? null;
          const rpeFactor = (newRpe != null && shouldApplyRpeKcalAdjustment(activity.name, "cardio"))
            ? getRpeKcalAdjustmentFactor(newRpe)
            : 1.0;
          updates.estimatedKcal = Math.round(rawKcal * rpeFactor);
        }
      }
    }
    
    const updated = await storage.updateSessionActivity(id, updates);
    
    // Recalculate session total calories
    await recalculateSessionCalories(activity.sessionId);
    
    res.json(updated);
  });

  app.delete("/api/workouts/activities/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const activity = await storage.getSessionActivity(id);
    const sessionId = activity?.sessionId;
    
    await storage.deleteSessionActivity(id);
    
    if (sessionId) {
      await recalculateSessionCalories(sessionId);
    }
    
    res.status(204).end();
  });

  function isValidDateParam(d: string): boolean {
    return /^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(new Date(d).getTime());
  }

  async function resolveBodyweight(userId: number, date: string, profileWeight: number | null | undefined): Promise<{ kg: number | null; source: "today" | "recent" | "profile" | null }> {
    const todayWeights = await storage.getWeightsRange(userId, date, date);
    if (todayWeights.length > 0 && todayWeights[0].weight) {
      return { kg: todayWeights[0].weight, source: "today" };
    }
    const weekAgo = new Date(date);
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = weekAgo.toISOString().split("T")[0];
    const recentWeights = await storage.getWeightsRange(userId, weekAgoStr, date);
    if (recentWeights.length > 0) {
      const sorted = recentWeights.sort((a: any, b: any) => b.date.localeCompare(a.date));
      if (sorted[0].weight) return { kg: sorted[0].weight, source: "recent" };
    }
    if (profileWeight && profileWeight > 0) {
      return { kg: profileWeight, source: "profile" };
    }
    return { kg: null, source: null };
  }

  // ===== Sleep Logs =====
  app.get("/api/me/sleep/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const log = await storage.getSleepLog(auth.profileUser.id, req.params.date);
    res.json(log || null);
  });

  app.put("/api/me/sleep/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const schema = z.object({
      hoursSlept: z.number().min(0).max(24),
      sleepQuality: z.number().int().min(1).max(5).optional().nullable(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.message });
    const log = await storage.upsertSleepLog({
      userId: auth.profileUser.id,
      date: req.params.date,
      hoursSlept: parsed.data.hoursSlept,
      sleepQuality: parsed.data.sleepQuality ?? null,
    });
    res.json(log);
  });

  // ===== Session Readiness =====
  app.get("/api/me/readiness/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const { calculateSleepScore, calculateEnergyAvailability, calculateCarbSufficiency, calculateAmqsSufficiency, calculateSessionReadiness } = await import("./lib/readiness");
    const user = auth.profileUser;
    const date = req.params.date;
    const yesterday = new Date(date);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    const bw = await resolveBodyweight(user.id, date, user.currentWeight);

    const sleepLog = await storage.getSleepLog(user.id, date);
    const sleepScore = sleepLog
      ? calculateSleepScore(sleepLog.hoursSlept, sleepLog.sleepQuality)
      : null;

    const yesterdayFood = await storage.getFoodEntries(user.id, yesterdayStr);
    const hasYesterdayFood = yesterdayFood.length > 0;
    const caloriesYesterday = yesterdayFood.reduce((s, f) => s + (f.calories || 0), 0);
    const carbsYesterday = yesterdayFood.reduce((s, f) => s + (f.carbs || 0), 0);

    const [yesterdaySessions, yesterdayRestDay] = await Promise.all([
      storage.getWorkoutSessions(user.id, yesterdayStr, yesterdayStr),
      storage.getRestDayLog(user.id, yesterdayStr),
    ]);
    // No sessions = assumed rest day (never provisional for training). This avoids asking users
    // to log training that didn't happen; rest days and off days are treated identically here.
    const hasYesterdayTraining = true;
    const exerciseKcalYesterday = yesterdaySessions.reduce((s, sess) => s + (sess.estimatedKcal || 0), 0);

    // Derive yesterday's training demand from actual session activities (if available).
    let yesterdayTrainingDemand: DayClassification | null = null;
    let yesterdayDailyLoad = null;
    if (yesterdaySessions.length > 0) {
      const allYesterdayActivities = (
        await Promise.all(yesterdaySessions.map(s => storage.getSessionActivities(s.id)))
      ).flat();
      yesterdayDailyLoad = computeDailyLoad(allYesterdayActivities, yesterdaySessions.length);
      yesterdayTrainingDemand = yesterdayDailyLoad.classification;
    } else {
      // No sessions (whether explicit rest day or simply no training logged) = rest
      yesterdayTrainingDemand = "rest";
    }

    // ── EA smoothing: average last 3 days to reduce single-day noise ──────────
    let smoothedEa: number | null = null;
    if (bw.kg) {
      try {
        const bfPct = (user as any).bodyFatPct ?? 0.15;
        const ffmKg = bw.kg * (1 - (bfPct > 0 && bfPct < 1 ? bfPct : 0.15));
        const eaDays: number[] = [(caloriesYesterday - exerciseKcalYesterday) / ffmKg];
        for (let dOffset = 2; dOffset <= 3; dOffset++) {
          const dDate = new Date(date);
          dDate.setDate(dDate.getDate() - dOffset);
          const dStr = dDate.toISOString().split("T")[0];
          const dFood = await storage.getFoodEntries(user.id, dStr);
          const dSessions = await storage.getWorkoutSessions(user.id, dStr, dStr);
          if (dFood.length > 0) {
            const dCal = dFood.reduce((s, f) => s + (f.calories || 0), 0);
            const dKcal = dSessions.reduce((s, sess) => s + (sess.estimatedKcal || 0), 0);
            eaDays.push((dCal - dKcal) / ffmKg);
          }
        }
        if (eaDays.length > 1) {
          smoothedEa = eaDays.reduce((s, v) => s + v, 0) / eaDays.length;
        }
      } catch {}
    }

    const energyScore = calculateEnergyAvailability(caloriesYesterday, exerciseKcalYesterday, bw.kg, (user as any).bodyFatPct ?? null, smoothedEa);

    // ── Today's training load for carb target ─────────────────────────────────
    const todaySessions = await storage.getWorkoutSessions(user.id, date, date);
    let plannedIntensity: "rest" | "light" | "moderate" | "hard" = "moderate";
    if (todaySessions.length > 0) {
      const intensities = todaySessions.map(s => s.intensity || "moderate");
      if (intensities.includes("vigorous")) plannedIntensity = "hard";
      else if (intensities.includes("moderate")) plannedIntensity = "moderate";
      else plannedIntensity = "light";
    }
    const todayActivities = (await Promise.all(todaySessions.map(s => storage.getSessionActivities(s.id)))).flat();
    const todayDailyLoad = computeDailyLoad(todayActivities, todaySessions.length);
    // Only use activity-derived classification when activities are present; otherwise fall back to session intensity
    const todayClassification: DayClassification = todayActivities.length > 0
      ? todayDailyLoad.classification
      : (plannedIntensity === "hard" ? "hard" : plannedIntensity === "light" ? "light" : "moderate");

    const carbScore = calculateCarbSufficiency(carbsYesterday, bw.kg, todayClassification);

    const { computeAMQSScore } = await import("./lib/amqs");
    let amqsValue = 50;
    try {
      const amqsResult = await computeAMQSScore(storage, user.id, yesterdayStr, user);
      amqsValue = amqsResult.score;
    } catch {}
    const amqsScore = calculateAmqsSufficiency(amqsValue);

    const result = calculateSessionReadiness(sleepScore, energyScore, carbScore, amqsScore, {
      hasSleepData: !!sleepLog,
      hasYesterdayFood,
      hasYesterdayTraining,
      bodyweightSource: bw.source,
      bodyweightKg: bw.kg,
    });

    let checkin = null;
    let provisionalReadiness = null;
    if (result.provisional) {
      checkin = await storage.getProvisionalCheckin(user.id, date) || null;
      if (checkin) {
        const { calculateProvisionalReadiness } = await import("./lib/provisional-readiness");
        // Prefer derived training demand from actual data; fall back to check-in answers.
        const derivedTrainedYesterday = yesterdayTrainingDemand !== null ? true : (checkin.trainedYesterday ?? undefined);
        const derivedIntensity = yesterdayTrainingDemand !== null
          ? classificationToPlannedIntensity(yesterdayTrainingDemand)
          : (checkin.yesterdayTrainingIntensity as "light" | "moderate" | "hard" | undefined ?? undefined);
        provisionalReadiness = calculateProvisionalReadiness(
          checkin.feelToday as "fresh" | "okay" | "tired",
          checkin.fueledToday as "yes" | "somewhat" | "no",
          checkin.plannedIntensity as "light" | "moderate" | "hard",
          derivedTrainedYesterday,
          derivedIntensity,
        );
      }
    }

    // ── Stacking detection for readiness context ──────────────────────────────
    const twoDaysAgoDate = new Date(date);
    twoDaysAgoDate.setDate(twoDaysAgoDate.getDate() - 2);
    const twoDaysAgoStr = twoDaysAgoDate.toISOString().split("T")[0];
    const twoDaysAgoSessions = await storage.getWorkoutSessions(user.id, twoDaysAgoStr, twoDaysAgoStr);
    let twoDaysAgoDailyLoad: DailyLoadResult | null = null;
    if (twoDaysAgoSessions.length > 0) {
      const twoDaysAgoActivities = (await Promise.all(twoDaysAgoSessions.map(s => storage.getSessionActivities(s.id)))).flat();
      twoDaysAgoDailyLoad = computeDailyLoad(twoDaysAgoActivities, twoDaysAgoSessions.length);
    }
    const stackingContext = computeLoadWarnings(
      todayDailyLoad,
      [yesterdayDailyLoad ?? computeDailyLoad([], 0), twoDaysAgoDailyLoad ?? computeDailyLoad([], 0)]
    );
    const { warnings: loadWarnings, backToBackHardDays, highLoadCluster, threeDayStreak } = stackingContext;

    res.json({ ...result, date, plannedIntensity, todayClassification, hasPlannedTraining: todaySessions.length > 0, hasYesterdayTraining, hasYesterdayFood, bodyweightSource: bw.source, bodyweightKg: bw.kg, checkin, provisionalReadiness, yesterdayTrainingDemand, yesterdayDailyLoad, loadWarnings, backToBackHardDays, highLoadCluster, threeDayStreak });
  });

  // ===== Fuel Availability / Glycogen Risk =====
  app.get("/api/me/fuel/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const { calculateFuelAvailability } = await import("./lib/fuel-availability");
    const user = auth.profileUser;
    const date = req.params.date;
    const yesterday = new Date(date);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    const bw = await resolveBodyweight(user.id, date, user.currentWeight);

    const yesterdayFood = await storage.getFoodEntries(user.id, yesterdayStr);
    const hasYesterdayFood = yesterdayFood.length > 0;
    const caloriesYesterday = yesterdayFood.reduce((s, f) => s + (f.calories || 0), 0);
    const carbsYesterday = yesterdayFood.reduce((s, f) => s + (f.carbs || 0), 0);

    const [yesterdaySessions, yesterdayRestDay] = await Promise.all([
      storage.getWorkoutSessions(user.id, yesterdayStr, yesterdayStr),
      storage.getRestDayLog(user.id, yesterdayStr),
    ]);
    // No sessions = assumed rest day. Never provisional for training.
    const hasYesterdayTraining = true;
    const exerciseKcalYesterday = yesterdaySessions.reduce((s, sess) => s + (sess.estimatedKcal || 0), 0);

    // Derive yesterday's training demand from actual session activities (if available).
    let yesterdayTrainingDemand: DayClassification | null = null;
    let yesterdayDailyLoad = null;
    if (yesterdaySessions.length > 0) {
      const allYesterdayActivities = (
        await Promise.all(yesterdaySessions.map(s => storage.getSessionActivities(s.id)))
      ).flat();
      yesterdayDailyLoad = computeDailyLoad(allYesterdayActivities, yesterdaySessions.length);
      yesterdayTrainingDemand = yesterdayDailyLoad.classification;
    } else {
      yesterdayTrainingDemand = "rest";
    }

    const todaySessions = await storage.getWorkoutSessions(user.id, date, date);

    // Compute activity-derived load for today — used to set plannedIntensity accurately.
    const todayActivitiesForFuel = (await Promise.all(todaySessions.map(s => storage.getSessionActivities(s.id)))).flat();
    const todayDailyLoadForFuel = computeDailyLoad(todayActivitiesForFuel, todaySessions.length);

    // Derive plannedIntensity: prefer activity-based classification when activities are logged
    // (avoids mismatch where session.intensity="moderate" but RPE×duration yields "hard").
    let plannedIntensity: "rest" | "light" | "moderate" | "hard" = "moderate";
    if (todaySessions.length > 0) {
      if (todayActivitiesForFuel.length > 0) {
        plannedIntensity = classificationToPlannedIntensity(todayDailyLoadForFuel.classification);
      } else {
        const intensities = todaySessions.map(s => s.intensity || "moderate");
        if (intensities.includes("vigorous")) plannedIntensity = "hard";
        else if (intensities.includes("moderate")) plannedIntensity = "moderate";
        else plannedIntensity = "light";
      }
    }

    // Provisional only when yesterday food OR training is missing.
    // Missing bodyweight alone does NOT trigger provisional — it is resolved via resolveBodyweight().
    const provisional = !hasYesterdayFood || !hasYesterdayTraining;
    const result = calculateFuelAvailability(caloriesYesterday, exerciseKcalYesterday, carbsYesterday, bw.kg, plannedIntensity, user.bodyFatPct);

    let checkin = null;
    let provisionalFuel = null;
    if (provisional) {
      checkin = await storage.getProvisionalCheckin(user.id, date) || null;
      if (checkin) {
        const { calculateProvisionalFuel } = await import("./lib/provisional-readiness");
        provisionalFuel = calculateProvisionalFuel(
          checkin.fueledToday as "yes" | "somewhat" | "no",
          checkin.plannedIntensity as "light" | "moderate" | "hard",
        );
      }
    }

    // ── Stacking detection for fuel context ───────────────────────────────────
    const fuelTwoDaysAgoDate = new Date(date);
    fuelTwoDaysAgoDate.setDate(fuelTwoDaysAgoDate.getDate() - 2);
    const fuelTwoDaysAgoStr = fuelTwoDaysAgoDate.toISOString().split("T")[0];
    const fuelTwoDaysAgoSessions = await storage.getWorkoutSessions(user.id, fuelTwoDaysAgoStr, fuelTwoDaysAgoStr);
    let fuelTwoDaysAgoDailyLoad: DailyLoadResult | null = null;
    if (fuelTwoDaysAgoSessions.length > 0) {
      const acts = (await Promise.all(fuelTwoDaysAgoSessions.map(s => storage.getSessionActivities(s.id)))).flat();
      fuelTwoDaysAgoDailyLoad = computeDailyLoad(acts, fuelTwoDaysAgoSessions.length);
    }

    const fuelStackingContext = computeLoadWarnings(
      todayDailyLoadForFuel,
      [yesterdayDailyLoad ?? computeDailyLoad([], 0), fuelTwoDaysAgoDailyLoad ?? computeDailyLoad([], 0)]
    );

    let fuelLoadWarning: string | null = null;
    if (fuelStackingContext.backToBackHardDays || fuelStackingContext.highLoadCluster || fuelStackingContext.threeDayStreak) {
      if (result.glycogenRisk === "High" || result.glycogenRisk === "Moderate") {
        fuelLoadWarning = "Training demand is stacking while fuel support is low";
      }
    } else if (
      (todayDailyLoadForFuel.classification === "hard" || todayDailyLoadForFuel.classification === "very_hard") &&
      (result.glycogenRisk === "High")
    ) {
      fuelLoadWarning = "High training demand with low carbohydrate support";
    }

    res.json({ ...result, date, plannedIntensity, hasPlannedTraining: todaySessions.length > 0, bodyweightSource: bw.source, bodyweightKg: bw.kg, provisional, hasYesterdayFood, hasYesterdayTraining, checkin, provisionalFuel, yesterdayTrainingDemand, yesterdayDailyLoad, fuelLoadWarning, backToBackHardDays: fuelStackingContext.backToBackHardDays, highLoadCluster: fuelStackingContext.highLoadCluster, threeDayStreak: fuelStackingContext.threeDayStreak });
  });

  // ===== Training Load / Day Classification =====

  /**
   * Fetch daily load results for a contiguous range of days, newest-first.
   * Used for acute/chronic load and stacking detection.
   */
  async function fetchHistoricalLoads(
    userId: number,
    endDate: string,
    daysBack: number
  ): Promise<DailyLoadResult[]> {
    const end = new Date(endDate);
    const start = new Date(endDate);
    start.setDate(start.getDate() - (daysBack - 1));
    const startStr = start.toISOString().split("T")[0];
    const endStr = end.toISOString().split("T")[0];

    const allSessions = await storage.getWorkoutSessions(userId, startStr, endStr);

    const sessionsByDate = new Map<string, typeof allSessions>();
    for (const s of allSessions) {
      const d = typeof s.date === "string" ? s.date : s.date.toISOString().split("T")[0];
      const list = sessionsByDate.get(d) || [];
      list.push(s);
      sessionsByDate.set(d, list);
    }

    const allSessionIds = allSessions.map(s => s.id);
    const activitiesPerSession = await Promise.all(allSessionIds.map(id => storage.getSessionActivities(id)));
    const activitiesBySessionId = new Map<number, Awaited<ReturnType<typeof storage.getSessionActivities>>>();
    allSessionIds.forEach((id, i) => activitiesBySessionId.set(id, activitiesPerSession[i]));

    const results: DailyLoadResult[] = [];
    for (let i = 0; i < daysBack; i++) {
      const d = new Date(end);
      d.setDate(d.getDate() - i);
      const dStr = d.toISOString().split("T")[0];
      const daySessions = sessionsByDate.get(dStr) || [];
      const dayActivities = daySessions.flatMap(s => activitiesBySessionId.get(s.id) || []);
      results.push(computeDailyLoad(dayActivities, daySessions.length));
    }

    return results;
  }

  app.get("/api/me/training-load/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const date = req.params.date;

    const [todayDayLoad, ...priorDays] = await fetchHistoricalLoads(auth.profileUser.id, date, 28);

    // Fetch today's override + overrides for prior days so stacking detection is accurate
    const overrideClassification = await storage.getLoadOverride(auth.profileUser.id, date);

    // Build date strings for each prior day (priorDays[0] = yesterday, [1] = 2 days ago, ...)
    const baseDate = new Date(date + "T00:00:00");
    const priorDaysWithOverrides = await Promise.all(
      priorDays.map(async (day, i) => {
        const priorDate = new Date(baseDate);
        priorDate.setDate(priorDate.getDate() - (i + 1));
        const priorDateStr = priorDate.toISOString().split("T")[0];
        const override = await storage.getLoadOverride(auth.profileUser.id, priorDateStr);
        if (override && (override === "light" || override === "moderate")) {
          return { ...day, classification: override as DayClassification };
        }
        return day;
      })
    );

    // Apply today's override to the load object used for stacking too
    const todayLoadForWarnings = overrideClassification
      ? { ...todayDayLoad, classification: overrideClassification as DayClassification }
      : todayDayLoad;

    const warningResult = computeLoadWarnings(todayLoadForWarnings, priorDaysWithOverrides);

    // If today is overridden to light/moderate, strip stress-level warnings
    let { warnings, highStress, veryHighStress } = warningResult;
    if (overrideClassification && (overrideClassification === "light" || overrideClassification === "moderate")) {
      highStress = false;
      veryHighStress = false;
      warnings = warnings.filter(w =>
        !w.toLowerCase().includes("elevated") &&
        !w.toLowerCase().includes("spike") &&
        !w.toLowerCase().includes("accumulating") &&
        !w.toLowerCase().includes("stress")
      );
    }

    res.json({
      ...todayDayLoad,
      date,
      ...warningResult,
      warnings,
      highStress,
      veryHighStress,
      overrideClassification: overrideClassification ?? null,
      effectiveClassification: overrideClassification ?? todayDayLoad.classification,
    });
  });

  app.post("/api/me/training/load-override/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const { classification } = req.body;
    const valid = ["light", "moderate", "hard", "very_hard"];
    if (!classification || !valid.includes(classification)) {
      return res.status(400).json({ message: "Invalid classification" });
    }
    await storage.upsertLoadOverride(auth.profileUser.id, req.params.date, classification);
    res.json({ success: true, overrideClassification: classification });
  });

  /**
   * GET /api/me/training/load-history/:date
   * Returns 28 days of daily load data (newest-first) for charting.
   * Each entry includes: date, totalLoad, classification, relativeLoad (vs baseline).
   */
  app.get("/api/me/training/load-history/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const date = req.params.date;

    const loads = await fetchHistoricalLoads(auth.profileUser.id, date, 28);

    // Compute baseline from the full 28-day window for relative load normalisation
    const { baselineLoad, baselineDaysUsed, acuteLoad, acuteDaily, acwr } = computeLoadWarnings(loads[0], loads.slice(1));

    const end = new Date(date);

    const history = loads.map((d, i) => {
      const dayDate = new Date(end);
      dayDate.setDate(dayDate.getDate() - i);
      const relLoad = (baselineLoad !== null && baselineLoad > 0)
        ? Math.round((d.totalLoad / baselineLoad) * 100) / 100
        : null;
      return {
        date: dayDate.toISOString().split("T")[0],
        totalLoad: d.totalLoad,
        classification: d.classification,
        relativeLoad: relLoad,
        sessionCount: d.sessionCount,
      };
    });

    // Reverse so array is chronological (oldest first) for charts
    history.reverse();

    res.json({
      history,
      baselineLoad,
      baselineDaysUsed,
      acuteLoad,
      acuteDaily,
      acwr,
      date,
    });
  });

  // ===== Provisional Check-in =====
  app.get("/api/me/provisional-checkin/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const checkin = await storage.getProvisionalCheckin(auth.profileUser.id, req.params.date);
    res.json(checkin || null);
  });

  app.put("/api/me/provisional-checkin/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const { insertProvisionalCheckinSchema } = await import("@shared/schema");
    const parsed = insertProvisionalCheckinSchema.safeParse({
      ...req.body,
      userId: auth.profileUser.id,
      date: req.params.date,
    });
    if (!parsed.success) return res.status(400).json({ message: parsed.error.message });
    const checkin = await storage.upsertProvisionalCheckin(parsed.data);
    res.json(checkin);
  });

  // ===== Weight Cut Planner =====
  app.get("/api/me/weight-cut", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const plan = await storage.getWeightCutPlan(auth.profileUser.id);
    if (!plan) return res.json(null);
    const { calculateWeightCutPlan } = await import("./lib/weight-cut");
    const user = auth.profileUser;
    const today = new Date().toISOString().split("T")[0];
    const bw = await resolveBodyweight(user.id, today, user.currentWeight);
    const currentWeight = bw.kg || plan.currentWeight;
    const result = calculateWeightCutPlan(currentWeight, plan.targetWeight, plan.fightDate, plan.weighInTiming as "same_day" | "day_before", undefined, plan.manualTempReductionKg);
    res.json({ ...result, planId: plan.id, currentWeight, bodyweightSource: bw.source, weighInTiming: plan.weighInTiming, manualTempReductionKg: plan.manualTempReductionKg ?? null });
  });

  app.post("/api/me/weight-cut", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const schema = z.object({
      currentWeight: z.number().min(30).max(300),
      targetWeight: z.number().min(30).max(300),
      fightDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      weighInTiming: z.enum(["same_day", "day_before"]).default("same_day"),
      manualTempReductionKg: z.number().min(0).max(30).optional().nullable(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.message });

    const existing = await storage.getWeightCutPlan(auth.profileUser.id);
    if (existing) {
      await storage.deleteWeightCutPlan(existing.id);
    }

    const plan = await storage.createWeightCutPlan({
      userId: auth.profileUser.id,
      ...parsed.data,
    });
    const { calculateWeightCutPlan } = await import("./lib/weight-cut");
    const result = calculateWeightCutPlan(parsed.data.currentWeight, parsed.data.targetWeight, parsed.data.fightDate, parsed.data.weighInTiming, undefined, parsed.data.manualTempReductionKg);
    res.status(201).json({ ...result, planId: plan.id, weighInTiming: plan.weighInTiming, manualTempReductionKg: plan.manualTempReductionKg ?? null });
  });

  app.put("/api/me/weight-cut", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const existing = await storage.getWeightCutPlan(auth.profileUser.id);
    if (!existing) return res.status(404).json({ message: "No weight cut plan found" });
    const schema = z.object({
      currentWeight: z.number().min(30).max(300).optional(),
      targetWeight: z.number().min(30).max(300).optional(),
      fightDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      weighInTiming: z.enum(["same_day", "day_before"]).optional(),
      manualTempReductionKg: z.number().min(0).max(30).optional().nullable(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: parsed.error.message });
    const updated = await storage.updateWeightCutPlan(existing.id, parsed.data);
    const { calculateWeightCutPlan } = await import("./lib/weight-cut");
    const user = auth.profileUser;
    const currentWeight = parsed.data.currentWeight || user.currentWeight || updated.currentWeight;
    const result = calculateWeightCutPlan(currentWeight, updated.targetWeight, updated.fightDate, updated.weighInTiming as "same_day" | "day_before", undefined, updated.manualTempReductionKg);
    res.json({ ...result, planId: updated.id, weighInTiming: updated.weighInTiming, manualTempReductionKg: updated.manualTempReductionKg ?? null });
  });

  app.delete("/api/me/weight-cut", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const existing = await storage.getWeightCutPlan(auth.profileUser.id);
    if (!existing) return res.status(404).json({ message: "No weight cut plan found" });
    await storage.deleteWeightCutPlan(existing.id);
    res.status(204).end();
  });

  // ===== Effective Nutrition Targets (fight-camp-aware) =====
  // Priority: Fight Camp Active > Profile Goal > Maintenance default
  // Accepts optional ?date=YYYY-MM-DD query param (defaults to today).
  // This allows the dashboard to show accurate targets for any viewed date.
  app.get("/api/me/targets/effective", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const user = auth.profileUser;

    // Resolve the date to use — caller may pass ?date= for past/future days
    const today = new Date().toISOString().split("T")[0];
    const dateParam = req.query.date as string | undefined;
    const targetDate = (dateParam && isValidDateParam(dateParam)) ? dateParam : today;

    // Always compute TDEE fresh from current profile stats
    const profileTargets = calculateTargets({
      gender: user.gender,
      weight: user.currentWeight,
      height: user.height,
      age: user.age,
      activityLevel: user.activityLevel,
      goal: user.goal || "fat_loss",
    });
    const tdee = profileTargets.tdee;
    const weight = user.currentWeight || 75;

    // Check for an active fight camp plan
    const plan = await storage.getWeightCutPlan(user.id);
    if (plan && plan.fightDate) {
      const { calculateWeightCutPlan } = await import("./lib/weight-cut");
      const bw = await resolveBodyweight(user.id, targetDate, user.currentWeight);
      const currentWeight = bw.kg || weight;

      const cut = calculateWeightCutPlan(
        currentWeight,
        plan.targetWeight,
        plan.fightDate,
        (plan.weighInTiming as "same_day" | "day_before") ?? "same_day",
        targetDate,
        plan.manualTempReductionKg
      );

      if (cut.daysUntil > 0) {
        // ── Fight Camp Calorie Model v2 (warn, don't force) ─────────────────
        // 1. plannedCalories  = tdeeNoExercise + (exerciseKcalAdjusted × 0.8) − plannedDeficit
        // 2. targetCalories   = plannedCalories  (NO automatic floor clamping)
        // 3. Macro split by day type (protein+fat fixed; carbs = residual)
        //      hard:      protein 1.8 g/kg, fat 0.7 g/kg
        //      very_hard: protein 1.8 g/kg, fat 0.5 g/kg
        //      moderate:  protein 2.0 g/kg, fat 0.9 g/kg
        //      light:     protein 2.0 g/kg, fat 0.9 g/kg
        //      rest:      protein 2.0 g/kg, fat 1.0 g/kg
        // 4. Flags + recommendations returned to client; client shows modals
        //    and lets the user decide whether to adjust.
        // ────────────────────────────────────────────────────────────────────

        const bmr = profileTargets.bmr;

        // Fetch sessions + activities for the requested date (not always today)
        const [todaySessions, isRestDayMarked] = await Promise.all([
          storage.getWorkoutSessions(user.id, targetDate, targetDate),
          storage.getRestDayLog(user.id, targetDate),
        ]);
        const todayActivities = (
          await Promise.all(todaySessions.map((s: any) => storage.getSessionActivities(s.id)))
        ).flat();

        // Sessions override the rest day mark — once training is logged, it's not a rest day
        const isRestDay = isRestDayMarked && todaySessions.length === 0;

        // Exercise kcal: session-level sum — RPE is already baked into each activity's
        // estimatedKcal at storage time (applied on create/update), so no delta needed here.
        const exerciseKcalRaw = isRestDay ? 0 : todaySessions.reduce(
          (sum: number, s: any) => sum + (s.estimatedKcal || 0),
          0
        );
        // exerciseKcalAdjusted == exerciseKcalRaw; alias kept for clarity in formulas below.
        const exerciseKcalAdjusted = exerciseKcalRaw;

        // ── Fight Camp: 80% exercise add-back ────────────────────────────
        // Only 80% of adjusted exercise kcal counts toward the calorie target.
        // This creates a deliberate "non-recovered" deficit buffer to stay on
        // track during a weight cut even on hard training days.
        const exerciseKcalAddedBack = Math.round(exerciseKcalAdjusted * 0.8);

        // Day type classification from actual activity load
        const todayLoad = computeDailyLoad(todayActivities, todaySessions.length);
        const dayType: DayClassification = todayLoad.classification;

        // Planned deficit — from the weight cut planner's recommended rate (capped 1% BW/wk)
        const plannedDeficitKcal = Math.round(cut.recommendedWeeklyRate * 7700 / 7);

        // Baseline TDEE: NEAT only, no structured exercise
        const tdeeNoExercise = Math.round(bmr * 1.4);

        // Planned calories: NEAT + 80% of RPE-adjusted exercise − planned deficit
        const plannedCalories = Math.round(tdeeNoExercise + exerciseKcalAddedBack - plannedDeficitKcal);

        // ── Body composition ──────────────────────────────────────────────
        const bodyFatPct = (user.bodyFatPct != null) ? user.bodyFatPct : 0.15;
        const ffmKg = currentWeight * (1 - bodyFatPct);

        // ── Final calorie target (no floor clamping — user decides) ───────
        const targetCalories = plannedCalories;

        // ── Macro split by day type ───────────────────────────────────────
        // Protein and fat fixed per-kg; carbs absorb remaining calories
        let proteinPerKg: number;
        let fatPerKg: number;
        if (dayType === "hard") {
          proteinPerKg = 1.8; fatPerKg = 0.7;
        } else if (dayType === "very_hard") {
          proteinPerKg = 1.8; fatPerKg = 0.5;
        } else if (isRestDay) {
          proteinPerKg = 2.0; fatPerKg = 1.0;
        } else {
          // moderate or light
          proteinPerKg = 2.0; fatPerKg = 0.9;
        }

        const targetProtein = Math.round(proteinPerKg * currentWeight);
        const targetFat     = Math.round(fatPerKg * currentWeight);
        const carbCals      = Math.max(0, targetCalories - targetProtein * 4 - targetFat * 9);
        const targetCarbs   = Math.round(carbCals / 4);

        // ── EA value (kcal/kg FFM after subtracting exercise) ────────────
        // Uses RPE-adjusted exercise kcal — more accurate reflection of actual expenditure
        const eaValue = parseFloat(((plannedCalories - exerciseKcalAdjusted) / ffmKg).toFixed(1));
        const carbsPerKg = parseFloat((targetCarbs / currentWeight).toFixed(2));

        // ── Hard warning flags (client shows modals for these) ────────────
        const isLowEA = eaValue < 30;
        // Carb floor only fires when there are actual training calories (not empty sessions, not rest days)
        const isLowCarb = exerciseKcalAdjusted > 0 && !isRestDay && carbsPerKg < 3;

        // ── Recommendations (what the user would need to eat to fix each) ──
        // eaRecommendedCalories: exactly hits EA = 30 kcal/kg FFM
        const eaRecommendedCalories = Math.round(exerciseKcalAdjusted + 30 * ffmKg);
        // carbRecommendedG: 3 g/kg bodyweight (IOC/ISSN minimum for athletes)
        const carbRecommendedG = Math.round(3 * currentWeight);

        // ── Soft performance warnings (client shows as toast, not modal) ───
        // Only raised when NOT also triggering the hard modal (isLowCarb)
        let isBelowPerformanceCarb = false;
        let performanceCarbWarning: string | null = null;
        if (exerciseKcalAdjusted > 0 && !isRestDay && !isLowCarb) {
          if (dayType === "hard" && carbsPerKg < 4) {
            isBelowPerformanceCarb = true;
            performanceCarbWarning =
              "Carbohydrate intake may be low for this training load. Increasing toward ~5 g/kg may support performance.";
          } else if (dayType === "very_hard" && carbsPerKg < 5) {
            isBelowPerformanceCarb = true;
            performanceCarbWarning =
              "Carbohydrate intake may be low for a very high training load. Increasing toward ~5–7 g/kg may support performance.";
          }
          // moderate/light: covered by the hard carb modal at < 3 g/kg; no separate soft range
        }

        // provisional: no raw training logged yet and not explicitly a rest day
        const provisional = exerciseKcalRaw === 0 && !isRestDayMarked;

        return res.json({
          mode: "fight_camp",
          modeLabel: "Fight Camp Fat Loss",
          modeNote: !isRestDay
            ? "Training is included in your calorie target."
            : "Rest day — target is based on NEAT only.",
          targetCalories,
          targetProtein,
          targetCarbs,
          targetFat,
          tdee: tdeeNoExercise + exerciseKcalAdjusted,
          baselineTdee: tdeeNoExercise,
          // trainingKcalToday: raw MET-based sum (no RPE adjustment) — preserved for existing consumers
          trainingKcalToday: exerciseKcalRaw,
          // Extra fields for clients that want full visibility into the fight-camp calorie model
          trainingKcalTodayAdjusted: exerciseKcalAdjusted,
          trainingKcalAddedBack: exerciseKcalAddedBack,
          exerciseAddBackPct: 0.8,
          dailyDeficit: plannedDeficitKcal,
          plannedCalories,
          dayType,
          ffmKg: parseFloat(ffmKg.toFixed(1)),
          // EA + carb data
          eaValue,
          carbsPerKg,
          isLowEA,
          isLowCarb,
          // Recommendations — what the user would need to eat to resolve each warning
          eaRecommendedCalories,
          carbRecommendedG,
          // Soft warnings — client shows as toast (not modal)
          isBelowPerformanceCarb,
          performanceCarbWarning,
          // 0: training is baked into targetCalories — client must NOT add training again
          trainingCalorieCreditPct: 0,
          provisional,
          weeklyRate: cut.weeklyRate,
          weeklyRatePct: cut.weeklyRatePct,
          daysUntil: cut.daysUntil,
          // Plan identity fields — used by the client to detect plan changes and re-trigger consent modals
          planId: plan.id,
          planFightDate: plan.fightDate,
          planTargetWeight: plan.targetWeight,
        });
      }
    }

    // Profile goal mode (no active fight camp)
    const deficit =
      profileTargets.goal === "fat_loss" ? 500 :
      profileTargets.goal === "weight_gain" ? -300 : 0;

    return res.json({
      mode: profileTargets.goal,
      modeLabel:
        profileTargets.goal === "weight_gain" ? "Weight Gain" :
        profileTargets.goal === "maintenance" ? "Maintenance" : "Fat Loss",
      modeNote: null,
      targetCalories: profileTargets.targetCalories,
      targetProtein: profileTargets.targetProtein,
      targetCarbs: profileTargets.targetCarbs,
      targetFat: profileTargets.targetFat,
      tdee,
      dailyDeficit: deficit,
      trainingCalorieCreditPct: profileTargets.trainingCalorieCreditPct,
    });
  });

  // ===== Morning Status =====
  app.get("/api/me/morning-status/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    const userId = auth.profileUser.id;
    const date = req.params.date;

    const sleepLog = await storage.getSleepLog(userId, date);
    const weightEntries = await storage.getWeightsRange(userId, date, date);
    const hasWeight = weightEntries.length > 0;
    const sessions = await storage.getWorkoutSessions(userId, date, date);
    const isRestDayMarked = await storage.getRestDayLog(userId, date);
    // Sessions override rest day mark — training logged = not a rest day
    const isRestDay = isRestDayMarked && sessions.length === 0;

    res.json({
      hasSleep: !!sleepLog,
      hasWeight,
      hasPlannedTraining: sessions.length > 0,
      isRestDay,
      sleepLog: sleepLog || null,
      weightLog: weightEntries[0] || null,
    });
  });

  app.post("/api/me/rest-day/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    await storage.setRestDayLog(auth.profileUser.id, req.params.date);
    res.json({ isRestDay: true });
  });

  app.delete("/api/me/rest-day/:date", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    if (!isValidDateParam(req.params.date)) return res.status(400).json({ message: "Invalid date format" });
    await storage.deleteRestDayLog(auth.profileUser.id, req.params.date);
    res.json({ isRestDay: false });
  });

  // Helper function to get username from userId
  async function getUsernameFromUserId(userId: number): Promise<string | null> {
    // This is a workaround since we don't have getUserById
    const users = await storage.getUser(""); // Won't work, need to iterate
    // For now, return null and handle in callers
    return null;
  }

  // Helper function to recalculate session calories
  // Calories are derived from child items only: sum(exerciseKcal) + sum(activityKcal)
  // Resistance training uses simple per-set estimates (~3-6 kcal/set by intensity)
  // Activities use MET-based calculations (requires user weight)
  async function recalculateSessionCalories(sessionId: number): Promise<void> {
    const session = await storage.getWorkoutSession(sessionId);
    if (!session) return;
    
    // Resolve bodyweight from daily logs → recent 7-day → profile
    const sessionUser = await storage.getUserById(session.userId);
    const bwSession = await resolveBodyweight(session.userId, session.date, sessionUser?.currentWeight);
    const weight = bwSession.kg;
    
    // Conservative per-set calorie estimates for resistance training exercises
    const kcalPerSetByIntensity: Record<string, number> = {
      light: 3,
      moderate: 4.5,
      vigorous: 6,
    };
    
    const exercises = await storage.getWorkoutExercises(sessionId);
    let exerciseKcal = 0;
    
    for (const exercise of exercises) {
      const sets = await storage.getWorkoutSets(exercise.id);
      const setCount = sets.length;
      
      if (setCount > 0) {
        const kcalPerSet = kcalPerSetByIntensity[exercise.intensity || "moderate"] || 4.5;
        const kcal = Math.round(setCount * kcalPerSet);
        exerciseKcal += kcal;
        await storage.updateWorkoutExercise(exercise.id, { estimatedKcal: kcal });
      } else {
        await storage.updateWorkoutExercise(exercise.id, { estimatedKcal: 0 });
      }
    }
    
    const activities = await storage.getSessionActivities(sessionId);
    let activityKcal = 0;
    for (const a of activities) {
      if (a.activityType === "lifting" && a.sessionRpe && a.bodyRegion && weight) {
        // Re-derive lifting calories using the RPE formula
        const kcalResult = estimateLiftingCalories({
          durationMinutes: a.durationMinutes,
          sessionRpe: a.sessionRpe,
          bodyRegion: a.bodyRegion as BodyRegion,
          bodyweightKg: weight,
        });
        activityKcal += kcalResult.estimatedKcal;
        // Persist the corrected value if it differs from stored
        if (kcalResult.estimatedKcal !== (a.estimatedKcal ?? 0)) {
          await storage.updateSessionActivity(a.id, { estimatedKcal: kcalResult.estimatedKcal });
        }
      } else if (a.activityType === "lifting") {
        // No bodyweight available — keep stored value (may be 0)
        activityKcal += a.estimatedKcal || 0;
      } else if (a.metValue > 0 && weight) {
        // Cardio: re-derive from MET × weight × duration, then apply RPE factor
        const rawKcal = Math.round((a.metValue * 3.5 * weight / 200) * a.durationMinutes);
        const rpeVal: number | null = (a as any).rpe ?? null;
        const rpeFactor = (rpeVal !== null && shouldApplyRpeKcalAdjustment(a.name, a.activityType))
          ? getRpeKcalAdjustmentFactor(rpeVal)
          : 1;
        const kcal = Math.round(rawKcal * rpeFactor);
        activityKcal += kcal;
        // Keep the stored estimatedKcal in sync so the activity card reflects RPE
        if (kcal !== (a.estimatedKcal ?? 0)) {
          await storage.updateSessionActivity(a.id, { estimatedKcal: kcal });
        }
      } else {
        activityKcal += a.estimatedKcal || 0;
      }
    }
    
    const totalKcal = exerciseKcal + activityKcal;
    await storage.updateWorkoutSession(sessionId, { estimatedKcal: totalKcal });
  }

  // ===== Training Block Planner =====

  // GET /api/training-blocks/active
  app.get("/api/training-blocks/active", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const block = await storage.getActiveTrainingBlock(auth.profileUser.id);
    res.json(block ?? null);
  });

  // POST /api/training-blocks
  app.post("/api/training-blocks", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { name, startDate, weekCount, days } = req.body;
    if (!name || !startDate || !weekCount || !Array.isArray(days)) {
      return res.status(400).json({ message: "name, startDate, weekCount, and days are required" });
    }
    if (!isValidDateParam(startDate)) {
      return res.status(400).json({ message: "Invalid startDate format" });
    }
    // Ensure each day has activities array
    const normalizedDays = days.map((d: any) => ({
      dayOfWeek: d.dayOfWeek,
      plannedLoad: d.plannedLoad ?? "rest",
      activities: Array.isArray(d.activities) ? d.activities : [],
      notes: d.notes ?? null,
    }));
    const block = await storage.createTrainingBlock(auth.profileUser.id, { name, startDate, weekCount }, normalizedDays);
    res.status(201).json(block);
  });

  // DELETE /api/training-blocks/:id
  app.delete("/api/training-blocks/:id", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const blockId = parseInt(req.params.id);
    if (isNaN(blockId)) return res.status(400).json({ message: "Invalid block id" });
    await storage.archiveTrainingBlock(auth.profileUser.id, blockId);
    res.json({ ok: true });
  });

  // POST /api/training-blocks/preview
  // Computes projected ACWR for each week of a proposed block, using actual historical load as the baseline.
  app.post("/api/training-blocks/preview", async (req, res) => {
    const auth = await getAuthenticatedUser(req, res);
    if (!auth) return;
    const { startDate, weekCount, days: templateDays } = req.body;
    if (!startDate || !weekCount || !Array.isArray(templateDays)) {
      return res.status(400).json({ message: "startDate, weekCount, and days are required" });
    }
    if (!isValidDateParam(startDate)) return res.status(400).json({ message: "Invalid startDate" });

    // Compute day AU from actual activities (RPE × duration sum)
    const computeDayAU = (activities: any[]): number => {
      if (!activities || activities.length === 0) return 0;
      return activities.reduce((sum: number, a: any) => {
        if (a.rpe) return sum + a.rpe * a.durationMinutes;
        if (a.metValue) return sum + a.metValue * a.durationMinutes;
        return sum + a.durationMinutes * 3;
      }, 0);
    };

    // Build a map: dayOfWeek → AU load
    const dayMap: Record<number, number> = {};
    for (const d of templateDays) {
      dayMap[d.dayOfWeek] = computeDayAU(d.activities ?? []);
    }

    // Fetch 28 days of actual history before startDate (newest-first)
    const startDateObj = new Date(startDate);
    const historyEndDate = new Date(startDateObj);
    historyEndDate.setDate(historyEndDate.getDate() - 1);
    const historyEndStr = historyEndDate.toISOString().split("T")[0];
    const historicalLoads = await fetchHistoricalLoads(auth.profileUser.id, historyEndStr, 28);

    // Build chronological timeline: history (oldest→newest) then block days
    const chronoHistory = [...historicalLoads].reverse(); // oldest first

    // Generate all block days as DailyLoadResult
    const totalDays = weekCount * 7;
    const blockDayLoads: import("./lib/training-load").DailyLoadResult[] = [];
    for (let i = 0; i < totalDays; i++) {
      const d = new Date(startDateObj);
      d.setDate(d.getDate() + i);
      const dow = (d.getDay() + 6) % 7; // 0=Mon…6=Sun
      const load = dayMap[dow] ?? 0;
      blockDayLoads.push({
        totalLoad: load,
        classification: classifyDayLoad(load),
        provisional: false,
        sessionCount: load > 0 ? 1 : 0,
        totalDurationMinutes: 0,
        totalKcal: 0,
      });
    }

    // Full chronological series
    const fullSeries = [...chronoHistory, ...blockDayLoads];

    // For each day in the block compute ACWR using trailing window
    const DOW_ABBREV = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

    const weekSummaries: {
      weekNum: number;
      startDate: string;
      endDate: string;
      days: { date: string; dow: number; plannedLoad: string; load: number }[];
      peakAcwr: number | null;
      avgLoad: number;
      hasSpike: boolean;
      hasCluster: boolean;
      warningReasons: string[];
    }[] = [];

    for (let w = 0; w < weekCount; w++) {
      const weekDays: { date: string; dow: number; plannedLoad: string; load: number }[] = [];
      let peakAcwr: number | null = null;
      let hasSpike = false;
      let hasCluster = false;
      const warningReasons: string[] = [];
      let clusterReported = false;

      for (let d = 0; d < 7; d++) {
        const idx = w * 7 + d;
        const dayDate = new Date(startDateObj);
        dayDate.setDate(dayDate.getDate() + idx);
        const dateStr = dayDate.toISOString().split("T")[0];
        const dow = (dayDate.getDay() + 6) % 7;
        const auLoad = dayMap[dow] ?? 0;
        const pl = auLoad === 0 ? "rest" : auLoad < 200 ? "light" : auLoad < 500 ? "moderate" : auLoad < 800 ? "hard" : "very_hard";

        // Position in fullSeries
        const pos = chronoHistory.length + idx;
        const todayLoad = fullSeries[pos];
        const prior = fullSeries.slice(0, pos).reverse(); // newest-first
        const { acwr, highLoadCluster, loadStatus, threeDayStreak } = computeLoadWarnings(todayLoad, prior);

        if (acwr !== null) {
          if (peakAcwr === null || acwr > peakAcwr) peakAcwr = acwr;
          if (acwr > 1.5) {
            hasSpike = true;
            warningReasons.push(`ACWR spike on ${DOW_ABBREV[dow]} (${acwr.toFixed(2)})`);
          } else if (acwr > 1.3) {
            warningReasons.push(`Elevated ACWR on ${DOW_ABBREV[dow]} (${acwr.toFixed(2)})`);
          }
        }
        if (threeDayStreak && !clusterReported) {
          warningReasons.push("3 consecutive high-load days");
          clusterReported = true;
        } else if (highLoadCluster && !clusterReported) {
          warningReasons.push("High-load cluster (2+ hard days in 3)");
          clusterReported = true;
        }
        if (highLoadCluster) hasCluster = true;
        if (loadStatus === "spike") hasSpike = true;

        weekDays.push({ date: dateStr, dow, plannedLoad: pl, load: todayLoad.totalLoad });
      }

      const wStart = new Date(startDateObj);
      wStart.setDate(wStart.getDate() + w * 7);
      const wEnd = new Date(wStart);
      wEnd.setDate(wEnd.getDate() + 6);
      const avgLoad = Math.round(weekDays.reduce((s, x) => s + x.load, 0) / 7);

      weekSummaries.push({
        weekNum: w + 1,
        startDate: wStart.toISOString().split("T")[0],
        endDate: wEnd.toISOString().split("T")[0],
        days: weekDays,
        peakAcwr: peakAcwr !== null ? Math.round(peakAcwr * 100) / 100 : null,
        avgLoad,
        hasSpike,
        hasCluster,
        warningReasons,
      });
    }

    const hasAnyOvertraining = weekSummaries.some(w => w.hasSpike);
    res.json({ weeks: weekSummaries, hasAnyOvertraining });
  });

  return httpServer;
}
