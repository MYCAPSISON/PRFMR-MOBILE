import { Router } from "express";
import rateLimit from "express-rate-limit";
import { requireAuth } from "./auth";
import { storage } from "./storage";
import { insertFeedbackSchema } from "@shared/schema";
import { sendEmail } from "./lib/email";
import { getAppVersion, getEnvironment } from "./lib/version";
import { db } from "./db";
import { usersAuth } from "@shared/schema";
import { eq } from "drizzle-orm";
import { ObjectStorageService } from "./replit_integrations/object_storage/objectStorage";

const router = Router();
const objectStorageService = new ObjectStorageService();

const feedbackLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { message: "Too many feedback submissions. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    return `feedback-${String((req as any).user?.id || "anon")}`;
  },
  validate: { xForwardedForHeader: false },
});

router.post("/api/feedback/upload-url", requireAuth, async (req, res) => {
  try {
    const { name, size, contentType } = req.body;

    if (!name || !contentType) {
      return res.status(400).json({ message: "Missing required fields: name, contentType" });
    }

    const allowedTypes = ["image/png", "image/jpeg", "image/webp"];
    if (!allowedTypes.includes(contentType)) {
      return res.status(400).json({ message: "Only PNG, JPEG, and WebP images are allowed" });
    }

    const maxSize = 5 * 1024 * 1024;
    if (size && size > maxSize) {
      return res.status(400).json({ message: "File size must be under 5MB" });
    }

    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);

    res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
  } catch (error) {
    console.error("[feedback] Error generating upload URL:", error);
    res.status(500).json({ message: "Failed to generate upload URL" });
  }
});

router.post("/api/feedback", requireAuth, feedbackLimiter, async (req, res) => {
  try {
    const userId = (req as any).user?.id;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const { attachments, ...feedbackData } = req.body;

    const parsed = insertFeedbackSchema.safeParse({ ...feedbackData, userId });
    if (!parsed.success) {
      return res.status(400).json({ message: "Invalid feedback", errors: parsed.error.flatten().fieldErrors });
    }

    const created = await storage.createFeedback(parsed.data);

    let savedAttachments: Array<{ url: string; filename: string; mimeType: string; size: number }> = [];
    if (Array.isArray(attachments) && attachments.length > 0) {
      const allowedMimes = ["image/png", "image/jpeg", "image/webp"];
      const maxSize = 5 * 1024 * 1024;
      const validAttachments = attachments
        .slice(0, 3)
        .filter((a: any) =>
          a.url && typeof a.url === "string" && a.url.startsWith("/objects/uploads/") &&
          a.filename && typeof a.filename === "string" &&
          a.mimeType && allowedMimes.includes(a.mimeType) &&
          typeof a.size === "number" && a.size > 0 && a.size <= maxSize
        );

      if (validAttachments.length > 0) {
        const records = validAttachments.map((a: any) => ({
          feedbackId: created.id,
          url: a.url,
          filename: a.filename,
          mimeType: a.mimeType,
          size: a.size,
        }));
        savedAttachments = await storage.createFeedbackAttachments(records);
      }
    }

    const feedbackToEmail = process.env.FEEDBACK_TO_EMAIL;
    if (feedbackToEmail) {
      const [authUser] = await db.select().from(usersAuth).where(eq(usersAuth.id, userId)).limit(1);
      const userIdentifier = authUser?.email || authUser?.username || `User #${userId}`;
      const subject = `PRFMR Beta Feedback — ${parsed.data.category} — ${userIdentifier}`;
      const timestamp = new Date().toISOString();
      const appBaseUrl = process.env.APP_BASE_URL || "https://app.prfmr.link";

      const attachmentLinksHtml = savedAttachments.length > 0
        ? `<div class="field"><span class="label">Attachments:</span><ul>${savedAttachments.map(
            (a) => `<li><a href="${appBaseUrl}${a.url}">${a.filename}</a> (${(a.size / 1024).toFixed(1)} KB)</li>`
          ).join("")}</ul></div>`
        : "";

      const text = [
        `Category: ${parsed.data.category}`,
        `Message: ${parsed.data.message}`,
        `Route: ${parsed.data.route || "N/A"}`,
        `Timestamp: ${timestamp}`,
        `User ID: ${userId}`,
        `Email: ${authUser?.email || "N/A"}`,
        `User Agent: ${parsed.data.userAgent || "N/A"}`,
        `Viewport: ${parsed.data.viewport || "N/A"}`,
        `App Version: ${parsed.data.appVersion || getAppVersion()}`,
        savedAttachments.length > 0 ? `Attachments: ${savedAttachments.map(a => `${a.filename} (${appBaseUrl}${a.url})`).join(", ")}` : "",
      ].filter(Boolean).join("\n");

      const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .label { font-weight: bold; color: #555; }
    .field { margin-bottom: 12px; }
    .message { background: #f3f4f6; padding: 12px; border-radius: 6px; margin: 16px 0; white-space: pre-wrap; }
    .badge { display: inline-block; background-color: #f97316; color: white; padding: 4px 12px; border-radius: 12px; font-size: 13px; text-transform: uppercase; }
    ul { padding-left: 20px; }
    li { margin-bottom: 4px; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Beta Feedback</h2>
    <span class="badge">${parsed.data.category}</span>
    <div class="message">${parsed.data.message.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</div>
    <div class="field"><span class="label">Route:</span> ${parsed.data.route || "N/A"}</div>
    <div class="field"><span class="label">Timestamp:</span> ${timestamp}</div>
    <div class="field"><span class="label">User:</span> ${userIdentifier} (ID: ${userId})</div>
    <div class="field"><span class="label">User Agent:</span> ${parsed.data.userAgent || "N/A"}</div>
    <div class="field"><span class="label">Viewport:</span> ${parsed.data.viewport || "N/A"}</div>
    <div class="field"><span class="label">App Version:</span> ${parsed.data.appVersion || getAppVersion()}</div>
    ${attachmentLinksHtml}
  </div>
</body>
</html>`;

      sendEmail({ to: feedbackToEmail, subject, text, html }).catch((err) => {
        console.error("[feedback] Failed to send email notification:", err);
      });
    }

    res.status(201).json({ ...created, attachments: savedAttachments });
  } catch (error: any) {
    console.error("[feedback] Error creating feedback:", error);
    res.status(500).json({ message: "Failed to submit feedback" });
  }
});

router.get("/api/feedback/mine", requireAuth, async (req, res) => {
  try {
    const userId = (req as any).user?.id;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const items = await storage.getUserFeedback(userId, 10);
    res.json(items);
  } catch (error: any) {
    console.error("[feedback] Error fetching feedback:", error);
    res.status(500).json({ message: "Failed to fetch feedback" });
  }
});

export default router;
