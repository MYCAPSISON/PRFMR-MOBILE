--
-- PostgreSQL database dump
--

\restrict WZjaTrcfpXR9ARZplDoSZBpu7i2TnwDnEhbvEQOKDXlwgQu1cRv4aw45HSUomd2

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: food_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.food_entries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date text NOT NULL,
    name text NOT NULL,
    grams integer DEFAULT 100,
    calories integer NOT NULL,
    protein integer NOT NULL,
    carbs integer NOT NULL,
    fat integer NOT NULL,
    fibre integer DEFAULT 0,
    meal text DEFAULT 'lunch'::text NOT NULL,
    snack_index integer
);


--
-- Name: food_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.food_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: food_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.food_entries_id_seq OWNED BY public.food_entries.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date text NOT NULL,
    weight real,
    calories integer DEFAULT 0,
    protein integer DEFAULT 0,
    carbs integer DEFAULT 0,
    fat integer DEFAULT 0,
    fibre integer DEFAULT 0
);


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: stack_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stack_reminders (
    id integer NOT NULL,
    stack_id integer NOT NULL,
    "time" text NOT NULL,
    days_of_week text NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: stack_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stack_reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stack_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stack_reminders_id_seq OWNED BY public.stack_reminders.id;


--
-- Name: stack_supplements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stack_supplements (
    id integer NOT NULL,
    stack_id integer NOT NULL,
    supplement_id integer NOT NULL
);


--
-- Name: stack_supplements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stack_supplements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stack_supplements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stack_supplements_id_seq OWNED BY public.stack_supplements.id;


--
-- Name: supplement_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplement_catalog (
    id integer NOT NULL,
    name text NOT NULL,
    default_unit text NOT NULL,
    micros_per_unit text NOT NULL,
    notes text
);


--
-- Name: supplement_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplement_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplement_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplement_catalog_id_seq OWNED BY public.supplement_catalog.id;


--
-- Name: supplement_intakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplement_intakes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    supplement_id integer NOT NULL,
    stack_id integer,
    reminder_id integer,
    date text NOT NULL,
    taken boolean DEFAULT true NOT NULL,
    taken_at text
);


--
-- Name: supplement_intakes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplement_intakes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplement_intakes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplement_intakes_id_seq OWNED BY public.supplement_intakes.id;


--
-- Name: supplement_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplement_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    supplement_id integer NOT NULL,
    stack_id integer,
    date text NOT NULL,
    "time" text,
    taken boolean DEFAULT true NOT NULL
);


--
-- Name: supplement_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplement_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplement_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplement_logs_id_seq OWNED BY public.supplement_logs.id;


--
-- Name: supplement_stacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplement_stacks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    description text
);


--
-- Name: supplement_stacks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplement_stacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplement_stacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplement_stacks_id_seq OWNED BY public.supplement_stacks.id;


--
-- Name: supplements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplements (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    brand text,
    form text,
    notes text,
    catalog_id integer,
    dose_amount real,
    dose_unit text
);


--
-- Name: supplements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplements_id_seq OWNED BY public.supplements.id;


--
-- Name: user_disclaimer_acceptance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_disclaimer_acceptance (
    id integer NOT NULL,
    user_id integer NOT NULL,
    disclaimer_type text NOT NULL,
    accepted_at text NOT NULL
);


--
-- Name: user_disclaimer_acceptance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_disclaimer_acceptance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_disclaimer_acceptance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_disclaimer_acceptance_id_seq OWNED BY public.user_disclaimer_acceptance.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    age integer,
    gender text,
    height integer,
    current_weight real,
    activity_level text,
    goal text,
    experience_level text,
    target_calories integer,
    target_protein integer,
    target_carbs integer,
    target_fat integer
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: weights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weights (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date text NOT NULL,
    weight real NOT NULL
);


--
-- Name: weights_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weights_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weights_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weights_id_seq OWNED BY public.weights.id;


--
-- Name: food_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.food_entries ALTER COLUMN id SET DEFAULT nextval('public.food_entries_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: stack_reminders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stack_reminders ALTER COLUMN id SET DEFAULT nextval('public.stack_reminders_id_seq'::regclass);


--
-- Name: stack_supplements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stack_supplements ALTER COLUMN id SET DEFAULT nextval('public.stack_supplements_id_seq'::regclass);


--
-- Name: supplement_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_catalog ALTER COLUMN id SET DEFAULT nextval('public.supplement_catalog_id_seq'::regclass);


--
-- Name: supplement_intakes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_intakes ALTER COLUMN id SET DEFAULT nextval('public.supplement_intakes_id_seq'::regclass);


--
-- Name: supplement_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_logs ALTER COLUMN id SET DEFAULT nextval('public.supplement_logs_id_seq'::regclass);


--
-- Name: supplement_stacks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_stacks ALTER COLUMN id SET DEFAULT nextval('public.supplement_stacks_id_seq'::regclass);


--
-- Name: supplements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplements ALTER COLUMN id SET DEFAULT nextval('public.supplements_id_seq'::regclass);


--
-- Name: user_disclaimer_acceptance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_disclaimer_acceptance ALTER COLUMN id SET DEFAULT nextval('public.user_disclaimer_acceptance_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: weights id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weights ALTER COLUMN id SET DEFAULT nextval('public.weights_id_seq'::regclass);


--
-- Data for Name: food_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.food_entries (id, user_id, date, name, grams, calories, protein, carbs, fat, fibre, meal, snack_index) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs (id, user_id, date, weight, calories, protein, carbs, fat, fibre) FROM stdin;
\.


--
-- Data for Name: stack_reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stack_reminders (id, stack_id, "time", days_of_week, enabled) FROM stdin;
\.


--
-- Data for Name: stack_supplements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stack_supplements (id, stack_id, supplement_id) FROM stdin;
\.


--
-- Data for Name: supplement_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplement_catalog (id, name, default_unit, micros_per_unit, notes) FROM stdin;
\.


--
-- Data for Name: supplement_intakes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplement_intakes (id, user_id, supplement_id, stack_id, reminder_id, date, taken, taken_at) FROM stdin;
\.


--
-- Data for Name: supplement_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplement_logs (id, user_id, supplement_id, stack_id, date, "time", taken) FROM stdin;
\.


--
-- Data for Name: supplement_stacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplement_stacks (id, user_id, name, description) FROM stdin;
\.


--
-- Data for Name: supplements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplements (id, user_id, name, brand, form, notes, catalog_id, dose_amount, dose_unit) FROM stdin;
\.


--
-- Data for Name: user_disclaimer_acceptance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_disclaimer_acceptance (id, user_id, disclaimer_type, accepted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, age, gender, height, current_weight, activity_level, goal, experience_level, target_calories, target_protein, target_carbs, target_fat) FROM stdin;
\.


--
-- Data for Name: weights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weights (id, user_id, date, weight) FROM stdin;
\.


--
-- Name: food_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.food_entries_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_id_seq', 1, false);


--
-- Name: stack_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stack_reminders_id_seq', 1, false);


--
-- Name: stack_supplements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stack_supplements_id_seq', 1, false);


--
-- Name: supplement_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplement_catalog_id_seq', 1, false);


--
-- Name: supplement_intakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplement_intakes_id_seq', 1, false);


--
-- Name: supplement_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplement_logs_id_seq', 1, false);


--
-- Name: supplement_stacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplement_stacks_id_seq', 1, false);


--
-- Name: supplements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplements_id_seq', 1, false);


--
-- Name: user_disclaimer_acceptance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_disclaimer_acceptance_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: weights_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weights_id_seq', 1, false);


--
-- Name: food_entries food_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.food_entries
    ADD CONSTRAINT food_entries_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: stack_reminders stack_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stack_reminders
    ADD CONSTRAINT stack_reminders_pkey PRIMARY KEY (id);


--
-- Name: stack_supplements stack_supplements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stack_supplements
    ADD CONSTRAINT stack_supplements_pkey PRIMARY KEY (id);


--
-- Name: supplement_catalog supplement_catalog_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_catalog
    ADD CONSTRAINT supplement_catalog_name_unique UNIQUE (name);


--
-- Name: supplement_catalog supplement_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_catalog
    ADD CONSTRAINT supplement_catalog_pkey PRIMARY KEY (id);


--
-- Name: supplement_intakes supplement_intakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_intakes
    ADD CONSTRAINT supplement_intakes_pkey PRIMARY KEY (id);


--
-- Name: supplement_logs supplement_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_logs
    ADD CONSTRAINT supplement_logs_pkey PRIMARY KEY (id);


--
-- Name: supplement_stacks supplement_stacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplement_stacks
    ADD CONSTRAINT supplement_stacks_pkey PRIMARY KEY (id);


--
-- Name: supplements supplements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplements
    ADD CONSTRAINT supplements_pkey PRIMARY KEY (id);


--
-- Name: user_disclaimer_acceptance user_disclaimer_acceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_disclaimer_acceptance
    ADD CONSTRAINT user_disclaimer_acceptance_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: weights weights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weights
    ADD CONSTRAINT weights_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict WZjaTrcfpXR9ARZplDoSZBpu7i2TnwDnEhbvEQOKDXlwgQu1cRv4aw45HSUomd2

