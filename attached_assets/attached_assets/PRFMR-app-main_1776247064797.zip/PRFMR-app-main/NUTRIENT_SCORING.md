# AMQS — Athlete Micronutrient Quality Score

## 1. Where the Scoring Logic Lives

| File | What it does |
|---|---|
| `server/lib/amqs.ts` | Core scoring engine — defines nutrients, weights, targets, calculates the final score, identifies gaps, generates food suggestions |
| `server/lib/micros.ts` | Aggregates daily micronutrient intake from food entries and supplements |
| `data/ingredients.json` | Reference database of foods with micronutrient values per 100g |
| `shared/utils.ts` | `getMicronutrientValue()` helper used to safely read nutrient values from ingredient objects |

### Key Functions

| Function | File | Role |
|---|---|---|
| `computeAMQSScore()` | `amqs.ts` | Main scoring function — takes user ID + date, returns score, tier, gaps, suggestions |
| `computeWeeklyAMQS()` | `amqs.ts` | Averages daily AMQS scores across a date range |
| `getDailyMicros()` | `micros.ts` | Sums all micronutrient intake (food + supplements) for one day |
| `getFoodMicrosForDate()` | `micros.ts` | Calculates micronutrient contributions from food entries |
| `getSupplementMicrosForDate()` | `micros.ts` | Calculates micronutrient contributions from taken supplements |

---

## 2. How the Score is Calculated

### The Formula

The AMQS is a **weighted average of nutrient adequacy ratios**, producing a score from 0 to 100.

```
AMQS = (Σ weight_i × adequacy_i) / (Σ weight_i) × 100
```

Where:
- `adequacy_i = min(intake_i / target_i, 1.0)` — how much of the daily target you've met, capped at 100%
- `weight_i` — how important each nutrient is (higher weight = more influence on the score)
- The sum runs over all 12 tracked nutrients

### Why Cap Adequacy at 1.0?

If you eat 500% of your selenium target (e.g., from Brazil nuts), that shouldn't mask a vitamin D deficiency. Capping at 1.0 means **meeting the target gives full credit, but exceeding it gives no extra credit**.

### Relevant Code

```typescript
// server/lib/amqs.ts, line ~217
const adequacy = Math.min(intake / target, 1.0);

// line ~230
sumWeightAdequacy += weight * adequacy;
sumWeight += weight;

// line ~258
const score = sumWeight === 0 ? 0 : Math.round((100 * sumWeightAdequacy) / sumWeight);
```

### Tier Classification

| Tier | Score Range |
|---|---|
| Elite | 90–100 |
| Optimal | 75–89 |
| Good | 50–74 |
| Fair | 30–49 |
| Basic | 0–29 |

### Confidence Level

The system also reports a data confidence level based on how many of your logged items actually have micronutrient data in the database:

| Confidence | Coverage |
|---|---|
| High | ≥ 75% of logged items have micro data |
| Medium | 40–74% |
| Low | < 40% (or no items logged) |

---

## 3. Nutrients Ranked by Weight

All 12 tracked nutrients, sorted from highest to lowest importance in the scoring system:

| Rank | Nutrient | Key | Weight | Unit | Daily Target (Male) | Daily Target (Female) |
|---|---|---|---|---|---|---|
| 1 | Iron | `iron_mg` | 2.0 (2.5 for females) | mg | 8.7 | 14.8 |
| 2 | Calcium | `calcium_mg` | 2.0 | mg | 700 | 700 |
| 3 | Vitamin D | `vitamin_d_ug` | 2.0 | µg | 10 | 10 |
| 4 | Magnesium | `magnesium_mg` | 1.5 | mg | 300 | 270 |
| 5 | Zinc | `zinc_mg` | 1.5 | mg | 9.5 | 7.0 |
| 6 | Iodine | `iodine_ug` | 1.0 | µg | 140 | 140 |
| 7 | Selenium | `selenium_ug` | 1.0 | µg | 75 | 60 |
| 8 | Folate | `folate_ug` | 1.0 | µg | 200 | 200 |
| 9 | Vitamin B12 | `vitamin_b12_ug` | 1.0 (2.0 for vegans) | µg | 1.5 | 1.5 |
| 10 | Vitamin C | `vitamin_c_mg` | 1.0 | mg | 40 | 40 |
| 11 | Vitamin A | `vitamin_a_ug` | 1.0 | µg | 700 | 600 |
| 12 | Potassium | `potassium_mg` | 1.0 | mg | 3500 | 3500 |

### Dynamic Weight Adjustments

Two nutrients have weights that change based on the user's profile:

- **Iron** — increases from 2.0 to **2.5** for females (higher menstrual iron losses)
- **Vitamin B12** — increases from 1.0 to **2.0** for vegans (no dietary B12 from animal sources)

These adjustments are applied in `server/lib/amqs.ts` (lines 227–228):

```typescript
if (n.key === "vitamin_b12_ug" && profile.diet === "vegan") weight = 2.0;
if (n.key === "iron_mg" && profile.sex === "female") weight = 2.5;
```

---

## 4. Why These Nutrients are Weighted Higher for Athletes

### Tier 1 — Weight 2.0 (Critical for Athletic Performance)

**Iron (weight 2.0, or 2.5 for females)**
- Transports oxygen via haemoglobin — directly impacts endurance and aerobic capacity
- Lost through sweat, foot-strike haemolysis (runners), and menstruation
- Iron deficiency is one of the most common nutritional deficiencies in athletes
- Even mild depletion impairs recovery and training adaptation

**Calcium (weight 2.0)**
- Essential for bone strength and density — critical for impact sports and fighters
- Supports muscle contraction mechanics
- Stress fractures are a real risk in high-training-volume athletes with low calcium intake
- Works synergistically with Vitamin D

**Vitamin D (weight 2.0)**
- Regulates calcium absorption (bone health)
- Supports immune function — important for athletes with high training loads
- Influences testosterone production and muscle protein synthesis
- Many athletes are deficient, especially those training indoors or in northern climates

### Tier 2 — Weight 1.5 (Important for Recovery)

**Magnesium (weight 1.5)**
- Involved in 300+ enzymatic reactions including energy production (ATP)
- Lost through sweat during training
- Supports muscle relaxation and sleep quality — both critical for recovery
- Common deficiency in active populations

**Zinc (weight 1.5)**
- Essential for protein synthesis and muscle repair
- Supports immune function (prevents training-related illness)
- Lost through sweat
- Important for testosterone production

### Tier 3 — Weight 1.0 (Supporting Nutrients)

**Iodine** — Thyroid function (metabolic rate regulation)
**Selenium** — Antioxidant defence against exercise-induced oxidative stress
**Folate** — Red blood cell production, DNA repair
**Vitamin B12** — Energy metabolism, nerve function (elevated to 2.0 for vegans who get none from diet)
**Vitamin C** — Collagen synthesis (joint/tendon health), immune support, iron absorption
**Vitamin A** — Immune function, vision, tissue repair
**Potassium** — Electrolyte balance, muscle contraction, lost heavily in sweat

---

## 5. How to Modify the Scoring System

### Changing Nutrient Weights

Open `server/lib/amqs.ts` and find the `NUTRIENTS` array (starts at line ~25):

```typescript
const NUTRIENTS: NutrientDef[] = [
  { key: "iron_mg", displayName: "Iron", unit: "mg", weight: 2.0, getTarget: (p) => (p.sex === "female" ? 14.8 : 8.7) },
  // ... more nutrients
];
```

To change a weight, simply update the `weight` number. For example, to make Vitamin C more important:

```typescript
// Before
{ key: "vitamin_c_mg", displayName: "Vitamin C", unit: "mg", weight: 1.0, getTarget: () => 40 },

// After — now weighted the same as Iron
{ key: "vitamin_c_mg", displayName: "Vitamin C", unit: "mg", weight: 2.0, getTarget: () => 40 },
```

Save the file. The server auto-restarts and the new weight takes effect immediately.

### Adding a New Nutrient

Three steps:

**Step 1** — Add to the `NUTRIENTS` array in `server/lib/amqs.ts`:

```typescript
{ key: "omega3_g", displayName: "Omega-3", unit: "g", weight: 1.5, getTarget: () => 1.6 },
```

**Step 2** — Add the key to `MICRO_KEYS` in `server/lib/micros.ts` (line ~144):

```typescript
const MICRO_KEYS = [
  "iron_mg",
  // ... existing keys
  "omega3_g",  // add here
];
```

**Step 3** — Add `omega3_g_per_100g` values to each food entry in `data/ingredients.json`:

```json
{
  "name": "Salmon (Fresh)",
  "omega3_g_per_100g": 2.3,
  // ... existing fields
}
```

### Changing Daily Targets

Targets are defined as functions that receive the user profile (sex, age, diet). To change a target:

```typescript
// Before — same target for everyone
{ key: "vitamin_c_mg", ..., getTarget: () => 40 },

// After — higher target for athletes (example)
{ key: "vitamin_c_mg", ..., getTarget: () => 80 },

// Or make it sex-dependent
{ key: "vitamin_c_mg", ..., getTarget: (p) => (p.sex === "female" ? 75 : 90) },
```

### Adjusting the Tier Thresholds

Find the `getTier()` function in `server/lib/amqs.ts` (line ~40):

```typescript
function getTier(score: number) {
  if (score >= 90) return "Elite";
  if (score >= 75) return "Optimal";
  if (score >= 50) return "Good";
  if (score >= 30) return "Fair";
  return "Basic";
}
```

Change the numbers to raise or lower the bar for each tier.

---

## 6. Example Calculation

### Scenario

A male user logs the following for one day:
- 200g Chicken Breast (cooked)
- 150g Spinach
- 200g Brown Rice

No supplements taken.

### Step 1: Look Up Micronutrients

From `ingredients.json`, the system calculates contributions (nutrient_per_100g × grams / 100):

| Nutrient | Chicken (200g) | Spinach (150g) | Brown Rice (200g) | **Total** | **Target** |
|---|---|---|---|---|---|
| Iron (mg) | 1.4 | 4.05 | 1.6 | **7.05** | 8.7 |
| Calcium (mg) | 22 | 148.5 | 20 | **190.5** | 700 |
| Vitamin D (µg) | 0.2 | 0 | 0 | **0.2** | 10 |
| Magnesium (mg) | 54 | 118.5 | 86 | **258.5** | 300 |
| Zinc (mg) | 1.8 | 0.75 | 2.4 | **4.95** | 9.5 |
| Vitamin C (mg) | 0 | 42 | 0 | **42** | 40 |

*(Showing 6 of 12 nutrients for brevity)*

### Step 2: Calculate Adequacy (capped at 1.0)

| Nutrient | Intake / Target | Adequacy (capped) |
|---|---|---|
| Iron | 7.05 / 8.7 = 0.81 | 0.81 |
| Calcium | 190.5 / 700 = 0.27 | 0.27 |
| Vitamin D | 0.2 / 10 = 0.02 | 0.02 |
| Magnesium | 258.5 / 300 = 0.86 | 0.86 |
| Zinc | 4.95 / 9.5 = 0.52 | 0.52 |
| Vitamin C | 42 / 40 = 1.05 | **1.0** ← capped |

### Step 3: Apply Weights

| Nutrient | Weight | Weight × Adequacy |
|---|---|---|
| Iron | 2.0 | 2.0 × 0.81 = 1.62 |
| Calcium | 2.0 | 2.0 × 0.27 = 0.54 |
| Vitamin D | 2.0 | 2.0 × 0.02 = 0.04 |
| Magnesium | 1.5 | 1.5 × 0.86 = 1.29 |
| Zinc | 1.5 | 1.5 × 0.52 = 0.78 |
| Vitamin C | 1.0 | 1.0 × 1.0 = 1.0 |

### Step 4: Calculate Final Score

```
Sum of (weight × adequacy) = 1.62 + 0.54 + 0.04 + 1.29 + 0.78 + 1.0 + ... (remaining 6 nutrients)
Sum of weights             = 2.0 + 2.0 + 2.0 + 1.5 + 1.5 + 1.0 + ... (remaining 6 nutrients)

Full sum of weights = 2.0 + 2.0 + 2.0 + 1.5 + 1.5 + 1.0 + 1.0 + 1.0 + 1.0 + 1.0 + 1.0 + 1.0 = 16.0

AMQS = round((sum_weighted_adequacy / 16.0) × 100)
```

### Step 5: Identify Gaps

The system sorts nutrients by adequacy (lowest first) and picks the top 3 as "gaps":
1. **Vitamin D** — 2% of target → suggests "Trout"
2. **Calcium** — 27% of target → suggests "Parmesan Cheese"
3. **Zinc** — 52% of target → suggests "Beef (Lean Mince)"

These suggestions come from ranking all foods in `ingredients.json` by a combined score of nutrient density and commonality (`commonScore`).

### Step 6: Assign Tier

If the final score is 38, the tier is **Fair** (30–49 range).

---

## Summary

The AMQS system is designed to be:
- **Transparent** — users can see exactly which nutrients are low and why
- **Actionable** — each gap comes with a specific food suggestion
- **Athlete-tuned** — weights reflect the nutrients that matter most for active people
- **Easy to modify** — all configuration lives in a single array in `server/lib/amqs.ts`
