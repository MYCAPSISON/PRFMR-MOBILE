export const USERNAME_MIN_LENGTH = 3;
export const USERNAME_MAX_LENGTH = 20;
export const USERNAME_REGEX = /^[a-z0-9._]+$/;
export const EMAIL_LIKE_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const RESERVED_USERNAMES = new Set([
  "admin",
  "support",
  "team",
  "api",
  "root",
  "help",
  "billing",
  "contact",
  "prfmr",
  "system",
  "null",
  "undefined",
  "me",
  "moderator",
  "mod",
  "staff",
  "official",
  "www",
  "mail",
]);

export interface UsernameValidationResult {
  valid: boolean;
  error: string | null;
  normalized: string;
}

export function normalizeUsername(raw: string): string {
  return raw.toLowerCase().trim().replace(/\s/g, "");
}

export function validateUsername(raw: string): UsernameValidationResult {
  const normalized = normalizeUsername(raw);

  if (!normalized) {
    return { valid: false, error: "Username is required", normalized };
  }

  if (EMAIL_LIKE_REGEX.test(normalized)) {
    return { valid: false, error: "Please don't use an email — create a username instead.", normalized };
  }

  if (normalized.length < USERNAME_MIN_LENGTH) {
    return { valid: false, error: `Username must be at least ${USERNAME_MIN_LENGTH} characters`, normalized };
  }

  if (normalized.length > USERNAME_MAX_LENGTH) {
    return { valid: false, error: `Username must be ${USERNAME_MAX_LENGTH} characters or less`, normalized };
  }

  if (!USERNAME_REGEX.test(normalized)) {
    return { valid: false, error: '3–20 characters. Letters, numbers, ".", "_" only.', normalized };
  }

  if (/^[^a-z]/.test(normalized)) {
    return { valid: false, error: "Username must start with a letter", normalized };
  }

  if (/\.\./.test(normalized)) {
    return { valid: false, error: "Username cannot contain consecutive dots", normalized };
  }

  if (normalized.endsWith(".")) {
    return { valid: false, error: "Username cannot end with a dot", normalized };
  }

  if (RESERVED_USERNAMES.has(normalized)) {
    return { valid: false, error: "This username is reserved", normalized };
  }

  return { valid: true, error: null, normalized };
}
