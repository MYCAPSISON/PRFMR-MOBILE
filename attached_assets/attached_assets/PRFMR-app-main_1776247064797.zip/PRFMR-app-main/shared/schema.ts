 import { pgTable, text, serial, integer, boolean, date, real, timestamp, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { validateUsername } from "./username-validation";

export const SOURCE_ALLOWLIST = [
  "ig", "tiktok", "reddit", "discord", "gym", "uni",
  "friend", "google", "facebook", "sideproject", "other", "unknown",
] as const;

export type TrafficSource = typeof SOURCE_ALLOWLIST[number];

export function normalizeSource(raw: string | null | undefined): TrafficSource {
  if (!raw) return "unknown";
  const cleaned = raw.toLowerCase().trim();
  return SOURCE_ALLOWLIST.includes(cleaned as TrafficSource) ? (cleaned as TrafficSource) : "unknown";
}

export const usersAuth = pgTable("users_auth", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash"),
  emailVerified: boolean("email_verified").notNull().default(false),
  emailVerifiedAt: timestamp("email_verified_at"),
  provider: text("provider").notNull().default("local"),
  providerUserId: text("provider_user_id"),
  source: text("source").notNull().default("unknown"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("users_auth_email_idx").on(table.email),
  uniqueIndex("users_auth_username_idx").on(table.username),
]);

export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }).unique("email_verification_tokens_user_id_key"),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("push_subscriptions_endpoint_idx").on(table.endpoint),
]);

export type PushSubscription = typeof pushSubscriptions.$inferSelect;
export type InsertPushSubscription = typeof pushSubscriptions.$inferInsert;

export const insertAuthUserSchema = createInsertSchema(usersAuth).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true,
  emailVerified: true,
  emailVerifiedAt: true,
  passwordHash: true,
  provider: true,
  providerUserId: true,
  source: true,
}).extend({
  email: z.string().email().transform(s => s.toLowerCase()),
  username: z.string().transform(s => {
    const result = validateUsername(s);
    return result.normalized;
  }).refine(s => validateUsername(s).valid, {
    message: "Invalid username format",
  }),
  password: z.string().min(8).regex(/^(?=.*[a-zA-Z])(?=.*\d)/, "Password must contain at least 1 letter and 1 number"),
});

export type AuthUser = typeof usersAuth.$inferSelect;
export type InsertAuthUser = z.infer<typeof insertAuthUserSchema>;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  authUserId: integer("auth_user_id").references(() => usersAuth.id),
  source: text("source").notNull().default("unknown"),
  // Onboarding fields
  age: integer("age"),
  gender: text("gender"), // 'male', 'female'
  height: integer("height"), // cm
  currentWeight: real("current_weight"), // kg
  activityLevel: text("activity_level"), // 'sedentary', 'light', 'moderate', 'active', 'very_active'
  goal: text("goal"), // 'fat_loss' | 'maintenance' | 'weight_gain'
  experienceLevel: text("experience_level"), // 'beginner', 'intermediate', 'advanced'
  // Calculated Targets
  targetCalories: integer("target_calories"),
  targetProtein: integer("target_protein"),
  targetCarbs: integer("target_carbs"),
  targetFat: integer("target_fat"),
  // Body composition (optional — used for FFM-based EA calculation)
  bodyFatPct: real("body_fat_pct"), // 0–1 decimal (e.g. 0.15 = 15%)
  // Profile
  profilePhotoUrl: text("profile_photo_url"),
  usernameChangedAt: timestamp("username_changed_at"),
});

export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  weight: real("weight"),
  calories: integer("calories").default(0),
  protein: integer("protein").default(0),
  carbs: integer("carbs").default(0),
  fat: integer("fat").default(0),
  fibre: integer("fibre").default(0),
});

export const mealEnum = ["breakfast", "lunch", "dinner", "snack"] as const;
export type MealType = typeof mealEnum[number];

export const foodEntries = pgTable("food_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  name: text("name").notNull(),
  grams: integer("grams").default(100),
  calories: integer("calories").notNull(),
  protein: integer("protein").notNull(),
  carbs: integer("carbs").notNull(),
  fat: integer("fat").notNull(),
  fibre: integer("fibre").default(0),
  meal: text("meal").notNull().default("lunch"), // breakfast, lunch, dinner, snack
  snackIndex: integer("snack_index"), // Only used when meal='snack', null otherwise
  // OFF barcode tracking fields
  sourceType: text("source_type").notNull().default("manual"), // 'manual'|'off'|'ingredient'
  offBarcode: text("off_barcode"), // Barcode if from OFF scan
  ingredientIndex: integer("ingredient_index"), // Index into ingredients.json for AMQS
  macroSource: text("macro_source").notNull().default("ingredient"), // 'off'|'ingredient'|'mixed'
  microSource: text("micro_source").notNull().default("none"), // 'ingredient'|'none'
  enteredBasis: text("entered_basis"), // 'raw'|'cooked'|null (null = legacy/not applicable)
  normalizedGrams: integer("normalized_grams"), // grams in canonical basis for nutrition calc
  yieldFactorUsed: real("yield_factor_used"), // cooked yield factor used for conversion
});

export const weights = pgTable("weights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  weight: real("weight").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertLogSchema = createInsertSchema(logs).omit({ id: true });
export const insertFoodEntrySchema = createInsertSchema(foodEntries).omit({ id: true });
export const insertWeightSchema = createInsertSchema(weights).omit({ id: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type FoodEntry = typeof foodEntries.$inferSelect;
export type InsertFoodEntry = z.infer<typeof insertFoodEntrySchema>;
export type Weight = typeof weights.$inferSelect;
export type InsertWeight = z.infer<typeof insertWeightSchema>;

// Onboarding input schema
export const onboardingSchema = insertUserSchema.pick({
  age: true,
  gender: true,
  height: true,
  currentWeight: true,
  activityLevel: true,
  experienceLevel: true,
  goal: true,
});

export type OnboardingData = z.infer<typeof onboardingSchema>;

// Supplement Catalog (predefined supplements with micronutrient data)
export const supplementCatalog = pgTable("supplement_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  defaultUnit: text("default_unit").notNull(), // mg, mcg, IU, g
  microsPerUnit: jsonb("micros_per_unit").notNull().default({}), // JSON object mapping nutrient keys to amounts
  notes: text("notes"),
});

// Supplement Tracker Tables
export const supplements = pgTable("supplements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  brand: text("brand"),
  form: text("form"), // pill, capsule, powder, liquid, etc.
  notes: text("notes"),
  catalogId: integer("catalog_id"), // FK to supplement_catalog, null for custom
  doseAmount: real("dose_amount"), // e.g. 25
  doseUnit: text("dose_unit"), // e.g. mcg, mg, IU
  reminderEnabled: boolean("reminder_enabled").default(false),
  reminderTime: text("reminder_time"), // HH:MM e.g. "08:00"
});

// Daily supplement intake tracking (per slot: stackId + reminderId + supplementId + date)
export const supplementIntakes = pgTable("supplement_intakes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
  stackId: integer("stack_id"), // null for standalone supplements
  reminderId: integer("reminder_id"), // null for standalone supplements
  date: text("date").notNull(), // YYYY-MM-DD
  taken: boolean("taken").notNull().default(true),
  takenAt: text("taken_at"), // ISO timestamp
});

export const supplementStacks = pgTable("supplement_stacks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
});

export const stackSupplements = pgTable("stack_supplements", {
  id: serial("id").primaryKey(),
  stackId: integer("stack_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
});

export const daysOfWeekEnum = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;
export type DayOfWeek = typeof daysOfWeekEnum[number];

export const stackReminders = pgTable("stack_reminders", {
  id: serial("id").primaryKey(),
  stackId: integer("stack_id").notNull(),
  time: text("time").notNull(), // HH:MM format
  daysOfWeek: text("days_of_week").notNull(), // JSON array of days
  enabled: boolean("enabled").notNull().default(true),
});

export const supplementLogs = pgTable("supplement_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
  stackId: integer("stack_id"),
  date: text("date").notNull(), // YYYY-MM-DD
  time: text("time"), // HH:MM
  taken: boolean("taken").notNull().default(true),
});

export const userDisclaimerAcceptance = pgTable("user_disclaimer_acceptance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  disclaimerType: text("disclaimer_type").notNull(), // 'supplement_reminders'
  acceptedAt: text("accepted_at").notNull(), // ISO timestamp
});

// ========== SAVED MEALS (MEAL TEMPLATES) ==========

export const mealTemplates = pgTable("meal_templates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  defaultMeal: text("default_meal"), // breakfast|lunch|dinner|snack (optional)
  createdAt: text("created_at").notNull(),
});

export const mealTemplateItems = pgTable("meal_template_items", {
  id: serial("id").primaryKey(),
  templateId: integer("template_id").notNull(),
  name: text("name").notNull(),
  grams: integer("grams").default(100),
  calories: integer("calories").notNull(),
  protein: integer("protein").notNull(),
  carbs: integer("carbs").notNull(),
  fat: integer("fat").notNull(),
  fibre: integer("fibre").default(0),
  sourceType: text("source_type").notNull().default("manual"),
  ingredientIndex: integer("ingredient_index"),
  offBarcode: text("off_barcode"),
  macroSource: text("macro_source").notNull().default("manual"),
  microSource: text("micro_source").notNull().default("none"),
  sortOrder: integer("sort_order").notNull().default(0),
});

// Insert schemas
export const insertMealTemplateSchema = createInsertSchema(mealTemplates).omit({ id: true });
export const insertMealTemplateItemSchema = createInsertSchema(mealTemplateItems).omit({ id: true });

export const insertSupplementCatalogSchema = createInsertSchema(supplementCatalog).omit({ id: true });
export const insertSupplementSchema = createInsertSchema(supplements).omit({ id: true });
export const insertSupplementIntakeSchema = createInsertSchema(supplementIntakes).omit({ id: true });
export const insertSupplementStackSchema = createInsertSchema(supplementStacks).omit({ id: true });
export const insertStackSupplementSchema = createInsertSchema(stackSupplements).omit({ id: true });
export const insertStackReminderSchema = createInsertSchema(stackReminders).omit({ id: true });
export const insertSupplementLogSchema = createInsertSchema(supplementLogs).omit({ id: true });
export const insertUserDisclaimerAcceptanceSchema = createInsertSchema(userDisclaimerAcceptance).omit({ id: true });

// Types
export type SupplementCatalogItem = typeof supplementCatalog.$inferSelect;
export type InsertSupplementCatalogItem = z.infer<typeof insertSupplementCatalogSchema>;
export type Supplement = typeof supplements.$inferSelect;
export type InsertSupplement = z.infer<typeof insertSupplementSchema>;
export type SupplementIntake = typeof supplementIntakes.$inferSelect;
export type InsertSupplementIntake = z.infer<typeof insertSupplementIntakeSchema>;
export type SupplementStack = typeof supplementStacks.$inferSelect;
export type InsertSupplementStack = z.infer<typeof insertSupplementStackSchema>;
export type StackSupplement = typeof stackSupplements.$inferSelect;
export type InsertStackSupplement = z.infer<typeof insertStackSupplementSchema>;
export type StackReminder = typeof stackReminders.$inferSelect;
export type InsertStackReminder = z.infer<typeof insertStackReminderSchema>;
export type SupplementLog = typeof supplementLogs.$inferSelect;
export type InsertSupplementLog = z.infer<typeof insertSupplementLogSchema>;
export type UserDisclaimerAcceptance = typeof userDisclaimerAcceptance.$inferSelect;
export type InsertUserDisclaimerAcceptance = z.infer<typeof insertUserDisclaimerAcceptanceSchema>;
export type MealTemplate = typeof mealTemplates.$inferSelect;
export type InsertMealTemplate = z.infer<typeof insertMealTemplateSchema>;
export type MealTemplateItem = typeof mealTemplateItems.$inferSelect;
export type InsertMealTemplateItem = z.infer<typeof insertMealTemplateItemSchema>;

// ========== TRAINING LOG TABLES ==========

// Time of day enum for workout sessions
export const timeOfDayEnum = ["morning", "afternoon", "evening"] as const;
export type TimeOfDay = typeof timeOfDayEnum[number];

// Intensity enum
export const intensityEnum = ["light", "moderate", "vigorous"] as const;
export type Intensity = typeof intensityEnum[number];

// Exercise categories
export const exerciseCategoryEnum = ["push", "pull", "legs", "core", "full_body", "cardio"] as const;
export type ExerciseCategory = typeof exerciseCategoryEnum[number];

// Equipment types
export const equipmentEnum = ["barbell", "dumbbell", "machine", "bodyweight", "cable", "kettlebell", "bands", "other"] as const;
export type Equipment = typeof equipmentEnum[number];

// A) Exercise Catalog - predefined common lifts
export const exerciseCatalog = pgTable("exercise_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(), // push/pull/legs/core/full_body
  equipment: text("equipment").notNull(), // barbell/dumbbell/machine/bodyweight/cable
  primaryMuscle: text("primary_muscle").notNull(),
  isCommon: boolean("is_common").notNull().default(true),
});

// B) Workout Sessions - container for a workout
export const workoutSessions = pgTable("workout_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  timeOfDay: text("time_of_day").notNull(), // morning/afternoon/evening
  title: text("title"),
  notes: text("notes"),
  durationMinutes: integer("duration_minutes"),
  intensity: text("intensity"), // light/moderate/vigorous
  estimatedMet: real("estimated_met"),
  estimatedKcal: real("estimated_kcal").default(0),
  isPlanned: boolean("is_planned").notNull().default(false),
  trainingBlockId: integer("training_block_id"),
});

// C) Workout Exercises - strength items inside a session
export const workoutExercises = pgTable("workout_exercises", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  exerciseCatalogId: integer("exercise_catalog_id"), // nullable for custom exercises
  name: text("name").notNull(), // always store name for display
  orderIndex: integer("order_index").notNull().default(0),
  intensity: text("intensity").default("moderate"), // light/moderate/vigorous for calorie estimation
  durationMinutes: integer("duration_minutes"), // optional manual duration
  estimatedKcal: real("estimated_kcal").default(0), // calculated calories
});

// D) Workout Sets - individual sets for an exercise
export const workoutSets = pgTable("workout_sets", {
  id: serial("id").primaryKey(),
  workoutExerciseId: integer("workout_exercise_id").notNull(),
  setIndex: integer("set_index").notNull(),
  reps: integer("reps").notNull(),
  weightKg: real("weight_kg"),
  rpe: real("rpe"), // Rate of Perceived Exertion (1-10)
  restSeconds: integer("rest_seconds"),
  tempo: text("tempo"), // e.g., "3-1-2-0"
  durationSeconds: integer("duration_seconds"), // for timed sets
});

// E) Activity Catalog - sports/cardio with MET values
export const activityCatalog = pgTable("activity_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  intensity: text("intensity").notNull(), // light/moderate/vigorous
  metValue: real("met_value").notNull(),
});

// F) Session Activities - sports/cardio items inside a session
export const sessionActivities = pgTable("session_activities", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  activityCatalogId: integer("activity_catalog_id"), // nullable for custom
  name: text("name").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  intensity: text("intensity").notNull(),
  metValue: real("met_value").notNull(),
  estimatedKcal: real("estimated_kcal").default(0),
  activityType: text("activity_type").default("cardio"), // "cardio" | "lifting"
  sessionRpe: real("session_rpe"),
  bodyRegion: text("body_region"), // "upper" | "lower" | "full"
  trainingLoadScore: real("training_load_score"),
  rpe: real("rpe"), // universal effort rating 1–10 (all activity types)
});

// Insert schemas for training tables
export const insertExerciseCatalogSchema = createInsertSchema(exerciseCatalog).omit({ id: true });
export const insertWorkoutSessionSchema = createInsertSchema(workoutSessions).omit({ id: true });
export const insertWorkoutExerciseSchema = createInsertSchema(workoutExercises).omit({ id: true });
export const insertWorkoutSetSchema = createInsertSchema(workoutSets).omit({ id: true });
export const insertActivityCatalogSchema = createInsertSchema(activityCatalog).omit({ id: true });
export const insertSessionActivitySchema = createInsertSchema(sessionActivities).omit({ id: true });

// Types for training tables
export type ExerciseCatalogItem = typeof exerciseCatalog.$inferSelect;
export type InsertExerciseCatalogItem = z.infer<typeof insertExerciseCatalogSchema>;
export type WorkoutSession = typeof workoutSessions.$inferSelect;
export type InsertWorkoutSession = z.infer<typeof insertWorkoutSessionSchema>;
export type WorkoutExercise = typeof workoutExercises.$inferSelect;
export type InsertWorkoutExercise = z.infer<typeof insertWorkoutExerciseSchema>;
export type WorkoutSet = typeof workoutSets.$inferSelect;
export type InsertWorkoutSet = z.infer<typeof insertWorkoutSetSchema>;
export type ActivityCatalogItem = typeof activityCatalog.$inferSelect;
export type InsertActivityCatalogItem = z.infer<typeof insertActivityCatalogSchema>;
export type SessionActivity = typeof sessionActivities.$inferSelect;
export type InsertSessionActivity = z.infer<typeof insertSessionActivitySchema>;

// ========== OFF (OPEN FOOD FACTS) BARCODE MAPPING ==========

// Match confidence enum
export const matchConfidenceEnum = ["high", "medium", "low"] as const;
export type MatchConfidence = typeof matchConfidenceEnum[number];

// Match method enum
export const matchMethodEnum = ["exact", "synonym", "fuzzy", "user_selected"] as const;
export type MatchMethod = typeof matchMethodEnum[number];

// Source type for food entries
export const sourceTypeEnum = ["manual", "off", "ingredient"] as const;
export type SourceType = typeof sourceTypeEnum[number];

// Macro/micro source for food entries
export const macroSourceEnum = ["off", "ingredient", "mixed"] as const;
export type MacroSource = typeof macroSourceEnum[number];
export const microSourceEnum = ["ingredient", "none"] as const;
export type MicroSource = typeof microSourceEnum[number];

// OFF Product Mappings - links barcodes to internal ingredients
export const offProductMappings = pgTable("off_product_mappings", {
  id: serial("id").primaryKey(),
  barcode: text("barcode").notNull().unique(),
  offName: text("off_name").notNull(),
  offBrand: text("off_brand"),
  offCategories: text("off_categories"),
  ingredientIndex: integer("ingredient_index").notNull(), // Index into ingredients.json
  ingredientName: text("ingredient_name").notNull(), // Cached for display
  matchConfidence: text("match_confidence").notNull(), // 'high'|'medium'|'low'
  matchMethod: text("match_method").notNull(), // 'exact'|'synonym'|'fuzzy'|'user_selected'
  verifiedByUser: boolean("verified_by_user").notNull().default(false),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertOffProductMappingSchema = createInsertSchema(offProductMappings).omit({ id: true, updatedAt: true });
export type OffProductMapping = typeof offProductMappings.$inferSelect;
export type InsertOffProductMapping = z.infer<typeof insertOffProductMappingSchema>;

// ========== USERNAME CHANGES (Rate Limiting) ==========

export const usernameChanges = pgTable("username_changes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }),
  oldUsername: text("old_username").notNull(),
  newUsername: text("new_username").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type UsernameChange = typeof usernameChanges.$inferSelect;

// ========== CUSTOM FOODS (User's "My Database") ==========

export const customFoods = pgTable("custom_foods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  brand: text("brand"),
  servingSizeG: integer("serving_size_g"),
  kcalPer100g: integer("kcal_per_100g").notNull(),
  proteinPer100g: real("protein_per_100g"),
  carbsPer100g: real("carbs_per_100g"),
  fatPer100g: real("fat_per_100g"),
  fibrePer100g: real("fibre_per_100g"),
  saltPer100g: real("salt_per_100g"),
  sugarPer100g: real("sugar_per_100g"),
  barcode: text("barcode"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCustomFoodSchema = createInsertSchema(customFoods).omit({ id: true, createdAt: true, updatedAt: true });
export type CustomFood = typeof customFoods.$inferSelect;
export type InsertCustomFood = z.infer<typeof insertCustomFoodSchema>;

export const inviteRequests = pgTable("invite_requests", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  status: text("status").notNull().default("pending"),
  source: text("source").notNull().default("unknown"),
  ip: text("ip"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type InviteRequest = typeof inviteRequests.$inferSelect;

export const invites = pgTable("invites", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  tokenHash: text("token_hash").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  usedByUserId: integer("used_by_user_id").references(() => usersAuth.id),
  maxUses: integer("max_uses").notNull().default(1),
  uses: integer("uses").notNull().default(0),
});

export type Invite = typeof invites.$inferSelect;

export const betaWaitlist = pgTable("beta_waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  source: text("source"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type BetaWaitlistEntry = typeof betaWaitlist.$inferSelect;

export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersAuth.id, { onDelete: "cascade" }),
  category: text("category").notNull(),
  message: text("message").notNull(),
  route: text("route"),
  userAgent: text("user_agent"),
  viewport: text("viewport"),
  appVersion: text("app_version"),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFeedbackSchema = createInsertSchema(feedback).omit({ id: true, createdAt: true, status: true }).extend({
  category: z.enum(["bug", "feature", "question", "other"]),
  message: z.string().min(10, "Message must be at least 10 characters"),
  route: z.string().optional(),
  userAgent: z.string().optional(),
  viewport: z.string().optional(),
  appVersion: z.string().optional(),
});
export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;

export const feedbackAttachments = pgTable("feedback_attachments", {
  id: serial("id").primaryKey(),
  feedbackId: integer("feedback_id").notNull().references(() => feedback.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFeedbackAttachmentSchema = createInsertSchema(feedbackAttachments).omit({ id: true, createdAt: true });
export type FeedbackAttachment = typeof feedbackAttachments.$inferSelect;
export type InsertFeedbackAttachment = z.infer<typeof insertFeedbackAttachmentSchema>;

export const sleepLogs = pgTable("sleep_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(),
  hoursSlept: real("hours_slept").notNull(),
  sleepQuality: integer("sleep_quality"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("sleep_logs_user_date_idx").on(table.userId, table.date),
]);

export const insertSleepLogSchema = createInsertSchema(sleepLogs).omit({ id: true, createdAt: true, updatedAt: true });
export type SleepLog = typeof sleepLogs.$inferSelect;
export type InsertSleepLog = z.infer<typeof insertSleepLogSchema>;

export const weightCutPlans = pgTable("weight_cut_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currentWeight: real("current_weight").notNull(),
  targetWeight: real("target_weight").notNull(),
  fightDate: text("fight_date").notNull(),
  weighInTiming: text("weigh_in_timing").notNull().default("same_day"),
  manualTempReductionKg: real("manual_temp_reduction_kg"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertWeightCutPlanSchema = createInsertSchema(weightCutPlans).omit({ id: true, createdAt: true, updatedAt: true });
export type WeightCutPlan = typeof weightCutPlans.$inferSelect;
export type InsertWeightCutPlan = z.infer<typeof insertWeightCutPlanSchema>;

export const provisionalCheckins = pgTable("provisional_checkins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(),
  feelToday: text("feel_today").notNull(), // 'fresh' | 'okay' | 'tired'
  fueledToday: text("fueled_today").notNull(), // 'yes' | 'somewhat' | 'no'
  plannedIntensity: text("planned_intensity").notNull(), // 'light' | 'moderate' | 'hard'
  trainedYesterday: boolean("trained_yesterday"), // null = not asked / not applicable
  yesterdayTrainingIntensity: text("yesterday_training_intensity"), // 'light' | 'moderate' | 'hard' | null
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("provisional_checkins_user_date_idx").on(table.userId, table.date),
]);

export const insertProvisionalCheckinSchema = createInsertSchema(provisionalCheckins).omit({ id: true, createdAt: true, updatedAt: true }).extend({
  feelToday: z.enum(["fresh", "okay", "tired"]),
  fueledToday: z.enum(["yes", "somewhat", "no"]),
  plannedIntensity: z.enum(["light", "moderate", "hard"]),
  trainedYesterday: z.boolean().optional().nullable(),
  yesterdayTrainingIntensity: z.enum(["light", "moderate", "hard"]).optional().nullable(),
});
export type ProvisionalCheckin = typeof provisionalCheckins.$inferSelect;
export type InsertProvisionalCheckin = z.infer<typeof insertProvisionalCheckinSchema>;

export const restDayLogs = pgTable("rest_day_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("rest_day_logs_user_date_idx").on(table.userId, table.date),
]);

export type RestDayLog = typeof restDayLogs.$inferSelect;

export const trainingLoadOverrides = pgTable("training_load_overrides", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(),
  overrideClassification: text("override_classification").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  uniqueIndex("training_load_overrides_user_date_idx").on(table.userId, table.date),
]);

export type TrainingLoadOverride = typeof trainingLoadOverrides.$inferSelect;

// ─── Training Block Planner ───────────────────────────────────────────────────

/** Activity template stored in a block day. Drives session_activities on commit. */
export interface BlockActivityTemplate {
  activityType: "cardio" | "lifting";
  name: string;
  durationMinutes: number;
  rpe?: number;           // 1–10 effort
  intensity?: string;     // light | moderate | vigorous (fallback when no RPE)
  metValue?: number;      // from catalog (cardio only)
  bodyRegion?: string;    // upper | lower | full (lifting only)
  activityCatalogId?: number;
  slot?: "morning" | "afternoon" | "evening" | "night"; // time-of-day slot
}

export const trainingBlocks = pgTable("training_blocks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  startDate: text("start_date").notNull(), // YYYY-MM-DD
  weekCount: integer("week_count").notNull(),
  status: text("status").notNull().default("active"), // active | archived
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const trainingBlockDays = pgTable("training_block_days", {
  id: serial("id").primaryKey(),
  blockId: integer("block_id").notNull().references(() => trainingBlocks.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(), // 0 = Mon … 6 = Sun
  plannedLoad: text("planned_load").notNull().default("rest"), // computed from activities
  activities: jsonb("activities").$type<BlockActivityTemplate[]>().notNull().default([]),
  notes: text("notes"),
});

export const insertTrainingBlockSchema = createInsertSchema(trainingBlocks).omit({ id: true, createdAt: true, status: true });
export const insertTrainingBlockDaySchema = createInsertSchema(trainingBlockDays).omit({ id: true });

export type TrainingBlock = typeof trainingBlocks.$inferSelect;
export type InsertTrainingBlock = z.infer<typeof insertTrainingBlockSchema>;
export type TrainingBlockDay = typeof trainingBlockDays.$inferSelect;
export type InsertTrainingBlockDay = z.infer<typeof insertTrainingBlockDaySchema>;
