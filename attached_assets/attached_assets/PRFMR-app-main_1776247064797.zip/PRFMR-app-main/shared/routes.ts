import { z } from 'zod';
import { insertUserSchema, insertLogSchema, insertFoodEntrySchema, users, logs, foodEntries, onboardingSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  user: {
    get: {
      method: 'GET' as const,
      path: '/api/user/:username',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/user',
      input: z.object({ username: z.string() }),
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
      },
    },
    onboard: {
        method: 'POST' as const,
        path: '/api/user/:username/onboard',
        input: onboardingSchema,
        responses: {
            200: z.custom<typeof users.$inferSelect>(),
        }
    }
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs/:username',
      responses: {
        200: z.array(z.custom<typeof logs.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/logs',
      input: insertLogSchema,
      responses: {
        201: z.custom<typeof logs.$inferSelect>(),
      },
    },
    update: { 
        method: 'PATCH' as const,
        path: '/api/logs/:id',
        input: insertLogSchema.partial(),
        responses: {
            200: z.custom<typeof logs.$inferSelect>(),
            404: errorSchemas.notFound,
        }
    }
  },
  food: {
    list: {
      method: 'GET' as const,
      path: '/api/food/:username/:date',
      responses: {
        200: z.array(z.custom<typeof foodEntries.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/food',
      input: insertFoodEntrySchema,
      responses: {
        201: z.custom<typeof foodEntries.$inferSelect>(),
      }
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/food/:id',
      responses: {
        204: z.null(),
        404: errorSchemas.notFound,
      }
    }
  },
  me: {
    food: {
      list: { method: 'GET' as const, path: '/api/me/food/:date' },
      range: { method: 'GET' as const, path: '/api/me/food-entries/range' },
    },
    logs: {
      list: { method: 'GET' as const, path: '/api/me/logs' },
    },
    weights: {
      range: { method: 'GET' as const, path: '/api/me/weights/range' },
    },
    supplements: {
      list: { method: 'GET' as const, path: '/api/me/supplements' },
    },
    stacks: {
      list: { method: 'GET' as const, path: '/api/me/stacks' },
      scheduled: { method: 'GET' as const, path: '/api/me/stacks/scheduled' },
    },
    reminders: {
      list: { method: 'GET' as const, path: '/api/me/reminders' },
      today: { method: 'GET' as const, path: '/api/me/reminders/today' },
    },
    supplementLogs: {
      list: { method: 'GET' as const, path: '/api/me/supplement-logs/:date' },
    },
    supplementIntakes: {
      byDate: { method: 'GET' as const, path: '/api/me/supplement-intakes/:date' },
      range: { method: 'GET' as const, path: '/api/me/supplement-intakes/:startDate/:endDate' },
    },
    supplementMicros: {
      byDate: { method: 'GET' as const, path: '/api/me/supplement-micros/:date' },
      range: { method: 'GET' as const, path: '/api/me/supplement-micros-range/:startDate/:endDate' },
    },
    amqs: {
      micros: { method: 'GET' as const, path: '/api/me/amqs/micros/:date' },
      score: { method: 'GET' as const, path: '/api/me/amqs/score/:date' },
      scoreRange: { method: 'GET' as const, path: '/api/me/amqs/score-range/:startDate/:endDate' },
    },
    training: {
      summary: { method: 'GET' as const, path: '/api/me/training/summary/:date' },
    },
    disclaimer: {
      get: { method: 'GET' as const, path: '/api/me/disclaimer/:type' },
    },
    profilePhoto: {
      update: { method: 'PUT' as const, path: '/api/me/profile-photo' },
    },
    username: {
      update: { method: 'PATCH' as const, path: '/api/me/username' },
      available: { method: 'GET' as const, path: '/api/username/available' },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
