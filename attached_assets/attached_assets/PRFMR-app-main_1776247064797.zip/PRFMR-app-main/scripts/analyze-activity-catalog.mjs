import { readFileSync } from "fs";
import { execSync } from "child_process";

// ─── 1. PARSE COMPENDIUM FROM EXTRACTED TEXT ──────────────────────────────────

const EXERCISE_CATEGORIES = new Set([
  "bicycling",
  "conditioning exercise",
  "running",
  "sports",
  "swimming and water activities",
  "walking",
  "winter activities",
  "water activities",
  "racket sports",
  "combat sports",
  "dancing",
]);

function parseCompendium(filePath) {
  const text = readFileSync(filePath, "utf8");
  const lines = text.split("\n");

  const activities = [];
  const linePattern = /^(.+?)\s{2,}(\d{5})\s+(\d+\.?\d*)\s{2,}(.+)$/;

  let currentCategory = null;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const match = line.match(linePattern);
    if (match) {
      const category = match[1].trim();
      const met = parseFloat(match[3]);
      const description = match[4].trim();

      if (category && category !== "Major Heading") {
        currentCategory = category;
      }

      const catLower = (currentCategory || category || "").toLowerCase();
      if ([...EXERCISE_CATEGORIES].some((c) => catLower.includes(c))) {
        activities.push({
          name: description,
          met,
          category: currentCategory || category,
        });
      }
    } else if (trimmed && !/^\d{5}$/.test(trimmed) && !/^\d+\.?\d*$/.test(trimmed)) {
      // Could be a wrapped description line or a category header — skip for now
    }
  }

  return activities;
}

// ─── 2. LOAD APP CATALOG FROM DB ─────────────────────────────────────────────

function loadAppCatalog() {
  const result = execSync(
    `psql "$DATABASE_URL" -t -A -F'|' -c "SELECT name, met_value FROM activity_catalog ORDER BY name;"`,
    { encoding: "utf8" }
  );
  return result
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((line) => {
      const [name, met] = line.split("|");
      return { name: name.trim(), met: parseFloat(met) || 0 };
    });
}

// ─── 3. TEXT NORMALISATION ────────────────────────────────────────────────────

const SYNONYMS = [
  [/\brunning\b/g, "run"],
  [/\bcycling\b/g, "bike"],
  [/\bbicycling\b/g, "bike"],
  [/\bbicycle\b/g, "bike"],
  [/\bweightlifting\b/g, "weight training"],
  [/\bweight lifting\b/g, "weight training"],
  [/\bresistance training\b/g, "weight training"],
  [/\bstrength training\b/g, "weight training"],
  [/\bcardio\b/g, "aerobic"],
  [/\baerobics\b/g, "aerobic"],
  [/\bstationary bike\b/g, "stationary bike"],
  [/\bergometer\b/g, "machine"],
  [/\btrail run\b/g, "trail run"],
  [/\bhiit\b/g, "high intensity interval"],
  [/\bjump rope\b/g, "jump rope"],
  [/\bjumping rope\b/g, "jump rope"],
  [/\bmartial arts\b/g, "martial arts"],
  [/\bjiu.jitsu\b/g, "jiu jitsu"],
];

function normalise(name) {
  let n = name.toLowerCase();
  n = n.replace(/[^a-z0-9\s]/g, " "); // strip punctuation
  n = n.replace(/\s+/g, " ").trim();
  for (const [from, to] of SYNONYMS) n = n.replace(from, to);
  return n;
}

// ─── 4. LEVENSHTEIN DISTANCE ─────────────────────────────────────────────────

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] =
        a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
  return dp[m][n];
}

function similarity(a, b) {
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - levenshtein(a, b) / maxLen;
}

// ─── 5. MATCH ─────────────────────────────────────────────────────────────────

const MATCH_THRESHOLD = 0.55;

function findBestMatch(compNorm, appActivities) {
  let best = null;
  let bestScore = 0;

  for (const app of appActivities) {
    const appNorm = normalise(app.name);

    // Exact match
    if (appNorm === compNorm) return { app, score: 1.0, type: "exact" };

    // One contains the other
    if (appNorm.includes(compNorm) || compNorm.includes(appNorm)) {
      const score = 0.85;
      if (score > bestScore) { best = app; bestScore = score; }
      continue;
    }

    // Token overlap
    const aTokens = new Set(appNorm.split(" ").filter((t) => t.length > 2));
    const cTokens = new Set(compNorm.split(" ").filter((t) => t.length > 2));
    const overlap = [...aTokens].filter((t) => cTokens.has(t)).length;
    const unionSize = new Set([...aTokens, ...cTokens]).size;
    const jaccard = unionSize > 0 ? overlap / unionSize : 0;

    // Levenshtein
    const lev = similarity(appNorm, compNorm);

    const score = Math.max(jaccard * 0.7 + lev * 0.3, lev);
    if (score > bestScore) { best = app; bestScore = score; }
  }

  if (bestScore >= MATCH_THRESHOLD) return { app: best, score: bestScore, type: "fuzzy" };
  return null;
}

// ─── 6. RUN ANALYSIS ─────────────────────────────────────────────────────────

const compendiumPath = "/tmp/compendium_layout.txt";
const compendium = parseCompendium(compendiumPath);
const appCatalog = loadAppCatalog();

const matched = [];
const missingInApp = [];
const appMatchedIds = new Set();

for (const comp of compendium) {
  const compNorm = normalise(comp.name);
  const match = findBestMatch(compNorm, appCatalog);

  if (match) {
    appMatchedIds.add(match.app.name);
    matched.push({
      compName: comp.name,
      appName: match.app.name,
      metCompendium: comp.met,
      metApp: match.app.met,
      metDiff: Math.abs(comp.met - match.app.met),
      similarityScore: Math.round(match.score * 100),
      category: comp.category,
      matchType: match.type,
    });
  } else {
    missingInApp.push(comp);
  }
}

const missingInCompendium = appCatalog.filter((a) => !appMatchedIds.has(a.name));
const metMismatches = matched.filter((m) => m.metDiff > 1.0);

// ─── 7. OUTPUT REPORT ─────────────────────────────────────────────────────────

const report = {
  summary: {
    totalCompendiumActivities: compendium.length,
    totalAppActivities: appCatalog.length,
    matched: matched.length,
    missingInApp: missingInApp.length,
    missingInCompendium: missingInCompendium.length,
    metMismatches: metMismatches.length,
    coveragePct: Math.round((appMatchedIds.size / appCatalog.length) * 100),
  },
  matched,
  missingInApp,
  missingInCompendium,
  metMismatches: metMismatches.sort((a, b) => b.metDiff - a.metDiff),
};

// Human-readable summary
console.log("\n====================================================");
console.log("     ACTIVITY CATALOG vs 2024 COMPENDIUM REPORT");
console.log("====================================================\n");

const s = report.summary;
console.log(`Compendium activities (exercise/sport categories): ${s.totalCompendiumActivities}`);
console.log(`App activity catalog entries:                      ${s.totalAppActivities}`);
console.log(`Matched (fuzzy):                                   ${s.matched}`);
console.log(`App activities not found in Compendium:            ${s.missingInCompendium}`);
console.log(`Compendium activities not in app:                  ${s.missingInApp}`);
console.log(`MET mismatches (diff > 1.0):                       ${s.metMismatches}`);
console.log(`App catalog coverage (matched/total):              ${s.coveragePct}%`);

console.log("\n─── TOP 10 MISSING ACTIVITIES (Compendium → should add to app) ───\n");
// Deduplicate by picking unique activities per category, pick highest-impact by MET
const uniqueMissing = [];
const seenMissingNorm = new Set();
for (const m of missingInApp.sort((a, b) => b.met - a.met)) {
  const n = normalise(m.name).slice(0, 30);
  if (!seenMissingNorm.has(n)) {
    seenMissingNorm.add(n);
    uniqueMissing.push(m);
  }
}
uniqueMissing.slice(0, 10).forEach((m, i) => {
  console.log(`  ${i + 1}. [${m.category}] ${m.name} — MET ${m.met}`);
});

console.log("\n─── TOP 10 MET MISMATCHES (fix these in your catalog) ───\n");
report.metMismatches.slice(0, 10).forEach((m, i) => {
  const arrow = m.metApp < m.metCompendium ? "↑" : "↓";
  console.log(
    `  ${i + 1}. "${m.appName}" — App: ${m.metApp}  Compendium: ${m.metCompendium}  (diff ${arrow}${m.metDiff.toFixed(1)})`
  );
  console.log(`       Best match: "${m.compName}" [${m.category}]`);
});

console.log("\n─── APP ACTIVITIES WITH NO COMPENDIUM MATCH ───\n");
missingInCompendium.forEach((a, i) => {
  console.log(`  ${i + 1}. "${a.name}" — MET ${a.met} (check naming or custom entry)`);
});

console.log("\n─── MATCHED ACTIVITIES (all) ───\n");
matched
  .sort((a, b) => b.metDiff - a.metDiff)
  .slice(0, 20)
  .forEach((m) => {
    const flag = m.metDiff > 1 ? "⚠️ MET DIFF" : "✓";
    console.log(
      `  ${flag} "${m.appName}" ↔ "${m.compName}"  App:${m.metApp} vs Comp:${m.metCompendium}  (sim ${m.similarityScore}%)`
    );
  });

console.log("\n====================================================\n");
